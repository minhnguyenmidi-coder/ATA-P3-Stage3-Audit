# ATA P3 – STAGE 3 – R4 INDEPENDENT AUDIT FOLLOW-UP (R4F) – BÁO CÁO GỘP

Gói gốc: ATA_P3_STAGE3_R4_AUDIT_CORRECTION.zip (SHA-256 20b05cba1fe03a25c031c188194d6cff9596cd4b23941ccd61ef092d9bb969a4). Pine 0.3.8 / 0.3.9 KHÔNG đổi (SHA ở mục 7). Ký hiệu: FACT (đã kiểm bằng mã, có bằng chứng) · PARTIALLY VERIFIED · ASSUMPTION · HYPOTHESIS · RECOMMENDATION. Trạng thái test: PASS · FAIL · WRONG_REASON · VALIDATOR_CRASH · ENV_ERROR · BLOCKED · NOT TESTED (không gộp). Thuật ngữ: *fill* = khớp lệnh/vào lệnh; *fixture* = bộ dữ liệu mẫu cố định của test; *mutant* (đột biến) = bản mã bị cố ý làm sai một chỗ để xem test có bắt được không.

## 0. Kết luận ngắn

| Hạng mục | Trạng thái | Kết luận | Loại |
|---|---|---|---|
| HD-01 | FAIL gốc giữ nguyên → FAIL_DA_PHAN_LOAI | Lỗi ở TEST (fixture thiếu sự kiện STEP so với hợp đồng máy trạng thái thêm từ Stage 3 vòng 2). Validator đúng, không nới. Mã R3 = R4. | FACT |
| OT-05 | FAIL gốc giữ nguyên → FAIL_DA_PHAN_LOAI | Lỗi ở TEST (assertion trước F29) + 1 câu VĂN BẢN hợp đồng cũ mâu thuẫn trong docstring (đã sửa câu chữ). Hành vi R3 = R4, đúng hợp đồng ở cả 156 ca nến hỏng. | FACT |
| OT-06 | FAIL gốc giữ nguyên → FAIL_DA_PHAN_LOAI | Lỗi ở TEST (assertion trước F29) cho đúng kịch bản của test. NHƯNG khi kiểm ma trận phát hiện LỖI CODE thật cùng chủ đề (BUG-R4F-1: R2 vào lệnh tại/trước nến trigger khi nến kế có thời gian trùng/lùi) – có từ Stage 3 vòng 1, không do R4; đã sửa tối thiểu 1 dòng, có test tái hiện. | FACT |
| KD-REG-S3 | bộ 88: PASS 76 / FAIL 3 / BLOCKED 6 / NOT TESTED 3, exit 1 | Trạng thái bộ = FAIL_DA_PHAN_LOAI (KHÔNG phải PASS). Mã thoát điều phối = 3 (3 = chỉ còn FAIL đã phân loại theo sổ khai báo trước). | FACT |
| Chạy lại toàn bộ R4 | 42/42 test R4, 7 nhóm + R4F + S3 + KD đầy đủ | Tổng 7 trạng thái: {'PASS': 228, 'FAIL': 3, 'WRONG_REASON': 0, 'VALIDATOR_CRASH': 0, 'ENV_ERROR': 0, 'BLOCKED': 13, 'NOT TESTED': 4}. Không TIMEOUT, không output cũ, không bytecode. | FACT |
| Đột biến | 27 đột biến | {'KILLED_EXPECTED': 27} | FACT |
| Cách ly | ĐẠT | 1 file sửa (mo_phong_lenh.py) so với R4; file mới chỉ trong kiem_toan_r4f/; Pine đúng SHA; bằng chứng R4 không đổi. | FACT |

**Đề xuất đóng (RECOMMENDATION):** xem mục 11 – đủ 6 điều kiện của mục 11 đề bài; các giới hạn thị trường thật / token / replay đầy đủ vẫn BLOCKED / NOT TESTED và không bị tính là PASS.

## 1. Phương pháp điều tra (không mặc định là lỗi lịch sử)

- Đọc thân 3 test trong `shadow_eval/kiem_thu_stage3.py` (OT-05 dòng 206, OT-06 dòng 215, HD-01 dòng 418), fixture `B`, `S0`, `FLAT`, `EV0/SIG0/TR0/BO0`.
- Trích NGUYÊN VĂN các hàm đó bằng AST (bỏ decorator, không sửa thân) và chạy trên 4 thế hệ mã: Stage 3 vòng 1 (ATA_P3_Stage3_Audit_Correction.zip), vòng 2 (ATA_P3_Stage3_Correction_R2.zip), vòng 3 (ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION.zip = `_truoc_r4`), R4 trước sửa. SHA đoạn mã test giống hệt ở cả 4 thế hệ (FACT).
- Dựng ma trận ca với KỲ VỌNG suy từ hợp đồng (docstring `mo_phong_lenh` mục KẾT CỤC; `may_trang_thai` mục A/B), không suy từ mã giả lập.
- Công cụ: `kiem_toan_r4f/dieu_tra_3fail.py` (kết quả `ket_qua/dieu_tra/*.json`), bộ test mới `kiem_toan_r4f/chay_r4f.py`.

| Thế hệ mã | OT-05 (test cũ) | OT-06 (test cũ) | HD-01 (test cũ) | Ma trận nến hỏng khớp hợp đồng | Ma trận thời gian khớp hợp đồng |
|---|---|---|---|---|---|
| S3R1 | PASS | PASS | PASS | 156/156 | 18/21 |
| S3R2 | FAIL | FAIL | FAIL | 156/156 | 18/21 |
| S3R3 | FAIL | FAIL | FAIL | 156/156 | 18/21 |
| R4_TRUOC_SUA | FAIL | FAIL | FAIL | 156/156 | 18/21 |

FACT: cả 3 test PASS ở vòng 1 và FAIL từ vòng 2 trở đi; R3 và R4 cho actual giống hệt (kiểm bằng R4F-GOC-R3-R4). 3 ca lệch của ma trận thời gian ở MỌI thế hệ là BUG-R4F-1 (mục 4).

## 2. HD-01 – báo cáo

| Mục | Nội dung (FACT) |
|---|---|
| Nguyên nhân chính xác | `kiem_bang` trả đúng 1 lỗi: `MÁY TRẠNG THÁI: aaaa: chuyển tiếp không hợp lệ CREATED → ARMED`. Fixture BO0 có chuỗi sự kiện ['CREATED', 'ARMED', 'TRIGGER'] – thiếu STEP. |
| Quy tắc hợp đồng | `may_trang_thai.py` mục A: CREATED → {STEP, VOID, EXPIRED}; ghi rõ 'Không hợp lệ: CREATED → ARMED (bỏ qua st 1)'. Suy từ Pine 0.3.9: st chỉ tăng 0 → 1 → 2 (SU-3: MSS H1 dòng 2834 rồi bước 4 dòng 3553–3556; SU-5: rời mức dòng 3559 rồi bước 3 dòng 3563, chuỗi else-if nên không cùng nến). Adapter `chuan_hoa._buoc_trung_gian` luôn phát STEP khi st đi qua 1, kể cả khi st nhảy 0 → 2 trong một nến. |
| Hành vi R3 / R4 | Giống hệt (cùng 1 lỗi). Máy trạng thái được đưa vào kiem_bang từ Stage 3 vòng 2 (hop_dong 1.2); vòng 1 không có → test PASS ở vòng 1. |
| Kết quả thực tế vs kỳ vọng | Test kỳ vọng 0 lỗi; thực tế 1 lỗi đúng quy tắc. Fixture + STEP → 0 lỗi; từng TRADE ngoại lệ OPEN / NO_FILL / NO_DATA / INVALID riêng lẻ → 0 lỗi. |
| Bản ghi hợp lệ THẬT | Bản ghi do adapter sinh (pipeline.chay_synth, 8 ô × 40 seed): 11908 EVENTS, 388 SIGNALS, 72 TRADES → 0 lỗi hợp đồng; chuyển tiếp STEP→ARMED = 800, CREATED→ARMED = 0. R3 cho cùng số liệu (11908 / 0 lỗi / CREATED→ARMED 0). |
| Validator không bị nới | R4F-HD01-KHONG-YEU: CREATED→ARMED, CREATED→TRIGGER, STEP→STEP, sự kiện sau kết thúc, SKIP cho SU3 đều bị bác đúng lý do; xóa STEP khỏi chuỗi THẬT → bị bác. Không sửa validator. |
| Lỗi nằm ở | TEST (fixture lỗi thời so với hợp đồng). Không phải code, không phải hợp đồng. Phân loại: TEST_LOI_THOI. |
| Ảnh hưởng F-01 / F-02 / F-03 / replay | Không. F-02: TRADE INVALID dùng cost_model 'C-x' (không bắt đầu 'C-s' → mã tự do) được chấp nhận ở cả R3 và R4 (chi_TRADE_rieng = 0 lỗi). F-01/F-03 không liên quan đến kiem_bang sự kiện. Replay: adapter không bao giờ sinh CREATED→ARMED. |
| Thay thế | KD-REPL-HD01S3 (R3), R4F-HD01-HOP-DONG, R4F-HD01-KHONG-YEU – PASS trong lần chạy điều phối. |

## 3. OT-05 – báo cáo

| Quy tắc vào | Vị trí nến hỏng | Khớp | Kỳ vọng theo hợp đồng |
|---|---|---|---|
| close | NEN_TRIGGER | 13/13 | NO_DATA/INVALID_BAR (trước khi vào) |
| close | NEN_DAU_CUA_SO | 13/13 | NO_DATA/INVALID_BAR_AFTER_FILL (sau khi vào, giữ entry) |
| close | GIUA_CUA_SO | 13/13 | NO_DATA/INVALID_BAR_AFTER_FILL (sau khi vào, giữ entry) |
| close | SAU_THOAT_TP1 | 13/13 | không ảnh hưởng: = kết quả cắt trước nến 3 (TP1) |
| close | SAU_THOAT_SL | 13/13 | không ảnh hưởng: = kết quả cắt trước nến 3 (SL) |
| close | NGOAI_CUA_SO_TIMEOUT | 13/13 | không ảnh hưởng: = kết quả cắt trước nến 4 (TIMEOUT) |
| next_open | NEN_TRIGGER | 13/13 | NO_DATA/INVALID_BAR (trước khi vào) |
| next_open | NEN_DAU_CUA_SO | 13/13 | NO_DATA/INVALID_BAR (trước khi vào) |
| next_open | GIUA_CUA_SO | 13/13 | NO_DATA/INVALID_BAR_AFTER_FILL (sau khi vào, giữ entry) |
| next_open | SAU_THOAT_TP1 | 13/13 | không ảnh hưởng: = kết quả cắt trước nến 3 (TP1) |
| next_open | SAU_THOAT_SL | 13/13 | không ảnh hưởng: = kết quả cắt trước nến 3 (SL) |
| next_open | NGOAI_CUA_SO_TIMEOUT | 13/13 | không ảnh hưởng: = kết quả cắt trước nến 5 (TIMEOUT) |

13 kiểu nến hỏng trong điều tra (High < Low, High < max(O,C), Low > min(O,C), NaN ở O/H/L/C, +∞, −∞, giá 0, giá âm, thiếu trường, thời gian không phải số nguyên); bộ test R4F thêm 'thời gian None' và nhân đôi BUY/SELL.

| Mục | Nội dung (FACT trừ khi ghi khác) |
|---|---|
| Nguyên nhân chính xác | Kịch bản R1: nến 0 là nến trigger, lệnh VÀO tại Close nến 0; nến hỏng ở nến 1 là nến SAU khi vào. Mã trả NO_DATA `INVALID_BAR_AFTER_FILL` (giữ entry_ts / entry_price, R / MFE / MAE / thoát = null). Test cũ đòi `INVALID_BAR`. actual của test chỉ ghi outcome (['NO_DATA'×3], 'TP1') nên nhìn actual không thấy lý do; R4F-GOC-R3-R4 kiểm trực tiếp fill_note. |
| Quy tắc hợp đồng | docstring mo_phong_lenh mục KẾT CỤC (từ F29, vòng 2): NO_DATA trước khi vào = NO_NEXT_BAR / INVALID_BAR (không chiếm vị thế); sau khi vào = INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL (đã vào, kết quả không xác định; R4 F-01: chiếm vị thế tới ∞). may_trang_thai mục B và FILL_NOTES của hop_dong khớp. |
| Khác biệt R3 / R4 chính xác | Hành vi giả lập: KHÔNG khác (ma trận R3 = R4 từng ca). Khác biệt duy nhất liên quan là lọc danh mục: R4 F-01 cho NO_DATA sau vào chiếm vị thế (R3: không) – R4F-DANH-MUC: trên mã R3 FAIL đúng chỗ 'sau vào – nến hỏng: giữ [a, b]'. |
| Trước vào | Nến trigger hỏng (R1, R2) và nến vào hỏng (R2) → NO_DATA INVALID_BAR, entry_price null, R/MFE/MAE/thoát null, bars_held 0 – khớp. |
| Sau nến thoát / ngoài cửa sổ | Nến hỏng sau nến thoát TP1/SL hoặc sau nến thứ max_bars (TIMEOUT) → kết quả TRÙNG HOÀN TOÀN với kết quả trên dữ liệu cắt trước nến đó (mọi trường, gồm MFE/MAE/exit_ts) – khớp. |
| Văn bản hợp đồng | Phát hiện thêm: dòng quy tắc 'Nến hỏng … trong cửa sổ đánh giá → dừng, NO_DATA INVALID_BAR' trong docstring là câu CŨ trước F29, mâu thuẫn với mục KẾT CỤC cùng file. Đã sửa CÂU CHỮ (không đổi mã) – khóa bằng R4F-HOP-DONG-VAN-BAN. |
| Quan sát không sửa (OBS-R4F-2) | Nến trigger có thời gian None → INVALID / INVALID_SIGNAL (không xác định được trigger_ts), không phải NO_DATA INVALID_BAR. Hành vi có từ vòng 1, ngoài phạm vi; ghi lại. |
| Quan sát không sửa (OBS-R4F-3) | NO_DATA sau vào ghi bars_held = 0 dù đã vào. Hợp đồng không quy định bars_held cho NO_DATA; không đổi (ASSUMPTION: chỉ đếm, không vào thống kê R). |
| Lỗi nằm ở | TEST (assertion lỗi thời) + văn bản hợp đồng (1 câu cũ). Code đúng hợp đồng. |
| Ảnh hưởng F-01 / F-02 / F-03 / replay | F-01: NO_DATA sau vào chiếm vị thế tới ∞ (đúng chủ đích R4) → lệnh sau cùng ô bị bỏ. F-02/F-03: không. Replay: pipeline chuẩn hóa nến nhưng không sửa giá; nến hỏng làm kiem_ohlcv FAIL trước khi giả lập. |
| Thay thế | KD-REPL-OT05, R4F-OT05-MA-TRAN, R4F-GOC-R3-R4 – PASS. |

## 4. OT-06 – báo cáo (kèm BUG-R4F-1)

| Quy tắc | Kiểu | Vị trí | Kết quả (mã R4 trước sửa) | outcome | fill_note | entry_ts_ms |
|---|---|---|---|---|---|---|
| close | TRUNG | NEN_DAU_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | TRUNG | GIUA_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | TRUNG | SAU_THOAT_TP1 | khớp | TP1 | None | 60000000000 |
| close | TRUNG | GIUA_CUA_SO_SAU_KHOANG_TRONG | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | LUI_1_NEN | NEN_DAU_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | LUI_1_NEN | GIUA_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | LUI_1_NEN | SAU_THOAT_TP1 | khớp | TP1 | None | 60000000000 |
| close | LUI_1_NEN | GIUA_CUA_SO_SAU_KHOANG_TRONG | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | LUI_10_NEN | NEN_DAU_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | LUI_10_NEN | GIUA_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| close | LUI_10_NEN | SAU_THOAT_TP1 | khớp | TP1 | None | 60000000000 |
| close | LUI_10_NEN | GIUA_CUA_SO_SAU_KHOANG_TRONG | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000000000 |
| next_open | TRUNG | NEN_DAU_CUA_SO | LỆCH: VI PHẠM HỢP ĐỒNG: vào lệnh tại entry_ts_ms 60000000000 ≤ trigger_ts_ms 60000000000; outcome OPEN ≠ NO_DATA | OPEN | None | 60000000000 |
| next_open | TRUNG | GIUA_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000300000 |
| next_open | TRUNG | SAU_THOAT_TP1 | khớp | TP1 | None | 60000300000 |
| next_open | LUI_1_NEN | NEN_DAU_CUA_SO | LỆCH: VI PHẠM HỢP ĐỒNG: vào lệnh tại entry_ts_ms 59999700000 ≤ trigger_ts_ms 60000000000; outcome OPEN ≠ NO_DATA | OPEN | None | 59999700000 |
| next_open | LUI_1_NEN | GIUA_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000300000 |
| next_open | LUI_1_NEN | SAU_THOAT_TP1 | khớp | TP1 | None | 60000300000 |
| next_open | LUI_10_NEN | NEN_DAU_CUA_SO | LỆCH: VI PHẠM HỢP ĐỒNG: vào lệnh tại entry_ts_ms 59997000000 ≤ trigger_ts_ms 60000000000; outcome OPEN ≠ NO_DATA | OPEN | None | 59997000000 |
| next_open | LUI_10_NEN | GIUA_CUA_SO | khớp | NO_DATA | NON_MONOTONIC_TIME_AFTER_FILL | 60000300000 |
| next_open | LUI_10_NEN | SAU_THOAT_TP1 | khớp | TP1 | None | 60000300000 |

| Mục | Nội dung (FACT trừ khi ghi khác) |
|---|---|
| Điều kiện phát hiện | Trong vòng lặp đánh giá: `k > ie and b['t'] <= t_prev` (t_prev khởi tạo = thời gian nến vào). R1: nến vào = nến trigger nên nến 1 được so với nến trigger. R2: nến vào = nến kế, vòng lặp bắt đầu TẠI nến vào nên điều kiện `k > ie` bỏ qua phép so nến vào với nến trigger. |
| Nguyên nhân FAIL của test cũ | Kịch bản test (R1, lỗi ở nến 2) → mã trả NON_MONOTONIC_TIME_AFTER_FILL (giữ entry, R null). Test đòi NON_MONOTONIC_TIME – ghi chú đã bị loại khỏi FILL_NOTES từ vòng 2 (F29). Lỗi ở TEST cho kịch bản này. |
| Sau vào vs trước vào | Sau vào (R1 nến ≥ 1; R2 nến ≥ 2): NON_MONOTONIC_TIME_AFTER_FILL, entry giữ, R/MFE/MAE/thoát null, time_gaps trước điểm lỗi được giữ (1 khoảng, max_gap 3 900 000 ms) – khớp. Sau nến thoát: không ảnh hưởng – khớp. TRƯỚC vào (R2 nến vào): xem BUG-R4F-1. |
| BUG-R4F-1 – ở đâu | shadow_eval/mo_phong_lenh.py, hàm mo_phong, nhánh R2 (cfg.entry == 'next_open'), dòng kiểm nến kế (dòng 105 sau sửa). |
| BUG-R4F-1 – nguyên nhân kỹ thuật | Nến kế chỉ được kiểm nen_hong (giá/kiểu thời gian), không kiểm thời gian > nến trigger. Nến kế có thời gian trùng hoặc lùi vẫn được dùng làm nến vào. |
| BUG-R4F-1 – hành vi sai | Trên mã R3 và R4 trước sửa: 18 / 18 ca R2 (R3: 18 / 18) VÀO lệnh với entry_ts_ms ≤ trigger_ts_ms và ra kết cục TP1/SL/OPEN có R (ví dụ: trùng thời gian → TP1, r_gross 2,0). Vi phạm may_trang_thai mục B ('R2 phải vào sau nến trigger') – bản ghi này bị kiem_lenh bác nếu đi qua kiểm hợp đồng. |
| BUG-R4F-1 – ảnh hưởng giao dịch thật | FACT: đường pipeline hiện tại KHÔNG chạm được lỗi: du_lieu.chuan_hoa sắp xếp theo t và bỏ dòng trùng giống hệt; trùng mâu thuẫn làm kiem_ohlcv FAIL. Điều kiện kích hoạt xuất hiện 0 lần trên SYNTH 40 seed; băm TRADES / chỉ số / chỉ số không chồng (F-01) / phễu của 8 ô trước và sau sửa GIỐNG HỆT. Ảnh hưởng chỉ tồn tại với bên gọi mo_phong trực tiếp bằng dữ liệu chưa chuẩn hóa: một lệnh 'vào trước tín hiệu' được tính R (thống kê lạc quan/sai) và (nếu OPEN) chiếm vị thế tới ∞, chặn lệnh sau (R4F-DANH-MUC trên mã trước sửa: 'giữ [a], bỏ 1'). |
| BUG-R4F-1 – sửa | Một điều kiện: `if nen_hong(bars[i_trig + 1]) or bars[i_trig + 1]['t'] <= t_trig:` → NO_DATA INVALID_BAR (chưa vào). Thêm 3 dòng docstring. Không đổi hợp đồng dữ liệu, không đổi máy trạng thái. |
| BUG-R4F-1 – lựa chọn ghi chú (ASSUMPTION) | Dùng INVALID_BAR (đã có trong FILL_NOTES và NOTE_TRUOC_VAO; nen_hong vốn coi thời gian sai kiểu là nến hỏng). Không thêm ghi chú mới vì sẽ phải sửa may_trang_thai.py (ngoài danh sách file được sửa). RECOMMENDATION: nếu chủ dự án muốn tách riêng, thêm NON_MONOTONIC_TIME_BEFORE_FILL ở vòng sau (đổi hợp đồng có chủ đích). |
| BUG-R4F-1 – rủi ro của bản sửa | (a) Tín hiệu R2 có dữ liệu trùng thời gian giờ thành NO_DATA (không còn TP1/SL giả) → số lệnh đóng có thể giảm với dữ liệu bẩn; (b) không ảnh hưởng R1; (c) oracle độc lập kiem_doc_lap/oracle.py có CÙNG điểm mù (không kiểm thời gian nến vào R2) – không sửa oracle cũ; xem rủi ro tồn đọng RR-2. |
| BUG-R4F-1 – cách kiểm | R4F-OT06-R2-NEN-VAO (18 ca R2 + 18 ca R1 đối chứng; kiểm máy trạng thái, lọc danh mục), R4F-OT06-TAI-HIEN (tái hiện trên R3 và R4 trước sửa), đột biến N01/N02/N03 (đều KILLED_EXPECTED – mục 8). |
| Ảnh hưởng lọc danh mục | NO_DATA sau vào (thời gian) chiếm vị thế tới ∞ (F-01) → lệnh sau bị bỏ; NO_DATA trước vào (gồm ca R2 mới) không chiếm – R4F-DANH-MUC PASS. |
| Lỗi nằm ở | TEST (assertion lỗi thời) cho kịch bản test cũ + CODE (BUG-R4F-1, kịch bản khác cùng chủ đề, có từ vòng 1). |
| Thay thế | KD-REPL-OT06, R4F-OT06-MA-TRAN, R4F-OT06-R2-NEN-VAO, R4F-GOC-R3-R4 – PASS. |

## 5. KD-REG-S3 – tóm tắt trạng thái và mã thoát

**Vì sao báo cáo R4 ghi 'KD-REG-S3 PASS':** KD-REG-S3 là một test HỒI QUY của bộ R3 (kiem_doc_lap/chay_doc_lap.py). Nó PASS khi tập FAIL của bộ 88 test BẰNG ĐÚNG tập khai báo trước `LOI_THOI_S3` và exit code 1 khớp với FAIL. Nhãn đó KHÔNG có nghĩa bộ 88 test PASS. Báo cáo R4 viết gộp làm người đọc hiểu nhầm – đây là lỗi TRÌNH BÀY/PHÂN LOẠI (FACT). R4F tách rõ hai tầng và giữ dấu FAIL gốc.

**Quy tắc phân loại khai báo TRƯỚC lần chạy** (`kiem_toan_r4f/phan_loai_fail.json`): C1 có trong sổ; C2 SHA đoạn mã test không đổi; C3 actual mới khớp chính xác chữ ký; C4 mọi test thay thế PASS trong CÙNG lần chạy; C5 R3 = mã đang kiểm cho kịch bản test cũ. Thiếu một tiêu chí → FAIL_CHUA_GIAI_QUYET → mã thoát 1. Kiểm âm: đột biến quy trình K01/K02 (mục 8).

**Chính sách mã thoát:** 0 = mọi test PASS · 1 = còn FAIL chưa giải quyết / WRONG_REASON / VALIDATOR_CRASH / ENV_ERROR / TIMEOUT / output cũ · 2 = chỉ còn BLOCKED / NOT TESTED · 3 = chỉ còn FAIL đã phân loại (± BLOCKED / NOT TESTED). Ưu tiên 1 > 3 > 2 > 0.

| ID | Trạng thái gốc | Trạng thái phân loại | Phân loại | Tiêu chí | Test thay thế (cùng lần chạy) |
|---|---|---|---|---|---|
| OT-05 | FAIL | FAIL_DA_PHAN_LOAI | TEST_LOI_THOI (assertion cũ trước F29) | C1=✓ C3=✓ C4=✓ C2=✓ | KD-REPL-OT05 PASS, R4F-OT05-MA-TRAN PASS, R4F-GOC-R3-R4 PASS |
| OT-06 | FAIL | FAIL_DA_PHAN_LOAI | TEST_LOI_THOI (assertion cũ trước F29) + phát hiện LỖI CODE TIỀM ẨN cùng chủ đề (BUG-R4F-1, đã sửa, test riêng) | C1=✓ C3=✓ C4=✓ C2=✓ | KD-REPL-OT06 PASS, R4F-OT06-MA-TRAN PASS, R4F-OT06-R2-NEN-VAO PASS, R4F-GOC-R3-R4 PASS |
| HD-01 | FAIL | FAIL_DA_PHAN_LOAI | TEST_LOI_THOI (fixture thiếu sự kiện STEP so với hợp đồng máy trạng thái thêm ở vòng 2) | C1=✓ C3=✓ C4=✓ C2=✓ | KD-REPL-HD01S3 PASS, R4F-HD01-HOP-DONG PASS, R4F-HD01-KHONG-YEU PASS, R4F-GOC-R3-R4 PASS |

Bộ 88 (chạy mới, bản sao sạch, run_id 41969e09-394f-4d62-8be3-46d85e650762, 40.3 s): PASS 76 · FAIL 3 · BLOCKED 6 · NOT TESTED 3 · exit 1 → trạng thái bộ **FAIL_DA_PHAN_LOAI**.

KD đầy đủ (chay_doc_lap.py, 840.7 s, mã thoát thô 0, 112562 assertion): {'PASS': 102, 'FAIL': 0, 'WRONG_REASON': 0, 'VALIDATOR_CRASH': 0, 'ENV_ERROR': 0, 'BLOCKED': 6, 'NOT TESTED': 1} – trùng số liệu hồi quy R3 trên mã R4 (102 / 6 / 1, 112 562 assertion). KD-REG-S3 trong lần này: **PASS** ở TẦNG HỒI QUY (nghĩa: tập FAIL bộ 88 = LOI_THOI_S3, exit 1 khớp); điều đó KHÔNG làm bộ 88 thành PASS. Trích actual: {'run_id': '7bc8393d-db0c-47b0-a29a-e9e8cfd8ac8a', 'exit': 1, 'dem': {'PASS': 76, 'FAIL': 3, 'BLOCKED': 6, 'NOT TESTED': 3, 'ERROR': 0}, 'fail': ['HD-01', 'OT-05', 'OT-06'], 'lien_ket_loi_thoi_s3': {'OT-05': {'ly_do': 'A…

## 6. Chạy lại toàn bộ R4 theo nhóm (bộ điều phối kiem_toan_r4f/chay_nhom.py)

run_id điều phối 2dd4ec58-4e02-47eb-adb2-f14174ddfc77 · bắt đầu 2026-11-21T13:40:38.008344+00:00 · 953.0 s · phủ 42/42 test R4 (thiếu [], trùng []) · SHA mã đổi trong lúc chạy: không · bytecode: không · **mã thoát 3**.

| Nhóm | Trạng thái nhóm | run_id | giây | assertion | PASS | FAIL | WRONG_REASON | VALIDATOR_CRASH | ENV_ERROR | BLOCKED | NOT TESTED | log | SHA mã trước/sau |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F01+PF | OK | 4df20905-e5e0-461c-b170-d230bf2d9443 | 21.1 | 26200 | 16 | 0 | 0 | 0 | 0 | 0 | 0 | log/F01+PF.log | giữ nguyên |
| F02 | OK | e56682ae-2d06-4c76-b273-132801423035 | 0.4 | 29012 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | log/F02.log | giữ nguyên |
| F03 | OK | b0b00810-cc20-4ecd-9af4-13c0b60c98b1 | 10.3 | 1170 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | log/F03.log | giữ nguyên |
| AD | OK | 2c463475-0d9f-437b-b675-9f8e7d3ee011 | 30.8 | 384 | 4 | 0 | 0 | 0 | 0 | 1 | 0 | log/AD.log | giữ nguyên |
| OR | OK | dd2c42e2-2b74-413f-8253-573e86134d5c | 2.5 | 118063 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | log/OR.log | giữ nguyên |
| HD | OK | 68daa89d-6f73-4927-8907-c3e32bbdebd0 | 0.2 | 35 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | log/HD.log | giữ nguyên |
| ISO | OK | f6e5c0a8-5711-4446-be1e-8a1bb9ef06e1 | 0.1 | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | log/ISO.log | giữ nguyên |
| R4F | OK | a520f5f6-3ff6-4fd9-b78c-8e5e7d600e6a | 6.3 | 5833 | 9 | 0 | 0 | 0 | 0 | 0 | 0 | log/R4F.log | giữ nguyên |
| S3 | OK | 41969e09-394f-4d62-8be3-46d85e650762 | 40.3 | — | 76 | 3 | 0 | 0 | 0 | 6 | 3 | log/S3_bo88.log | giữ nguyên |
| KD | OK | KD-2dd4ec58-4e02-47eb-adb2-f14174ddfc77 | 840.7 | 112562 | 102 | 0 | 0 | 0 | 0 | 6 | 1 | log/KD.log | giữ nguyên |

Tổng: {'PASS': 228, 'FAIL': 3, 'WRONG_REASON': 0, 'VALIDATOR_CRASH': 0, 'ENV_ERROR': 0, 'BLOCKED': 13, 'NOT TESTED': 4}. Giới hạn đã nêu ở đề bài: ChatGPT không chạy lại được toàn bộ R4 vì giới hạn thời gian – trong môi trường này toàn bộ chạy xong (không TIMEOUT); bộ điều phối cho phép chạy từng nhóm riêng (`--nhom F02`) để kiểm độc lập theo phần.

Bộ 0.3.9 (điều kiện tiên quyết của KD-REG-S3) chạy mới: {'PASS': 47, 'BLOCKED': 7, 'FAIL': 1, 'NOT TESTED': 1} trong 836 s – FAIL duy nhất T-01 (token, đã phân loại từ 0.3.9).

## 7. Cách ly và toàn vẹn

| Kiểm | Chi tiết | Đạt |
|---|---|---|
| So với gói R4 | sửa ['shadow_eval/mo_phong_lenh.py']; file mới 129 (ngoài kiem_toan_r4f/: không); xóa không | True |
| Bằng chứng R4 + test cũ | 57 file (kiem_toan_r4/**, kiem_doc_lap/**, kiem_thu_stage3.py, _truoc_r4/**) – đổi: không | True |
| Manifest R4 | 300 dòng – lệch: ['shadow_eval/mo_phong_lenh.py'] (đúng file đã sửa) | True |
| So với R3 | sửa ['shadow_eval/chi_so.py', 'shadow_eval/hop_dong.py', 'shadow_eval/mo_phong_lenh.py'] (⊆ danh sách R4); file mới ngoài chỗ cho phép: không | True |
| Pine | ATA_P3_Build_0.3.8_Candidate_Indicator.pine 79793fcf7d5530d8… đúng; ATA_P3_Build_0.3.9_Candidate_Indicator.pine 2184d8926f6b7bef… đúng | True |
| Bytecode | không có __pycache__/.pyc | True |
| Phạm vi dòng sửa | 6 dòng diff; dòng MÃ ngoài docstring: 1 | True |
| Ngoài phạm vi (dashboard / D0 / D1 / token gate) | không đụng | True |
| Độ mới / run_id | 10 run_id duy nhất; log cũ hơn lúc bắt đầu: không | True |

Kết luận cách ly: **ĐẠT** (FACT, `ket_qua/cach_ly_r4f.json`). Bằng chứng R4 (kiem_toan_r4/ket_qua, BAN_GIAO_R4) không bị ghi đè; R4F ghi vào kiem_toan_r4f/.

## 8. Kiểm thử đột biến (chạy mới)

27 đột biến, 2007.6 s. Bản gốc: R4 {'PASS': 41, 'BLOCKED': 1}, R4F {'PASS': 9}; bất thường ngoài BLOCKED đã biết: không. Kết quả: **{'KILLED_EXPECTED': 27}**. Đột biến tương đương: không có (M02/M12 tương đương của R4 đã được thay ở R4, không tính phủ).

Đồng nhất mã: mọi file mã được kiểm có mtime TRƯỚC lúc bắt đầu chạy đột biến (file sửa sau đó: không); SHA hiện tại = SHA của lần chạy điều phối cuối: khớp (mo_phong_lenh.py 74ac5e965a8aa70e…) → đột biến chạy trên đúng mã của kết luận. M06/M07 được khai báo TRƯỚC (từ R4) là 'bắt qua lý do' (qua_ly_do): test ra WRONG_REASON vì đột biến đổi đúng thông điệp lý do mà test kiểm chính xác – tính KILLED_EXPECTED theo định nghĩa khai báo trước. K01: OT-05 hết FAIL (đột biến làm assertion cũ đúng trở lại) → OT-06 / HD-01 mất tiêu chí C2/C4 → FAIL_CHUA_GIAI_QUYET, mã thoát 1: sổ phân loại không che được lỗi thật.

| ID | Nguồn | File | Mô tả | Mã đột biến | Test / điều kiện khai báo trước | Phân loại | Bằng chứng |
|---|---|---|---|---|---|---|---|
| M01 | R4 (chạy lại) | mo_phong_lenh.py | F-01 tái phát: NO_DATA sau vào không chiếm vị thế | `if t.get("outcome") == "NO_DATA" and t.get("fill_note") in N` → `if False:             pass` | F01-NODATA-SAU, F01-CHUOI-TOI-THIEU | KILLED_EXPECTED | F01-NODATA-SAU: FAIL; F01-CHUOI-TOI-THIEU: FAIL |
| M02 | R4 (chạy lại) | mo_phong_lenh.py | NO_DATA sau vào chỉ chặn đúng thời điểm vào (hết vị thế sai) | `mo[k] = math.inf if t.get("outcome") == "OPEN" or t.get("exi` → `mo[k] = t["entry_ts_ms"] if t.get("outcome") == "NO_DATA" el` | F01-NODATA-SAU, F01-CHUOI-TOI-THIEU | KILLED_EXPECTED | F01-NODATA-SAU: FAIL; F01-CHUOI-TOI-THIEU: FAIL |
| M03 | R4 (chạy lại) | mo_phong_lenh.py | NO_DATA TRƯỚC khi vào bị coi là đã vào | `NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_` → `NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_` | F01-NODATA-TRUOC | KILLED_EXPECTED | F01-NODATA-TRUOC: FAIL |
| M04 | R4 (chạy lại) | mo_phong_lenh.py | bỏ sót NON_MONOTONIC_TIME_AFTER_FILL | `NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_` → `NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL",)` | F01-NODATA-SAU | KILLED_EXPECTED | F01-NODATA-SAU: FAIL |
| M05 | R4 (chạy lại) | mo_phong_lenh.py | biên entry = exit không còn bị bỏ | `if k in mo and t["entry_ts_ms"] <= mo[k]:` → `if k in mo and t["entry_ts_ms"] < mo[k]:` | F01-DONG-THEO-THOI-GIAN, F01-CHUOI-TOI-THIEU | KILLED_EXPECTED | F01-DONG-THEO-THOI-GIAN: FAIL; F01-CHUOI-TOI-THIEU: FAIL |
| M06 | R4 (chạy lại) | hop_dong.py | F-02 tái phát: regex lỏng [0-9.]+ | `_SO = r"([0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)"` → `_SO = r"([0-9.]+)"` | F02-MA-HONG | KILLED_EXPECTED | F02-MA-HONG: WRONG_REASON |
| M07 | R4 (chạy lại) | hop_dong.py | bỏ kiểm số không hữu hạn trong cost_model | `if not all(math.isfinite(x) for x in v):` → `if False:` | F02-MA-HONG | KILLED_EXPECTED | F02-MA-HONG: WRONG_REASON |
| M08 | R4 (chạy lại) | hop_dong.py | mã 'C-s…' sai cấu trúc bị bỏ qua im lặng | `    if not isinstance(ma, str) or not ma.startswith("C-s"): ` → `    if not isinstance(ma, str) or not ma.startswith("C-s"): ` | F02-MA-HONG, F02-FUZZ | KILLED_EXPECTED | F02-MA-HONG: FAIL; F02-FUZZ: FAIL |
| M09 | R4 (chạy lại) | hop_dong.py | đổi công thức chi phí đóng băng (trượt 1 lần) | `cp = v[0] + v[1] + 2 * v[2]` → `cp = v[0] + v[1] + v[2]` | F02-MA-HOP-LE, F02-CONG-THUC-DONG-BANG | KILLED_EXPECTED | F02-MA-HOP-LE: FAIL; F02-CONG-THUC-DONG-BANG: FAIL |
| M10 | R4 (chạy lại) | chi_so.py | F-03 tái phát: bootstrap_khoi bỏ kiểm tham số chung | `    R = list(R_theo_thoi_gian)     _kiem_tham_so(R, n_boot, ` → `    R = list(R_theo_thoi_gian)` | F03-DONG-NHAT | KILLED_EXPECTED | F03-DONG-NHAT: FAIL |
| M11 | R4 (chạy lại) | chi_so.py | cho phép L = n (CI suy biến giả 'OK') | `    if L is not None and L > n - 1:` → `    if L is not None and L > n:` | F03-L | KILLED_EXPECTED | F03-L: FAIL |
| M12 | R4 (chạy lại) | chi_so.py | bỏ kiểm kiểu n_boot (float 40.0 lọt) | `if not isinstance(n_boot, int) or isinstance(n_boot, bool) o` → `if n_boot < N_BOOT_MIN:` | F03-DONG-NHAT | KILLED_EXPECTED | F03-DONG-NHAT: FAIL |
| M13 | R4 (chạy lại) | chi_so.py | đổi seed (mất tất định so với R3) | `rnd = random.Random(_seed(seed, key))` → `rnd = random.Random(_seed(seed + 1, key))` | F03-KHONG-DOI-PHUONG-PHAP | KILLED_EXPECTED | F03-KHONG-DOI-PHUONG-PHAP: FAIL |
| M14 | R4 (chạy lại) | mo_phong_lenh.py | lỗi hồi quy tự gây ở lượt 1 (bản ghi thiếu outcome chiếm vị thế ∞) – phát hiện bởi REG-01 R3 | `mo[k] = math.inf if t.get("outcome") == "OPEN" or` → `mo[k] = math.inf if t.get("outcome") not in DONG or` | PF-KHONG-DOI-CA-DUNG | KILLED_EXPECTED | PF-KHONG-DOI-CA-DUNG: FAIL |
| N01 | R4F (mới) | mo_phong_lenh.py | BUG-R4F-1 tái phát: bỏ kiểm thời gian nến vào R2 | ` or bars[i_trig + 1]["t"] <= t_trig:` → `:` | R4F-OT06-R2-NEN-VAO, R4F-DANH-MUC | KILLED_EXPECTED | R4F-OT06-R2-NEN-VAO: FAIL; R4F-DANH-MUC: FAIL |
| N02 | R4F (mới) | mo_phong_lenh.py | biên: nến vào TRÙNG thời gian trigger lọt | `bars[i_trig + 1]["t"] <= t_trig:` → `bars[i_trig + 1]["t"] < t_trig:` | R4F-OT06-R2-NEN-VAO | KILLED_EXPECTED | R4F-OT06-R2-NEN-VAO: FAIL |
| N03 | R4F (mới) | mo_phong_lenh.py | sai ghi chú: nến vào lỗi thời gian ghi NO_NEXT_BAR | `        if nen_hong(bars[i_trig + 1]) or bars[i_trig + 1]["t` → `        if nen_hong(bars[i_trig + 1]):             return _k` | R4F-OT06-R2-NEN-VAO | KILLED_EXPECTED | R4F-OT06-R2-NEN-VAO: FAIL |
| N04 | R4F (mới) | mo_phong_lenh.py | F29 tái phát (nến hỏng sau vào ghi INVALID_BAR) | `"INVALID_BAR_AFTER_FILL" if why else` → `"INVALID_BAR" if why else` | R4F-OT05-MA-TRAN | KILLED_EXPECTED | R4F-OT05-MA-TRAN: FAIL |
| N05 | R4F (mới) | mo_phong_lenh.py | F29 tái phát (thời gian sau vào ghi NON_MONOTONIC_TIME) | `if why else "NON_MONOTONIC_TIME_AFTER_FILL")` → `if why else "NON_MONOTONIC_TIME")` | R4F-OT06-MA-TRAN | KILLED_EXPECTED | R4F-OT06-MA-TRAN: FAIL |
| N06 | R4F (mới) | mo_phong_lenh.py | thời gian TRÙNG sau vào không bị phát hiện | `if why or (k > ie and b["t"] <= t_prev):` → `if why or (k > ie and b["t"] < t_prev):` | R4F-OT06-MA-TRAN | KILLED_EXPECTED | R4F-OT06-MA-TRAN: FAIL |
| N07 | R4F (mới) | mo_phong_lenh.py | NO_DATA sau vào làm mất entry_price | `return dict(_khong(base, "NO_DATA", "INVALID_BAR_AFTER_FILL"` → `return dict(_khong(dict(base, entry_price=None), "NO_DATA", ` | R4F-OT05-MA-TRAN | KILLED_EXPECTED | R4F-OT05-MA-TRAN: FAIL |
| N08 | R4F (mới) | mo_phong_lenh.py | nhìn trước 1 nến: nến hỏng SAU nến thoát làm hỏng kết quả | `        why = nen_hong(b) ` → `        why = nen_hong(b) or (k + 1 < len(bars) and nen_hong` | R4F-OT05-MA-TRAN | KILLED_EXPECTED | R4F-OT05-MA-TRAN: FAIL |
| N09 | R4F (mới) | may_trang_thai.py | nới máy trạng thái: cho CREATED → ARMED | `"CREATED": {"STEP", "VOID", "EXPIRED"}` → `"CREATED": {"STEP", "VOID", "EXPIRED", "ARMED"}` | R4F-HD01-HOP-DONG, R4F-HD01-KHONG-YEU | KILLED_EXPECTED | R4F-HD01-HOP-DONG: FAIL; R4F-HD01-KHONG-YEU: FAIL |
| N10 | R4F (mới) | hop_dong.py | bỏ kiểm vòng đời sự kiện trong kiem_bang | `loi += [f"MÁY TRẠNG THÁI: {x}" for x in MT.kiem_vong_doi(eve` → `pass` | R4F-HD01-HOP-DONG, R4F-HD01-KHONG-YEU | KILLED_EXPECTED | R4F-HD01-HOP-DONG: FAIL; R4F-HD01-KHONG-YEU: FAIL |
| N11 | R4F (mới) | mo_phong_lenh.py | NO_DATA TRƯỚC khi vào chiếm vị thế | `elif t.get("outcome") in KHONG_VAO:` → `elif t.get("outcome") in ("NO_FILL", "INVALID"):` | R4F-DANH-MUC | KILLED_EXPECTED | R4F-DANH-MUC: FAIL |
| K01 | R4F (quy trình) | mo_phong_lenh.py | F29 tái phát trong cây đầy đủ → OT-05 không còn FAIL theo chữ ký; R4F FAIL → điều phối phải ra mã 1 | `"INVALID_BAR_AFTER_FILL" if why else` → `"INVALID_BAR" if why else` | ma_thoat == 1 và R4F có FAIL | KILLED_EXPECTED | mã thoát 1, S3 {'OT-06': 'FAIL_CHUA_GIAI_QUYET', 'HD-01': 'FAIL_CHUA_GIAI_QUYET'} |
| K02 | R4F (quy trình) | may_trang_thai.py | đổi thông điệp lỗi máy trạng thái → actual HD-01 lệch chữ ký → phải là FAIL_CHUA_GIAI_QUYET | `chuyển tiếp không hợp lệ {cu} → {et}` → `chuyển tiếp sai {cu} → {et}` | HD-01 = FAIL_CHUA_GIAI_QUYET và ma_thoat == 1 | KILLED_EXPECTED | mã thoát 1, S3 {'OT-05': 'FAIL_CHUA_GIAI_QUYET', 'OT-06': 'FAIL_CHUA_GIAI_QUYET', 'HD-01': 'FAIL_CHUA_GIAI_QUYET'} |

## 9. Danh sách BLOCKED / NOT TESTED (không tính là PASS)

| Bộ | ID | Trạng thái | Lý do |
|---|---|---|---|
| AD | AD-TAO-KET-THUC-CUNG-NEN | BLOCKED | Adapter + driver giả lập: CREATED → END_NO_EVENT (máy trạng thái bác). Engine thật: 0 lần trên 200 seed. Chưa chứng minh engine đi được nhánh này → KH |
| KD | KD-REAL-XAU-SU3 | BLOCKED | Không có OHLCV lịch sử có nguồn (mạng của công cụ tắt) và chưa có replay bối cảnh từ OHLCV |
| KD | KD-REAL-XAU-SU5 | BLOCKED | Như trên |
| KD | KD-REAL-BTC-SU3 | BLOCKED | Như trên |
| KD | KD-REAL-BTC-SU5 | BLOCKED | Như trên |
| KD | KD-REPLAY-EQ | BLOCKED | Không có dữ liệu đối chứng; Data Window chỉ giữ một phần sự kiện SHADOW (B-1) |
| KD | KD-TV-TOKEN | BLOCKED | TradingView không in số token khi compile thành công |
| KD | KD-REPLAY-FULL | NOT TESTED | Chưa hiện thực – ngoài phạm vi (không xây full Pine interpreter) |
| S3 (bộ 88) | REAL-XAU-SU3 | BLOCKED | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| S3 (bộ 88) | REAL-XAU-SU5 | BLOCKED | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| S3 (bộ 88) | REAL-BTC-SU3 | BLOCKED | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| S3 (bộ 88) | REAL-BTC-SU5 | BLOCKED | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| S3 (bộ 88) | REPLAY-EQ | BLOCKED | Chưa có dữ liệu đối chứng từ TradingView; Data Window chỉ chứa một phần sự kiện SHADOW (K.5) – không tuyên bố PASS |
| S3 (bộ 88) | TV-TOKEN | BLOCKED | TradingView không in số token khi compile thành công |
| S3 (bộ 88) | REPLAY-FULL | NOT TESTED | Chưa hiện thực – ngoài phạm vi nhiệm vụ (không tự xây full Pine interpreter) |
| S3 (bộ 88) | DL-REAL-FILE | NOT TESTED | Chưa có file thật; định dạng được kiểm bằng file tổng hợp (DL-01, DL-02, DL-09) |
| S3 (bộ 88) | FUNNEL-REAL | NOT TESTED | Phụ thuộc REPLAY-FULL và dữ liệu thật |
| 0.3.9 (bộ 56) | C-06 | BLOCKED | Không triển khai: đặc tả không định nghĩa danh tính một cụm qua các lần gom lại (F.4: trạng thái lưu theo MỨC; cụm tính lại mỗi nến H1) nên không xác  |
| 0.3.9 (bộ 56) | C-07 | BLOCKED | Không tính trong SHADOW: K.5 chỉ cần P_ref/SL/TP1; SU-3 luôn tối đa B; SU-5 – I.5 yêu cầu C-1, C-2 nhưng J.4 không định nghĩa C-1/C-2 cho SU-5 (IP-23) |
| 0.3.9 (bộ 56) | T-02 | BLOCKED | Chưa đo – chỉ TradingView cho số thật (CE10117 in số token khi vượt) |
| 0.3.9 (bộ 56) | TV-COMPILE | BLOCKED | Chưa có |
| 0.3.9 (bộ 56) | TV-M5 | BLOCKED | Chưa có |
| 0.3.9 (bộ 56) | TV-RELOAD | BLOCKED | Chưa có |
| 0.3.9 (bộ 56) | TV-KHUNG | BLOCKED | Chưa có |
| 0.3.9 (bộ 56) | TV-EXNESS | NOT TESTED | chưa có |

KD đầy đủ: BLOCKED 6, NOT TESTED 1 – KD-REAL-XAU-SU3, KD-REAL-XAU-SU5, KD-REAL-BTC-SU3, KD-REAL-BTC-SU5, KD-REPLAY-EQ, KD-TV-TOKEN, KD-REPLAY-FULL.


Không tuyên bố: dữ liệu thị trường thật, REPLAY-EQ (tương đương Python ↔ TradingView), token TradingView, replay Pine đầy đủ, oracle độc lập với đặc tả, thứ tự sự kiện cùng nến trên dữ liệu thật.

## 10. Rủi ro tồn đọng

| ID | Rủi ro | Loại | Đề xuất |
|---|---|---|---|
| RR-1 | Ghi chú INVALID_BAR cho ca R2 nến vào lỗi thời gian gộp hai nguyên nhân (giá hỏng / thời gian) ở nhánh trước vào. | ASSUMPTION | Chủ dự án quyết có tách ghi chú (đổi hợp đồng + may_trang_thai) hay không. |
| RR-2 | Oracle độc lập cũ (kiem_doc_lap/oracle.py) có cùng điểm mù với BUG-R4F-1 → bằng chứng 'code = oracle' cũ không phát hiện được loại lỗi này; không sửa oracle cũ theo ràng buộc. | FACT | Vòng sau: bổ sung quy tắc vào oracle (có review độc lập). |
| RR-3 | Oracle không độc lập với đặc tả (cùng tác giả, cùng tài liệu). | FACT (giới hạn đã nêu từ R3/R4) | Giữ là NOT TESTED / giới hạn. |
| RR-4 | Kết luận 'pipeline không chạm BUG-R4F-1' dựa trên SYNTH + đọc mã du_lieu.chuan_hoa; chưa có dữ liệu thật. | PARTIALLY VERIFIED | Kiểm lại khi có OHLCV thật có nguồn. |
| RR-5 | R4-OBS-1 (AD-TAO-KET-THUC-CUNG-NEN) vẫn BLOCKED – 0 lần xuất hiện trong 200 seed SYNTH. | FACT | Cần dữ liệu/kịch bản tạo được ca này. |
| RR-6 | OBS-R4F-2 / OBS-R4F-3 (nến trigger thời gian None → INVALID_SIGNAL; NO_DATA sau vào bars_held 0) – hành vi có sẵn, ngoài phạm vi, không đổi. | FACT | Chủ dự án quyết ở vòng sau. |

## 11. Kết luận đóng vòng

| Điều kiện (mục 11 đề bài) | Trạng thái |
|---|---|
| HD-01, OT-05, OT-06 xử lý có bằng chứng | ĐẠT |
| KD-REG-S3 phản ánh đúng thực tế (FAIL gốc giữ, không gắn PASS cho bộ có FAIL, mã thoát ≠ 0) | ĐẠT |
| Toàn bộ R4 đã chạy lại theo nhóm (giới hạn được phân loại) | ĐẠT |
| Đột biến có kết quả mới, đủ bản ghi | ĐẠT |
| Cách ly đạt, Pine không đổi | ĐẠT |
| Không FAIL chưa giải quyết nào bị gắn PASS | ĐẠT |

**RECOMMENDATION: đề xuất ĐÓNG vòng R4F.** Mã thoát 3 là trạng thái đúng (còn 3 FAIL đã phân loại có bằng chứng + BLOCKED/NOT TESTED ngoài phạm vi), không phải 'sạch'. Quyết định đóng thuộc chủ dự án; không cần chủ dự án chạy test thủ công.


## 12. Danh mục gói R4F

- Mã: `shadow_eval/mo_phong_lenh.py` (sửa BUG-R4F-1 + docstring). Công cụ mới: `kiem_toan_r4f/{dieu_tra_3fail.py, chay_r4f.py, chay_nhom.py, dot_bien_r4f.py, kiem_cach_ly_r4f.py, so_sanh_pipeline.py, tao_ban_giao_r4f.py, phan_loai_fail.json}`, bản trước sửa `kiem_toan_r4f/truoc_sua_r4f/mo_phong_lenh.py`, mã các vòng cũ `kiem_toan_r4f/lich_su_module/`.
- Kết quả: `kiem_toan_r4f/ket_qua/chay_nhom/` (log từng nhóm, JSON từng nhóm, ket_qua_dieu_phoi.json, S3 88 test, KD đầy đủ), `ket_qua/dieu_tra/`, `ket_qua/pipeline/`, `ket_qua/r4f_tren_ma_R3/`, `ket_qua/r4f_tren_ma_R4_truoc_sua/`, `ket_qua/dot_bien_r4f.json`, `ket_qua/cach_ly_r4f.json`, `ket_qua/reg039_r4f/`; lần chạy thử trước `ket_qua/chay_nhom_LAN0_THU/` (giữ làm bằng chứng, không dùng cho kết luận) và `ket_qua/chay_nhom_LAN1_HUY/` (dừng tay ở nhóm KD vì đã tạo/sửa tao_ban_giao_r4f.py – file trong phạm vi băm SHA – trong lúc chạy; không hợp lệ theo quy tắc SHA trước = sau; đã chạy lại toàn bộ).
- Bàn giao: `kiem_toan_r4f/BAN_GIAO_R4F/` – báo cáo này, TEST_MATRIX.csv, PHAN_LOAI_FAIL.csv, MUTATION.csv, BLOCKED_NOT_TESTED.csv, DIFF.patch, SHA_SAU_SUA.txt, SHA_PINE.txt, MANIFEST_SHA256.txt.

