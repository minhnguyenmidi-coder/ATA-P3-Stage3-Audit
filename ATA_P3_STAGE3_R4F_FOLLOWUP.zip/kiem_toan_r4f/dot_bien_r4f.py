# -*- coding: utf-8 -*-
"""ĐỘT BIẾN R4F (mục 7). Ngoài Pine. Không ghi vào kiem_toan_r4/ket_qua (bằng chứng R4 giữ nguyên).
python3 -B kiem_toan_r4f/dot_bien_r4f.py → kiem_toan_r4f/ket_qua/dot_bien_r4f.json

Ba loại:
  M01–M14 : 14 đột biến R4 (đọc nguyên DB từ kiem_toan_r4/dot_bien_r4.py, không sửa) – CHẠY LẠI trên mã R4F.
  N01–N11 : đột biến MỚI cho HD-01 / OT-05 / OT-06 / BUG-R4F-1 / lọc danh mục.
  K01–K02 : đột biến QUY TRÌNH – kiểm âm cho quy tắc phân loại FAIL: chạy bộ điều phối (chay_nhom.py --nhom R4F,S3) trong BẢN SAO cây có module đột biến;
            kỳ vọng mã thoát 1 và FAIL bị đưa về FAIL_CHUA_GIAI_QUYET (quy tắc phân loại không che lỗi thật).
Mỗi đột biến M/N: chép shadow_eval/*.py vào thư mục tạm, áp đột biến (điểm neo phải xuất hiện ĐÚNG 1 lần), chạy chay_r4.py VÀ chay_r4f.py với --module-dir trong tiến trình
riêng (python -B, PYTHONDONTWRITEBYTECODE=1, ATA_GOC = gốc dự án), kiểm output mới (mtime, module_dir, run_id).
Phân loại (không gộp): KILLED_EXPECTED · WRONG_REASON · VALIDATOR_CRASH · KILLED_UNEXPECTED · SURVIVED · ENV_ERROR (định nghĩa như dot_bien_r4.py).
Đột biến tương đương (không thể đổi hành vi theo hợp đồng) KHÔNG tính là lỗ hổng phủ – ghi riêng nếu có."""
import sys
sys.dont_write_bytecode = True
import importlib.util, json, os, shutil, subprocess, tempfile, time   # noqa: E402

D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
OUT = os.path.join(D, "ket_qua"); os.makedirs(OUT, exist_ok=True)
ENV = dict(os.environ, ATA_GOC=G, PYTHONDONTWRITEBYTECODE="1")
spec = importlib.util.spec_from_file_location("dot_bien_r4_db", os.path.join(G, "kiem_toan_r4", "dot_bien_r4.py")); _m = importlib.util.module_from_spec(spec); spec.loader.exec_module(_m)
DB_R4 = list(_m.DB)
CHAP_NHAN_BLOCKED = set(_m.CHAP_NHAN_BLOCKED)

MPL = "mo_phong_lenh.py"
DB_MOI = [  # (id, file, neo, thay, mô tả, test khai báo, chuỗi lý do kỳ vọng)
    ("N01", MPL, ' or bars[i_trig + 1]["t"] <= t_trig:', ':', "BUG-R4F-1 tái phát: bỏ kiểm thời gian nến vào R2", ["R4F-OT06-R2-NEN-VAO", "R4F-DANH-MUC"], "VÀO tại"),
    ("N02", MPL, 'bars[i_trig + 1]["t"] <= t_trig:', 'bars[i_trig + 1]["t"] < t_trig:', "biên: nến vào TRÙNG thời gian trigger lọt", ["R4F-OT06-R2-NEN-VAO"], "TRUNG"),
    ("N03", MPL, '        if nen_hong(bars[i_trig + 1]) or bars[i_trig + 1]["t"] <= t_trig:      # R4F BUG-R4F-1: nến vào không sau nến trigger → chưa vào\n'
                 '            return _khong(base, "NO_DATA", "INVALID_BAR")',
     '        if nen_hong(bars[i_trig + 1]):\n            return _khong(base, "NO_DATA", "INVALID_BAR")\n        if bars[i_trig + 1]["t"] <= t_trig:\n'
     '            return _khong(base, "NO_DATA", "NO_NEXT_BAR")', "sai ghi chú: nến vào lỗi thời gian ghi NO_NEXT_BAR", ["R4F-OT06-R2-NEN-VAO"], "fill_note NO_NEXT_BAR ≠ INVALID_BAR"),
    ("N04", MPL, '"INVALID_BAR_AFTER_FILL" if why else', '"INVALID_BAR" if why else', "F29 tái phát (nến hỏng sau vào ghi INVALID_BAR)", ["R4F-OT05-MA-TRAN"], "≠ INVALID_BAR_AFTER_FILL"),
    ("N05", MPL, 'if why else "NON_MONOTONIC_TIME_AFTER_FILL")', 'if why else "NON_MONOTONIC_TIME")', "F29 tái phát (thời gian sau vào ghi NON_MONOTONIC_TIME)",
     ["R4F-OT06-MA-TRAN"], "≠ NON_MONOTONIC_TIME_AFTER_FILL"),
    ("N06", MPL, 'if why or (k > ie and b["t"] <= t_prev):', 'if why or (k > ie and b["t"] < t_prev):', "thời gian TRÙNG sau vào không bị phát hiện", ["R4F-OT06-MA-TRAN"], "TRUNG"),
    ("N07", MPL, 'return dict(_khong(base, "NO_DATA", "INVALID_BAR_AFTER_FILL" if why',
     'return dict(_khong(dict(base, entry_price=None), "NO_DATA", "INVALID_BAR_AFTER_FILL" if why', "NO_DATA sau vào làm mất entry_price", ["R4F-OT05-MA-TRAN"], "entry ("),
    ("N08", MPL, '        why = nen_hong(b)\n', '        why = nen_hong(b) or (k + 1 < len(bars) and nen_hong(bars[k + 1]))\n',
     "nhìn trước 1 nến: nến hỏng SAU nến thoát làm hỏng kết quả", ["R4F-OT05-MA-TRAN"], "sau TP1"),
    ("N09", "may_trang_thai.py", '"CREATED": {"STEP", "VOID", "EXPIRED"}', '"CREATED": {"STEP", "VOID", "EXPIRED", "ARMED"}', "nới máy trạng thái: cho CREATED → ARMED",
     ["R4F-HD01-HOP-DONG", "R4F-HD01-KHONG-YEU"], "CREATED"),
    ("N10", "hop_dong.py", 'loi += [f"MÁY TRẠNG THÁI: {x}" for x in MT.kiem_vong_doi(events)]', 'pass', "bỏ kiểm vòng đời sự kiện trong kiem_bang",
     ["R4F-HD01-HOP-DONG", "R4F-HD01-KHONG-YEU"], "fixture gốc"),
    ("N11", MPL, 'elif t.get("outcome") in KHONG_VAO:', 'elif t.get("outcome") in ("NO_FILL", "INVALID"):', "NO_DATA TRƯỚC khi vào chiếm vị thế", ["R4F-DANH-MUC"], "trước vào"),
]
DB_QT = [  # (id, file, neo, thay, mô tả, điều kiện kỳ vọng)
    ("K01", MPL, '"INVALID_BAR_AFTER_FILL" if why else', '"INVALID_BAR" if why else', "F29 tái phát trong cây đầy đủ → OT-05 không còn FAIL theo chữ ký; R4F FAIL → điều phối phải ra mã 1",
     "ma_thoat == 1 và R4F có FAIL"),
    ("K02", "may_trang_thai.py", 'chuyển tiếp không hợp lệ {cu} → {et}', 'chuyển tiếp sai {cu} → {et}', "đổi thông điệp lỗi máy trạng thái → actual HD-01 lệch chữ ký → phải là FAIL_CHUA_GIAI_QUYET",
     "HD-01 = FAIL_CHUA_GIAI_QUYET và ma_thoat == 1"),
]


def ap_dot_bien(md, f, neo, thay):
    p = os.path.join(md, f); src = open(p, encoding="utf-8").read()
    if src.count(neo) != 1:
        return f"ENV_ERROR: điểm neo xuất hiện {src.count(neo)} lần trong {f}"
    open(p, "w", encoding="utf-8").write(src.replace(neo, thay, 1))
    return None


def chay_bo(md, tmp):
    kq = {}
    for ten, script, fo in (("r4", os.path.join(G, "kiem_doc_lap", "chay_r4.py"), "ket_qua_r4.json"), ("r4f", os.path.join(D, "chay_r4f.py"), "ket_qua_r4f.json")):
        out = os.path.join(tmp, "out_" + ten); t0 = time.time()
        p = subprocess.run([sys.executable, "-B", script, "--module-dir", md, "--out", out], capture_output=True, text=True, timeout=1800, env=ENV, cwd=tmp)
        f = os.path.join(out, fo)
        if not os.path.exists(f) or os.path.getmtime(f) < t0:
            return None, f"ENV_ERROR: {ten} không có kết quả mới (exit {p.returncode}) {p.stderr[-300:]}"
        r = json.load(open(f, encoding="utf-8"))
        if r["module_dir"] != md:
            return None, f"ENV_ERROR: {ten} kết quả của thư mục module khác"
        kq[ten] = dict(r, exit=p.returncode)
    return kq, None


def chay_mut(mut):
    tmp = tempfile.mkdtemp(prefix="r4f_mut_"); md = os.path.join(tmp, "m"); os.makedirs(md)
    try:
        for f in os.listdir(os.path.join(G, "shadow_eval")):
            if f.endswith(".py"):
                shutil.copy(os.path.join(G, "shadow_eval", f), md)
        if mut:
            loi = ap_dot_bien(md, *mut[1:4])
            if loi:
                return None, loi
        return chay_bo(md, tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def phan_loai(mut, kq):
    mid, f, _, _, mo, khai, ly = mut[:7]
    qua_ly_do = len(mut) > 7 and mut[7]
    tat = kq["r4"]["ket_qua"] + kq["r4f"]["ket_qua"]
    st = {k["test_id"]: k for k in tat}
    kb = [st[t] for t in khai if t in st]
    if len(kb) != len(khai):
        return "ENV_ERROR", kb
    if any(x["status"] == "FAIL" and ly in x["actual"] for x in kb) or (qua_ly_do and any(x["status"] == "WRONG_REASON" and ly in x["actual"] for x in kb)):
        return "KILLED_EXPECTED", kb
    if any(x["status"] in ("FAIL", "WRONG_REASON") for x in kb):
        return "WRONG_REASON", kb
    if any(x["status"] == "VALIDATOR_CRASH" for x in kb):
        return "VALIDATOR_CRASH", kb
    if any(x["status"] != "PASS" and x["test_id"] not in CHAP_NHAN_BLOCKED for x in tat):
        return "KILLED_UNEXPECTED", kb
    return "SURVIVED", kb


def chay_qt(mut):
    """Đột biến quy trình: bản sao cây đầy đủ (không bytecode), module đột biến, chạy chay_nhom.py --nhom R4F,S3 với ATA_GOC = bản sao."""
    tmp = tempfile.mkdtemp(prefix="r4f_qt_"); g2 = os.path.join(tmp, "kt")
    try:
        shutil.copytree(G, g2, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "ket_qua"))
        loi = ap_dot_bien(os.path.join(g2, "shadow_eval"), *mut[1:4])
        if loi:
            return dict(phan_loai="ENV_ERROR", chi_tiet=loi)
        out = os.path.join(tmp, "out"); t0 = time.time()
        p = subprocess.run([sys.executable, "-B", os.path.join(g2, "kiem_toan_r4f", "chay_nhom.py"), "--nhom", "R4F,S3", "--out", out], capture_output=True, text=True, timeout=1800,
                           env=dict(ENV, ATA_GOC=g2), cwd=g2)
        f = os.path.join(out, "ket_qua_dieu_phoi.json")
        if not os.path.exists(f) or os.path.getmtime(f) < t0:
            return dict(phan_loai="ENV_ERROR", chi_tiet=f"không có kết quả điều phối mới (exit {p.returncode}) {p.stderr[-300:]}")
        r = json.load(open(f, encoding="utf-8"))
        s3 = next(k for k in r["nhom"] if k["nhom"] == "S3"); r4f = next(k for k in r["nhom"] if k["nhom"] == "R4F")
        pl = {x["test_id"]: x["status_phan_loai"] for x in s3.get("phan_loai", [])}
        fail_s3 = sorted(pl)
        if mut[0] == "K01":
            ok = r["ma_thoat"] == 1 and p.returncode == 1 and (r4f.get("dem") or {}).get("FAIL", 0) > 0
        else:
            ok = r["ma_thoat"] == 1 and p.returncode == 1 and pl.get("HD-01") == "FAIL_CHUA_GIAI_QUYET"
        return dict(phan_loai="KILLED_EXPECTED" if ok else ("SURVIVED" if r["ma_thoat"] in (0, 2, 3) else "WRONG_REASON"), ma_thoat=r["ma_thoat"], ma_thoat_tien_trinh=p.returncode,
                    fail_s3=fail_s3, phan_loai_s3=pl, r4f_dem=r4f.get("dem"), r4f_khong_pass=[t["test_id"] for t in r4f.get("test", []) if t["status"] != "PASS"],
                    run_id_dieu_phoi=r["run_id_dieu_phoi"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    t_all = time.time()
    goc, loi = chay_mut(None)
    assert goc and not loi, loi
    bat_thuong = {k["test_id"]: k["status"] for b in ("r4", "r4f") for k in goc[b]["ket_qua"] if k["status"] != "PASS" and k["test_id"] not in CHAP_NHAN_BLOCKED}
    bang = []
    for m in DB_R4 + DB_MOI:
        t0 = time.time(); kq, loi = chay_mut(m)
        if loi:
            bang.append(dict(id=m[0], file=m[1], mo_ta=m[4], ma_dot_bien=dict(neo=m[2], thay=m[3]), test_khai_bao=m[5], phan_loai="ENV_ERROR", chi_tiet=loi)); print(m[0], "ENV_ERROR", loi); continue
        pl, kb = phan_loai(m, kq)
        khac = sorted(x["test_id"] for b in ("r4", "r4f") for x in kq[b]["ket_qua"] if x["status"] != "PASS" and x["test_id"] not in CHAP_NHAN_BLOCKED)
        bang.append(dict(id=m[0], nguon="R4 (chạy lại)" if m in DB_R4 else "R4F (mới)", file=m[1], mo_ta=m[4], ma_dot_bien=dict(neo=m[2], thay=m[3]), test_khai_bao=m[5],
                         ly_do_ky_vong=m[6], qua_ly_do=bool(len(m) > 7 and m[7]), phan_loai=pl, ket_qua_test_khai_bao={x["test_id"]: [x["status"], str(x["actual"])[:220]] for x in kb},
                         test_khong_pass=khac, run_id=dict(r4=kq["r4"]["run_id"], r4f=kq["r4f"]["run_id"]), exit=dict(r4=kq["r4"]["exit"], r4f=kq["r4f"]["exit"]),
                         thoi_gian_s=round(time.time() - t0, 1)))
        print(m[0], pl, khac)
    for m in DB_QT:
        t0 = time.time(); r = chay_qt(m)
        bang.append(dict(id=m[0], nguon="R4F (quy trình)", file=m[1], mo_ta=m[4], ma_dot_bien=dict(neo=m[2], thay=m[3]), dieu_kien_ky_vong=m[5], thoi_gian_s=round(time.time() - t0, 1), **r))
        print(m[0], r["phan_loai"], r.get("ma_thoat"), r.get("phan_loai_s3"))
    dem = {}
    for b in bang:
        dem[b["phan_loai"]] = dem.get(b["phan_loai"], 0) + 1
    out = dict(goc=dict(run_id=dict(r4=goc["r4"]["run_id"], r4f=goc["r4f"]["run_id"]), tom_tat=dict(r4=goc["r4"]["tom_tat"], r4f=goc["r4f"]["tom_tat"]), bat_thuong=bat_thuong),
               dem=dem, so_dot_bien=len(bang), tuong_duong=[], thoi_gian_s=round(time.time() - t_all, 1), dot_bien=bang)
    json.dump(out, open(os.path.join(OUT, "dot_bien_r4f.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("ĐỘT BIẾN R4F:", dem, "| bản gốc bất thường:", bat_thuong, "|", out["thoi_gian_s"], "s")
    return 0 if dem == {"KILLED_EXPECTED": len(bang)} and not bat_thuong else 1


if __name__ == "__main__":
    sys.exit(main())
