# -*- coding: utf-8 -*-
"""ẢNH HƯỞNG CỦA SỬA BUG-R4F-1 LÊN PIPELINE / F-01 / F-02 / F-03 (SYNTH). Ngoài Pine. Không dữ liệu thị trường.
python3 -B kiem_toan_r4f/so_sanh_pipeline.py --cay <gốc cây mã> --nhan <nhãn> --out <json>
Chạy pipeline.chay_synth (XAUUSD/BTCUSD × SU3/SU5 × R1/R2, seed 0–39) và ghi băm (SHA-256) của TRADES, chỉ số (chi_so), chỉ số không chồng lệnh (F-01), phễu;
đồng thời đếm số tín hiệu có nến vào R2 với thời gian ≤ nến trigger trong dữ liệu đã chuẩn hóa (điều kiện kích hoạt BUG-R4F-1)."""
import sys
sys.dont_write_bytecode = True
import argparse, hashlib, json, os   # noqa: E402

ap = argparse.ArgumentParser(); ap.add_argument("--cay", required=True); ap.add_argument("--nhan", required=True); ap.add_argument("--out", required=True); A = ap.parse_args()
G = os.path.abspath(A.cay); os.environ["ATA_GOC"] = G
sys.path.insert(0, os.path.join(G, "shadow_eval"))
import pipeline as PL, mo_phong_lenh as MP, chuan_hoa as CH   # noqa: E402
assert os.path.dirname(os.path.abspath(PL.__file__)) == os.path.join(G, "shadow_eval")
h = lambda x: hashlib.sha256(json.dumps(x, sort_keys=True, default=str, ensure_ascii=False).encode()).hexdigest()   # noqa: E731
kq, kich_hoat = {}, 0
for sd in range(40):
    r = CH.replay_synth(sd)
    b = r["bars"]
    kich_hoat += sum(1 for s in r["signals"] if r["idx"][s["trigger_ts_ms"]] + 1 < len(b) and b[r["idx"][s["trigger_ts_ms"]] + 1]["t"] <= s["trigger_ts_ms"])
    kich_hoat += sum(1 for i in range(1, len(b)) if b[i]["t"] <= b[i - 1]["t"])
for sym in ("XAUUSD", "BTCUSD"):
    for su in ("SU3", "SU5"):
        for rule in ("close", "next_open"):
            r = PL.chay_synth(sym, su, seeds=range(40), cfg=MP.Cfg(entry=rule, max_bars=60))
            kq[f"{sym}-{su}-{rule}"] = dict(so_lenh=len(r["trades"]), loi_hop_dong=len(r["loi_hop_dong"]), trades=h(r["trades"]), chi_so=h(r["chi_so"]),
                                            chi_so_khong_chong=h(r["chi_so_khong_chong"]), phieu=h(r["phieu"]), bo_chong_lan=r["bo_chong_lan"])
sha = {f: hashlib.sha256(open(os.path.join(G, "shadow_eval", f), "rb").read()).hexdigest() for f in ("mo_phong_lenh.py", "hop_dong.py", "chi_so.py", "pipeline.py", "chuan_hoa.py")}
out = dict(nhan=A.nhan, cay=G, sha=sha, so_lan_kich_hoat_dieu_kien_bug=kich_hoat, o=kq)
json.dump(out, open(A.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(A.nhan, "kích hoạt:", kich_hoat, "| tổng lệnh:", sum(v["so_lenh"] for v in kq.values()), "| băm tổng:", h(kq)[:16])
