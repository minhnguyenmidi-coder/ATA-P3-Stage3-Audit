# -*- coding: utf-8 -*-
"""CÁCH LY + TOÀN VẸN R4F (mục 6). Ngoài Pine.
python3 -B kiem_toan_r4f/kiem_cach_ly_r4f.py --goc-r4 <ZIP R4 đã giải nén> --goc-r3 <ZIP R3 đã giải nén> --zip-r4 <đường dẫn ZIP R4> [--dieu-phoi <ket_qua_dieu_phoi.json>] --out <json>
Kiểm:
  (1) so với gói R4: file sửa ĐÚNG {shadow_eval/mo_phong_lenh.py}; file mới CHỈ dưới kiem_toan_r4f/; không file nào bị xóa;
  (2) bằng chứng R4 + test cũ không đổi: kiem_toan_r4/**, kiem_doc_lap/**, shadow_eval/kiem_thu_stage3.py, shadow_eval/_truoc_r4/**;
  (3) manifest R4: mọi dòng khớp trừ đúng file đã sửa; (4) so với R3: file sửa ⊆ danh sách R4 được phép; file mới chỉ ở chỗ R4/R4F được phép;
  (5) Pine 0.3.8 / 0.3.9 đúng SHA khóa; (6) không __pycache__/.pyc; (7) phạm vi dòng thay đổi trong mo_phong_lenh.py (docstring + 1 dòng mã);
  (8) không đụng ngoài phạm vi: dashboard / D0 / D1 / token gate (token_budget, cong_tien_md6), kiem_toan039, src0*; (9) độ mới kết quả điều phối (run_id duy nhất, mtime)."""
import sys
sys.dont_write_bytecode = True
import argparse, difflib, hashlib, json, os   # noqa: E402

D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
ap = argparse.ArgumentParser(); ap.add_argument("--goc-r4", required=True); ap.add_argument("--goc-r3", required=True); ap.add_argument("--zip-r4", required=True)
ap.add_argument("--dieu-phoi", default=None); ap.add_argument("--out", required=True); A = ap.parse_args()
PINE = {"src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine": "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13",
        "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine": "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"}
ZIP_R4_SHA = "20b05cba1fe03a25c031c188194d6cff9596cd4b23941ccd61ef092d9bb969a4"
DUOC_SUA_R4F = {"shadow_eval/mo_phong_lenh.py"}
DUOC_SUA_R3 = {"shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py"}
DUOC_THEM_R4 = ("shadow_eval/_truoc_r4/", "kiem_doc_lap/chay_r4.py", "kiem_doc_lap/oracle_r4.py", "kiem_toan_r4/")
DUOC_THEM_R4F = ("kiem_toan_r4f/",)
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()   # noqa: E731


def cay(goc):
    return {os.path.relpath(os.path.join(r, f), goc): sha(os.path.join(r, f)) for r, _, fs in os.walk(goc) for f in fs}


w, r4, r3 = cay(G), cay(os.path.abspath(A.goc_r4)), cay(os.path.abspath(A.goc_r3))
kq = {}
doi4 = sorted(k for k in r4 if k in w and r4[k] != w[k]); moi4 = sorted(k for k in w if k not in r4); xoa4 = sorted(k for k in r4 if k not in w)
kq["1_so_voi_R4"] = dict(zip_r4_sha=sha(A.zip_r4), zip_r4_sha_dung=sha(A.zip_r4) == ZIP_R4_SHA, doi=doi4, doi_ngoai_phep=[k for k in doi4 if k not in DUOC_SUA_R4F],
                         so_moi=len(moi4), moi_ngoai_phep=[k for k in moi4 if not k.startswith(DUOC_THEM_R4F)], xoa=xoa4,
                         dat=set(doi4) == DUOC_SUA_R4F and not [k for k in moi4 if not k.startswith(DUOC_THEM_R4F)] and not xoa4)
bv = [k for k in r4 if k.startswith(("kiem_toan_r4/", "kiem_doc_lap/", "shadow_eval/_truoc_r4/")) or k == "shadow_eval/kiem_thu_stage3.py"]
kq["2_bang_chung_R4_va_test_cu"] = dict(so_file=len(bv), doi=[k for k in bv if w.get(k) != r4[k]], dat=all(w.get(k) == r4[k] for k in bv))
man = os.path.join(G, "kiem_toan_r4", "BAN_GIAO_R4", "ATA_P3_STAGE3_R4_MANIFEST_SHA256.txt")
dong = [x.rstrip("\n").split("  ./", 1) for x in open(man, encoding="utf-8") if x.strip()]
lech = sorted(p for h, p in dong if w.get(p) != h)
kq["3_manifest_R4"] = dict(so_dong=len(dong), lech=lech, dat=set(lech) == DUOC_SUA_R4F)
doi3 = sorted(k for k in r3 if k in w and r3[k] != w[k]); moi3 = sorted(k for k in w if k not in r3); xoa3 = sorted(k for k in r3 if k not in w)
kq["4_so_voi_R3"] = dict(doi=doi3, doi_ngoai_phep=[k for k in doi3 if k not in DUOC_SUA_R3], so_moi=len(moi3),
                         moi_ngoai_phep=[k for k in moi3 if not k.startswith(DUOC_THEM_R4 + DUOC_THEM_R4F)], xoa=xoa3,
                         dat=set(doi3) <= DUOC_SUA_R3 and not [k for k in moi3 if not k.startswith(DUOC_THEM_R4 + DUOC_THEM_R4F)] and not xoa3)
kq["5_pine"] = {p: dict(sha=w.get(p), dung=w.get(p) == h) for p, h in PINE.items()}
pyc = sorted(k for k in w if "__pycache__" in k or k.endswith(".pyc"))
kq["6_bytecode"] = dict(pyc=pyc, dat=not pyc)
a = open(os.path.join(A.goc_r4, "shadow_eval", "mo_phong_lenh.py"), encoding="utf-8").read().splitlines()
b = open(os.path.join(G, "shadow_eval", "mo_phong_lenh.py"), encoding="utf-8").read().splitlines()
hunks = [x for x in difflib.unified_diff(a, b, lineterm="", n=0) if x.startswith(("+", "-")) and not x.startswith(("+++", "---"))]
doc_end = next(i for i, x in enumerate(b) if x.strip().endswith('"""') and i > 0)
sm = difflib.SequenceMatcher(None, a, b)
ma_doi = [(tag, i1, i2, j1, j2) for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag != "equal"]
dong_ma = [j for tag, i1, i2, j1, j2 in ma_doi for j in range(j1, j2) if j > doc_end]
kq["7_pham_vi_dong"] = dict(so_dong_doi=len(hunks), dong=hunks, so_dong_ma_ngoai_docstring=len(dong_ma), dat=len(dong_ma) == 1)
ngoai = [k for k in doi4 + moi4 + xoa4 if k.startswith(("token_budget/", "cong_tien_md6/", "kiem_toan039/", "src0", "dashboard", "ket_qua039/", "kiem_toan034a/", "kiem_toan035/"))]
kq["8_ngoai_pham_vi"] = dict(dung_cham=ngoai, ghi_chu="Không có thư mục dashboard / D0 / D1 trong gói Stage 3 R4; token gate = token_budget + cong_tien_md6", dat=not ngoai)
if A.dieu_phoi:
    j = json.load(open(A.dieu_phoi, encoding="utf-8"))
    rids = j["run_id_cac_nhom"]
    from datetime import datetime
    t0 = datetime.fromisoformat(j["bat_dau"]).timestamp()
    cu = []
    for k in j["nhom"]:
        lg = os.path.join(os.path.dirname(A.dieu_phoi), k.get("log", "")) if k.get("log") else None
        if lg and os.path.exists(lg) and os.path.getmtime(lg) < t0:
            cu.append(k["nhom"])
    kq["9_do_moi"] = dict(run_id_dieu_phoi=j["run_id_dieu_phoi"], so_run_id=len(rids), run_id_duy_nhat=len(rids) == len(set(rids)), log_cu_hon_luc_bat_dau=cu,
                          sha_ma_doi_trong_luc_chay=j["sha_ma_doi"], bytecode=j["bytecode_sau"],
                          dat=len(rids) == len(set(rids)) and not cu and not j["sha_ma_doi"] and not j["bytecode_sau"])
kq["dat"] = all(v["dat"] if "dat" in v else all(x["dung"] for x in v.values()) for v in kq.values())
os.makedirs(os.path.dirname(os.path.abspath(A.out)), exist_ok=True)
json.dump(kq, open(A.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({k: (v.get("dat") if isinstance(v, dict) and "dat" in v else v) for k, v in kq.items()}, ensure_ascii=False))
print("ĐẠT" if kq["dat"] else "KHÔNG ĐẠT")
sys.exit(0 if kq["dat"] else 1)
