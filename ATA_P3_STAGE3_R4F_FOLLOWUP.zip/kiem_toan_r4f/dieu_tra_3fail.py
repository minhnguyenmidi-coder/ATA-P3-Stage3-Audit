# -*- coding: utf-8 -*-
"""ĐIỀU TRA 3 FAIL CỦA KD-REG-S3 (HD-01, OT-05, OT-06) – R4 FOLLOW-UP. Ngoài Pine. Không sửa test cũ, không sửa module.

Cách dùng (mỗi lần chạy = MỘT bộ module, chạy trong tiến trình riêng):
  PYTHONDONTWRITEBYTECODE=1 python3 -B kiem_toan_r4f/dieu_tra_3fail.py --module-dir <thư mục shadow_eval> --test-file <kiem_thu_stage3.py> --nhan R4 --out <json>
  thêm --synth <thư mục gốc cây mã> để kiểm bản ghi THẬT do adapter sinh ra (pipeline.chay_synth) bằng kiem_bang.

Phần 1 – chạy NGUYÊN VĂN 3 hàm test cũ (trích bằng AST từ test-file, bỏ decorator, không sửa thân hàm) trên bộ module chỉ định.
Phần 2 – ma trận nến hỏng (OT-05) và ma trận thời gian (OT-06) với KỲ VỌNG suy từ hợp đồng (docstring mo_phong_lenh mục KẾT CỤC +
          may_trang_thai mục B), KHÔNG suy từ mã giả lập. Mỗi ca ghi: kỳ vọng, thực tế, các trường thời gian / R / MFE / MAE, khớp hay không.
Phần 3 – HD-01: lỗi kiem_bang trên fixture gốc; fixture + STEP; từng TRADE ngoại lệ riêng; (tùy chọn) bản ghi do adapter sinh ra.
Phần 4 – ảnh hưởng lọc danh mục (khong_chong) của NO_DATA trước / sau khi vào."""
import argparse, ast, copy, importlib, json, math, os, sys, uuid, datetime as dt

ap = argparse.ArgumentParser()
ap.add_argument("--module-dir", required=True); ap.add_argument("--test-file", required=True)
ap.add_argument("--nhan", required=True); ap.add_argument("--out", required=True); ap.add_argument("--synth", default=None)
A = ap.parse_args()
MD = os.path.abspath(A.module_dir)
sys.path.insert(0, MD)
MP = importlib.import_module("mo_phong_lenh")
HD = importlib.import_module("hop_dong")
assert os.path.dirname(os.path.abspath(MP.__file__)) == MD and os.path.dirname(os.path.abspath(HD.__file__)) == MD, "nạp sai module"

# ------------------------------------------------------------------ Phần 1: trích nguyên văn test cũ
SRC = open(A.test_file, encoding="utf-8").read()
CAN = ("B", "gan", "EV0", "SIG0", "TR0", "BO0", "t_ot_bad", "t_ot_mono", "t_hd_ok")
NS = dict(MP=MP, HD=HD, copy=copy, math=math)
for n in ast.parse(SRC).body:
    if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ("S0", "FLAT", "NUL") for t in n.targets):
        exec(compile(ast.Module([n], []), A.test_file, "exec"), NS)
for n in ast.parse(SRC).body:
    if isinstance(n, ast.FunctionDef) and n.name in CAN:
        n.decorator_list = []
        exec(compile(ast.Module([n], []), A.test_file, "exec"), NS)
assert all(k in NS for k in CAN + ("S0", "FLAT")), "thiếu hàm/fixture trong test-file"
B, S0, FLAT = NS["B"], NS["S0"], NS["FLAT"]


def chay_goc(fn):
    try:
        ok, act = NS[fn]()
        return dict(status="PASS" if ok else "FAIL", actual=act)
    except Exception as ex:      # noqa: BLE001
        return dict(status="FAIL", actual=f"NGOẠI LỆ: {ex!r}")


P1 = {"OT-05": chay_goc("t_ot_bad"), "OT-06": chay_goc("t_ot_mono"), "HD-01": chay_goc("t_hd_ok")}

# ------------------------------------------------------------------ Phần 2: ma trận theo hợp đồng
TRUONG = ("outcome", "fill_note", "entry_ts_ms", "entry_price", "risk", "r_gross", "r_net", "mfe_r", "mae_r", "exit_ts_ms", "exit_price", "bars_held", "time_gaps", "max_gap_ms")
NUL_R = ("risk", "r_gross", "r_net", "mfe_r", "mae_r", "exit_ts_ms", "exit_price")
HAS_AFTER = hasattr(MP, "NO_DATA_SAU_VAO") or "INVALID_BAR_AFTER_FILL" in getattr(HD, "FILL_NOTES", ())


def cfg(rule, **kw):
    try:
        return MP.Cfg(entry=rule, **kw)
    except TypeError:
        return None


def rut(r):
    return {k: r.get(k) for k in TRUONG}


HONG = {"HIGH_NHO_HON_LOW": (2000, 1990, 2010, 2001), "HIGH_NHO_HON_MAX_OC": (2000, 1999.5, 1999, 2000), "LOW_LON_HON_MIN_OC": (2000, 2001, 2000.5, 2000.2),
        "NAN_OPEN": (float("nan"), 2001, 1999, 2000), "NAN_HIGH": (2000, float("nan"), 1999, 2000), "NAN_LOW": (2000, 2001, float("nan"), 2000),
        "NAN_CLOSE": (2000, 2001, 1999, float("nan")), "INF_HIGH": (2000, float("inf"), 1999, 2000), "NEG_INF_LOW": (2000, 2001, float("-inf"), 2000),
        "GIA_0": (0, 2001, 0, 2000), "GIA_AM": (-5, 2001, -6, 2000), "THIEU_TRUONG_C": None, "THOI_GIAN_FLOAT": "tfloat"}


def chen_hong(bars, p, kieu):
    b = copy.deepcopy(bars)
    v = HONG[kieu]
    if v is None:
        del b[p]["c"]
    elif v == "tfloat":
        b[p]["t"] = float(b[p]["t"]) + 0.5
    else:
        b[p].update(o=float(v[0]), h=float(v[1]), l=float(v[2]), c=float(v[3]))
    return b


def ky_vong_khong_vao(r, note):
    """Hợp đồng: NO_DATA trước khi vào → chưa có giá vào thực (entry_price null), R/MFE/MAE/thoát null, bars_held 0."""
    loi = []
    if r["outcome"] != "NO_DATA": loi.append(f"outcome {r['outcome']} ≠ NO_DATA")
    if r["fill_note"] != note: loi.append(f"fill_note {r['fill_note']} ≠ {note}")
    if r.get("entry_price") is not None: loi.append("entry_price phải null (chưa vào)")
    for k in NUL_R:
        if r.get(k) is not None: loi.append(f"{k} phải null")
    if r.get("bars_held") != 0: loi.append("bars_held phải 0")
    return loi


def ky_vong_sau_vao(r, note, entry_ts, entry_px):
    """Hợp đồng (R2 F29 + R4 F-01): NO_DATA SAU khi vào → giữ entry_ts/entry_price, R = null, thoát null."""
    loi = []
    if r["outcome"] != "NO_DATA": loi.append(f"outcome {r['outcome']} ≠ NO_DATA")
    if r["fill_note"] != note: loi.append(f"fill_note {r['fill_note']} ≠ {note}")
    if r.get("entry_ts_ms") != entry_ts: loi.append(f"entry_ts_ms {r.get('entry_ts_ms')} ≠ {entry_ts}")
    if r.get("entry_price") != entry_px: loi.append(f"entry_price {r.get('entry_price')} ≠ {entry_px}")
    for k in NUL_R:
        if r.get(k) is not None: loi.append(f"{k} phải null")
    return loi


def giong_cat_cut(r, ref):
    """Nến hỏng/ thời gian lỗi SAU nến thoát hoặc ngoài cửa sổ → kết quả phải trùng HOÀN TOÀN kết quả trên dữ liệu cắt trước nến đó."""
    return [f"{k}: {r.get(k)!r} ≠ {ref.get(k)!r}" for k in TRUONG if r.get(k) != ref.get(k) and not (isinstance(r.get(k), float) and isinstance(ref.get(k), float) and math.isnan(r.get(k)) and math.isnan(ref.get(k)))]


MA_TRAN_NEN, MA_TRAN_TG = [], []
T0 = 60000 * 1000000
SER_OPEN = [FLAT] * 6                                         # không chạm SL/TP → OPEN
SER_TP = [FLAT, FLAT, (2000, 2011, 1999, 2005), FLAT, FLAT]   # TP1 ở nến 2
SER_SL = [FLAT, FLAT, (2000, 2001, 1994, 1996), FLAT, FLAT]   # SL ở nến 2
SER_TO = [FLAT] * 6                                           # max_bars 3 → TIMEOUT

for rule in ("close", "next_open"):
    c0 = cfg(rule)
    if c0 is None:
        continue
    for kieu in HONG:
        # (a) nến trigger hỏng → trước khi vào (cả R1, R2)
        for p, vt in ((0, "NEN_TRIGGER"), (1, "NEN_DAU_CUA_SO"), (3, "GIUA_CUA_SO")):
            bars = chen_hong(B(SER_OPEN), p, kieu)
            r = MP.mo_phong(S0, bars, 0, c0)
            truoc_vao = p == 0 or (rule == "next_open" and p == 1)
            if truoc_vao:
                kv = "NO_DATA/INVALID_BAR (trước khi vào)"; loi = ky_vong_khong_vao(r, "INVALID_BAR")
            else:
                ets = T0 if rule == "close" else T0 + 300000
                note = "INVALID_BAR_AFTER_FILL" if HAS_AFTER else "INVALID_BAR"
                kv = f"NO_DATA/{note} (sau khi vào, giữ entry)"; loi = ky_vong_sau_vao(r, note, ets, 2000.0)
            MA_TRAN_NEN.append(dict(quy_tac=rule, kieu=kieu, vi_tri=vt, chi_so_nen=p, truoc_vao=truoc_vao, ky_vong=kv, thuc_te=rut(r), khop=not loi, lech=loi))
        # (b) nến hỏng SAU nến thoát (TP1 / SL) và ngoài cửa sổ max_bars (TIMEOUT)
        for ten, ser, cf in (("SAU_THOAT_TP1", SER_TP, c0), ("SAU_THOAT_SL", SER_SL, c0), ("NGOAI_CUA_SO_TIMEOUT", SER_TO, cfg(rule, max_bars=3))):
            p = 3 if ten != "NGOAI_CUA_SO_TIMEOUT" else (4 if rule == "close" else 5)
            ref = MP.mo_phong(S0, B(ser)[:p], 0, cf)
            r = MP.mo_phong(S0, chen_hong(B(ser), p, kieu), 0, cf)
            loi = giong_cat_cut(r, ref)
            if ref["outcome"] not in ("TP1", "SL", "TIMEOUT"): loi.append(f"tham chiếu {ref['outcome']} không phải lệnh đóng")
            MA_TRAN_NEN.append(dict(quy_tac=rule, kieu=kieu, vi_tri=ten, chi_so_nen=p, truoc_vao=False, ky_vong=f"không ảnh hưởng: = kết quả cắt trước nến {p} ({ref['outcome']})",
                                    thuc_te=rut(r), khop=not loi, lech=loi))

TG_KIEU = {"TRUNG": 0, "LUI_1_NEN": -300000, "LUI_10_NEN": -3000000}
for rule in ("close", "next_open"):
    c0 = cfg(rule)
    if c0 is None:
        continue
    for kieu, dl in TG_KIEU.items():
        for p, vt in ((1, "NEN_DAU_CUA_SO"), (3, "GIUA_CUA_SO")):
            bars = B(SER_OPEN); bars[p]["t"] = bars[p - 1]["t"] + dl
            r = MP.mo_phong(S0, bars, 0, c0)
            truoc_vao = rule == "next_open" and p == 1           # R2: nến 1 là nến VÀO – thời gian ≤ nến trigger → không thể vào sau trigger
            if truoc_vao:
                kv = "NO_DATA trước khi vào (không được vào tại/ trước nến trigger), note INVALID_BAR"
                loi = ky_vong_khong_vao(r, "INVALID_BAR")
                if r.get("entry_ts_ms") is not None and r.get("entry_price") is not None and r["entry_ts_ms"] <= T0:
                    loi.insert(0, f"VI PHẠM HỢP ĐỒNG: vào lệnh tại entry_ts_ms {r['entry_ts_ms']} ≤ trigger_ts_ms {T0}")
            else:
                ets = T0 if rule == "close" else T0 + 300000
                note = "NON_MONOTONIC_TIME_AFTER_FILL" if HAS_AFTER else "NON_MONOTONIC_TIME"
                kv = f"NO_DATA/{note} (sau khi vào, giữ entry)"; loi = ky_vong_sau_vao(r, note, ets, 2000.0)
            MA_TRAN_TG.append(dict(quy_tac=rule, kieu=kieu, vi_tri=vt, chi_so_nen=p, truoc_vao=truoc_vao, ky_vong=kv, thuc_te=rut(r), khop=not loi, lech=loi))
        # sau nến thoát TP1 → không ảnh hưởng
        bars = B(SER_TP); bars[3]["t"] = bars[2]["t"] + dl
        ref = MP.mo_phong(S0, B(SER_TP)[:3], 0, c0); r = MP.mo_phong(S0, bars, 0, c0)
        loi = giong_cat_cut(r, ref)
        MA_TRAN_TG.append(dict(quy_tac=rule, kieu=kieu, vi_tri="SAU_THOAT_TP1", chi_so_nen=3, truoc_vao=False, ky_vong=f"không ảnh hưởng: = kết quả cắt trước nến 3 ({ref['outcome']})",
                               thuc_te=rut(r), khop=not loi, lech=loi))
        # khoảng trống time_gaps trước lỗi thời gian được giữ (R1, gap ở nến 2, lỗi ở nến 4)
        if rule == "close":
            bars = B(SER_OPEN)
            for x in bars[2:]: x["t"] += 3600000
            bars[4]["t"] = bars[3]["t"] + dl
            r = MP.mo_phong(S0, bars, 0, c0)
            note = "NON_MONOTONIC_TIME_AFTER_FILL" if HAS_AFTER else "NON_MONOTONIC_TIME"
            loi = ky_vong_sau_vao(r, note, T0, 2000.0)
            if r.get("time_gaps") != 1 or r.get("max_gap_ms") != 3900000: loi.append(f"time_gaps/max_gap_ms {r.get('time_gaps')}/{r.get('max_gap_ms')} ≠ 1/3900000")
            MA_TRAN_TG.append(dict(quy_tac=rule, kieu=kieu, vi_tri="GIUA_CUA_SO_SAU_KHOANG_TRONG", chi_so_nen=4, truoc_vao=False, ky_vong=f"{note}; time_gaps 1, max_gap_ms 3900000",
                                   thuc_te=rut(r), khop=not loi, lech=loi))

# ------------------------------------------------------------------ Phần 3: HD-01
P3 = {}
if hasattr(HD, "kiem_bang"):
    ev, sg, tr = NS["BO0"]()
    TR0 = NS["TR0"]
    ngoai = dict(
        OPEN=TR0(outcome="OPEN", exit_ts_ms=None, exit_price=None, r_gross=0.4, r_net=0.4, mfe_r=0.5, mae_r=-0.1, sim_rule="R-close-sl_first-1"),
        NO_FILL=TR0(outcome="NO_FILL", fill_note="GAP_BEYOND_SL", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0,
                    entry_ts_ms=1767324300000, sim_rule="R-next_open-sl_first-288"),
        NO_DATA=TR0(outcome="NO_DATA", fill_note="NO_NEXT_BAR", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0,
                    sim_rule="R-next_open-tp_first-288"),
        INVALID=TR0(outcome="INVALID", fill_note="INVALID_RISK", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, cost_model="C-x"))
    P3["fixture_goc"] = HD.kiem_bang(ev, sg, tr + list(ngoai.values()))
    P3["chuoi_su_kien_fixture"] = [e["event_type"] for e in ev]
    step = NS["EV0"](event_id="e1b", emit_seq=1, event_type="STEP", step=1, state=0, ts="2026-01-02T03:05:00Z", ts_ms=1767323100000)
    ev2 = [ev[0], step] + [dict(e, emit_seq=e["emit_seq"] + 1) for e in ev[1:]]
    sg2 = [dict(s, emit_seq=s["emit_seq"] + 1) for s in sg]
    fix = lambda t: dict(t, emit_seq=t["emit_seq"] + 1)          # noqa: E731
    P3["fixture_them_STEP"] = HD.kiem_bang(ev2, sg2, [fix(t) for t in tr + list(ngoai.values())])
    P3["chi_TRADE_rieng"] = {k: HD.kiem_bang(ev2, sg2, [fix(v)]) for k, v in ngoai.items()}
    P3["chi_kiem_dong_TRADE"] = {k: HD.kiem(v, HD.TRADES) for k, v in ngoai.items()}
    P3["chi_kiem_dong_EVENTS"] = [HD.kiem(e, HD.EVENTS) for e in ev]
    # biến thể đảo ngược: CREATED → ARMED KHÔNG được chấp nhận ở mọi dạng (đối chứng: validator không yếu đi)
    P3["doi_chung_CREATED_ARMED_khong_signal"] = HD.kiem_bang(ev, [], [])
    if A.synth:
        sys.path.insert(0, os.path.join(os.path.abspath(A.synth), "shadow_eval"))
        PL = importlib.import_module("pipeline")
        assert os.path.dirname(os.path.abspath(PL.__file__)) == MD, "pipeline phải cùng thư mục module"
        tk = dict(o=[], tong_ev=0, tong_sg=0, tong_tr=0, loi=0, chuyen=dict(), outcome=dict(), fill_note=dict())
        for sym in ("XAUUSD", "BTCUSD"):
            for su in ("SU3", "SU5"):
                for rule in ("close", "next_open"):
                    r = PL.chay_synth(sym, su, seeds=range(40), cfg=MP.Cfg(entry=rule, max_bars=60))
                    tk["o"].append(dict(o=f"{sym}-{su}-{rule}", ev=len(r["events"]), sg=len(r["signals"]), tr=len(r["trades"]), loi_hop_dong=len(r["loi_hop_dong"]), mau_loi=r["loi_hop_dong"][:3]))
                    tk["tong_ev"] += len(r["events"]); tk["tong_sg"] += len(r["signals"]); tk["tong_tr"] += len(r["trades"]); tk["loi"] += len(r["loi_hop_dong"])
                    theo = {}
                    for e in sorted(r["events"], key=lambda e: (e["_seed"], e["emit_seq"])):
                        theo.setdefault((e["_seed"], e["setup_id"]), []).append(e["event_type"])
                    for chuoi in theo.values():
                        for a_, b_ in zip(["(bắt đầu)"] + chuoi, chuoi):
                            tk["chuyen"][f"{a_}→{b_}"] = tk["chuyen"].get(f"{a_}→{b_}", 0) + 1
                    for t in r["trades"]:
                        tk["outcome"][t["outcome"]] = tk["outcome"].get(t["outcome"], 0) + 1
                        tk["fill_note"][str(t["fill_note"])] = tk["fill_note"].get(str(t["fill_note"]), 0) + 1
        tk["CREATED→ARMED"] = tk["chuyen"].get("CREATED→ARMED", 0)
        P3["ban_ghi_adapter_sinh"] = tk

# ------------------------------------------------------------------ Phần 4: lọc danh mục
P4 = {}
if hasattr(MP, "khong_chong"):
    def tr_(sid, r, ets, xts=None, **kw):
        d = dict(signal_id=sid, symbol="XAUUSD", setup="SU5", sim_rule="R-close-sl_first-288", outcome=r, entry_ts_ms=ets, exit_ts_ms=xts, emit_seq=0, fill_note=None)
        d.update(kw); return d
    sau = MP.mo_phong(S0, chen_hong(B(SER_OPEN), 2, "HIGH_NHO_HON_LOW"), 0, cfg("close"))
    bars = B(SER_OPEN); bars[2]["t"] = bars[1]["t"]
    sau_tg = MP.mo_phong(S0, bars, 0, cfg("close"))
    truoc = MP.mo_phong(S0, chen_hong(B(SER_OPEN), 0, "HIGH_NHO_HON_LOW"), 0, cfg("close"))
    for ten, r in (("NO_DATA_SAU_VAO_NEN_HONG", sau), ("NO_DATA_SAU_VAO_THOI_GIAN", sau_tg), ("NO_DATA_TRUOC_VAO", truoc)):
        a = dict(r, signal_id="a", symbol="XAUUSD", setup="SU5", sim_rule="R-close-sl_first-288", emit_seq=0)
        b = tr_("b", "TP1", T0 + 10 * 300000, T0 + 12 * 300000, emit_seq=1, entry_price=2000.0, r_net=1.9)
        giu, bo = MP.khong_chong([a, b])
        P4[ten] = dict(outcome=r["outcome"], fill_note=r["fill_note"], lenh_sau_duoc_giu=[t["signal_id"] for t in giu], so_bo=bo)

KQ = dict(nhan=A.nhan, run_id=str(uuid.uuid4()), luc=dt.datetime.now(dt.timezone.utc).isoformat(), module_dir=MD,
          sha_module={m: __import__("hashlib").sha256(open(os.path.join(MD, m + ".py"), "rb").read()).hexdigest() for m in ("mo_phong_lenh", "hop_dong")},
          phan1_test_goc=P1,
          phan2_nen_hong=dict(so_ca=len(MA_TRAN_NEN), khop=sum(x["khop"] for x in MA_TRAN_NEN), lech=[x for x in MA_TRAN_NEN if not x["khop"]], tat_ca=MA_TRAN_NEN),
          phan2_thoi_gian=dict(so_ca=len(MA_TRAN_TG), khop=sum(x["khop"] for x in MA_TRAN_TG), lech=[x for x in MA_TRAN_TG if not x["khop"]], tat_ca=MA_TRAN_TG),
          phan3_hd01=P3, phan4_danh_muc=P4)
os.makedirs(os.path.dirname(os.path.abspath(A.out)), exist_ok=True)
json.dump(KQ, open(A.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str, allow_nan=True)
print(json.dumps(dict(nhan=A.nhan, p1={k: v["status"] for k, v in P1.items()}, nen=(KQ["phan2_nen_hong"]["khop"], len(MA_TRAN_NEN)),
                      tg=(KQ["phan2_thoi_gian"]["khop"], len(MA_TRAN_TG)), hd_goc=len(P3.get("fixture_goc", [])), hd_step=len(P3.get("fixture_them_STEP", [])),
                      adapter=(P3.get("ban_ghi_adapter_sinh") or {}).get("loi"), created_armed=(P3.get("ban_ghi_adapter_sinh") or {}).get("CREATED→ARMED")), ensure_ascii=False))
