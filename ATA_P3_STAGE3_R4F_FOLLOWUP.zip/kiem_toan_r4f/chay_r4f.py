# -*- coding: utf-8 -*-
"""BỘ KIỂM R4F (R4 FOLLOW-UP) – điều tra và khóa hành vi của 3 FAIL KD-REG-S3 (HD-01, OT-05, OT-06). Ngoài Pine. Không sửa test cũ.
python3 -B kiem_toan_r4f/chay_r4f.py [--module-dir D] [--chi ID1,ID2] --out DIR  → DIR/ket_qua_r4f.json
Trạng thái (giống chay_r4.py, không gộp): PASS · FAIL · WRONG_REASON · VALIDATOR_CRASH · ENV_ERROR · BLOCKED · NOT TESTED.
Kỳ vọng suy từ HỢP ĐỒNG (docstring mo_phong_lenh mục KẾT CỤC; may_trang_thai mục A/B), không suy từ mã giả lập.
Mã thoát: 0 nếu mọi test PASS; 1 nếu có FAIL / WRONG_REASON / VALIDATOR_CRASH / ENV_ERROR; 2 nếu chỉ còn BLOCKED / NOT TESTED."""
import sys
sys.dont_write_bytecode = True
import argparse, ast, copy, datetime as dt, hashlib, importlib, importlib.util, inspect, json, math, os, time, traceback, uuid   # noqa: E402

D = os.path.dirname(os.path.abspath(__file__)); G = os.environ.get("ATA_GOC") or os.path.dirname(D)
ap = argparse.ArgumentParser(); ap.add_argument("--module-dir", default=os.path.join(G, "shadow_eval")); ap.add_argument("--chi", default="")
ap.add_argument("--out", required=True); A = ap.parse_args()
MD = os.path.abspath(A.module_dir)
sys.path.insert(0, MD)
import mo_phong_lenh as MP, hop_dong as HD, may_trang_thai as MT   # noqa: E402
assert os.path.dirname(os.path.abspath(MP.__file__)) == MD
TEST_S3 = os.path.join(G, "shadow_eval", "kiem_thu_stage3.py")        # bộ 88 test – CHỈ ĐỌC, trích thân hàm bằng AST
R3_DIR = os.path.join(G, "shadow_eval", "_truoc_r4")                    # mã R3 (đã khóa SHA ở R4)
R4_TRUOC = os.path.join(D, "truoc_sua_r4f")                             # mo_phong_lenh R4 trước sửa BUG-R4F-1
RUN_ID, T_BAT_DAU = str(uuid.uuid4()), time.time()
KQ, TESTS, DEM = [], [], {"a": 0}


class Sai(AssertionError):
    pass


class SaiLyDo(AssertionError):
    pass


def kt(dk, mo=""):
    DEM["a"] += 1
    if not dk:
        raise Sai(mo)


def T(tid, nhom, muc_tieu, bang_chung="FACT"):
    def wrap(fn):
        def run():
            a0, t0 = DEM["a"], time.time()
            try:
                r = fn(); st, act = (r if isinstance(r, tuple) and r and r[0] in ("BLOCKED", "NOT TESTED") else ("PASS", r))
            except SaiLyDo as e:
                st, act = "WRONG_REASON", str(e)
            except Sai as e:
                st, act = "FAIL", f"assertion sai: {e}"
            except Exception as e:      # noqa: BLE001
                tb = traceback.extract_tb(e.__traceback__)
                trong_code = any(os.path.abspath(f.filename).startswith(MD + os.sep) for f in tb)
                st = "VALIDATOR_CRASH" if trong_code else "ENV_ERROR"
                act = f"{type(e).__name__}: {e} @ {tb[-1].filename.split('/')[-1]}:{tb[-1].lineno}"
            rec = dict(test_id=tid, nhom=nhom, muc_tieu=muc_tieu, bang_chung=bang_chung, status=st, so_assertion=DEM["a"] - a0, actual=act,
                       test_source=f"kiem_toan_r4f/chay_r4f.py::{fn.__name__} (dòng {inspect.getsourcelines(fn)[1]})",
                       run_time=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), duration_ms=round((time.time() - t0) * 1000, 1))
            KQ.append(rec); print(f"[{st:15}] {tid:26} a={rec['so_assertion']:<6} {muc_tieu[:76]}")
        run.tid = tid
        TESTS.append(run)
        return run
    return wrap


def nap(thu_muc, ten, bi_danh):
    """Nạp module từ thư mục khác dưới tên riêng (không đụng sys.modules của module đang kiểm)."""
    sys.path.insert(0, thu_muc)
    luu = {k: sys.modules.pop(k) for k in ("may_trang_thai",) if k in sys.modules and thu_muc != MD}
    try:
        spec = importlib.util.spec_from_file_location(bi_danh, os.path.join(thu_muc, ten + ".py")); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    finally:
        sys.path.remove(thu_muc)
        sys.modules.update(luu)
    return m


# --------------------------------------------------------------------------------------------- tiện ích dữ liệu
T0, STEP = 60000 * 1000000, 300000
BUY = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
SELL = dict(dir=-1, p_ref=2000.0, sl=2005.0, tp1=1990.0)
FLAT = (2000, 2001, 1999, 2000.5)
NUL_R = ("risk", "r_gross", "r_net", "mfe_r", "mae_r", "exit_ts_ms", "exit_price")
TRUONG = ("outcome", "fill_note", "entry_ts_ms", "entry_price", "risk", "r_gross", "r_net", "mfe_r", "mae_r", "exit_ts_ms", "exit_price", "bars_held", "time_gaps", "max_gap_ms",
          "same_bar_conflict", "gap_exit")


def B(rows, t0=T0, step=STEP):
    return [dict(t=t0 + step * i, o=float(o), h=float(h), l=float(l), c=float(c)) for i, (o, h, l, c) in enumerate(rows)]


def guong(rows, p=4000.0):
    return [(p - o, p - l, p - h, p - c) for o, h, l, c in rows]


HONG = {"HIGH_NHO_HON_LOW": (2000, 1990, 2010, 2001), "HIGH_NHO_HON_MAX_OC": (2000, 1999.5, 1999, 2000), "LOW_LON_HON_MIN_OC": (2000, 2001, 2000.5, 2000.2),
        "NAN_OPEN": (float("nan"), 2001, 1999, 2000), "NAN_HIGH": (2000, float("nan"), 1999, 2000), "NAN_LOW": (2000, 2001, float("nan"), 2000),
        "NAN_CLOSE": (2000, 2001, 1999, float("nan")), "INF_HIGH": (2000, float("inf"), 1999, 2000), "NEG_INF_LOW": (2000, 2001, float("-inf"), 2000),
        "GIA_0": (0, 2001, 0, 2000), "GIA_AM": (-5, 2001, -6, 2000), "THIEU_TRUONG_C": None, "THOI_GIAN_FLOAT": "tfloat", "THOI_GIAN_NONE": "tnone"}


def chen_hong(bars, p, kieu):
    b = copy.deepcopy(bars); v = HONG[kieu]
    if v is None:
        del b[p]["c"]
    elif v == "tfloat":
        b[p]["t"] = float(b[p]["t"]) + 0.5
    elif v == "tnone":
        b[p]["t"] = None
    else:
        b[p].update(o=float(v[0]), h=float(v[1]), l=float(v[2]), c=float(v[3]))
    return b


def la_khong_vao(r, note, tag):
    kt(r["outcome"] == "NO_DATA", f"{tag}: outcome {r['outcome']} ≠ NO_DATA")
    kt(r["fill_note"] == note, f"{tag}: fill_note {r['fill_note']} ≠ {note}")
    kt(r.get("entry_price") is None, f"{tag}: entry_price {r.get('entry_price')} phải null (chưa vào)")
    for k in NUL_R:
        kt(r.get(k) is None, f"{tag}: {k} phải null")
    kt(r.get("bars_held") == 0, f"{tag}: bars_held {r.get('bars_held')} ≠ 0")


def la_sau_vao(r, note, ets, epx, tag):
    kt(r["outcome"] == "NO_DATA", f"{tag}: outcome {r['outcome']} ≠ NO_DATA")
    kt(r["fill_note"] == note, f"{tag}: fill_note {r['fill_note']} ≠ {note}")
    kt(r.get("entry_ts_ms") == ets and r.get("entry_price") == epx, f"{tag}: entry ({r.get('entry_ts_ms')}, {r.get('entry_price')}) ≠ ({ets}, {epx})")
    for k in NUL_R:
        kt(r.get(k) is None, f"{tag}: {k} phải null")


def bang_nhau(r, ref, tag):
    for k in TRUONG:
        a, b = r.get(k), ref.get(k)
        kt(a == b or (isinstance(a, float) and isinstance(b, float) and math.isnan(a) and math.isnan(b)), f"{tag}: {k} {a!r} ≠ {b!r}")


def lenh_hop_dong(r, rule, sig_ts=T0):
    """Bản ghi TRADE dựng từ kết quả giả lập → kiểm vòng đời lệnh của máy trạng thái (may_trang_thai.kiem_lenh) và kiểm dòng TRADES."""
    t = dict(r, schema_version=HD.SCHEMA_VERSION, signal_id="s", symbol="XAUUSD", setup="SU5", emit_seq=0, sim_rule=MP.Cfg(entry=rule).rule_id(), cost_model="C-0")
    s = dict(reason=16, trigger_ts_ms=sig_ts)
    return MT.kiem_lenh(t, s, rule), HD.kiem(t, HD.TRADES)


# ============================================================================================ OT-05
@T("R4F-OT05-MA-TRAN", "OT05", "Ma trận nến hỏng 14 kiểu × vị trí (nến trigger, nến đầu cửa sổ, giữa cửa sổ, sau thoát TP1/SL, ngoài cửa sổ TIMEOUT) × R1/R2 × BUY/SELL: "
   "trước vào → NO_DATA INVALID_BAR (entry null); sau vào → INVALID_BAR_AFTER_FILL (giữ entry, R/MFE/MAE/thoát null); sau thoát / ngoài cửa sổ → không đổi kết quả")
def t_ot05_ma_tran():
    n = 0
    for chieu, sig in (("BUY", BUY), ("SELL", SELL)):
        g = (lambda rows: rows) if chieu == "BUY" else guong
        ser_open, ser_tp = g([FLAT] * 6), g([FLAT, FLAT, (2000, 2011, 1999, 2005), FLAT, FLAT])
        ser_sl = g([FLAT, FLAT, (2000, 2001, 1994, 1996), FLAT, FLAT])
        for rule in ("close", "next_open"):
            c0 = MP.Cfg(entry=rule)
            for kieu in HONG:
                hong = HONG[kieu] if isinstance(HONG[kieu], tuple) else None
                hong_g = (hong if kieu in ("GIA_0", "GIA_AM") else g([hong])[0]) if hong else None     # giá ≤ 0 không lấy gương (gương làm giá dương)
                for p in (0, 1, 3):
                    bars = B(ser_open)
                    if hong_g:
                        bars[p].update(o=float(hong_g[0]), h=float(hong_g[1]), l=float(hong_g[2]), c=float(hong_g[3]))
                    else:
                        bars = chen_hong(bars, p, kieu)
                    r = MP.mo_phong(sig, bars, 0, c0); tag = f"{chieu} {rule} {kieu} nến {p}"
                    if p == 0 and kieu == "THOI_GIAN_NONE":
                        # nến trigger không có thời gian → không xác định được trigger_ts: hành vi CÓ SẴN từ vòng 1 là INVALID / INVALID_SIGNAL (OBS-R4F-2, không đổi)
                        kt(r["outcome"] == "INVALID" and r["fill_note"] == "INVALID_SIGNAL" and r.get("entry_price") is None, f"{tag}: {r['outcome']}/{r['fill_note']}")
                    elif p == 0 or (rule == "next_open" and p == 1):
                        la_khong_vao(r, "INVALID_BAR", tag)
                    else:
                        la_sau_vao(r, "INVALID_BAR_AFTER_FILL", T0 if rule == "close" else T0 + STEP, 2000.0, tag)
                        kl, kd = lenh_hop_dong(r, rule)
                        kt(kl == [] and kd == [], f"{tag}: bản ghi vi phạm hợp đồng {kl + kd}")
                    n += 1
                for ten, ser, cf, p in (("sau TP1", ser_tp, c0, 3), ("sau SL", ser_sl, c0, 3), ("ngoài cửa sổ", g([FLAT] * 6), MP.Cfg(entry=rule, max_bars=3), 4 if rule == "close" else 5)):
                    ref = MP.mo_phong(sig, B(ser)[:p], 0, cf)
                    bars = B(ser)
                    if hong_g:
                        bars[p].update(o=float(hong_g[0]), h=float(hong_g[1]), l=float(hong_g[2]), c=float(hong_g[3]))
                    else:
                        bars = chen_hong(bars, p, kieu)
                    r = MP.mo_phong(sig, bars, 0, cf)
                    kt(ref["outcome"] in ("TP1", "SL", "TIMEOUT"), f"tham chiếu {ten}: {ref['outcome']}")
                    bang_nhau(r, ref, f"{chieu} {rule} {kieu} {ten}"); n += 1
    return dict(so_ca=n)


# ============================================================================================ OT-06
@T("R4F-OT06-MA-TRAN", "OT06", "Ma trận thời gian trùng / lùi 1 nến / lùi 10 nến × vị trí (R1 nến đầu cửa sổ, giữa cửa sổ, sau khoảng trống, sau thoát TP1) × R1/R2 × BUY/SELL: "
   "sau vào → NON_MONOTONIC_TIME_AFTER_FILL (giữ entry, R null, time_gaps trước điểm lỗi giữ nguyên); sau thoát → không đổi")
def t_ot06_ma_tran():
    n = 0
    for chieu, sig in (("BUY", BUY), ("SELL", SELL)):
        g = (lambda rows: rows) if chieu == "BUY" else guong
        for rule in ("close", "next_open"):
            c0 = MP.Cfg(entry=rule); ets = T0 if rule == "close" else T0 + STEP
            for kieu, dl in (("TRUNG", 0), ("LUI_1_NEN", -STEP), ("LUI_10_NEN", -10 * STEP)):
                vt = (1, 3) if rule == "close" else (2, 3)          # R2: nến 1 là nến VÀO – xem R4F-OT06-R2-NEN-VAO
                for p in vt:
                    bars = B(g([FLAT] * 6)); bars[p]["t"] = bars[p - 1]["t"] + dl
                    r = MP.mo_phong(sig, bars, 0, c0)
                    la_sau_vao(r, "NON_MONOTONIC_TIME_AFTER_FILL", ets, 2000.0, f"{chieu} {rule} {kieu} nến {p}")
                    kl, kd = lenh_hop_dong(r, rule); kt(kl == [] and kd == [], f"hợp đồng: {kl + kd}"); n += 1
                bars = B(g([FLAT] * 6))
                for x in bars[2:]:
                    x["t"] += 3600000
                bars[4]["t"] = bars[3]["t"] + dl
                r = MP.mo_phong(sig, bars, 0, c0)
                la_sau_vao(r, "NON_MONOTONIC_TIME_AFTER_FILL", ets, 2000.0, f"{chieu} {rule} {kieu} sau khoảng trống")
                kt(r["time_gaps"] == 1 and r["max_gap_ms"] == 3900000, f"time_gaps/max_gap_ms {r['time_gaps']}/{r['max_gap_ms']}"); n += 1
                ser = g([FLAT, FLAT, (2000, 2011, 1999, 2005), FLAT, FLAT])
                bars = B(ser); bars[3]["t"] = bars[2]["t"] + dl
                bang_nhau(MP.mo_phong(sig, bars, 0, c0), MP.mo_phong(sig, B(ser)[:3], 0, c0), f"{chieu} {rule} {kieu} sau TP1"); n += 1
    return dict(so_ca=n)


def _ca_r2_nen_vao():
    """R2: nến kế (nến VÀO) có thời gian ≤ nến trigger, với Open bình thường / Open vượt SL / Open vượt TP1, dữ liệu sau đó chạm TP1."""
    ca = []
    for chieu, sig in (("BUY", BUY), ("SELL", SELL)):
        g = (lambda rows: rows) if chieu == "BUY" else guong
        for mo_ta, nen1 in (("Open bình thường", FLAT), ("Open vượt SL", (1994, 1995, 1990, 1992)), ("Open vượt TP1", (2011, 2012, 2010.5, 2011.5))):
            for kieu, dl in (("TRUNG", 0), ("LUI_1_NEN", -STEP), ("LUI_10_NEN", -10 * STEP)):
                bars = B(g([FLAT, nen1, (2000, 2011, 1999, 2005), FLAT])); bars[1]["t"] = bars[0]["t"] + dl
                ca.append((f"{chieu} {mo_ta} {kieu}", sig, bars))
    return ca


@T("R4F-OT06-R2-NEN-VAO", "OT06", "BUG-R4F-1: R2, nến VÀO (nến kế trigger) có thời gian trùng/lùi so với nến trigger → NO_DATA INVALID_BAR TRƯỚC khi vào (entry null, R null, "
   "không chiếm vị thế); bản ghi thỏa máy trạng thái (không vào tại/ trước trigger)")
def t_ot06_r2_nen_vao():
    for tag, sig, bars in _ca_r2_nen_vao():
        r = MP.mo_phong(sig, bars, 0, MP.Cfg(entry="next_open"))
        kt(not (r.get("entry_price") is not None and r.get("entry_ts_ms") is not None and r["entry_ts_ms"] <= T0),
           f"{tag}: VÀO tại entry_ts_ms {r.get('entry_ts_ms')} ≤ trigger {T0} ({r['outcome']})")
        la_khong_vao(r, "INVALID_BAR", tag)
        kl, kd = lenh_hop_dong(r, "next_open"); kt(kl == [] and kd == [], f"{tag}: hợp đồng {kl + kd}")
        a = dict(r, signal_id="a", symbol="XAUUSD", setup="SU5", emit_seq=0)
        b = dict(signal_id="b", symbol="XAUUSD", setup="SU5", emit_seq=1, outcome="TP1", fill_note=None, entry_ts_ms=T0 + 2 * STEP, exit_ts_ms=T0 + 3 * STEP)
        giu, bo = MP.khong_chong([a, b])
        kt([t["signal_id"] for t in giu] == ["a", "b"] and bo == 0, f"{tag}: NO_DATA trước vào chiếm vị thế {[t['signal_id'] for t in giu]}")
    # R1 không bị ảnh hưởng: cùng dữ liệu, nến 1 là nến đầu cửa sổ SAU khi vào → NON_MONOTONIC_TIME_AFTER_FILL
    for tag, sig, bars in _ca_r2_nen_vao():
        r = MP.mo_phong(sig, bars, 0, MP.Cfg(entry="close"))
        la_sau_vao(r, "NON_MONOTONIC_TIME_AFTER_FILL", T0, 2000.0, "R1 " + tag)
    return dict(so_ca=2 * len(_ca_r2_nen_vao()))


@T("R4F-OT06-TAI-HIEN", "OT06", "Tái hiện BUG-R4F-1 trên mã TRƯỚC sửa (R3 _truoc_r4 và R4 truoc_sua_r4f): R2 vào lệnh tại/ trước nến trigger và ra kết cục đóng có R")
def t_ot06_tai_hien():
    kq = {}
    for nhan, thu_muc in (("R3", R3_DIR), ("R4_truoc_sua", R4_TRUOC)):
        m = nap(thu_muc, "mo_phong_lenh", f"mpl_{nhan}")
        vp = []
        for tag, sig, bars in _ca_r2_nen_vao():
            r = m.mo_phong(sig, bars, 0, m.Cfg(entry="next_open"))
            if r.get("entry_price") is not None and r.get("entry_ts_ms") is not None and r["entry_ts_ms"] <= T0:
                vp.append((tag, r["outcome"], r["entry_ts_ms"], r.get("r_gross")))
        kt(len(vp) > 0, f"{nhan}: không tái hiện được lỗi")
        kt(any(o in ("TP1", "SL", "TIMEOUT") for _, o, _, _ in vp), f"{nhan}: không có kết cục đóng sai")
        kq[nhan] = dict(so_ca_vi_pham=len(vp), mau=vp[:3])
    return kq


# ============================================================================================ HD-01
def _trich(fn_names):
    src = open(TEST_S3, encoding="utf-8").read(); ns, sha = {}, {}
    for n in ast.parse(src).body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ("S0", "FLAT", "NUL") for t in n.targets):
            exec(compile(ast.Module([n], []), TEST_S3, "exec"), ns)
    for n in ast.parse(src).body:
        if isinstance(n, ast.FunctionDef) and n.name in fn_names:
            dec = "".join(ast.get_source_segment(src, d) for d in n.decorator_list)
            sha[n.name] = hashlib.sha256((dec + ast.get_source_segment(src, n)).encode()).hexdigest()[:12]
            n.decorator_list = []
            ns.setdefault("_nodes", []).append(n)
    return ns, sha


def chay_test_goc(mp, hd):
    """Chạy NGUYÊN VĂN thân 3 test cũ trên bộ module (mp, hd)."""
    ns, sha = _trich(("B", "gan", "EV0", "SIG0", "TR0", "BO0", "t_ot_bad", "t_ot_mono", "t_hd_ok"))
    ns.update(MP=mp, HD=hd, copy=copy, math=math)
    for n in ns.pop("_nodes"):
        exec(compile(ast.Module([n], []), TEST_S3, "exec"), ns)
    out = {}
    for tid, fn in (("OT-05", "t_ot_bad"), ("OT-06", "t_ot_mono"), ("HD-01", "t_hd_ok")):
        ok, act = ns[fn]()
        out[tid] = dict(status="PASS" if ok else "FAIL", actual=act)
    return out, sha, ns


@T("R4F-HD01-HOP-DONG", "HD01", "HD-01: fixture gốc bị bác bởi ĐÚNG MỘT lỗi CREATED → ARMED; fixture + STEP → 0 lỗi (đủ TP1/OPEN/NO_FILL/NO_DATA/INVALID); bản ghi THẬT do adapter "
   "sinh (pipeline.chay_synth, XAUUSD/BTCUSD × SU3/SU5) → 0 lỗi hợp đồng và 0 chuyển tiếp CREATED → ARMED")
def t_hd01_hop_dong():
    _, _, ns = chay_test_goc(MP, HD)
    ev, sg, tr = ns["BO0"](); TR0, EV0 = ns["TR0"], ns["EV0"]
    ngoai = [TR0(outcome="OPEN", exit_ts_ms=None, exit_price=None, r_gross=0.4, r_net=0.4, mfe_r=0.5, mae_r=-0.1, sim_rule="R-close-sl_first-1"),
             TR0(outcome="NO_FILL", fill_note="GAP_BEYOND_SL", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0,
                 entry_ts_ms=1767324300000, sim_rule="R-next_open-sl_first-288"),
             TR0(outcome="NO_DATA", fill_note="NO_NEXT_BAR", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0,
                 sim_rule="R-next_open-tp_first-288"),
             TR0(outcome="INVALID", fill_note="INVALID_RISK", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, cost_model="C-x")]
    l0 = HD.kiem_bang(ev, sg, tr + ngoai)
    kt(l0 == ["MÁY TRẠNG THÁI: aaaa: chuyển tiếp không hợp lệ CREATED → ARMED"], f"fixture gốc: {l0}")
    step = EV0(event_id="e1b", emit_seq=1, event_type="STEP", step=1, ts="2026-01-02T03:05:00Z", ts_ms=1767323100000)
    ev2 = [ev[0], step] + [dict(e, emit_seq=e["emit_seq"] + 1) for e in ev[1:]]
    sg2 = [dict(s, emit_seq=s["emit_seq"] + 1) for s in sg]
    tr2 = [dict(t, emit_seq=t["emit_seq"] + 1) for t in tr + ngoai]
    kt(HD.kiem_bang(ev2, sg2, tr2) == [], f"fixture + STEP: {HD.kiem_bang(ev2, sg2, tr2)[:3]}")
    kt(sorted(t["outcome"] for t in tr2) == ["INVALID", "NO_DATA", "NO_FILL", "OPEN", "TP1"], "thiếu ngoại lệ")
    for t in tr2:
        kt(HD.kiem_bang(ev2, sg2, [t]) == [], f"{t['outcome']} riêng: {HD.kiem_bang(ev2, sg2, [t])}")
    import pipeline as PL
    kt(os.path.dirname(os.path.abspath(PL.__file__)) == MD, "pipeline nạp sai thư mục")
    tk = dict(ev=0, sg=0, tr=0, loi=0, created_armed=0, step_armed=0)
    for sym in ("XAUUSD", "BTCUSD"):
        for su in ("SU3", "SU5"):
            r = PL.chay_synth(sym, su, seeds=range(12), cfg=MP.Cfg(max_bars=60))
            tk["ev"] += len(r["events"]); tk["sg"] += len(r["signals"]); tk["tr"] += len(r["trades"]); tk["loi"] += len(r["loi_hop_dong"])
            theo = {}
            for e in sorted(r["events"], key=lambda e: (e["_seed"], e["emit_seq"])):
                theo.setdefault((e["_seed"], e["setup_id"]), []).append(e["event_type"])
            for c in theo.values():
                tk["created_armed"] += sum(1 for a, b in zip(c, c[1:]) if (a, b) == ("CREATED", "ARMED"))
                tk["step_armed"] += sum(1 for a, b in zip(c, c[1:]) if (a, b) == ("STEP", "ARMED"))
    kt(tk["ev"] > 0 and tk["step_armed"] > 0, f"bản ghi adapter quá ít để kết luận: {tk}")
    kt(tk["loi"] == 0, f"bản ghi adapter có lỗi hợp đồng: {tk}")
    kt(tk["created_armed"] == 0, f"adapter sinh CREATED → ARMED: {tk}")
    return dict(fixture_goc=l0, adapter=tk)


@T("R4F-HD01-KHONG-YEU", "HD01", "Validator KHÔNG bị nới: CREATED → ARMED, CREATED → TRIGGER, STEP → STEP, sự kiện sau kết thúc, SKIP cho SU3 đều bị bác đúng lý do; "
   "xóa STEP khỏi chuỗi THẬT của adapter → bị bác CREATED → ARMED")
def t_hd01_khong_yeu():
    def E(t, seq, su="SU5", sid="x"):
        return dict(setup_id=sid, emit_seq=seq, event_type=t, setup=su)
    ca = [([("CREATED", "SU5"), ("ARMED", "SU5")], "CREATED → ARMED"), ([("CREATED", "SU5"), ("TRIGGER", "SU5")], "CREATED → TRIGGER"),
          ([("CREATED", "SU5"), ("STEP", "SU5"), ("STEP", "SU5")], "STEP → STEP"), ([("CREATED", "SU5"), ("VOID", "SU5"), ("STEP", "SU5")], "sau sự kiện kết thúc"),
          ([("CREATED", "SU3"), ("STEP", "SU3"), ("SKIP", "SU3")], "SKIP chỉ hợp lệ cho SU5")]
    for chuoi, ly in ca:
        l_ = MT.kiem_vong_doi([E(t, i, su) for i, (t, su) in enumerate(chuoi)])
        kt(len(l_) == 1 and ly in l_[0], f"{chuoi}: {l_}")
    import chuan_hoa as CH
    r = CH.replay_synth(3, symbol="XAUUSD"); ev = r["events"]
    theo = {}
    for e in sorted(ev, key=lambda e: e["emit_seq"]):
        theo.setdefault(e["setup_id"], []).append(e)
    chon = next((sid for sid, es in theo.items() if [x["event_type"] for x in es][:3] == ["CREATED", "STEP", "ARMED"]), None)
    if chon is None:
        return ("BLOCKED", "seed 3 không có chuỗi CREATED → STEP → ARMED để làm đối chứng")
    kt(HD.kiem_bang(ev, r["signals"], []) == [], "chuỗi thật ban đầu phải hợp lệ")
    bo = [e for e in ev if not (e["setup_id"] == chon and e["event_type"] == "STEP")]
    l_ = HD.kiem_bang(bo, r["signals"], [])
    kt(any(f"{chon}: chuyển tiếp không hợp lệ CREATED → ARMED" in x for x in l_), f"xóa STEP không bị bác: {l_[:3]}")
    return dict(setup_id=chon, loi_sau_khi_xoa_STEP=l_[:2])


# ============================================================================================ ĐỐI CHIẾU R3 / R4 cho kịch bản test cũ
@T("R4F-GOC-R3-R4", "GOC", "Chạy NGUYÊN VĂN thân OT-05 / OT-06 / HD-01 (trích AST, SHA đoạn mã khớp sổ phân loại) trên mã R3 và mã đang kiểm: kết quả giống hệt; FAIL đúng chữ ký "
   "lỗi thời; nguyên nhân FAIL OT-05/OT-06 là fill_note sau-vào (giữ entry), không phải hành vi khác")
def t_goc_r3_r4():
    so = json.load(open(os.path.join(D, "phan_loai_fail.json"), encoding="utf-8"))["fail"]
    r3_mp, r3_hd = nap(R3_DIR, "mo_phong_lenh", "mpl_r3g"), None
    sys.path.insert(0, R3_DIR); luu = sys.modules.pop("may_trang_thai", None)
    try:
        spec = importlib.util.spec_from_file_location("hd_r3g", os.path.join(R3_DIR, "hop_dong.py")); r3_hd = importlib.util.module_from_spec(spec); spec.loader.exec_module(r3_hd)
    finally:
        sys.path.remove(R3_DIR)
        if luu is not None:
            sys.modules["may_trang_thai"] = luu
    a, sha, _ = chay_test_goc(r3_mp, r3_hd)
    b, _, _ = chay_test_goc(MP, HD)
    for tid in ("OT-05", "OT-06", "HD-01"):
        for fn, h in so[tid]["doan_ma_sha256_12"].items():
            kt(sha.get(fn) == h, f"{tid}: đoạn mã {fn} đổi ({sha.get(fn)} ≠ {h}) – phân loại không còn hiệu lực")
        kt(a[tid] == b[tid], f"{tid}: R3 {a[tid]} ≠ đang kiểm {b[tid]}")
        kt(b[tid]["status"] == "FAIL", f"{tid}: không còn FAIL ({b[tid]}) – cần xem lại phân loại")
        kt(json.loads(json.dumps(b[tid]["actual"])) == so[tid]["chu_ky_actual"], f"{tid}: actual {b[tid]['actual']} ≠ chữ ký {so[tid]['chu_ky_actual']}")
    S0 = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
    for hong in ((2000, 1990, 2010, 2001), (2000, float("nan"), 1999, 2000), (0, 2001, 0, 2000)):
        for m in (r3_mp, MP):
            r = m.mo_phong(S0, B([FLAT, hong]), 0)
            la_sau_vao(r, "INVALID_BAR_AFTER_FILL", T0, 2000.0, f"OT-05 {hong}")
    for lui in (0, STEP):
        for m in (r3_mp, MP):
            b_ = B([FLAT] * 4); b_[2]["t"] = b_[1]["t"] - lui
            la_sau_vao(m.mo_phong(S0, b_, 0), "NON_MONOTONIC_TIME_AFTER_FILL", T0, 2000.0, f"OT-06 lùi {lui}")
    return dict(r3=a, dang_kiem=b, sha=sha)


@T("R4F-DANH-MUC", "GOC", "Ảnh hưởng lọc danh mục: NO_DATA sau vào (nến hỏng / thời gian) chiếm vị thế tới ∞ (F-01) → lệnh sau bị bỏ; NO_DATA trước vào (INVALID_BAR, R2 nến vào lỗi thời gian) → không chiếm")
def t_danh_muc():
    S0 = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
    b_tg = B([FLAT] * 6); b_tg[2]["t"] = b_tg[1]["t"]
    b_r2 = B([FLAT] * 6); b_r2[1]["t"] = b_r2[0]["t"]
    ca = [("sau vào – nến hỏng", MP.mo_phong(S0, chen_hong(B([FLAT] * 6), 2, "HIGH_NHO_HON_LOW"), 0), True),
          ("sau vào – thời gian", MP.mo_phong(S0, b_tg, 0), True),
          ("trước vào – nến trigger hỏng", MP.mo_phong(S0, chen_hong(B([FLAT] * 6), 0, "NAN_HIGH"), 0), False),
          ("trước vào – R2 nến vào lỗi thời gian", MP.mo_phong(S0, b_r2, 0, MP.Cfg(entry="next_open")), False)]
    out = {}
    for ten, r, chiem in ca:
        a = dict(r, signal_id="a", symbol="XAUUSD", setup="SU5", emit_seq=0)
        b = dict(signal_id="b", symbol="XAUUSD", setup="SU5", emit_seq=1, outcome="TP1", fill_note=None, entry_ts_ms=T0 + 50 * STEP, exit_ts_ms=T0 + 52 * STEP)
        giu, bo = MP.khong_chong([a, b])
        ids = [t["signal_id"] for t in giu]
        kt(ids == (["a"] if chiem else ["a", "b"]) and bo == (1 if chiem else 0), f"{ten}: giữ {ids}, bỏ {bo}")
        out[ten] = dict(outcome=r["outcome"], fill_note=r["fill_note"], giu=ids)
    return out


@T("R4F-HOP-DONG-VAN-BAN", "GOC", "Văn bản hợp đồng trong docstring mo_phong_lenh không còn mâu thuẫn: quy tắc nến hỏng nêu cả INVALID_BAR (trước vào) và INVALID_BAR_AFTER_FILL (sau vào); "
   "nêu quy tắc R2 nến vào có thời gian ≤ nến trigger")
def t_van_ban():
    doc = MP.__doc__
    dong = [("• " + x).split("•")[1] for x in doc.split("• ")[1:] if x.startswith("Nến hỏng")]   # cả đoạn quy tắc (có thể nhiều dòng)
    kt(len(dong) == 1, f"phải có đúng một quy tắc nến hỏng: {dong}")
    kt("INVALID_BAR_AFTER_FILL" in dong[0] and "trong cửa sổ đánh giá → dừng, NO_DATA INVALID_BAR." not in dong[0], f"quy tắc nến hỏng còn câu cũ mâu thuẫn: {dong}")
    kt("INVALID_BAR" in dong[0].replace("INVALID_BAR_AFTER_FILL", ""), f"quy tắc nến hỏng thiếu INVALID_BAR (trước vào): {dong}")
    kt("thời gian ≤ nến trigger" in doc, "thiếu quy tắc R2 nến vào có thời gian ≤ nến trigger")
    return dong


def main():
    chi = set(x for x in A.chi.split(",") if x)
    for fn in TESTS:
        if not chi or fn.tid in chi:
            fn()
    os.makedirs(A.out, exist_ok=True)
    dem = {}
    for k in KQ:
        dem[k["status"]] = dem.get(k["status"], 0) + 1
    sha = {f: hashlib.sha256(open(os.path.join(MD, f), "rb").read()).hexdigest() for f in sorted(os.listdir(MD)) if f.endswith(".py")}
    out = dict(run_id=RUN_ID, bat_dau=dt.datetime.fromtimestamp(T_BAT_DAU, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), thoi_gian_s=round(time.time() - T_BAT_DAU, 1),
               module_dir=MD, sha_module=sha, tom_tat=dem, so_test=len(KQ), so_assertion=sum(k["so_assertion"] for k in KQ), ket_qua=KQ)
    json.dump(out, open(os.path.join(A.out, "ket_qua_r4f.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)
    print(dem, "assertion:", out["so_assertion"], out["thoi_gian_s"], "s", "run_id", RUN_ID)
    if set(dem) <= {"PASS"}:
        return 0
    return 1 if set(dem) - {"PASS", "BLOCKED", "NOT TESTED"} else 2


if __name__ == "__main__":
    sys.exit(main())
