# -*- coding: utf-8 -*-
"""BỘ ĐIỀU PHỐI CHẠY THEO NHÓM – R4 FOLLOW-UP (mục 5). Ngoài Pine. Không sửa test cũ, không tạo bytecode.
python3 -B kiem_toan_r4f/chay_nhom.py --out DIR [--nhom F01+PF,F02,...] [--kd] [--timeout-nhom S]

Nhóm:
  F01+PF, F02, F03, AD, OR, HD, ISO : bộ R4 (kiem_doc_lap/chay_r4.py, KHÔNG sửa) – gọi --chi <danh sách test của nhóm>; danh sách lấy bằng AST từ decorator @T(id, nhóm)
  R4F                               : bộ mới kiem_toan_r4f/chay_r4f.py (HD-01 / OT-05 / OT-06, BUG-R4F-1)
  S3                                : bộ Stage 3 88 test (shadow_eval/kiem_thu_stage3.py, KHÔNG sửa) chạy MỚI trong bản sao sạch + test thay thế KD-REPL-* chạy mới
                                      + áp sổ phân loại khai báo trước (kiem_toan_r4f/phan_loai_fail.json). Trạng thái gốc giữ nguyên.
  KD (tùy chọn --kd)                : hồi quy R3 đầy đủ kiem_doc_lap/chay_doc_lap.py (≈ 20–25 phút; cần bộ 0.3.9 chạy mới ở /tmp/reg039)
Mỗi nhóm: tiến trình riêng, log riêng, run_id, SHA mã trước/sau, thời gian, số assertion, đủ 7 trạng thái; kiểm output MỚI (mtime ≥ lúc bắt đầu, run_id chưa từng
thấy), kiểm không có __pycache__/.pyc trước/sau. Hết giờ → TIMEOUT (ghi nhóm, thời gian, lý do). Không bao giờ dùng kết quả cũ thay kết quả mới.
Mã thoát theo phan_loai_fail.json/chinh_sach_ma_thoat: 1 > 3 > 2 > 0."""
import sys
sys.dont_write_bytecode = True
import argparse, ast, datetime as dt, hashlib, json, os, shutil, subprocess, tempfile, time, uuid   # noqa: E402

D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
ap = argparse.ArgumentParser(); ap.add_argument("--out", required=True); ap.add_argument("--nhom", default="F01+PF,F02,F03,AD,OR,HD,ISO,R4F,S3")
ap.add_argument("--kd", action="store_true"); ap.add_argument("--timeout-nhom", type=int, default=1200); ap.add_argument("--timeout-kd", type=int, default=3600)
A = ap.parse_args()
OUT = os.path.abspath(A.out)
TRANG_THAI = ("PASS", "FAIL", "WRONG_REASON", "VALIDATOR_CRASH", "ENV_ERROR", "BLOCKED", "NOT TESTED")
RUN_ORCH = str(uuid.uuid4())
SO = json.load(open(os.path.join(D, "phan_loai_fail.json"), encoding="utf-8"))
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
RUN_ID_DA_THAY = set()


def sha_f(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def sha_ma():
    """SHA của mọi file mã có thể ảnh hưởng kết quả (module, bộ test, oracle, Pine)."""
    out = {}
    for d in ("shadow_eval", "kiem_doc_lap", "kiem_toan_r4f", "shadow_eval/_truoc_r4", "kiem_toan_r4f/truoc_sua_r4f"):
        p = os.path.join(G, d)
        for f in sorted(os.listdir(p)):
            if f.endswith((".py", ".json")) and os.path.isfile(os.path.join(p, f)):
                out[f"{d}/{f}"] = sha_f(os.path.join(p, f))
    for p in ("src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine"):
        out[p] = sha_f(os.path.join(G, p))
    return out


def bytecode():
    return sorted(os.path.relpath(os.path.join(r, x), G) for r, ds, fs in os.walk(G) for x in ds + fs if x == "__pycache__" or x.endswith(".pyc"))


def nhom_r4():
    """Danh sách test của chay_r4.py theo nhóm (AST, không chạy file)."""
    src = open(os.path.join(G, "kiem_doc_lap", "chay_r4.py"), encoding="utf-8").read(); out = {}
    for n in ast.parse(src).body:
        if isinstance(n, ast.FunctionDef):
            for d in n.decorator_list:
                if isinstance(d, ast.Call) and getattr(d.func, "id", "") == "T":
                    out.setdefault(d.args[1].value, []).append(d.args[0].value)
    return out


def dem7(ket_qua, khoa="status"):
    d = {k: 0 for k in TRANG_THAI}
    for x in ket_qua:
        d[x[khoa]] = d.get(x[khoa], 0) + 1
    return d


def chay_tien_trinh(ten, cmd, cwd, f_out, timeout, env=ENV):
    log = os.path.join(OUT, "log", f"{ten}.log"); os.makedirs(os.path.dirname(log), exist_ok=True)
    t0 = time.time(); bat_dau = dt.datetime.now(dt.timezone.utc).isoformat()
    if os.path.exists(f_out):
        os.remove(f_out)                                   # không để output cũ có thể bị đọc nhầm
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        ma, het_gio, so, se = p.returncode, False, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        ma, het_gio = None, True
        so = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        se = (e.stderr or b"").decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
    tg = round(time.time() - t0, 1)
    open(log, "w", encoding="utf-8").write(f"# nhóm {ten} · lệnh {cmd} · cwd {cwd} · bắt đầu {bat_dau} · {tg} s · mã thoát {ma} · hết giờ {het_gio}\n" + so + "\n--- stderr ---\n" + se)
    moi = os.path.exists(f_out) and os.path.getmtime(f_out) >= t0
    return dict(ma_thoat_tho=ma, het_gio=het_gio, thoi_gian_s=tg, bat_dau=bat_dau, log=os.path.relpath(log, OUT), output=f_out, output_moi=moi, t0=t0)


def nhom_json(ten, cmd, f_out, khoa_run="run_id"):
    r = chay_tien_trinh(ten, cmd, G, f_out, A.timeout_nhom)
    rec = dict(nhom=ten, lenh=" ".join(cmd[1:]), **{k: v for k, v in r.items() if k not in ("t0", "output")})
    if r["het_gio"]:
        return dict(rec, trang_thai_nhom="TIMEOUT", ly_do=f"quá {A.timeout_nhom} s", dem={k: 0 for k in TRANG_THAI})
    if not r["output_moi"]:
        return dict(rec, trang_thai_nhom="STALE_OR_MISSING", ly_do="không có output mới (mtime < lúc bắt đầu hoặc không tồn tại)", dem={k: 0 for k in TRANG_THAI})
    j = json.load(open(f_out, encoding="utf-8"))
    rid = j.get(khoa_run)
    if not rid or rid in RUN_ID_DA_THAY:
        return dict(rec, trang_thai_nhom="STALE_OR_MISSING", ly_do=f"run_id thiếu/trùng: {rid}", dem={k: 0 for k in TRANG_THAI})
    RUN_ID_DA_THAY.add(rid)
    d = dem7(j["ket_qua"])
    return dict(rec, run_id=rid, so_test=len(j["ket_qua"]), so_assertion=j.get("so_assertion"), dem=d, sha_module_trong_output=j.get("sha_module"),
                test=[dict(test_id=x["test_id"], status=x["status"], so_assertion=x.get("so_assertion"), actual=str(x.get("actual"))[:300]) for x in j["ket_qua"]],
                trang_thai_nhom="OK")


def nhom_s3(ket_r4f):
    """Bộ 88 test chạy MỚI trong bản sao sạch (không có ket_qua_stage3) + KD-REPL-* chạy mới + áp sổ phân loại."""
    tmp = tempfile.mkdtemp(prefix="r4f_s3_")
    try:
        for d in ("shadow_eval", "token_budget", "kiem_toan039", "ket_qua039", "ket_qua_shadow_eval", "kiem_doc_lap", "kiem_toan034a", "kiem_toan035", "cong_tien_md6", "kiem_toan_stage3"):
            if os.path.exists(os.path.join(G, d)):
                shutil.copytree(os.path.join(G, d), os.path.join(tmp, d), ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        for d in [x for x in os.listdir(G) if x.startswith("src0")]:
            shutil.copytree(os.path.join(G, d), os.path.join(tmp, d))
        assert not os.path.exists(os.path.join(tmp, "ket_qua_stage3")), "bản sao không sạch"
        rid = str(uuid.uuid4()); f = os.path.join(tmp, "ket_qua_stage3", "ket_qua_kiem_thu.json")
        r = chay_tien_trinh("S3_bo88", [sys.executable, "-B", os.path.join(tmp, "shadow_eval", "kiem_thu_stage3.py")], tmp, f, A.timeout_nhom, env=dict(ENV, KT_RUN_ID=rid))
        rec = dict(nhom="S3", lenh="shadow_eval/kiem_thu_stage3.py (bản sao sạch)", **{k: v for k, v in r.items() if k not in ("t0", "output")})
        if r["het_gio"]:
            return dict(rec, trang_thai_nhom="TIMEOUT", ly_do=f"quá {A.timeout_nhom} s")
        if not r["output_moi"]:
            return dict(rec, trang_thai_nhom="STALE_OR_MISSING", ly_do="không có output mới")
        j = json.load(open(f, encoding="utf-8"))
        if j.get("run_id") != rid:
            return dict(rec, trang_thai_nhom="STALE_OR_MISSING", ly_do=f"run_id {j.get('run_id')} ≠ {rid}")
        RUN_ID_DA_THAY.add(rid)
        shutil.copy(f, os.path.join(OUT, "S3_ket_qua_kiem_thu_88.json"))
        goc = {x["test_id"]: x for x in j["ket_qua"]}
        dem_goc = {"PASS": 0, "FAIL": 0, "BLOCKED": 0, "NOT TESTED": 0, "FAIL_NGOAI_LE": 0}
        for x in j["ket_qua"]:
            k = "FAIL_NGOAI_LE" if x["status"] == "FAIL" and str(x["actual"]).startswith("NGOẠI LỆ") else x["status"]
            dem_goc[k] = dem_goc.get(k, 0) + 1
        # test thay thế của R3 (KD-REPL-*) chạy MỚI
        thay_kd = sorted({t for v in SO["fail"].values() for t in v["thay_the"] if t.startswith("KD-")})
        f_kd = os.path.join(OUT, "S3_kd_repl", "ket_qua_doc_lap.json")
        r2 = chay_tien_trinh("S3_kd_repl", [sys.executable, "-B", os.path.join(G, "kiem_doc_lap", "chay_doc_lap.py"), "--chi", ",".join(thay_kd), "--out", os.path.dirname(f_kd)],
                             G, f_kd, A.timeout_nhom)
        kd = {}
        if r2["output_moi"] and not r2["het_gio"]:
            kd = {x["test_id"]: x["status"] for x in json.load(open(f_kd, encoding="utf-8"))["ket_qua"]}
        r4f = {x["test_id"]: x["status"] for x in (ket_r4f or {}).get("test", [])}
        phan_loai = []
        for tid, x in goc.items():
            if x["status"] != "FAIL":
                continue
            e = SO["fail"].get(tid)
            tc = {}
            tc["C1_co_trong_so"] = e is not None
            if e:
                tc["C3_actual_khop_chu_ky"] = json.loads(json.dumps(x["actual"])) == e["chu_ky_actual"]
                tt = {t: (kd.get(t) if t.startswith("KD-") else r4f.get(t)) for t in e["thay_the"]}
                tc["C4_thay_the_PASS_cung_lan_chay"] = all(v == "PASS" for v in tt.values())
                tc["C2_C5_qua_R4F-GOC-R3-R4"] = r4f.get("R4F-GOC-R3-R4") == "PASS"      # R4F-GOC-R3-R4 kiểm SHA đoạn mã (C2) và R3 = đang kiểm (C5)
            else:
                tt = {}
            ok = all(tc.values()) and bool(tc)
            phan_loai.append(dict(test_id=tid, status_goc="FAIL", status_phan_loai="FAIL_DA_PHAN_LOAI" if ok else "FAIL_CHUA_GIAI_QUYET",
                                  phan_loai=(e or {}).get("phan_loai"), nguyen_nhan=(e or {}).get("nguyen_nhan"), tieu_chi=tc, test_thay_the=tt, actual=x["actual"],
                                  bat_dau_fail_tu=(e or {}).get("bat_dau_fail_tu")))
        chua = [p["test_id"] for p in phan_loai if p["status_phan_loai"] != "FAIL_DA_PHAN_LOAI"]
        return dict(rec, run_id=rid, so_test=j.get("so_test"), ma_thoat_bo88=r["ma_thoat_tho"], dem_goc=dem_goc,
                    dem={"PASS": dem_goc["PASS"], "FAIL": dem_goc["FAIL"] + dem_goc["FAIL_NGOAI_LE"], "WRONG_REASON": 0, "VALIDATOR_CRASH": dem_goc["FAIL_NGOAI_LE"], "ENV_ERROR": 0,
                         "BLOCKED": dem_goc["BLOCKED"], "NOT TESTED": dem_goc["NOT TESTED"]},
                    fail_da_phan_loai=[p["test_id"] for p in phan_loai if p["status_phan_loai"] == "FAIL_DA_PHAN_LOAI"], fail_chua_giai_quyet=chua, phan_loai=phan_loai,
                    blocked=[dict(test_id=t, actual=str(x["actual"])[:200]) for t, x in goc.items() if x["status"] == "BLOCKED"],
                    not_tested=[dict(test_id=t, actual=str(x["actual"])[:200]) for t, x in goc.items() if x["status"] == "NOT TESTED"],
                    kd_repl=dict(run=dict((k, v) for k, v in r2.items() if k not in ("t0", "output")), status=kd),
                    trang_thai_nhom="OK", trang_thai_bo="PASS" if dem_goc["FAIL"] + dem_goc["FAIL_NGOAI_LE"] == 0 else ("FAIL_DA_PHAN_LOAI" if not chua else "FAIL"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def nhom_kd():
    bd = "/tmp/reg039_batdau.txt"; f39 = "/tmp/reg039/ket_qua039/ket_qua_039.json"
    if not (os.path.exists(bd) and os.path.exists(f39) and os.path.getmtime(f39) >= int(open(bd).read())):
        return dict(nhom="KD", trang_thai_nhom="BLOCKED", ly_do="bộ 0.3.9 chưa chạy mới ở /tmp/reg039 (điều kiện của KD-REG-S3)", dem={k: 0 for k in TRANG_THAI})
    f = os.path.join(OUT, "KD_day_du", "ket_qua_doc_lap.json")
    r = chay_tien_trinh("KD", [sys.executable, "-B", os.path.join(G, "kiem_doc_lap", "chay_doc_lap.py"), "--out", os.path.dirname(f)], G, f, A.timeout_kd)
    rec = dict(nhom="KD", lenh="kiem_doc_lap/chay_doc_lap.py --out ...", **{k: v for k, v in r.items() if k not in ("t0", "output")})
    if r["het_gio"]:
        return dict(rec, trang_thai_nhom="TIMEOUT", ly_do=f"quá {A.timeout_kd} s", dem={k: 0 for k in TRANG_THAI})
    if not r["output_moi"]:
        return dict(rec, trang_thai_nhom="STALE_OR_MISSING", ly_do="không có output mới", dem={k: 0 for k in TRANG_THAI})
    j = json.load(open(f, encoding="utf-8"))
    rid = f"KD-{RUN_ORCH}"; RUN_ID_DA_THAY.add(rid)
    d = dem7(j["ket_qua"])
    reg = next((x for x in j["ket_qua"] if x["test_id"] == "KD-REG-S3"), None)
    return dict(rec, run_id=rid, ghi_chu_run_id="chay_doc_lap.py không tự ghi run_id; dùng run_id điều phối + kiểm mtime", so_test=len(j["ket_qua"]), so_assertion=j.get("so_assertion"),
                dem=d, kd_reg_s3=reg, test=[dict(test_id=x["test_id"], status=x["status"], actual=str(x.get("actual"))[:200]) for x in j["ket_qua"] if x["status"] != "PASS"],
                trang_thai_nhom="OK")


def main():
    os.makedirs(OUT, exist_ok=True)
    chon = [x for x in A.nhom.split(",") if x]
    sha0, bc0, t_all = sha_ma(), bytecode(), time.time()
    if bc0:
        print("CẢNH BÁO: đã có bytecode trước khi chạy:", bc0[:5])
    nh = nhom_r4()
    tat_ca_r4 = sorted(t for v in nh.values() for t in v)
    ket, r4f = [], None
    for ten in chon:
        sha_t = sha_ma(); t0 = time.time()
        if ten == "R4F":
            k = nhom_json("R4F", [sys.executable, "-B", os.path.join(D, "chay_r4f.py"), "--out", os.path.join(OUT, "R4F")], os.path.join(OUT, "R4F", "ket_qua_r4f.json")); r4f = k
        elif ten == "S3":
            k = nhom_s3(r4f)
        else:
            ids = [t for g in ten.split("+") for t in nh.get(g, [])]
            if not ids:
                k = dict(nhom=ten, trang_thai_nhom="ENV_ERROR", ly_do="nhóm không có test", dem={x: 0 for x in TRANG_THAI})
            else:
                k = nhom_json(ten, [sys.executable, "-B", os.path.join(G, "kiem_doc_lap", "chay_r4.py"), "--chi", ",".join(ids), "--out", os.path.join(OUT, ten)],
                              os.path.join(OUT, ten, "ket_qua_r4.json"))
                k["test_khai_bao"] = ids
                if k.get("trang_thai_nhom") == "OK" and sorted(x["test_id"] for x in k["test"]) != sorted(ids):
                    k["trang_thai_nhom"] = "ENV_ERROR"; k["ly_do"] = "tập test chạy ≠ tập khai báo của nhóm"
        sha_s = sha_ma()
        k["sha_ma_truoc"], k["sha_ma_sau"] = hashlib.sha256(json.dumps(sha_t, sort_keys=True).encode()).hexdigest(), hashlib.sha256(json.dumps(sha_s, sort_keys=True).encode()).hexdigest()
        k["sha_ma_doi_trong_nhom"] = sorted(f for f in set(sha_t) | set(sha_s) if sha_t.get(f) != sha_s.get(f))
        k["bytecode_sau_nhom"] = bytecode()
        ket.append(k)
        print(f"== {ten}: {k.get('trang_thai_nhom')} {k.get('dem')} {k.get('thoi_gian_s')} s run_id {k.get('run_id')}")
    if A.kd:
        sha_t = sha_ma(); k = nhom_kd(); sha_s = sha_ma()
        k["sha_ma_doi_trong_nhom"] = sorted(f for f in set(sha_t) | set(sha_s) if sha_t.get(f) != sha_s.get(f)); k["bytecode_sau_nhom"] = bytecode()
        ket.append(k); print(f"== KD: {k.get('trang_thai_nhom')} {k.get('dem')} {k.get('thoi_gian_s')} s")
    sha1, bc1 = sha_ma(), bytecode()
    # phủ: mọi test của chay_r4.py được chạy đúng một lần trong các nhóm R4
    da_chay = sorted(t["test_id"] for k in ket if k["nhom"] not in ("R4F", "S3", "KD") for t in k.get("test", []))
    phu = dict(tong_test_r4=len(tat_ca_r4), da_chay=len(da_chay), thieu=sorted(set(tat_ca_r4) - set(da_chay)), trung=sorted({t for t in da_chay if da_chay.count(t) > 1}),
               nhom_r4={g: len(v) for g, v in nh.items()})
    tong = {x: sum((k.get("dem") or {}).get(x, 0) for k in ket) for x in TRANG_THAI}
    # mã thoát theo chính sách khai báo trước
    loi_nhom = [k["nhom"] for k in ket if k.get("trang_thai_nhom") not in ("OK", "BLOCKED")]
    s3 = next((k for k in ket if k["nhom"] == "S3"), None)
    fail_da_pl = len(s3.get("fail_da_phan_loai", [])) if s3 else 0
    fail_tong = tong["FAIL"]
    fail_chua = fail_tong - fail_da_pl
    kd = next((k for k in ket if k["nhom"] == "KD"), None)
    if kd and kd.get("trang_thai_nhom") == "OK":
        fail_chua -= 0                                           # FAIL của KD (nếu có) tính là chưa giải quyết – KD không có sổ phân loại riêng ở R4F
    nghiem = loi_nhom or fail_chua > 0 or tong["WRONG_REASON"] or tong["VALIDATOR_CRASH"] or tong["ENV_ERROR"] or bc1 or bc0 or (sha0 != sha1) or phu["thieu"] or phu["trung"]
    if nghiem:
        ma = 1
    elif fail_da_pl:
        ma = 3
    elif tong["BLOCKED"] or tong["NOT TESTED"] or any(k.get("trang_thai_nhom") == "BLOCKED" for k in ket):
        ma = 2
    else:
        ma = 0
    out = dict(run_id_dieu_phoi=RUN_ORCH, bat_dau=dt.datetime.fromtimestamp(t_all, dt.timezone.utc).isoformat(), thoi_gian_s=round(time.time() - t_all, 1),
               chinh_sach_ma_thoat=SO["chinh_sach_ma_thoat"], ma_thoat=ma, tong_7_trang_thai=tong, fail_da_phan_loai=fail_da_pl, fail_chua_giai_quyet=fail_chua,
               nhom_loi=loi_nhom, phu_nhom_r4=phu, sha_ma_truoc=sha0, sha_ma_sau=sha1, sha_ma_doi=sorted(f for f in set(sha0) | set(sha1) if sha0.get(f) != sha1.get(f)),
               bytecode_truoc=bc0, bytecode_sau=bc1, run_id_cac_nhom=sorted(RUN_ID_DA_THAY), nhom=ket)
    json.dump(out, open(os.path.join(OUT, "ket_qua_dieu_phoi.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)
    print("TỔNG:", tong, "| FAIL đã phân loại:", fail_da_pl, "| FAIL chưa giải quyết:", fail_chua, "| nhóm lỗi:", loi_nhom, "| phủ:", phu["da_chay"], "/", phu["tong_test_r4"],
          "| bytecode:", len(bc1), "| mã thoát:", ma)
    return ma


if __name__ == "__main__":
    sys.exit(main())
