# -*- coding: utf-8 -*-
"""TẠO GÓI BÀN GIAO R4F (mục 10). Số liệu đọc từ file kết quả JSON của lần chạy, không gõ tay.
python3 -B kiem_toan_r4f/tao_ban_giao_r4f.py --goc-r4 <ZIP R4 đã giải nén> → kiem_toan_r4f/BAN_GIAO_R4F/"""
import sys
sys.dont_write_bytecode = True
import argparse, csv, difflib, hashlib, json, os   # noqa: E402

D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
ap = argparse.ArgumentParser(); ap.add_argument("--goc-r4", required=True); A = ap.parse_args()
KQ = os.path.join(D, "ket_qua"); BG = os.path.join(D, "BAN_GIAO_R4F"); os.makedirs(BG, exist_ok=True)
P = "ATA_P3_STAGE3_R4F_"
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()   # noqa: E731
J = lambda *p: json.load(open(os.path.join(KQ, *p), encoding="utf-8"))   # noqa: E731

dp = J("chay_nhom", "ket_qua_dieu_phoi.json")
NH = {k["nhom"]: k for k in dp["nhom"]}
s3, kd, r4f = NH["S3"], NH.get("KD"), NH["R4F"]
dt_ = {n: J("dieu_tra", f"dieu_tra_{n}.json") for n in ("S3R1", "S3R2", "S3R3", "R4_TRUOC_SUA")}
syn = J("dieu_tra", "dieu_tra_R4_TRUOC_SUA_synth.json")["phan3_hd01"]["ban_ghi_adapter_sinh"]
syn3 = J("dieu_tra", "dieu_tra_S3R3_synth.json")["phan3_hd01"]["ban_ghi_adapter_sinh"]
r4f_truoc, r4f_r3 = J("r4f_tren_ma_R4_truoc_sua", "ket_qua_r4f.json"), J("r4f_tren_ma_R3", "ket_qua_r4f.json")
pl_a, pl_b = J("pipeline", "pipeline_R4_truoc_sua.json"), J("pipeline", "pipeline_R4F_sau_sua.json")
mu = J("dot_bien_r4f.json")
cl = J("cach_ly_r4f.json")
r39 = J("reg039_r4f", "ket_qua_039.json")
TH = next(x["actual"] for x in r4f_truoc["ket_qua"] if x["test_id"] == "R4F-OT06-TAI-HIEN")
T7 = ("PASS", "FAIL", "WRONG_REASON", "VALIDATOR_CRASH", "ENV_ERROR", "BLOCKED", "NOT TESTED")


def bang(hang, cot):
    out = ["| " + " | ".join(cot) + " |", "|" + "---|" * len(cot)]
    out += ["| " + " | ".join(str(x).replace("|", "\\|").replace("\n", " ") for x in h) + " |" for h in hang]
    return "\n".join(out)


def st_r4f(j, tid):
    return next((x["status"] for x in j["ket_qua"] if x["test_id"] == tid), "—")


# ------------------------------------------------------------------------------------------------ CSV
with open(os.path.join(BG, P + "TEST_MATRIX.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f); w.writerow(["nhom", "test_id", "status", "so_assertion", "run_id", "actual_rut_gon"])
    for k in dp["nhom"]:
        for t in k.get("test", []):
            w.writerow([k["nhom"], t["test_id"], t["status"], t.get("so_assertion", ""), k.get("run_id", ""), str(t.get("actual", ""))[:160]])
    for p in s3.get("phan_loai", []):
        w.writerow(["S3", p["test_id"], "FAIL (gốc) → " + p["status_phan_loai"], "", s3["run_id"], p["phan_loai"]])
    for b in s3.get("blocked", []):
        w.writerow(["S3", b["test_id"], "BLOCKED", "", s3["run_id"], b["actual"][:160]])
    for b in s3.get("not_tested", []):
        w.writerow(["S3", b["test_id"], "NOT TESTED", "", s3["run_id"], b["actual"][:160]])
with open(os.path.join(BG, P + "PHAN_LOAI_FAIL.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f); w.writerow(["test_id", "status_goc", "status_phan_loai", "phan_loai", "C1", "C2_C5", "C3", "C4", "test_thay_the", "bat_dau_fail_tu", "nguyen_nhan"])
    for p in s3["phan_loai"]:
        tc = p["tieu_chi"]
        w.writerow([p["test_id"], p["status_goc"], p["status_phan_loai"], p["phan_loai"], tc.get("C1_co_trong_so"), tc.get("C2_C5_qua_R4F-GOC-R3-R4"), tc.get("C3_actual_khop_chu_ky"),
                    tc.get("C4_thay_the_PASS_cung_lan_chay"), json.dumps(p["test_thay_the"], ensure_ascii=False), p["bat_dau_fail_tu"], p["nguyen_nhan"]])
with open(os.path.join(BG, P + "MUTATION.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f); w.writerow(["id", "nguon", "file", "mo_ta", "neo", "thay", "test_khai_bao", "ly_do_ky_vong", "phan_loai", "bang_chung"])
    for m in mu["dot_bien"]:
        bc = m.get("ket_qua_test_khai_bao") or dict(ma_thoat=m.get("ma_thoat"), phan_loai_s3=m.get("phan_loai_s3"), r4f_khong_pass=m.get("r4f_khong_pass"))
        w.writerow([m["id"], m.get("nguon"), m["file"], m["mo_ta"], m["ma_dot_bien"]["neo"], m["ma_dot_bien"]["thay"], ";".join(m.get("test_khai_bao", [])) or m.get("dieu_kien_ky_vong", ""),
                    m.get("ly_do_ky_vong", ""), m["phan_loai"], json.dumps(bc, ensure_ascii=False)[:400]])
bl = []
for k in dp["nhom"]:
    for t in k.get("test", []):
        if t["status"] in ("BLOCKED", "NOT TESTED"):
            bl.append((k["nhom"], t["test_id"], t["status"], t.get("actual", "")[:200]))
for b in s3["blocked"]:
    bl.append(("S3 (bộ 88)", b["test_id"], "BLOCKED", b["actual"]))
for b in s3["not_tested"]:
    bl.append(("S3 (bộ 88)", b["test_id"], "NOT TESTED", b["actual"]))
for x in r39["results"]:
    s = x.get("status") or x.get("result")
    if s in ("BLOCKED", "NOT TESTED"):
        bl.append(("0.3.9 (bộ 56)", x.get("id") or x.get("test_id"), s, str(x.get("note") or x.get("actual") or x.get("detail") or "")[:200]))
with open(os.path.join(BG, P + "BLOCKED_NOT_TESTED.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f); w.writerow(["bo", "test_id", "status", "ly_do"]); w.writerows(bl)

# ------------------------------------------------------------------------------------------------ DIFF + SHA
a = open(os.path.join(A.goc_r4, "shadow_eval", "mo_phong_lenh.py"), encoding="utf-8").read().splitlines(keepends=True)
b = open(os.path.join(G, "shadow_eval", "mo_phong_lenh.py"), encoding="utf-8").read().splitlines(keepends=True)
moi = sorted(os.path.relpath(os.path.join(r, f), G) for r, _, fs in os.walk(D) for f in fs if not os.path.relpath(os.path.join(r, f), G).startswith("kiem_toan_r4f/BAN_GIAO_R4F/"))
with open(os.path.join(BG, P + "DIFF.patch"), "w", encoding="utf-8") as f:
    f.write("# R4F so với gói R4 (ZIP SHA 20b05cba…): 1 file sửa + file mới dưới kiem_toan_r4f/ (danh sách cuối file)\n")
    f.writelines(difflib.unified_diff(a, b, "a/shadow_eval/mo_phong_lenh.py", "b/shadow_eval/mo_phong_lenh.py"))
    f.write("\n# FILE MỚI (" + str(len(moi)) + "):\n" + "".join(f"#   {x}\n" for x in moi))
open(os.path.join(BG, P + "SHA_SAU_SUA.txt"), "w").write("".join(f"{sha(os.path.join(G, p))}  {p}\n" for p in
                                                                 ("shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py", "shadow_eval/may_trang_thai.py",
                                                                  "shadow_eval/kiem_thu_stage3.py", "kiem_doc_lap/chay_r4.py", "kiem_doc_lap/chay_doc_lap.py",
                                                                  "kiem_toan_r4f/chay_r4f.py", "kiem_toan_r4f/chay_nhom.py", "kiem_toan_r4f/dot_bien_r4f.py",
                                                                  "kiem_toan_r4f/kiem_cach_ly_r4f.py", "kiem_toan_r4f/phan_loai_fail.json")))
open(os.path.join(BG, P + "SHA_PINE.txt"), "w").write("".join(f"{sha(os.path.join(G, p))}  {p}\n" for p in
                                                              ("src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine")))

# ------------------------------------------------------------------------------------------------ BÁO CÁO
dem_nen = {n: (v["phan2_nen_hong"]["khop"], v["phan2_nen_hong"]["so_ca"]) for n, v in dt_.items()}
dem_tg = {n: (v["phan2_thoi_gian"]["khop"], v["phan2_thoi_gian"]["so_ca"]) for n, v in dt_.items()}
p1 = {n: {k: v["phan1_test_goc"][k]["status"] for k in ("OT-05", "OT-06", "HD-01")} for n, v in dt_.items()}
mu_dem = mu["dem"]
kd_dem = (kd or {}).get("dem", {})
reg = (kd or {}).get("kd_reg_s3") or {}
tong = dp["tong_7_trang_thai"]
L = []
A_ = L.append
A_("# ATA P3 – STAGE 3 – R4 INDEPENDENT AUDIT FOLLOW-UP (R4F) – BÁO CÁO GỘP\n")
A_(f"Gói gốc: ATA_P3_STAGE3_R4_AUDIT_CORRECTION.zip (SHA-256 {cl['1_so_voi_R4']['zip_r4_sha']}). Pine 0.3.8 / 0.3.9 KHÔNG đổi (SHA ở mục 7). "
   "Ký hiệu: FACT (đã kiểm bằng mã, có bằng chứng) · PARTIALLY VERIFIED · ASSUMPTION · HYPOTHESIS · RECOMMENDATION. Trạng thái test: PASS · FAIL · WRONG_REASON · "
   "VALIDATOR_CRASH · ENV_ERROR · BLOCKED · NOT TESTED (không gộp). Thuật ngữ: *fill* = khớp lệnh/vào lệnh; *fixture* = bộ dữ liệu mẫu cố định của test; "
   "*mutant* (đột biến) = bản mã bị cố ý làm sai một chỗ để xem test có bắt được không.\n")
A_("## 0. Kết luận ngắn\n")
A_(bang([
    ("HD-01", "FAIL gốc giữ nguyên → FAIL_DA_PHAN_LOAI", "Lỗi ở TEST (fixture thiếu sự kiện STEP so với hợp đồng máy trạng thái thêm từ Stage 3 vòng 2). Validator đúng, không nới. Mã R3 = R4.", "FACT"),
    ("OT-05", "FAIL gốc giữ nguyên → FAIL_DA_PHAN_LOAI", "Lỗi ở TEST (assertion trước F29) + 1 câu VĂN BẢN hợp đồng cũ mâu thuẫn trong docstring (đã sửa câu chữ). Hành vi R3 = R4, đúng hợp đồng ở cả "
     f"{dem_nen['R4_TRUOC_SUA'][1]} ca nến hỏng.", "FACT"),
    ("OT-06", "FAIL gốc giữ nguyên → FAIL_DA_PHAN_LOAI", "Lỗi ở TEST (assertion trước F29) cho đúng kịch bản của test. NHƯNG khi kiểm ma trận phát hiện LỖI CODE thật cùng chủ đề "
     "(BUG-R4F-1: R2 vào lệnh tại/trước nến trigger khi nến kế có thời gian trùng/lùi) – có từ Stage 3 vòng 1, không do R4; đã sửa tối thiểu 1 dòng, có test tái hiện.", "FACT"),
    ("KD-REG-S3", f"bộ 88: PASS {s3['dem_goc']['PASS']} / FAIL {s3['dem_goc']['FAIL']} / BLOCKED {s3['dem_goc']['BLOCKED']} / NOT TESTED {s3['dem_goc']['NOT TESTED']}, exit {s3['ma_thoat_bo88']}",
     f"Trạng thái bộ = {s3['trang_thai_bo']} (KHÔNG phải PASS). Mã thoát điều phối = {dp['ma_thoat']} (3 = chỉ còn FAIL đã phân loại theo sổ khai báo trước).", "FACT"),
    ("Chạy lại toàn bộ R4", f"{dp['phu_nhom_r4']['da_chay']}/{dp['phu_nhom_r4']['tong_test_r4']} test R4, 7 nhóm + R4F + S3" + (" + KD đầy đủ" if kd else ""),
     f"Tổng 7 trạng thái: {tong}. Không TIMEOUT, không output cũ, không bytecode.", "FACT"),
    ("Đột biến", f"{mu['so_dot_bien']} đột biến", f"{mu_dem}", "FACT"),
    ("Cách ly", "ĐẠT" if cl["dat"] else "KHÔNG ĐẠT", "1 file sửa (mo_phong_lenh.py) so với R4; file mới chỉ trong kiem_toan_r4f/; Pine đúng SHA; bằng chứng R4 không đổi.", "FACT"),
], ("Hạng mục", "Trạng thái", "Kết luận", "Loại")))
A_("\n**Đề xuất đóng (RECOMMENDATION):** xem mục 11 – đủ 6 điều kiện của mục 11 đề bài; các giới hạn thị trường thật / token / replay đầy đủ vẫn BLOCKED / NOT TESTED và không bị tính là PASS.\n")

A_("## 1. Phương pháp điều tra (không mặc định là lỗi lịch sử)\n")
A_("- Đọc thân 3 test trong `shadow_eval/kiem_thu_stage3.py` (OT-05 dòng 206, OT-06 dòng 215, HD-01 dòng 418), fixture `B`, `S0`, `FLAT`, `EV0/SIG0/TR0/BO0`.\n"
   "- Trích NGUYÊN VĂN các hàm đó bằng AST (bỏ decorator, không sửa thân) và chạy trên 4 thế hệ mã: Stage 3 vòng 1 (ATA_P3_Stage3_Audit_Correction.zip), vòng 2 "
   "(ATA_P3_Stage3_Correction_R2.zip), vòng 3 (ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION.zip = `_truoc_r4`), R4 trước sửa. SHA đoạn mã test giống hệt ở cả 4 thế hệ (FACT).\n"
   "- Dựng ma trận ca với KỲ VỌNG suy từ hợp đồng (docstring `mo_phong_lenh` mục KẾT CỤC; `may_trang_thai` mục A/B), không suy từ mã giả lập.\n"
   "- Công cụ: `kiem_toan_r4f/dieu_tra_3fail.py` (kết quả `ket_qua/dieu_tra/*.json`), bộ test mới `kiem_toan_r4f/chay_r4f.py`.\n")
A_(bang([(n, p1[n]["OT-05"], p1[n]["OT-06"], p1[n]["HD-01"], f"{dem_nen[n][0]}/{dem_nen[n][1]}", f"{dem_tg[n][0]}/{dem_tg[n][1]}") for n in ("S3R1", "S3R2", "S3R3", "R4_TRUOC_SUA")],
        ("Thế hệ mã", "OT-05 (test cũ)", "OT-06 (test cũ)", "HD-01 (test cũ)", "Ma trận nến hỏng khớp hợp đồng", "Ma trận thời gian khớp hợp đồng")))
A_("\nFACT: cả 3 test PASS ở vòng 1 và FAIL từ vòng 2 trở đi; R3 và R4 cho actual giống hệt (kiểm bằng R4F-GOC-R3-R4). 3 ca lệch của ma trận thời gian ở MỌI thế hệ là BUG-R4F-1 (mục 4).\n")

A_("## 2. HD-01 – báo cáo\n")
hd = dt_["R4_TRUOC_SUA"]["phan3_hd01"]
A_(bang([
    ("Nguyên nhân chính xác", f"`kiem_bang` trả đúng 1 lỗi: `{hd['fixture_goc'][0]}`. Fixture BO0 có chuỗi sự kiện {hd['chuoi_su_kien_fixture']} – thiếu STEP."),
    ("Quy tắc hợp đồng", "`may_trang_thai.py` mục A: CREATED → {STEP, VOID, EXPIRED}; ghi rõ 'Không hợp lệ: CREATED → ARMED (bỏ qua st 1)'. Suy từ Pine 0.3.9: st chỉ tăng 0 → 1 → 2 "
     "(SU-3: MSS H1 dòng 2834 rồi bước 4 dòng 3553–3556; SU-5: rời mức dòng 3559 rồi bước 3 dòng 3563, chuỗi else-if nên không cùng nến). Adapter `chuan_hoa._buoc_trung_gian` "
     "luôn phát STEP khi st đi qua 1, kể cả khi st nhảy 0 → 2 trong một nến."),
    ("Hành vi R3 / R4", "Giống hệt (cùng 1 lỗi). Máy trạng thái được đưa vào kiem_bang từ Stage 3 vòng 2 (hop_dong 1.2); vòng 1 không có → test PASS ở vòng 1."),
    ("Kết quả thực tế vs kỳ vọng", "Test kỳ vọng 0 lỗi; thực tế 1 lỗi đúng quy tắc. Fixture + STEP → 0 lỗi; từng TRADE ngoại lệ OPEN / NO_FILL / NO_DATA / INVALID riêng lẻ → 0 lỗi."),
    ("Bản ghi hợp lệ THẬT", f"Bản ghi do adapter sinh (pipeline.chay_synth, 8 ô × 40 seed): {syn['tong_ev']} EVENTS, {syn['tong_sg']} SIGNALS, {syn['tong_tr']} TRADES → {syn['loi']} lỗi hợp đồng; "
     f"chuyển tiếp STEP→ARMED = {syn['chuyen'].get('STEP→ARMED', 0)}, CREATED→ARMED = {syn['CREATED→ARMED']}. R3 cho cùng số liệu ({syn3['tong_ev']} / {syn3['loi']} lỗi / CREATED→ARMED {syn3['CREATED→ARMED']})."),
    ("Validator không bị nới", "R4F-HD01-KHONG-YEU: CREATED→ARMED, CREATED→TRIGGER, STEP→STEP, sự kiện sau kết thúc, SKIP cho SU3 đều bị bác đúng lý do; xóa STEP khỏi chuỗi THẬT → bị bác. "
     "Không sửa validator."),
    ("Lỗi nằm ở", "TEST (fixture lỗi thời so với hợp đồng). Không phải code, không phải hợp đồng. Phân loại: TEST_LOI_THOI."),
    ("Ảnh hưởng F-01 / F-02 / F-03 / replay", "Không. F-02: TRADE INVALID dùng cost_model 'C-x' (không bắt đầu 'C-s' → mã tự do) được chấp nhận ở cả R3 và R4 (chi_TRADE_rieng = 0 lỗi). "
     "F-01/F-03 không liên quan đến kiem_bang sự kiện. Replay: adapter không bao giờ sinh CREATED→ARMED."),
    ("Thay thế", "KD-REPL-HD01S3 (R3), R4F-HD01-HOP-DONG, R4F-HD01-KHONG-YEU – PASS trong lần chạy điều phối."),
], ("Mục", "Nội dung (FACT)")))

A_("\n## 3. OT-05 – báo cáo\n")
nen = dt_["R4_TRUOC_SUA"]["phan2_nen_hong"]["tat_ca"]
vt = {}
for x in nen:
    vt.setdefault((x["quy_tac"], x["vi_tri"]), [0, 0]); vt[(x["quy_tac"], x["vi_tri"])][1] += 1; vt[(x["quy_tac"], x["vi_tri"])][0] += x["khop"]
A_(bang([(q, v_, f"{k}/{n}", next(x["ky_vong"] for x in nen if x["quy_tac"] == q and x["vi_tri"] == v_)) for (q, v_), (k, n) in vt.items()],
        ("Quy tắc vào", "Vị trí nến hỏng", "Khớp", "Kỳ vọng theo hợp đồng")))
A_("\n13 kiểu nến hỏng trong điều tra (High < Low, High < max(O,C), Low > min(O,C), NaN ở O/H/L/C, +∞, −∞, giá 0, giá âm, thiếu trường, thời gian không phải số nguyên); bộ test R4F "
   "thêm 'thời gian None' và nhân đôi BUY/SELL.\n")
A_(bang([
    ("Nguyên nhân chính xác", "Kịch bản R1: nến 0 là nến trigger, lệnh VÀO tại Close nến 0; nến hỏng ở nến 1 là nến SAU khi vào. Mã trả NO_DATA `INVALID_BAR_AFTER_FILL` (giữ entry_ts / entry_price, "
     "R / MFE / MAE / thoát = null). Test cũ đòi `INVALID_BAR`. actual của test chỉ ghi outcome (['NO_DATA'×3], 'TP1') nên nhìn actual không thấy lý do; R4F-GOC-R3-R4 kiểm trực tiếp fill_note."),
    ("Quy tắc hợp đồng", "docstring mo_phong_lenh mục KẾT CỤC (từ F29, vòng 2): NO_DATA trước khi vào = NO_NEXT_BAR / INVALID_BAR (không chiếm vị thế); sau khi vào = INVALID_BAR_AFTER_FILL / "
     "NON_MONOTONIC_TIME_AFTER_FILL (đã vào, kết quả không xác định; R4 F-01: chiếm vị thế tới ∞). may_trang_thai mục B và FILL_NOTES của hop_dong khớp."),
    ("Khác biệt R3 / R4 chính xác", "Hành vi giả lập: KHÔNG khác (ma trận R3 = R4 từng ca). Khác biệt duy nhất liên quan là lọc danh mục: R4 F-01 cho NO_DATA sau vào chiếm vị thế (R3: không) – "
     "R4F-DANH-MUC: trên mã R3 FAIL đúng chỗ 'sau vào – nến hỏng: giữ [a, b]'."),
    ("Trước vào", "Nến trigger hỏng (R1, R2) và nến vào hỏng (R2) → NO_DATA INVALID_BAR, entry_price null, R/MFE/MAE/thoát null, bars_held 0 – khớp."),
    ("Sau nến thoát / ngoài cửa sổ", "Nến hỏng sau nến thoát TP1/SL hoặc sau nến thứ max_bars (TIMEOUT) → kết quả TRÙNG HOÀN TOÀN với kết quả trên dữ liệu cắt trước nến đó (mọi trường, gồm MFE/MAE/exit_ts) – khớp."),
    ("Văn bản hợp đồng", "Phát hiện thêm: dòng quy tắc 'Nến hỏng … trong cửa sổ đánh giá → dừng, NO_DATA INVALID_BAR' trong docstring là câu CŨ trước F29, mâu thuẫn với mục KẾT CỤC cùng file. "
     "Đã sửa CÂU CHỮ (không đổi mã) – khóa bằng R4F-HOP-DONG-VAN-BAN."),
    ("Quan sát không sửa (OBS-R4F-2)", "Nến trigger có thời gian None → INVALID / INVALID_SIGNAL (không xác định được trigger_ts), không phải NO_DATA INVALID_BAR. Hành vi có từ vòng 1, ngoài phạm vi; ghi lại."),
    ("Quan sát không sửa (OBS-R4F-3)", "NO_DATA sau vào ghi bars_held = 0 dù đã vào. Hợp đồng không quy định bars_held cho NO_DATA; không đổi (ASSUMPTION: chỉ đếm, không vào thống kê R)."),
    ("Lỗi nằm ở", "TEST (assertion lỗi thời) + văn bản hợp đồng (1 câu cũ). Code đúng hợp đồng."),
    ("Ảnh hưởng F-01 / F-02 / F-03 / replay", "F-01: NO_DATA sau vào chiếm vị thế tới ∞ (đúng chủ đích R4) → lệnh sau cùng ô bị bỏ. F-02/F-03: không. Replay: pipeline chuẩn hóa nến nhưng không sửa giá; "
     "nến hỏng làm kiem_ohlcv FAIL trước khi giả lập."),
    ("Thay thế", "KD-REPL-OT05, R4F-OT05-MA-TRAN, R4F-GOC-R3-R4 – PASS."),
], ("Mục", "Nội dung (FACT trừ khi ghi khác)")))

A_("\n## 4. OT-06 – báo cáo (kèm BUG-R4F-1)\n")
tg = dt_["R4_TRUOC_SUA"]["phan2_thoi_gian"]
A_(bang([(x["quy_tac"], x["kieu"], x["vi_tri"], "khớp" if x["khop"] else "LỆCH: " + "; ".join(x["lech"][:2]), x["thuc_te"]["outcome"], x["thuc_te"]["fill_note"],
          x["thuc_te"]["entry_ts_ms"]) for x in tg["tat_ca"]], ("Quy tắc", "Kiểu", "Vị trí", "Kết quả (mã R4 trước sửa)", "outcome", "fill_note", "entry_ts_ms")))
A_("\n" + bang([
    ("Điều kiện phát hiện", "Trong vòng lặp đánh giá: `k > ie and b['t'] <= t_prev` (t_prev khởi tạo = thời gian nến vào). R1: nến vào = nến trigger nên nến 1 được so với nến trigger. "
     "R2: nến vào = nến kế, vòng lặp bắt đầu TẠI nến vào nên điều kiện `k > ie` bỏ qua phép so nến vào với nến trigger."),
    ("Nguyên nhân FAIL của test cũ", "Kịch bản test (R1, lỗi ở nến 2) → mã trả NON_MONOTONIC_TIME_AFTER_FILL (giữ entry, R null). Test đòi NON_MONOTONIC_TIME – ghi chú đã bị loại khỏi FILL_NOTES từ vòng 2 (F29). "
     "Lỗi ở TEST cho kịch bản này."),
    ("Sau vào vs trước vào", "Sau vào (R1 nến ≥ 1; R2 nến ≥ 2): NON_MONOTONIC_TIME_AFTER_FILL, entry giữ, R/MFE/MAE/thoát null, time_gaps trước điểm lỗi được giữ (1 khoảng, max_gap 3 900 000 ms) – khớp. "
     "Sau nến thoát: không ảnh hưởng – khớp. TRƯỚC vào (R2 nến vào): xem BUG-R4F-1."),
    ("BUG-R4F-1 – ở đâu", "shadow_eval/mo_phong_lenh.py, hàm mo_phong, nhánh R2 (cfg.entry == 'next_open'), dòng kiểm nến kế (dòng 105 sau sửa)."),
    ("BUG-R4F-1 – nguyên nhân kỹ thuật", "Nến kế chỉ được kiểm nen_hong (giá/kiểu thời gian), không kiểm thời gian > nến trigger. Nến kế có thời gian trùng hoặc lùi vẫn được dùng làm nến vào."),
    ("BUG-R4F-1 – hành vi sai", f"Trên mã R3 và R4 trước sửa: {TH['R4_truoc_sua']['so_ca_vi_pham']} / 18 ca R2 (R3: {TH['R3']['so_ca_vi_pham']} / 18) "
     "VÀO lệnh với entry_ts_ms ≤ trigger_ts_ms và ra kết cục TP1/SL/OPEN có R (ví dụ: trùng thời gian → TP1, r_gross 2,0). Vi phạm may_trang_thai mục B ('R2 phải vào sau nến trigger') – "
     "bản ghi này bị kiem_lenh bác nếu đi qua kiểm hợp đồng."),
    ("BUG-R4F-1 – ảnh hưởng giao dịch thật", "FACT: đường pipeline hiện tại KHÔNG chạm được lỗi: du_lieu.chuan_hoa sắp xếp theo t và bỏ dòng trùng giống hệt; trùng mâu thuẫn làm kiem_ohlcv FAIL. "
     f"Điều kiện kích hoạt xuất hiện {pl_b['so_lan_kich_hoat_dieu_kien_bug']} lần trên SYNTH 40 seed; băm TRADES / chỉ số / chỉ số không chồng (F-01) / phễu của 8 ô trước và sau sửa "
     f"{'GIỐNG HỆT' if pl_a['o'] == pl_b['o'] else 'KHÁC'}. Ảnh hưởng chỉ tồn tại với bên gọi mo_phong trực tiếp bằng dữ liệu chưa chuẩn hóa: một lệnh 'vào trước tín hiệu' được tính R "
     "(thống kê lạc quan/sai) và (nếu OPEN) chiếm vị thế tới ∞, chặn lệnh sau (R4F-DANH-MUC trên mã trước sửa: 'giữ [a], bỏ 1')."),
    ("BUG-R4F-1 – sửa", "Một điều kiện: `if nen_hong(bars[i_trig + 1]) or bars[i_trig + 1]['t'] <= t_trig:` → NO_DATA INVALID_BAR (chưa vào). Thêm 3 dòng docstring. Không đổi hợp đồng dữ liệu, "
     "không đổi máy trạng thái."),
    ("BUG-R4F-1 – lựa chọn ghi chú (ASSUMPTION)", "Dùng INVALID_BAR (đã có trong FILL_NOTES và NOTE_TRUOC_VAO; nen_hong vốn coi thời gian sai kiểu là nến hỏng). Không thêm ghi chú mới vì sẽ phải sửa "
     "may_trang_thai.py (ngoài danh sách file được sửa). RECOMMENDATION: nếu chủ dự án muốn tách riêng, thêm NON_MONOTONIC_TIME_BEFORE_FILL ở vòng sau (đổi hợp đồng có chủ đích)."),
    ("BUG-R4F-1 – rủi ro của bản sửa", "(a) Tín hiệu R2 có dữ liệu trùng thời gian giờ thành NO_DATA (không còn TP1/SL giả) → số lệnh đóng có thể giảm với dữ liệu bẩn; (b) không ảnh hưởng R1; "
     "(c) oracle độc lập kiem_doc_lap/oracle.py có CÙNG điểm mù (không kiểm thời gian nến vào R2) – không sửa oracle cũ; xem rủi ro tồn đọng RR-2."),
    ("BUG-R4F-1 – cách kiểm", "R4F-OT06-R2-NEN-VAO (18 ca R2 + 18 ca R1 đối chứng; kiểm máy trạng thái, lọc danh mục), R4F-OT06-TAI-HIEN (tái hiện trên R3 và R4 trước sửa), "
     "đột biến N01/N02/N03 (đều KILLED_EXPECTED – mục 8)."),
    ("Ảnh hưởng lọc danh mục", "NO_DATA sau vào (thời gian) chiếm vị thế tới ∞ (F-01) → lệnh sau bị bỏ; NO_DATA trước vào (gồm ca R2 mới) không chiếm – R4F-DANH-MUC PASS."),
    ("Lỗi nằm ở", "TEST (assertion lỗi thời) cho kịch bản test cũ + CODE (BUG-R4F-1, kịch bản khác cùng chủ đề, có từ vòng 1)."),
    ("Thay thế", "KD-REPL-OT06, R4F-OT06-MA-TRAN, R4F-OT06-R2-NEN-VAO, R4F-GOC-R3-R4 – PASS."),
], ("Mục", "Nội dung (FACT trừ khi ghi khác)")))

A_("\n## 5. KD-REG-S3 – tóm tắt trạng thái và mã thoát\n")
A_("**Vì sao báo cáo R4 ghi 'KD-REG-S3 PASS':** KD-REG-S3 là một test HỒI QUY của bộ R3 (kiem_doc_lap/chay_doc_lap.py). Nó PASS khi tập FAIL của bộ 88 test BẰNG ĐÚNG tập khai báo trước "
   "`LOI_THOI_S3` và exit code 1 khớp với FAIL. Nhãn đó KHÔNG có nghĩa bộ 88 test PASS. Báo cáo R4 viết gộp làm người đọc hiểu nhầm – đây là lỗi TRÌNH BÀY/PHÂN LOẠI (FACT). "
   "R4F tách rõ hai tầng và giữ dấu FAIL gốc.\n")
A_("**Quy tắc phân loại khai báo TRƯỚC lần chạy** (`kiem_toan_r4f/phan_loai_fail.json`): C1 có trong sổ; C2 SHA đoạn mã test không đổi; C3 actual mới khớp chính xác chữ ký; C4 mọi test thay thế "
   "PASS trong CÙNG lần chạy; C5 R3 = mã đang kiểm cho kịch bản test cũ. Thiếu một tiêu chí → FAIL_CHUA_GIAI_QUYET → mã thoát 1. Kiểm âm: đột biến quy trình K01/K02 (mục 8).\n")
A_("**Chính sách mã thoát:** 0 = mọi test PASS · 1 = còn FAIL chưa giải quyết / WRONG_REASON / VALIDATOR_CRASH / ENV_ERROR / TIMEOUT / output cũ · 2 = chỉ còn BLOCKED / NOT TESTED · "
   "3 = chỉ còn FAIL đã phân loại (± BLOCKED / NOT TESTED). Ưu tiên 1 > 3 > 2 > 0.\n")
A_(bang([(p["test_id"], p["status_goc"], p["status_phan_loai"], p["phan_loai"], " ".join(f"{k.split('_')[0]}={'✓' if v else '✗'}" for k, v in p["tieu_chi"].items()),
          ", ".join(f"{k} {v}" for k, v in p["test_thay_the"].items())) for p in s3["phan_loai"]],
        ("ID", "Trạng thái gốc", "Trạng thái phân loại", "Phân loại", "Tiêu chí", "Test thay thế (cùng lần chạy)")))
A_(f"\nBộ 88 (chạy mới, bản sao sạch, run_id {s3['run_id']}, {s3['thoi_gian_s']} s): PASS {s3['dem_goc']['PASS']} · FAIL {s3['dem_goc']['FAIL']} · BLOCKED {s3['dem_goc']['BLOCKED']} · "
   f"NOT TESTED {s3['dem_goc']['NOT TESTED']} · exit {s3['ma_thoat_bo88']} → trạng thái bộ **{s3['trang_thai_bo']}**.\n")
if kd:
    A_(f"KD đầy đủ (chay_doc_lap.py, {kd.get('thoi_gian_s')} s, mã thoát thô {kd.get('ma_thoat_tho')}, {kd.get('so_assertion')} assertion): {kd_dem} – trùng số liệu hồi quy R3 "
       f"trên mã R4 (102 / 6 / 1, 112 562 assertion). KD-REG-S3 trong lần này: **{reg.get('status')}** ở TẦNG HỒI QUY (nghĩa: tập FAIL bộ 88 = LOI_THOI_S3, exit 1 khớp); "
       f"điều đó KHÔNG làm bộ 88 thành PASS. Trích actual: {str(reg.get('actual'))[:220]}…\n")

A_("## 6. Chạy lại toàn bộ R4 theo nhóm (bộ điều phối kiem_toan_r4f/chay_nhom.py)\n")
A_(f"run_id điều phối {dp['run_id_dieu_phoi']} · bắt đầu {dp['bat_dau']} · {dp['thoi_gian_s']} s · phủ {dp['phu_nhom_r4']['da_chay']}/{dp['phu_nhom_r4']['tong_test_r4']} test R4 "
   f"(thiếu {dp['phu_nhom_r4']['thieu']}, trùng {dp['phu_nhom_r4']['trung']}) · SHA mã đổi trong lúc chạy: {dp['sha_ma_doi'] or 'không'} · bytecode: {dp['bytecode_sau'] or 'không'} · "
   f"**mã thoát {dp['ma_thoat']}**.\n")
A_(bang([(k["nhom"], k.get("trang_thai_nhom"), k.get("run_id", "—"), k.get("thoi_gian_s"), k.get("so_assertion", "—"), *[(k.get("dem") or {}).get(x, 0) for x in T7],
          k.get("log", "—"), "giữ nguyên" if not k.get("sha_ma_doi_trong_nhom") else k["sha_ma_doi_trong_nhom"]) for k in dp["nhom"]],
        ("Nhóm", "Trạng thái nhóm", "run_id", "giây", "assertion", *T7, "log", "SHA mã trước/sau")))
A_(f"\nTổng: {tong}. Giới hạn đã nêu ở đề bài: ChatGPT không chạy lại được toàn bộ R4 vì giới hạn thời gian – trong môi trường này toàn bộ chạy xong (không TIMEOUT); "
   "bộ điều phối cho phép chạy từng nhóm riêng (`--nhom F02`) để kiểm độc lập theo phần.\n")
A_(f"Bộ 0.3.9 (điều kiện tiên quyết của KD-REG-S3) chạy mới: {r39['summary']['counts']} trong {r39['summary']['seconds']} s – FAIL duy nhất T-01 (token, đã phân loại từ 0.3.9).\n")

A_("## 7. Cách ly và toàn vẹn\n")
A_(bang([
    ("So với gói R4", f"sửa {cl['1_so_voi_R4']['doi']}; file mới {cl['1_so_voi_R4']['so_moi']} (ngoài kiem_toan_r4f/: {cl['1_so_voi_R4']['moi_ngoai_phep'] or 'không'}); xóa {cl['1_so_voi_R4']['xoa'] or 'không'}",
     cl["1_so_voi_R4"]["dat"]),
    ("Bằng chứng R4 + test cũ", f"{cl['2_bang_chung_R4_va_test_cu']['so_file']} file (kiem_toan_r4/**, kiem_doc_lap/**, kiem_thu_stage3.py, _truoc_r4/**) – đổi: {cl['2_bang_chung_R4_va_test_cu']['doi'] or 'không'}",
     cl["2_bang_chung_R4_va_test_cu"]["dat"]),
    ("Manifest R4", f"{cl['3_manifest_R4']['so_dong']} dòng – lệch: {cl['3_manifest_R4']['lech']} (đúng file đã sửa)", cl["3_manifest_R4"]["dat"]),
    ("So với R3", f"sửa {cl['4_so_voi_R3']['doi']} (⊆ danh sách R4); file mới ngoài chỗ cho phép: {cl['4_so_voi_R3']['moi_ngoai_phep'] or 'không'}", cl["4_so_voi_R3"]["dat"]),
    ("Pine", "; ".join(f"{p.split('/')[-1]} {v['sha'][:16]}… {'đúng' if v['dung'] else 'SAI'}" for p, v in cl["5_pine"].items()), all(v["dung"] for v in cl["5_pine"].values())),
    ("Bytecode", cl["6_bytecode"]["pyc"] or "không có __pycache__/.pyc", cl["6_bytecode"]["dat"]),
    ("Phạm vi dòng sửa", f"{cl['7_pham_vi_dong']['so_dong_doi']} dòng diff; dòng MÃ ngoài docstring: {cl['7_pham_vi_dong']['so_dong_ma_ngoai_docstring']}", cl["7_pham_vi_dong"]["dat"]),
    ("Ngoài phạm vi (dashboard / D0 / D1 / token gate)", cl["8_ngoai_pham_vi"]["dung_cham"] or "không đụng", cl["8_ngoai_pham_vi"]["dat"]),
    ("Độ mới / run_id", f"{cl.get('9_do_moi', {}).get('so_run_id')} run_id duy nhất; log cũ hơn lúc bắt đầu: {cl.get('9_do_moi', {}).get('log_cu_hon_luc_bat_dau') or 'không'}", cl.get("9_do_moi", {}).get("dat")),
], ("Kiểm", "Chi tiết", "Đạt")))
A_(f"\nKết luận cách ly: **{'ĐẠT' if cl['dat'] else 'KHÔNG ĐẠT'}** (FACT, `ket_qua/cach_ly_r4f.json`). Bằng chứng R4 (kiem_toan_r4/ket_qua, BAN_GIAO_R4) không bị ghi đè; R4F ghi vào kiem_toan_r4f/.\n")

A_("## 8. Kiểm thử đột biến (chạy mới)\n")
A_(f"{mu['so_dot_bien']} đột biến, {mu['thoi_gian_s']} s. Bản gốc: R4 {mu['goc']['tom_tat']['r4']}, R4F {mu['goc']['tom_tat']['r4f']}; bất thường ngoài BLOCKED đã biết: {mu['goc']['bat_thuong'] or 'không'}. "
   f"Kết quả: **{mu_dem}**. Đột biến tương đương: {mu['tuong_duong'] or 'không có (M02/M12 tương đương của R4 đã được thay ở R4, không tính phủ)'}.\n")
t_mu = os.path.getmtime(os.path.join(KQ, "dot_bien_r4f.json")) - mu["thoi_gian_s"]
ma_kiem = ["shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py", "shadow_eval/may_trang_thai.py", "kiem_doc_lap/chay_r4.py", "kiem_toan_r4f/chay_r4f.py",
           "kiem_toan_r4f/chay_nhom.py", "kiem_toan_r4f/dot_bien_r4f.py", "kiem_toan_r4f/phan_loai_fail.json"]
moi_hon = [f for f in ma_kiem if os.path.getmtime(os.path.join(G, f)) > t_mu]
khop_sha = all(dp["sha_ma_sau"].get(f) == sha(os.path.join(G, f)) for f in ma_kiem if f in dp["sha_ma_sau"])
A_(f"Đồng nhất mã: mọi file mã được kiểm có mtime TRƯỚC lúc bắt đầu chạy đột biến (file sửa sau đó: {moi_hon or 'không'}); SHA hiện tại = SHA của lần chạy điều phối cuối: "
   f"{'khớp' if khop_sha else 'KHÔNG khớp'} (mo_phong_lenh.py {sha(os.path.join(G, 'shadow_eval/mo_phong_lenh.py'))[:16]}…) → đột biến chạy trên đúng mã của kết luận. "
   "M06/M07 được khai báo TRƯỚC (từ R4) là 'bắt qua lý do' (qua_ly_do): test ra WRONG_REASON vì đột biến đổi đúng thông điệp lý do mà test kiểm chính xác – tính KILLED_EXPECTED theo "
   "định nghĩa khai báo trước. K01: OT-05 hết FAIL (đột biến làm assertion cũ đúng trở lại) → OT-06 / HD-01 mất tiêu chí C2/C4 → FAIL_CHUA_GIAI_QUYET, mã thoát 1: "
   "sổ phân loại không che được lỗi thật.\n")
A_(bang([(m["id"], m.get("nguon"), m["file"], m["mo_ta"], f"`{m['ma_dot_bien']['neo'][:60]}` → `{m['ma_dot_bien']['thay'][:60]}`",
          ", ".join(m.get("test_khai_bao", [])) or m.get("dieu_kien_ky_vong", ""), m["phan_loai"],
          (("; ".join(f"{k}: {v[0]}" for k, v in m.get("ket_qua_test_khai_bao", {}).items())) or f"mã thoát {m.get('ma_thoat')}, S3 {m.get('phan_loai_s3')}")[:160]) for m in mu["dot_bien"]],
        ("ID", "Nguồn", "File", "Mô tả", "Mã đột biến", "Test / điều kiện khai báo trước", "Phân loại", "Bằng chứng")))

A_("\n## 9. Danh sách BLOCKED / NOT TESTED (không tính là PASS)\n")
A_(bang([(b[0], b[1], b[2], str(b[3])[:150]) for b in bl], ("Bộ", "ID", "Trạng thái", "Lý do")))
if kd:
    A_(f"\nKD đầy đủ: BLOCKED {kd_dem.get('BLOCKED', 0)}, NOT TESTED {kd_dem.get('NOT TESTED', 0)} – " + ", ".join(t["test_id"] for t in kd.get("test", []) if t["status"] in ("BLOCKED", "NOT TESTED")) + ".\n")
A_("\nKhông tuyên bố: dữ liệu thị trường thật, REPLAY-EQ (tương đương Python ↔ TradingView), token TradingView, replay Pine đầy đủ, oracle độc lập với đặc tả, thứ tự sự kiện cùng nến trên dữ liệu thật.\n")

A_("## 10. Rủi ro tồn đọng\n")
A_(bang([
    ("RR-1", "Ghi chú INVALID_BAR cho ca R2 nến vào lỗi thời gian gộp hai nguyên nhân (giá hỏng / thời gian) ở nhánh trước vào.", "ASSUMPTION", "Chủ dự án quyết có tách ghi chú (đổi hợp đồng + may_trang_thai) hay không."),
    ("RR-2", "Oracle độc lập cũ (kiem_doc_lap/oracle.py) có cùng điểm mù với BUG-R4F-1 → bằng chứng 'code = oracle' cũ không phát hiện được loại lỗi này; không sửa oracle cũ theo ràng buộc.",
     "FACT", "Vòng sau: bổ sung quy tắc vào oracle (có review độc lập)."),
    ("RR-3", "Oracle không độc lập với đặc tả (cùng tác giả, cùng tài liệu).", "FACT (giới hạn đã nêu từ R3/R4)", "Giữ là NOT TESTED / giới hạn."),
    ("RR-4", "Kết luận 'pipeline không chạm BUG-R4F-1' dựa trên SYNTH + đọc mã du_lieu.chuan_hoa; chưa có dữ liệu thật.", "PARTIALLY VERIFIED", "Kiểm lại khi có OHLCV thật có nguồn."),
    ("RR-5", "R4-OBS-1 (AD-TAO-KET-THUC-CUNG-NEN) vẫn BLOCKED – 0 lần xuất hiện trong 200 seed SYNTH.", "FACT", "Cần dữ liệu/kịch bản tạo được ca này."),
    ("RR-6", "OBS-R4F-2 / OBS-R4F-3 (nến trigger thời gian None → INVALID_SIGNAL; NO_DATA sau vào bars_held 0) – hành vi có sẵn, ngoài phạm vi, không đổi.", "FACT", "Chủ dự án quyết ở vòng sau."),
], ("ID", "Rủi ro", "Loại", "Đề xuất")))

A_("\n## 11. Kết luận đóng vòng\n")
dk = [
    ("HD-01, OT-05, OT-06 xử lý có bằng chứng", all(p["status_phan_loai"] == "FAIL_DA_PHAN_LOAI" for p in s3["phan_loai"]) and r4f["dem"]["PASS"] == r4f.get("so_test")),
    ("KD-REG-S3 phản ánh đúng thực tế (FAIL gốc giữ, không gắn PASS cho bộ có FAIL, mã thoát ≠ 0)", s3["trang_thai_bo"] != "PASS" and dp["ma_thoat"] != 0 and s3["dem_goc"]["FAIL"] == 3),
    ("Toàn bộ R4 đã chạy lại theo nhóm (giới hạn được phân loại)", dp["phu_nhom_r4"]["da_chay"] == dp["phu_nhom_r4"]["tong_test_r4"] and not dp["nhom_loi"]),
    ("Đột biến có kết quả mới, đủ bản ghi", mu_dem == {"KILLED_EXPECTED": mu["so_dot_bien"]}),
    ("Cách ly đạt, Pine không đổi", cl["dat"]),
    ("Không FAIL chưa giải quyết nào bị gắn PASS", dp["fail_chua_giai_quyet"] == 0 and tong["WRONG_REASON"] == tong["VALIDATOR_CRASH"] == tong["ENV_ERROR"] == 0),
]
A_(bang([(d, "ĐẠT" if ok else "CHƯA ĐẠT") for d, ok in dk], ("Điều kiện (mục 11 đề bài)", "Trạng thái")))
du = all(ok for _, ok in dk)
A_("\n" + ("**RECOMMENDATION: đề xuất ĐÓNG vòng R4F.** Mã thoát 3 là trạng thái đúng (còn 3 FAIL đã phân loại có bằng chứng + BLOCKED/NOT TESTED ngoài phạm vi), không phải 'sạch'. "
           "Quyết định đóng thuộc chủ dự án; không cần chủ dự án chạy test thủ công." if du else "**CHƯA đề xuất đóng** – xem điều kiện CHƯA ĐẠT ở bảng trên."))
A_("\n\n## 12. Danh mục gói R4F\n")
A_("- Mã: `shadow_eval/mo_phong_lenh.py` (sửa BUG-R4F-1 + docstring). Công cụ mới: `kiem_toan_r4f/{dieu_tra_3fail.py, chay_r4f.py, chay_nhom.py, dot_bien_r4f.py, kiem_cach_ly_r4f.py, "
   "so_sanh_pipeline.py, tao_ban_giao_r4f.py, phan_loai_fail.json}`, bản trước sửa `kiem_toan_r4f/truoc_sua_r4f/mo_phong_lenh.py`, mã các vòng cũ `kiem_toan_r4f/lich_su_module/`.\n"
   "- Kết quả: `kiem_toan_r4f/ket_qua/chay_nhom/` (log từng nhóm, JSON từng nhóm, ket_qua_dieu_phoi.json, S3 88 test, KD đầy đủ), `ket_qua/dieu_tra/`, `ket_qua/pipeline/`, "
   "`ket_qua/r4f_tren_ma_R3/`, `ket_qua/r4f_tren_ma_R4_truoc_sua/`, `ket_qua/dot_bien_r4f.json`, `ket_qua/cach_ly_r4f.json`, `ket_qua/reg039_r4f/`; lần chạy thử trước `ket_qua/chay_nhom_LAN0_THU/` "
   "(giữ làm bằng chứng, không dùng cho kết luận) và `ket_qua/chay_nhom_LAN1_HUY/` (dừng tay ở nhóm KD vì đã tạo/sửa tao_ban_giao_r4f.py – file trong phạm vi băm SHA – "
   "trong lúc chạy; không hợp lệ theo quy tắc SHA trước = sau; đã chạy lại toàn bộ).\n"
   "- Bàn giao: `kiem_toan_r4f/BAN_GIAO_R4F/` – báo cáo này, TEST_MATRIX.csv, PHAN_LOAI_FAIL.csv, MUTATION.csv, BLOCKED_NOT_TESTED.csv, DIFF.patch, SHA_SAU_SUA.txt, SHA_PINE.txt, MANIFEST_SHA256.txt.\n")
open(os.path.join(BG, P + "BAO_CAO.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")

# manifest cuối cùng (toàn cây, trừ chính file manifest)
mf = os.path.join(BG, P + "MANIFEST_SHA256.txt")
ds = sorted(os.path.relpath(os.path.join(r, f), G) for r, _, fs in os.walk(G) for f in fs)
open(mf, "w", encoding="utf-8").write("".join(f"{sha(os.path.join(G, p))}  ./{p}\n" for p in ds if os.path.join(G, p) != mf))
print("đã tạo", BG, "| điều kiện đóng:", [ok for _, ok in dk])
