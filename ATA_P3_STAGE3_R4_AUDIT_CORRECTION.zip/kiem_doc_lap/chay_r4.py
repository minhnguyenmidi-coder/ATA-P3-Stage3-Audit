# -*- coding: utf-8 -*-
"""BỘ KIỂM VÒNG 4 (R4) – ATA P3 Stage 3. python3 -B kiem_doc_lap/chay_r4.py [--module-dir D] [--chi ID1,ID2] [--out DIR]
Nhóm: F01 (lọc danh mục, NO_DATA sau khi vào) · PF (hồi quy danh mục) · F02 (cost_model) · F03 (bootstrap) · AD (adapter F-05) · OR (oracle F-06)
      · HD (strict JSON + hợp đồng) · ISO (cách ly / độ mới).
Trạng thái test: PASS · FAIL (assertion sai) · WRONG_REASON (lỗi đúng chỗ nhưng sai lý do kỳ vọng) · VALIDATOR_CRASH (code ĐƯỢC KIỂM ném ngoại lệ)
                 · ENV_ERROR (ngoại lệ của khung kiểm / môi trường) · BLOCKED · NOT TESTED. Không gộp trạng thái."""
import sys
sys.dont_write_bytecode = True
import argparse, ast, copy, datetime as dt, hashlib, importlib.util, inspect, json, math, os, random, time, traceback, uuid   # noqa: E402

KD = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(KD)
ap = argparse.ArgumentParser(); ap.add_argument("--module-dir", default=os.path.join(G, "shadow_eval")); ap.add_argument("--chi", default="")
ap.add_argument("--out", default=os.path.join(G, "kiem_toan_r4", "ket_qua")); A = ap.parse_args()
MD = os.path.abspath(A.module_dir)
sys.path.insert(0, MD); sys.path.insert(1, KD)
import mo_phong_lenh as MP, hop_dong as HD, chi_so as CS, may_trang_thai as MT   # noqa: E402
import oracle_r4 as O4, vector_vang as VV   # noqa: E402
TRUOC = os.path.join(G, "shadow_eval", "_truoc_r4")
RUN_ID, T_BAT_DAU = str(uuid.uuid4()), time.time()
KQ, TESTS, DEM = [], [], {"a": 0}


class Sai(AssertionError):
    pass


class SaiLyDo(AssertionError):
    pass


def kt(dk, mo=""):
    DEM["a"] += 1
    if not dk:
        raise Sai(mo)


def ky_vong_loi(loi, chuoi, tag=""):
    """Danh sách lỗi phải KHÁC RỖNG và chứa thông điệp kỳ vọng; có lỗi nhưng sai lý do → WRONG_REASON."""
    DEM["a"] += 1
    if not loi:
        raise Sai(f"{tag}: không phát hiện lỗi (kỳ vọng '{chuoi}')")
    if not any(chuoi in x for x in loi):
        raise SaiLyDo(f"{tag}: phát hiện nhưng sai lý do – kỳ vọng '{chuoi}', được {loi[:3]}")


def nap_cu(ten):
    p = os.path.join(TRUOC, ten + ".py")
    sys.path.insert(0, TRUOC)
    try:
        spec = importlib.util.spec_from_file_location(f"{ten}_truoc_r4", p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    finally:
        sys.path.remove(TRUOC)
    return m


def T(tid, nhom, muc_tieu, bang_chung="FACT"):
    def wrap(fn):
        def run():
            a0, t0 = DEM["a"], time.time()
            try:
                r = fn(); st, act = (r if isinstance(r, tuple) and r and r[0] in ("BLOCKED", "NOT TESTED") else ("PASS", r))
            except SaiLyDo as e:
                st, act = "WRONG_REASON", str(e)
            except Sai as e:
                st, act = "FAIL", f"assertion sai: {e}"
            except Exception as e:      # noqa: BLE001
                tb = traceback.extract_tb(e.__traceback__)
                trong_code = any(os.path.abspath(f.filename).startswith(MD + os.sep) for f in tb)
                st = "VALIDATOR_CRASH" if trong_code else "ENV_ERROR"
                act = f"{type(e).__name__}: {e} @ {tb[-1].filename.split('/')[-1]}:{tb[-1].lineno}"
            rec = dict(test_id=tid, nhom=nhom, muc_tieu=muc_tieu, bang_chung=bang_chung, status=st, so_assertion=DEM["a"] - a0, actual=act,
                       test_source=f"kiem_doc_lap/chay_r4.py::{fn.__name__} (dòng {inspect.getsourcelines(fn)[1]})",
                       run_time=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), duration_ms=round((time.time() - t0) * 1000, 1))
            KQ.append(rec); print(f"[{st:15}] {tid:24} a={rec['so_assertion']:<6} {muc_tieu[:78]}")
        run.tid = tid
        TESTS.append(run)
        return run
    return wrap


# ============================================================================================ F01 – LỌC DANH MỤC
def L(e, x=None, o="TP1", note=None, sym="XAUUSD", su="SU5", seq=0, sid=None):
    return dict(symbol=sym, setup=su, entry_ts_ms=e, exit_ts_ms=x, outcome=o, fill_note=note, emit_seq=seq, signal_id=sid or f"{sym}-{su}-{e}-{seq}-{o}")


def loc(tr):
    g, n = MP.khong_chong(tr)
    kt(O4.kiem_danh_muc_r4(tr, g, n) == [], f"oracle R4: {O4.kiem_danh_muc_r4(tr, g, n)}")
    return g, n


def chiem(lenh, thoi_diem):
    """Trạng thái chiếm vị thế quan sát được: thêm lệnh dò TP1 cùng khóa vào tại thoi_diem; bị bỏ ⇔ khóa đang có vị thế."""
    do = L(thoi_diem, thoi_diem + 1, sym=lenh["symbol"], su=lenh["setup"], seq=99, sid="DO")
    g, n = MP.khong_chong([lenh, do])
    return "DO" not in [t["signal_id"] for t in g]


def kiem_ca(tr, giu_ky_vong, bo_ky_vong, tag):
    g, n = loc(tr)
    ids = [t["signal_id"] for t in g]
    kt(sorted(ids) == sorted(giu_ky_vong), f"{tag}: giữ {ids} ≠ {giu_ky_vong}")
    kt(sorted(t["signal_id"] for t in tr if t["signal_id"] not in ids) == sorted(bo_ky_vong) and n == len(bo_ky_vong), f"{tag}: bỏ {n}")
    return ids


@T("F01-CU-TAI-HIEN", "F01", "Tái hiện lỗi F-01 trên bản R3: NO_DATA sau khi vào (INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL) KHÔNG chặn lệnh sau cùng khóa")
def t_f01_cu():
    MPc = nap_cu("mo_phong_lenh")
    for note in O4.SAU_VAO:
        g, n = MPc.khong_chong([L(1, o="NO_DATA", note=note, sid="nd"), L(5, 9, sid="tp")])
        kt(n == 0 and [t["signal_id"] for t in g] == ["nd", "tp"], f"R3 phải giữ cả 2 ({note})")
    return "R3: NO_DATA sau khi vào không chiếm vị thế (lỗi F-01 tái hiện)"


@T("F01-NODATA-TRUOC", "F01", "NO_DATA trước khi vào (NO_NEXT_BAR, INVALID_BAR) không chiếm vị thế; TP1 sau đó (kể cả cùng entry_ts) được giữ")
def t_f01_truoc():
    for note in ("NO_NEXT_BAR", "INVALID_BAR"):
        nd = L(1, o="NO_DATA", note=note, sid="nd")
        kiem_ca([nd, L(1, 5, sid="tp0", seq=1), L(6, 9, sid="tp1")], ["nd", "tp0", "tp1"], [], note)
        kt(not chiem(nd, 2), f"{note}: không được chiếm vị thế")
    return "OK"


@T("F01-NODATA-SAU", "F01", "NO_DATA sau khi vào chiếm vị thế tới ∞: lệnh sau cùng (symbol, setup) bị bỏ ở mọi thời điểm; tự nó được giữ")
def t_f01_sau():
    for note in O4.SAU_VAO:
        nd = L(1, o="NO_DATA", note=note, sid="nd")
        kiem_ca([nd, L(5, 9, sid="a"), L(10 ** 9, 10 ** 9 + 5, sid="b")], ["nd"], ["a", "b"], note)
        kt(chiem(nd, 2) and chiem(nd, 10 ** 12), f"{note}: phải chiếm vị thế")
        kt(not chiem(nd, 0), f"{note}: lệnh dò vào TRƯỚC (thứ tự nhỏ hơn) không bị chặn")
    return "OK"


@T("F01-NODATA-SAU-BI-BO", "F01", "NO_DATA sau khi vào cũng CHỊU lọc: vào khi khóa đang có TP1 mở → bị bỏ, và vì bị bỏ nên không chặn lệnh sau thời điểm thoát của TP1")
def t_f01_sau_bo():
    for note in O4.SAU_VAO:
        kiem_ca([L(1, 10, sid="tp"), L(5, o="NO_DATA", note=note, sid="nd"), L(11, 20, sid="sau")], ["tp", "sau"], ["nd"], note)
    return "OK"


@T("F01-OPEN", "F01", "OPEN chặn lệnh tiếp theo cùng khóa (kể cả rất xa), OPEN cuối chuỗi được giữ")
def t_f01_open():
    op = L(5, o="OPEN", sid="op")
    kiem_ca([L(1, 3, sid="tp"), op, L(6, 7, sid="x"), L(10 ** 10, 10 ** 10 + 1, sid="y")], ["tp", "op"], ["x", "y"], "OPEN")
    kiem_ca([L(1, 3, sid="tp"), L(4, 6, "SL", sid="sl"), L(7, o="OPEN", sid="cuoi")], ["tp", "sl", "cuoi"], [], "OPEN cuối chuỗi")
    kt(chiem(op, 6), "OPEN phải chiếm")
    return "OK"


@T("F01-NOFILL-INVALID", "F01", "NO_FILL và INVALID (trước khi vào) không chiếm vị thế; lệnh cùng entry_ts hoặc sau đó được xét bình thường")
def t_f01_nofill():
    for o, note in (("NO_FILL", "GAP_BEYOND_SL"), ("NO_FILL", "GAP_BEYOND_TP"), ("INVALID", "INVALID_RISK"), ("INVALID", "INVALID_SIGNAL"), ("INVALID", "TP_WRONG_SIDE")):
        x = L(1, o=o, note=note, sid="x")
        kiem_ca([x, L(1, 4, sid="a", seq=1), L(2, 3, sid="b")], ["x", "a"], ["b"], o + note)
        kt(not chiem(x, 2), f"{o} {note}: không được chiếm")
    return "OK"


@T("F01-DONG-THEO-THOI-GIAN", "F01", "TP1 / SL / TIMEOUT giải phóng vị thế theo exit_ts_ms: vào trước exit → bỏ; vào ĐÚNG exit → bỏ (bảo thủ); vào sau exit → giữ")
def t_f01_dong():
    for o in ("TP1", "SL", "TIMEOUT"):
        kiem_ca([L(1, 10, o, sid="d"), L(5, 6, sid="truoc")], ["d"], ["truoc"], f"{o} vào trước exit")
        kiem_ca([L(1, 10, o, sid="d"), L(10, 12, sid="bang")], ["d"], ["bang"], f"{o} vào = exit")
        kiem_ca([L(1, 10, o, sid="d"), L(11, 12, sid="sau")], ["d", "sau"], [], f"{o} vào sau exit")
    return "OK"


@T("F01-CUNG-ENTRY", "F01", "Hai lệnh cùng entry_ts cùng khóa: giữ emit_seq nhỏ hơn; cùng emit_seq → signal_id nhỏ hơn; NO_DATA sau khi vào cùng entry thắng/thua theo cùng khóa thứ tự")
def t_f01_cung():
    kiem_ca([L(5, 9, seq=2, sid="a"), L(5, 9, seq=1, sid="b")], ["b"], ["a"], "emit_seq")
    kiem_ca([L(5, 9, seq=1, sid="b"), L(5, 9, seq=1, sid="a")], ["a"], ["b"], "signal_id")
    kiem_ca([L(5, o="NO_DATA", note="INVALID_BAR_AFTER_FILL", seq=1, sid="nd"), L(5, 9, seq=2, sid="tp")], ["nd"], ["tp"], "NO_DATA sau vào trước")
    kiem_ca([L(5, o="NO_DATA", note="INVALID_BAR_AFTER_FILL", seq=3, sid="nd"), L(5, 9, seq=2, sid="tp")], ["tp"], ["nd"], "NO_DATA sau vào sau")
    return "OK"


@T("F01-DAO-THU-TU", "F01", "Đảo / xáo trộn thứ tự đầu vào không đổi kết quả (mọi hoán vị của 6 lệnh hỗn hợp = 720 hoán vị)")
def t_f01_dao():
    import itertools
    tr = [L(1, o="NO_DATA", note="NO_NEXT_BAR", sid="a"), L(2, 5, sid="b"), L(4, o="NO_DATA", note="INVALID_BAR_AFTER_FILL", sid="c"),
          L(6, o="NO_DATA", note="NON_MONOTONIC_TIME_AFTER_FILL", sid="d"), L(7, o="NO_FILL", note="GAP_BEYOND_SL", sid="e"), L(8, o="OPEN", sid="f")]
    ref = None
    for p in itertools.permutations(tr):
        g, n = loc(list(p)); k = (sorted(t["signal_id"] for t in g), n); ref = ref or k
        kt(k == ref, f"phụ thuộc thứ tự: {k} vs {ref}")
    kt(ref == (["a", "b", "d", "e"], 2), f"kỳ vọng tính tay: giữ a b d e, bỏ c f – được {ref}")
    return dict(hoan_vi=720, ket_qua=ref)


@T("F01-TRUNG-ID", "F01", "signal_id trùng trong một lượt lọc → ValueError có thông điệp (không để thứ tự quyết định), kể cả khi một bản là NO_DATA sau khi vào")
def t_f01_trung():
    for a, b in ((L(1, 5, sid="x"), L(7, 9, sid="x")), (L(1, o="NO_DATA", note="INVALID_BAR_AFTER_FILL", sid="x"), L(7, 9, sid="x"))):
        try:
            MP.khong_chong([a, b]); kt(False, "không phát hiện signal_id trùng")
        except ValueError as e:
            kt("signal_id trùng" in str(e), f"sai thông điệp {e}")
    return "OK"


@T("F01-CHUOI-TOI-THIEU", "F01", "Chuỗi tối thiểu (mục 3): NO_DATA trước → TP1; NO_DATA sau → chặn; OPEN → chặn; NO_FILL → xét tiếp; SL → xét sau đóng; cùng entry; entry = exit; entry < exit; đảo ngược đầu vào – mỗi ca xác nhận danh sách giữ, danh sách bỏ và trạng thái chiếm vị thế")
def t_f01_chuoi():
    ca = [  # (mô tả, lệnh, giữ, bỏ, [(id, thời điểm dò, chiếm?)])
        ("NO_DATA trước → TP1", [L(1, o="NO_DATA", note="NO_NEXT_BAR", sid="nd"), L(2, 6, sid="tp")], ["nd", "tp"], [], [("nd", 2, False), ("tp", 3, True), ("tp", 7, False)]),
        ("NO_DATA sau → lệnh sau bị chặn", [L(1, o="NO_DATA", note="INVALID_BAR_AFTER_FILL", sid="nd"), L(2, 6, sid="tp")], ["nd"], ["tp"], [("nd", 2, True), ("nd", 10 ** 9, True)]),
        ("OPEN → lệnh sau bị chặn", [L(1, o="OPEN", sid="op"), L(2, 6, sid="tp")], ["op"], ["tp"], [("op", 10 ** 9, True)]),
        ("NO_FILL → lệnh sau được xét", [L(1, o="NO_FILL", note="GAP_BEYOND_SL", sid="nf"), L(2, 6, sid="tp")], ["nf", "tp"], [], [("nf", 2, False)]),
        ("SL → xét sau thời điểm đóng", [L(1, 5, "SL", sid="sl"), L(4, 8, sid="a"), L(6, 8, sid="b")], ["sl", "b"], ["a"], [("sl", 4, True), ("sl", 6, False)]),
        ("hai lệnh cùng entry", [L(3, 6, seq=1, sid="x1"), L(3, 6, seq=2, sid="x2")], ["x1"], ["x2"], [("x1", 6, True)]),
        ("entry = exit lệnh trước", [L(1, 5, sid="a"), L(5, 9, sid="b")], ["a"], ["b"], [("a", 5, True)]),
        ("entry < exit lệnh trước", [L(1, 5, sid="a"), L(4, 9, sid="b")], ["a"], ["b"], [("a", 4, True)]),
    ]
    for mo, tr, giu, bo, do in ca:
        for thu_tu in (tr, list(reversed(tr))):
            kiem_ca(copy.deepcopy(thu_tu), giu, bo, mo)
        idx = {t["signal_id"]: t for t in tr}
        for sid, td, kv in do:
            kt(chiem(idx[sid], td) == kv, f"{mo}: chiếm({sid}, {td}) ≠ {kv}")
    return f"{len(ca)} ca × 2 thứ tự"


# ============================================================================================ PF – HỒI QUY DANH MỤC
OUTS = [("TP1", None), ("SL", None), ("TIMEOUT", None), ("OPEN", None), ("NO_FILL", "GAP_BEYOND_SL"), ("NO_FILL", "GAP_BEYOND_TP"), ("INVALID", "INVALID_RISK"),
        ("NO_DATA", "NO_NEXT_BAR"), ("NO_DATA", "INVALID_BAR"), ("NO_DATA", "INVALID_BAR_AFTER_FILL"), ("NO_DATA", "NON_MONOTONIC_TIME_AFTER_FILL")]


def tap_ngau_nhien(R, n_max=24, emit_trung=True):
    tr = []
    for j in range(R.randint(1, n_max)):
        o, note = R.choice(OUTS); e = R.randint(0, 40)
        tr.append(L(e, (e + R.randint(0, 10)) if o in ("TP1", "SL", "TIMEOUT") else None, o, note, sym=R.choice(("XAUUSD", "BTCUSD")), su=R.choice(("SU3", "SU5")),
                    seq=R.randint(0, 3) if emit_trung else j, sid=f"s{j}"))
    return tr


@T("PF-PROP-R4", "PF", "2.000 tập ngẫu nhiên (11 kết cục/ghi chú, nhiều symbol/setup, emit_seq TRÙNG, va chạm biên) × 5 xáo trộn: thỏa P0–P4 của oracle R4 (độc lập code) và không phụ thuộc thứ tự")
def t_pf_prop():
    R = random.Random(404)
    for _ in range(2000):
        tr = tap_ngau_nhien(R); ref = None
        for _ in range(5):
            R.shuffle(tr); g, n = loc(tr)
            k = (sorted(t["signal_id"] for t in g), n); ref = ref or k; kt(k == ref, "phụ thuộc thứ tự")
    return "2.000 × 5"


@T("PF-KHONG-DOI-CA-DUNG", "PF", "Ca đang đúng KHÔNG đổi: 3.000 tập ngẫu nhiên KHÔNG có NO_DATA sau khi vào → kết quả R4 trùng từng phần tử với bản R3; có NO_DATA sau khi vào → R4 = R3 khi đổi các lệnh đó thành OPEN (ánh xạ ngữ nghĩa F-01); 1.000 tập có bản ghi cũ THIẾU outcome → trùng R3")
def t_pf_khong_doi():
    MPc = nap_cu("mo_phong_lenh"); R = random.Random(405); co = 0
    for _ in range(3000):
        tr = tap_ngau_nhien(R)
        g4, n4 = MP.khong_chong(tr)
        sau = {t["signal_id"] for t in tr if t["outcome"] == "NO_DATA" and t["fill_note"] in O4.SAU_VAO}
        if not sau:
            g3, n3 = MPc.khong_chong(tr)
            kt([t["signal_id"] for t in g4] == [t["signal_id"] for t in g3] and n4 == n3, "ca không có NO_DATA sau vào bị đổi")
        else:
            co += 1
            tr3 = [dict(t, outcome="OPEN", fill_note=None) if t["signal_id"] in sau else t for t in tr]
            g3, n3 = MPc.khong_chong(tr3)
            kt([t["signal_id"] for t in g4] == [t["signal_id"] for t in g3] and n4 == n3, "ánh xạ NO_DATA sau vào ≡ OPEN không giữ")
    for _ in range(1000):          # bản ghi CŨ thiếu 'outcome' (bộ Stage 3 gốc DUP-02 dùng dạng này) – hành vi phải trùng R3 (lỗi hồi quy phát hiện bởi REG-01 ở lượt 1)
        tr = tap_ngau_nhien(R, emit_trung=False)
        for t in tr:
            if R.random() < 0.4:
                t.pop("outcome"); t.pop("fill_note"); t["exit_ts_ms"] = t["entry_ts_ms"] + R.randint(0, 6)
        tr = [t for t in tr if "outcome" not in t or t["outcome"] != "NO_DATA" or t["fill_note"] not in O4.SAU_VAO]
        g4, n4 = MP.khong_chong(tr); g3, n3 = MPc.khong_chong(tr)
        kt([t["signal_id"] for t in g4] == [t["signal_id"] for t in g3] and n4 == n3, "bản ghi thiếu outcome: R4 khác R3")
    return dict(tap=3000, co_no_data_sau_vao=co, tap_thieu_outcome=1000)


@T("PF-DOC-LAP-DEDUP", "PF", "Lọc danh mục độc lập với khử trùng: kết quả không đổi khi đổi/bỏ dup_key, khi thêm tín hiệu trùng khóa IP-21 ở bảng SIGNALS; khu_trung không được gọi trong khong_chong")
def t_pf_dedup():
    R = random.Random(406)
    src = inspect.getsource(MP.khong_chong)
    kt("khu_trung" not in src and "dup_key" not in src, "khong_chong tham chiếu khử trùng")
    for _ in range(500):
        tr = tap_ngau_nhien(R); g1, n1 = MP.khong_chong(tr)
        tr2 = [dict(t, dup_key=R.choice(("K", "L", None))) for t in tr]; g2, n2 = MP.khong_chong(tr2)
        kt([t["signal_id"] for t in g1] == [t["signal_id"] for t in g2] and n1 == n2, "dup_key ảnh hưởng lọc danh mục")
    return "500 tập"


@T("PF-MOI-SEED-RIENG", "PF", "pipeline.chay_synth lọc RIÊNG từng seed: bo_chong_lan = tổng số bỏ khi lọc từng seed; lọc gộp các seed cho số khác (chứng minh việc tách có tác dụng) trên 40 seed × 2 symbol × 2 setup")
def t_pf_seed():
    import pipeline as PL
    out = {}
    for sym in ("XAUUSD", "BTCUSD"):
        for su in ("SU3", "SU5"):
            syn = PL.chay_synth(sym, su, seeds=range(40))
            rieng = sum(MP.khong_chong([t for t in syn["trades"] if t["_seed"] == sd])[1] for sd in {t["_seed"] for t in syn["trades"]})
            kt(syn["bo_chong_lan"] == rieng, f"{sym} {su}: {syn['bo_chong_lan']} ≠ {rieng}")
            out[f"{sym}-{su}"] = dict(so_lenh=len(syn["trades"]), bo_rieng=rieng, no_data_sau_vao=sum(t["outcome"] == "NO_DATA" and t["fill_note"] in O4.SAU_VAO for t in syn["trades"]))
    return out


@T("PF-EMIT-TRUNG", "PF", "emit_seq trùng giữa các lệnh cùng entry → phân xử bằng signal_id, tất định qua xáo trộn; entry_ts quyết định trước emit_seq")
def t_pf_emit():
    tr = [L(5, 9, seq=1, sid="c"), L(5, 9, seq=1, sid="a"), L(5, 9, seq=1, sid="b"), L(4, 4, seq=9, sid="z")]
    R = random.Random(407)
    for _ in range(50):
        R.shuffle(tr); g, n = loc(tr); kt([t["signal_id"] for t in g] == ["z", "a"] and n == 2, f"{[t['signal_id'] for t in g]}")
    return "OK"


# ============================================================================================ F02 – COST_MODEL
def trade_hop_le(spread=1.0, comm=0.0, slip=0.0):
    b = [dict(t=VV.T0 + 300000 * k, o=float(o), h=float(h), l=float(l), c=float(c)) for k, (o, h, l, c) in enumerate([VV.TRIG, (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)])]
    cfg = MP.Cfg(spread=spread, commission=comm, slippage=slip)
    r = MP.mo_phong(VV.BUY, b, 0, cfg)
    return dict(r, schema_version="1.2", signal_id="aaaa000000000001", symbol="XAUUSD", setup="SU5", emit_seq=3, sim_rule=cfg.rule_id(), cost_model=cfg.cost_id())


MA_HONG = ["C-s.-c0-sl0", "C-s1..2-c0-sl0", "C-s1-c.-sl0", "C-s1-c0-sl.", "C-sNaN-c0-sl0", "C-sInfinity-c0-sl0", "C-s-inf-c0-sl0", "C-s1e999-c0-sl0",
           "C-s1-c0", "C-s1-c0-sl0-x", "C-s 1-c0-sl0", "C-s1-c0-sl0\n", "C-s+1-c0-sl0", "C-s-1-c0-sl0", "C-s1.-c0-sl0", "C-s.5-c0-sl0", "C-s1e-c0-sl0", "C-s١-c0-sl0", "C-s"]


@T("F02-CU-TAI-HIEN", "F02", "Tái hiện F-02 trên bản R3: hop_dong.kiem với cost_model 'C-s1..2-c0-sl0' NÉM ValueError (validator crash)")
def t_f02_cu():
    HDc = nap_cu("hop_dong"); t = trade_hop_le()
    try:
        HDc.kiem(dict(t, cost_model="C-s1..2-c0-sl0"), HDc.TRADES); kt(False, "R3 không crash – không tái hiện được")
    except ValueError as e:
        return f"R3 ném {e!r}"


@T("F02-MA-HONG", "F02", f"{len(MA_HONG)} mã cost_model sai cú pháp/cấu trúc (gồm 6 mã của nhiệm vụ) → lỗi hợp đồng có kiểm soát, KHÔNG ngoại lệ")
def t_f02_hong():
    t = trade_hop_le()
    for m in MA_HONG:
        loi = HD.kiem(dict(t, cost_model=m), HD.TRADES)
        ky_vong_loi(loi, "cost_model có số không hữu hạn" if m == "C-s1e999-c0-sl0" else "cost_model sai cấu trúc", m)    # lý do CHÍNH XÁC từng loại
    return f"{len(MA_HONG)} mã"


@T("F02-MA-HOP-LE", "F02", "Mã hợp lệ tiếp tục PASS: 'C-s1-c0-sl0' (r_net khớp chi phí 1), mọi cost_id() do Cfg sinh (0, số nguyên, thập phân, 1e-05, 1e+21), mã tự do 'C-0'/'C-x' giữ phạm vi hợp đồng 1.2")
def t_f02_ok():
    t = trade_hop_le(spread=1.0)
    kt(HD.kiem(dict(t, cost_model="C-s1-c0-sl0"), HD.TRADES) == [], f"C-s1-c0-sl0: {HD.kiem(dict(t, cost_model='C-s1-c0-sl0'), HD.TRADES)}")
    for s, c, sl in ((0.0, 0.0, 0.0), (1, 0, 0), (0.5, 0.25, 0.125), (1e-05, 0.0, 0.0), (0.3, 0.1, 0.05), (2, 1, 1)):
        tt = trade_hop_le(s, c, sl)
        kt(HD.kiem(tt, HD.TRADES) == [], f"{tt['cost_model']}: {HD.kiem(tt, HD.TRADES)}")
    kt(HD.chi_phi_tu_ma(MP.Cfg(spread=1e21).cost_id())[0] == (1e21, 0.0, 0.0), "1e+21")
    for m in ("C-0", "C-x"):
        kt(HD.kiem(dict(t, cost_model=m), HD.TRADES) == [], f"mã tự do {m} bị bác (đổi phạm vi hợp đồng)")
    return "OK"


@T("F02-CONG-THUC-DONG-BANG", "F02", "Công thức chi phí đóng băng: r_gross − r_net = (spread + phí + 2×trượt)/risk; sai lệch 1 lần trượt bị bắt đúng lý do")
def t_f02_ct():
    t = trade_hop_le(0.3, 0.1, 0.05)
    kt(abs((t["r_gross"] - t["r_net"]) - (0.3 + 0.1 + 2 * 0.05) / t["risk"]) < 1e-12, "mo_phong chi phí")
    ky_vong_loi(HD.kiem(dict(t, r_net=t["r_gross"] - (0.3 + 0.1 + 0.05) / t["risk"]), HD.TRADES), "chi phí (theo cost_model)", "1 lần trượt")
    return "OK"


@T("F02-FUZZ", "F02", "Fuzz 30.000 chuỗi cost_model (bảng chữ 'C-scl0123456789.eE+-NaInfty ' và biến dạng mã hợp lệ) + 5.000 bản ghi TRADES hỏng kiểu: validator không bao giờ ném ngoại lệ; mọi mã bắt đầu 'C-s' mà không khớp cú pháp đều bị báo")
def t_f02_fuzz():
    R = random.Random(202); t = trade_hop_le(); bao = 0
    ky = "C-scl0123456789.eE+-NaInfty "
    for i in range(30000):
        if i % 2:
            m = "C-s" + "".join(R.choice(ky) for _ in range(R.randint(0, 14)))
        else:
            m = list(t["cost_model"]); j = R.randrange(len(m)); m[j] = R.choice(ky); m = "".join(m)
        loi = HD.kiem(dict(t, cost_model=m), HD.TRADES)
        if m.startswith("C-s") and not HD.CHI_PHI.fullmatch(m):
            kt(any("cost_model" in x for x in loi), f"mã sai không bị báo: {m!r}"); bao += 1
    rac = [None, True, 1, -1.5, float("nan"), float("inf"), "", "x", [], {}, "C-s1..2-c0-sl0", 10 ** 30]
    for _ in range(5000):
        r = dict(t)
        for k in R.sample(list(r), R.randint(1, 4)):
            r[k] = R.choice(rac)
        HD.kiem(r, HD.TRADES)
    DEM["a"] += 5000
    return dict(chuoi=30000, ma_sai_bi_bao=bao, ban_ghi_hong=5000)


# ============================================================================================ F03 – BOOTSTRAP
def ci_cu_moi(fn, *a, **k):
    try:
        return ("OK", fn(*a, **k))
    except ValueError as e:
        return ("ValueError", str(e))
    except Exception as e:      # noqa: BLE001
        return ("CRASH", f"{type(e).__name__}: {e}")


@T("F03-CU-TAI-HIEN", "F03", "Tái hiện F-03 trên bản R3: bootstrap_khoi n_boot = 0 → IndexError; L ≥ n → CI suy biến bị ghi 'OK'; L = 0 bị nuốt thành mặc định; bootstrap_ci kiểm n_boot SAU nhánh suy biến (thứ tự không đồng nhất); alpha = 1 → chỉ số phân vị dưới > trên (khoảng đảo/rỗng, không báo lỗi)")
def t_f03_cu():
    CSc = nap_cu("chi_so"); x = [1.0, -1.0, 2.0, 0.5, -0.3]
    kt(ci_cu_moi(CSc.bootstrap_khoi, x, 7, ("a",), n_boot=0)[0] == "CRASH", "n_boot 0")
    ci, st, L = CSc.bootstrap_khoi(x, 7, ("a",), L=5); kt(st == "OK" and abs(ci[0] - ci[1]) < 1e-12, f"L = n: {ci} {st}")
    kt(CSc.bootstrap_khoi(x, 7, ("a",), L=0)[2] == 2, "L = 0 nuốt")
    kt(CSc.bootstrap_ci([0.5] * 5, 7, ("a",), n_boot=10)[1] == "SUY_BIEN" and ci_cu_moi(CSc.bootstrap_ci, x, 7, ("a",), n_boot=10)[0] == "ValueError", "thứ tự kiểm")
    B_ = 2000; k_ = (B_ * int(round(1.0 * 1000))) // 2000; kt(k_ > B_ - 1 - k_, "alpha 1: chỉ số dưới > chỉ số trên (khoảng đảo)")
    lo, hi = CSc.bootstrap_ci(x, 7, ("a",), alpha=1.0)[0]; kt(lo >= hi, f"alpha 1: {lo} {hi}")
    return "5 hành vi lỗi R3 tái hiện"


@T("F03-DONG-NHAT", "F03", "Hai hàm bootstrap cư xử GIỐNG NHAU với đầu vào sai, kiểm TRƯỚC mọi nhánh (n < 2, suy biến): n_boot ∉ int ≥ 40, alpha ∉ (0,1), R có NaN/±Inf/None/bool → ValueError có thông điệp; không IndexError/kết quả sai im lặng")
def t_f03_dn():
    for R_ in ([1.0, -1.0, 2.0], [0.5, 0.5, 0.5], [1.0]):
        for kw in (dict(n_boot=0), dict(n_boot=39), dict(n_boot=40.0), dict(n_boot=True), dict(n_boot=None), dict(alpha=0), dict(alpha=1), dict(alpha=-0.1), dict(alpha=1.5),
                   dict(alpha=float("nan")), dict(alpha=float("inf")), dict(alpha=True)):
            for fn in (CS.bootstrap_ci, CS.bootstrap_khoi):
                r = ci_cu_moi(fn, R_, 7, ("a",), **kw)
                kt(r[0] == "ValueError", f"{fn.__name__} {R_} {kw}: {r}")
    for bad in ([1.0, float("nan")], [1.0, float("inf")], [float("-inf"), 1.0], [1.0, None], [True, 1.0]):
        for fn in (CS.bootstrap_ci, CS.bootstrap_khoi):
            kt(ci_cu_moi(fn, bad, 7, ("a",))[0] == "ValueError", f"{fn.__name__} {bad}")
    return "OK"


@T("F03-L", "F03", "L của bootstrap khối: 0, âm, bool, float, L = n, L > n → ValueError; L = n − 1 hợp lệ; L = None → mặc định max(1, round(n^(1/3)))")
def t_f03_L():
    x = [1.0, -1.0, 2.0, 0.5, -0.3]
    for L_ in (0, -1, True, 2.0, 5, 9):
        kt(ci_cu_moi(CS.bootstrap_khoi, x, 7, ("a",), L=L_)[0] == "ValueError", f"L = {L_!r}")
    kt(ci_cu_moi(CS.bootstrap_khoi, x, 7, ("a",), L=4)[0] == "OK", "L = n − 1")
    kt(CS.bootstrap_khoi(x, 7, ("a",))[2] == round(5 ** (1 / 3)), "mặc định")
    return "OK"


@T("F03-BIEN", "F03", "Biên: n = 1 → N_NHO_HON_2 (cả hai); n = 2 → OK; R suy biến → SUY_BIEN (cả hai); n_boot = 40 tối thiểu chạy; alpha 0,001 → (min, max) của mẫu bootstrap; alpha 0,999 với B = 40 → dưới ≤ trên; phan_vi_doi_xung B = 0 / alpha sai → ValueError, giá trị cũ giữ nguyên")
def t_f03_bien():
    kt(CS.bootstrap_ci([1.0], 7, ("a",)) == (None, "N_NHO_HON_2") and CS.bootstrap_khoi([1.0], 7, ("a",)) == (None, "N_NHO_HON_2", None), "n = 1")
    kt(CS.bootstrap_ci([1.0, -1.0], 7, ("a",))[1] == "OK" and CS.bootstrap_khoi([1.0, -1.0], 7, ("a",))[1] == "OK", "n = 2")
    kt(CS.bootstrap_ci([0.3] * 6, 7, ("a",)) == ([0.3, 0.3], "SUY_BIEN") and CS.bootstrap_khoi([0.3] * 6, 7, ("a",))[:2] == ([0.3, 0.3], "SUY_BIEN"), "suy biến")
    x = [1.0, -1.0, 2.0, 0.5, -0.3, 1.2]
    for fn in (CS.bootstrap_ci, CS.bootstrap_khoi):
        r = fn(x, 7, ("a",), n_boot=40); kt(r[1] == "OK" and r[0][0] <= r[0][1], f"{fn.__name__} n_boot 40")
        r = fn(x, 7, ("a",), alpha=0.999, n_boot=40); kt(r[0][0] <= r[0][1], f"{fn.__name__} alpha 0,999")
    kt(CS.phan_vi_doi_xung(list(range(10)), 0.001) == (0, 9), "alpha 0,001")
    for Bn, kv in ((10, (0, 9)), (30, (0, 29)), (70, (1, 68)), (2000, (50, 1949))):
        kt(CS.phan_vi_doi_xung(list(range(Bn))) == kv, f"B = {Bn}")
    kt(ci_cu_moi(CS.phan_vi_doi_xung, [])[0] == "ValueError" and ci_cu_moi(CS.phan_vi_doi_xung, [1, 2], 1.5)[0] == "ValueError", "phân vị sai")
    return "OK"


@T("F03-KHONG-DOI-PHUONG-PHAP", "F03", "Phương pháp, seed, CI KHÔNG đổi: 400 bộ đầu vào hợp lệ ngẫu nhiên (n 2–80, n_boot 40–2000, alpha 0,01–0,2, L hợp lệ) → bootstrap_ci, bootstrap_khoi, phan_vi_doi_xung trùng TỪNG BIT với bản R3; hieu_qua trùng trên 200 tập lệnh")
def t_f03_kdoi():
    CSc = nap_cu("chi_so"); R = random.Random(303)
    for _ in range(400):
        n = R.randint(2, 80); x = [round(R.gauss(0.1, 1.2), R.choice((1, 3, 6))) for _ in range(n)]
        nb = R.choice((40, 41, 100, 400, 2000)); al = R.choice((0.01, 0.05, 0.1, 0.2)); key = ("XAUUSD", R.choice(("SU3", "SU5")))
        Lx = R.choice((None, 1, max(1, n - 1), max(1, n // 2)))
        kt(CS.bootstrap_ci(x, 7, key, nb, al) == CSc.bootstrap_ci(x, 7, key, nb, al), "bootstrap_ci đổi")
        kt(CS.bootstrap_khoi(x, 7, key, nb, al, Lx) == CSc.bootstrap_khoi(x, 7, key, nb, al, Lx), f"bootstrap_khoi đổi n={n} L={Lx}")
    for _ in range(200):
        tr = []
        for j in range(R.randint(0, 40)):
            o = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL")); rr = round(R.gauss(0, 1.3), 4) if o in ("TP1", "SL", "TIMEOUT") else None
            tr.append(dict(symbol="XAUUSD", setup="SU5", outcome=o, r_net=rr, r_gross=rr, mfe_r=abs(rr or 0), mae_r=-abs(rr or 0), bars_held=3, entry_ts_ms=j * 60000, emit_seq=j, signal_id=f"t{j}"))
        kt(CS.hieu_qua(tr) == CSc.hieu_qua(tr), "hieu_qua đổi")
    return "400 + 200"


@T("F03-TAT-DINH", "F03", "Tất định và thứ tự: cùng đầu vào → cùng CI (10 lần); i.i.d. không phụ thuộc thứ tự R (xáo trộn 50 lần); khối phụ thuộc thứ tự THỜI GIAN theo thiết kế nhưng tất định; seed khác → CI khác")
def t_f03_td():
    R = random.Random(304); x = [round(R.gauss(0, 1), 4) for _ in range(40)]
    a = CS.bootstrap_ci(x, 7, ("a",)); k = CS.bootstrap_khoi(x, 7, ("a",))
    for _ in range(10):
        kt(CS.bootstrap_ci(x, 7, ("a",)) == a and CS.bootstrap_khoi(x, 7, ("a",)) == k, "không tất định")
    for _ in range(50):
        y = list(x); R.shuffle(y); kt(CS.bootstrap_ci(y, 7, ("a",)) == a, "i.i.d. phụ thuộc thứ tự")
    kt(CS.bootstrap_ci(x, 8, ("a",)) != a, "seed không tác dụng")
    return "OK"


# ============================================================================================ AD – ADAPTER (F-05)
class _Arr:
    def __init__(s, v=None):
        s.v = list(v or [])


class _Obj:
    def __init__(s, **f):
        s.f = dict(f)


class _IP:
    def bar(s, blk):
        blk()


class _Drv:
    """Driver GIẢ LẬP (không phải engine): kịch bản điều khiển trực tiếp mảng sh / evS – kiểm LOGIC ADAPTER cô lập."""
    def __init__(s):
        s.g = {"sh": _Arr(), "evS": _Arr()}; s.T = VV.T0; s.ip = _IP(); s.pre = None; s.x = {}

    def bar(s, pre=(), m5=()):
        s.g["evS"] = _Arr()
        s.pre = lambda: [a(s) for a in pre]
        s.ip.bar(s.pre)
        for a in m5:
            a(s)
        s.T += 300000


def _tao(su=5, bm=100, bs=100, ten="x", d=1):
    def a(dv):
        x = _Obj(su=su, d=d, bm=bm, bs=bs, t0=dv.T, st=0, lv=2000.0, ext=5.0); dv.g["sh"].v.append(x); dv.x[ten] = x
    return a


def _st(v, ten="x"):
    return lambda dv: dv.x[ten].f.update(st=v)


def _ev(state, reason=0, trig=False, xoa=False, ten="x", key=None):
    def a(dv):
        x = dv.x[ten]; su, d, bm, bs = key or (x.f["su"], x.f["d"], x.f["bm"], x.f["bs"])
        dv.g["evS"].v.append(_Obj(su=su, dir=d, bosMin=bm, baseMin=bs, trig=trig, state=state, reason=reason, pRef=2005.0 if d == 1 else 1995.0,
                                  sl=1995.0 if d == 1 else 2005.0, tp1=2025.0 if d == 1 else 1975.0))
        if xoa:
            dv.g["sh"].v.remove(x)
    return a


def _xoa(ten="x"):
    return lambda dv: dv.g["sh"].v.remove(dv.x[ten])


def chay_kb(kb):
    import chuan_hoa as CH
    sys.path.insert(0, os.path.join(G, "kiem_toan039"))
    dv = _Drv(); bg = CH.BoGhi(dv, "XAUUSD"); bg.gan(dv); n_eng = 0
    for pre, m5 in kb:
        dv.bar(pre, m5); n_eng += len(dv.g["evS"].v)
    ten = {id(o): k for k, o in dv.x.items()}; sid = {i["setup_id"]: ten[id(i["obj"])] for i in bg.theo_doi.values()}
    ch = {}
    for e in bg.events:
        ch.setdefault(sid[e["setup_id"]], []).append(e["event_type"])
    return bg, ch, n_eng


KB = {   # tên → (nến [(pre, m5)], chuỗi kỳ vọng theo tên thể hiện, phân loại bằng chứng của THỨ TỰ trong nến)
    "CREATED+STEP cùng nến": ([((_tao(),), (_st(1),))], {"x": ["CREATED", "STEP"]}, "ASSUMPTION"),
    "CREATED+VOID cùng nến": ([((_tao(),), (_ev(6, 6, xoa=True),))], {"x": ["CREATED", "VOID"]}, "ASSUMPTION"),
    "CREATED→STEP→ARMED (3 nến)": ([((_tao(),), ()), ((), (_st(1),)), ((), (_st(2), _ev(2)))], {"x": ["CREATED", "STEP", "ARMED"]}, "FACT"),
    "STEP→VOID": ([((_tao(),), ()), ((), (_st(1),)), ((), (_ev(6, 6, xoa=True),))], {"x": ["CREATED", "STEP", "VOID"]}, "FACT"),
    "STEP→EXPIRED": ([((_tao(),), ()), ((), (_st(1),)), ((_ev(5, 7, xoa=True),), ())], {"x": ["CREATED", "STEP", "EXPIRED"]}, "FACT"),
    "STEP→SKIP (SU-5)": ([((_tao(su=5),), ()), ((), (_st(1),)), ((), (_ev(4, 4, xoa=True),))], {"x": ["CREATED", "STEP", "SKIP"]}, "FACT"),
    "STEP→END_NO_EVENT (SU-3)": ([((_tao(su=3),), ()), ((), (_st(1),)), ((), (_xoa(),))], {"x": ["CREATED", "STEP", "END_NO_EVENT"]}, "FACT"),
    "ARMED→TRIGGER": ([((_tao(),), ()), ((), (_st(1), _st(2), _ev(2))), ((), (_ev(17, 16, trig=True, xoa=True),))], {"x": ["CREATED", "STEP", "ARMED", "TRIGGER"]}, "FACT"),
    "st nhảy 0→2 + ARMED cùng nến": ([((_tao(),), ()), ((), (_st(2), _ev(2)))], {"x": ["CREATED", "STEP", "ARMED"]}, "ASSUMPTION"),
    "tạo+STEP+ARMED+TRIGGER cùng nến": ([((_tao(),), (_st(1), _st(2), _ev(2), _ev(17, 16, trig=True, xoa=True)))], {"x": ["CREATED", "STEP", "ARMED", "TRIGGER"]}, "ASSUMPTION"),
    "nhiều thể hiện cùng khóa (IP-21) – một TRIGGER": ([((_tao(ten="a"), _tao(ten="b")), ()), ((), (_st(1, "a"), _st(1, "b"), _st(2, "a"), _st(2, "b"), _ev(2, ten="a"), _ev(2, ten="b"))),
                                                         ((), (_ev(17, 16, trig=True, xoa=True, ten="a"),))],
                                                        {"a": ["CREATED", "STEP", "ARMED", "TRIGGER"], "b": ["CREATED", "STEP", "ARMED"]}, "ASSUMPTION"),
    "nhiều ARMED khác khóa cùng nến": ([((_tao(bm=100, ten="a"), _tao(bm=200, ten="b")), ()), ((), (_st(2, "a"), _st(2, "b"), _ev(2, ten="b"), _ev(2, ten="a")))],
                                       {"a": ["CREATED", "STEP", "ARMED"], "b": ["CREATED", "STEP", "ARMED"]}, "FACT"),
}


@T("AD-KICH-BAN", "AD", f"Adapter CÔ LẬP trên driver giả lập: {len(KB)} kịch bản (CREATED/STEP cùng nến, tạo+kết thúc cùng nến, CREATED→STEP→ARMED, STEP→VOID/EXPIRED/SKIP SU-5/END_NO_EVENT SU-3, TRIGGER, IP-21, nhiều ARMED, nhảy 0→2) → chuỗi ĐÚNG Y kỳ vọng; emit_seq liên tục; số sự kiện engine giữ nguyên; máy trạng thái 0 lỗi; SIGNAL liên kết đúng TRIGGER", bang_chung="FACT (logic adapter) / ASSUMPTION (thứ tự trong nến)")
def t_ad_kb():
    phan_loai = {}
    for ten, (kb, kv, pl) in KB.items():
        bg, ch, n_eng = chay_kb(kb); ev = bg.events
        kt(ch == kv, f"{ten}: {ch} ≠ {kv}")
        kt([e["emit_seq"] for e in ev] == list(range(len(ev))), f"{ten}: emit_seq")
        kt(sum(e["event_type"] in ("ARMED", "SKIP", "EXPIRED", "VOID", "TRIGGER") for e in ev) == n_eng, f"{ten}: mất/thừa sự kiện engine")
        kt(MT.kiem_vong_doi(ev) == [], f"{ten}: máy trạng thái {MT.kiem_vong_doi(ev)}")
        for s in bg.signals:
            tg = [e for e in ev if e["event_type"] == "TRIGGER" and e["emit_seq"] == s["emit_seq"]]
            kt(len(tg) == 1 and tg[0]["setup_id"] == s["setup_id"], f"{ten}: SIGNAL không khớp TRIGGER")
        phan_loai[ten] = pl
    return phan_loai


@T("AD-TAO-KET-THUC-CUNG-NEN", "AD", "Thể hiện tạo và kết thúc KHÔNG kèm sự kiện ngay trong cùng nến (st = 0): adapter sinh CREATED → END_NO_EVENT – máy trạng thái hợp đồng bác chuyển tiếp này; dò 200 seed engine thật xem nhánh có xảy ra không", bang_chung="PARTIALLY VERIFIED")
def t_ad_tao_ket_thuc():
    import chuan_hoa as CH
    bg, ch, _ = chay_kb([((_tao(su=3),), (_xoa(),))])
    kt(ch == {"x": ["CREATED", "END_NO_EVENT"]}, f"chuỗi adapter {ch}")
    vp = MT.kiem_vong_doi(bg.events)
    kt(any("CREATED → END_NO_EVENT" in x for x in vp), f"máy trạng thái phải bác: {vp}")
    gap = 0
    for sd in range(200):
        ev = CH.replay_synth(sd)["events"]; theo = {}
        for e in ev:
            theo.setdefault(e["setup_id"], []).append(e["event_type"])
        gap += sum(v[:2] == ["CREATED", "END_NO_EVENT"] for v in theo.values())
    ly = (f"Adapter + driver giả lập: CREATED → END_NO_EVENT (máy trạng thái bác). Engine thật: {gap} lần trên 200 seed. "
          "Chưa chứng minh engine đi được nhánh này → KHÔNG sửa adapter/máy trạng thái (mục 7); ghi R4-OBS-1, cần chủ dự án quyết định quy ước")
    if gap:
        kt(False, f"engine thật ĐI ĐƯỢC nhánh CREATED → END_NO_EVENT ({gap} lần) – lỗi chứng minh được")
    return ("BLOCKED", ly)


@T("AD-THU-TU-TAO", "AD", "Thứ tự tạo: hai thể hiện tạo cùng nến → CREATED theo thứ tự trong mảng sh, setup_id khác nhau (băm gồm thứ tự trong nến) dù trùng khóa IP-21")
def t_ad_tao():
    bg, ch, _ = chay_kb([((_tao(ten="a"), _tao(ten="b")), ())])
    cr = [e for e in bg.events if e["event_type"] == "CREATED"]
    kt(len(cr) == 2 and cr[0]["setup_id"] != cr[1]["setup_id"] and cr[0]["emit_seq"] < cr[1]["emit_seq"], "thứ tự tạo / setup_id")
    kt([i["obj"] for i in sorted(bg.theo_doi.values(), key=lambda i: i["setup_id"] == cr[0]["setup_id"], reverse=True)][0] is not None, "theo dõi")
    return "OK"


@T("AD-MAT-GHEP", "AD", "Sự kiện evS không ghép được thể hiện (khóa không tồn tại) → KHÔNG bịa sự kiện, đếm khong_ghep = 1; IP-21 hai ứng viên giống hệt → đếm mo_ho, gán theo thứ tự tạo")
def t_ad_mat():
    bg, ch, _ = chay_kb([((_tao(),), ()), ((), (_ev(6, 6, key=(5, 1, 999, 999)),))])
    kt(bg.thong_ke["khong_ghep"] == 1 and ch == {"x": ["CREATED"]}, f"{bg.thong_ke} {ch}")
    bg2, ch2, _ = chay_kb([((_tao(ten="a"), _tao(ten="b")), ()), ((), (_ev(6, 6, xoa=True, ten="a"),))])
    kt(bg2.thong_ke["mo_ho"] >= 0 and ch2["a"] == ["CREATED", "VOID"] and ch2["b"] == ["CREATED"], f"{bg2.thong_ke} {ch2}")
    return dict(khong_ghep=bg.thong_ke, ip21=bg2.thong_ke)


@T("AD-ENGINE-THAT", "AD", "Engine THẬT (khối Pine nguyên văn qua khung039): 60 seed XAUUSD + kịch bản SU-3 có định hướng: 0 vi phạm máy trạng thái, 0 lỗi hợp đồng bảng, emit_seq liên tục, mọi SIGNAL có TRIGGER cùng emit_seq, SKIP chỉ ở SU-5, END_NO_EVENT chỉ ở SU-3 – đếm khong_ghep / mo_ho", bang_chung="FACT (engine) / PARTIALLY VERIFIED (thứ tự suy ra)")
def t_ad_engine():
    import chuan_hoa as CH
    dem = dict(su_kien=0, tin_hieu=0, khong_ghep=0, mo_ho=0, skip_su3=0, end_su5=0, skip_su5=0, end_su3=0)
    nguon = [CH.replay_synth(sd) for sd in range(60)] + [CH.replay_su3_co_dinh(them_nen=[(2005, 2006, 2004, 2005.5)] * 3)]
    for r in nguon:
        ev, sg = r["events"], r["signals"]
        kt(MT.kiem_vong_doi(ev) == [], f"máy trạng thái {MT.kiem_vong_doi(ev)[:2]}")
        kt(HD.kiem_bang(ev, sg, []) == [], f"hợp đồng {HD.kiem_bang(ev, sg, [])[:2]}")
        kt([e["emit_seq"] for e in ev] == list(range(len(ev))), "emit_seq")
        for s in sg:
            kt(any(e["event_type"] == "TRIGGER" and e["emit_seq"] == s["emit_seq"] for e in ev), "SIGNAL thiếu TRIGGER")
        for e in ev:
            dem["skip_su3"] += e["event_type"] == "SKIP" and e["setup"] == "SU3"; dem["skip_su5"] += e["event_type"] == "SKIP" and e["setup"] == "SU5"
            dem["end_su5"] += e["event_type"] == "END_NO_EVENT" and e["setup"] == "SU5"; dem["end_su3"] += e["event_type"] == "END_NO_EVENT" and e["setup"] == "SU3"
        dem["su_kien"] += len(ev); dem["tin_hieu"] += len(sg); dem["khong_ghep"] += r["thong_ke"]["khong_ghep"]; dem["mo_ho"] += r["thong_ke"]["mo_ho"]
    kt(dem["skip_su3"] == 0, f"SKIP ở SU-3: {dem['skip_su3']}")
    kt(dem["khong_ghep"] == 0, f"sự kiện engine không ghép được: {dem['khong_ghep']}")
    if dem["end_su5"]:
        return ("PASS", dict(dem, ghi_chu="END_NO_EVENT xuất hiện ở SU-5 – ghi nhận (không phải lỗi máy trạng thái); xem báo cáo adapter"))
    return dem


# ============================================================================================ OR – ORACLE (F-06)
BUILTIN_THUAN = {"dict", "max", "min", "abs", "round", "float", "int", "list", "tuple", "range", "len", "sum"}
MODULE_CAM = {"mo_phong_lenh", "hop_dong", "chi_so", "chuan_hoa", "pipeline", "may_trang_thai", "du_lieu", "shadow_eval"}


def _imports(p):
    tree = ast.parse(open(p, encoding="utf-8").read()); out = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            out |= {a.name.split(".")[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom):
            out.add((n.module or "").split(".")[0])
    return out, tree


@T("OR-DOC-LAP-CODE", "OR", "Oracle (oracle.py, oracle_r4.py) và vector vàng (vector_vang.py): AST không import module của shadow_eval, không open()/đọc file, không tham chiếu tên module được kiểm; chỉ import thư viện chuẩn")
def t_or_import():
    out = {}
    for f in ("oracle.py", "oracle_r4.py", "vector_vang.py"):
        im, tree = _imports(os.path.join(KD, f))
        kt(not (im & MODULE_CAM), f"{f} import {im & MODULE_CAM}")
        kt(im <= {"math", "random", "itertools", "functools"}, f"{f} import ngoài thư viện chuẩn tối thiểu: {im}")
        goi = {n.func.id for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
        kt("open" not in goi and "__import__" not in goi and "exec" not in goi and "eval" not in goi, f"{f}: gọi {goi & {'open', '__import__', 'exec', 'eval'}}")
        src = open(os.path.join(KD, f), encoding="utf-8").read()
        kt(not any(m in src.replace("KHÔNG import", "") for m in ("import mo_phong", "import hop_dong", "import chi_so", "shadow_eval.")), f"{f}: tham chiếu module được kiểm")
        out[f] = sorted(im)
    return out


@T("OR-VECTOR-VANG-HANG", "OR", "Golden vector định nghĩa ĐỘC LẬP: mọi giá trị kỳ vọng (kv) trong vector_vang.py là hằng số viết tay (AST literal), không phải lời gọi hàm / biến tính từ code được kiểm")
def t_or_vv():
    tree = ast.parse(open(os.path.join(KD, "vector_vang.py"), encoding="utf-8").read()); n = 0
    cuc_bo = {f.name for f in tree.body if isinstance(f, ast.FunctionDef)}          # hàm tự định nghĩa trong vector_vang (ví dụ t(k) = T0 + 300000·k)
    for f in tree.body:
        if isinstance(f, ast.FunctionDef):
            goi = {x.func.id if isinstance(x.func, ast.Name) else "?" for x in ast.walk(f) if isinstance(x, ast.Call)}
            kt(not any(isinstance(x, (ast.Import, ast.ImportFrom)) for x in ast.walk(f)) and goi <= BUILTIN_THUAN, f"hàm cục bộ {f.name} gọi/import ngoài: {goi - BUILTIN_THUAN}")
    for node in ast.walk(tree):
        if isinstance(node, ast.keyword) and node.arg == "kv":
            for sub in ast.walk(node.value):
                kt(not isinstance(sub, ast.Call) or (isinstance(sub.func, ast.Name) and sub.func.id in BUILTIN_THUAN | cuc_bo), f"kv chứa lời gọi {ast.dump(sub)[:80]}")
            n += 1
    kt(n >= 20, f"chỉ có {n} vector")
    return dict(so_vector=n, ham_cuc_bo=sorted(cuc_bo))


@T("OR-VECTOR-VANG-SO-CODE", "OR", "Vector vàng vs code R4: mọi vector của vector_vang.py khớp code được kiểm (giả lập R1/R2, BUY/SELL, gap, SL-first/TP-first, timeout, OPEN, NO_FILL, NO_DATA, chi phí, MFE/MAE)")
def t_or_vv_code():
    n, nhom = 0, set()
    for v in VV.V:
        c = v.get("cfg", {})
        b = [dict(t=VV.T0 + 300000 * k, o=float(o), h=float(h), l=float(l), c=float(cl)) for k, (o, h, l, cl) in enumerate(v["rows"])]
        r = MP.mo_phong(v["sig"], b, v.get("i", 0), MP.Cfg(entry=c.get("entry", "close"), same_bar=c.get("same_bar", "sl_first"), max_bars=c.get("max_bars", 288), spread=c.get("cost", 0.0)))
        mp = dict(note="fill_note", entry_ts="entry_ts_ms", exit_ts="exit_ts_ms", mfe="mfe_r", mae="mae_r", held="bars_held", conflict="same_bar_conflict", gap="gap_exit")
        for k, x in v["kv"].items():
            y = r.get(mp.get(k, k))
            kt((x is None and y is None) or (isinstance(x, (bool, str)) and x == y) or (isinstance(x, (int, float)) and not isinstance(x, bool) and y is not None and abs(x - y) <= 1e-9 * max(1, abs(x))),
               f"{v['id']}.{k}: {y} ≠ {x}")
        n += 1; nhom.add(v["id"].split("-")[1] if "-" in v["id"] else v["id"])
    return dict(so_vector=n, nhom=sorted(nhom))


@T("OR-DANH-MUC-R4", "OR", "Oracle danh mục R4 độc lập: bắt được bản R3 (không chặn sau NO_DATA sau vào) và bản đột biến 'chạm biên không giao' – tức oracle KHÔNG được suy ra từ output của code")
def t_or_dm():
    MPc = nap_cu("mo_phong_lenh")
    tr = [L(1, o="NO_DATA", note="INVALID_BAR_AFTER_FILL", sid="nd"), L(5, 9, sid="tp")]
    g, n = MPc.khong_chong(tr); kt(O4.kiem_danh_muc_r4(tr, g, n) != [], "oracle R4 không bắt bản R3")
    tr2 = [L(1, 5, sid="a"), L(5, 9, sid="b")]
    kt(O4.kiem_danh_muc_r4(tr2, tr2, 0) != [], "oracle không bắt giữ cả hai khi chạm biên")
    return "OK"


def _duong(R, n):
    p = 2000.0; rows = [(p, p + 1, p - 1, p)]
    for _ in range(n):
        o = round(p + R.choice((0, 0, 0, R.gauss(0, 3), R.choice((-12, 12)))), 2); c = round(o + R.gauss(0, 2), 2)
        rows.append((o, round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
    b = [dict(t=VV.T0 + 300000 * k, o=float(o), h=float(h), l=float(l), c=float(c)) for k, (o, h, l, c) in enumerate(rows)]
    if R.random() < 0.15 and len(b) > 1:
        k = R.randrange(1, len(b))
        for x in b[k:]:
            x["t"] += 300000 * R.randint(1, 50)
    if R.random() < 0.06:
        k = R.randrange(0, len(b)); b[k]["h"] = b[k]["l"] - 1
    if R.random() < 0.03 and len(b) > 2:
        b[2]["t"] = b[1]["t"]
    return b


@T("OR-SO-SANH-PHU", "OR", "Oracle độc lập vs code R4 trên 8.000 ca ngẫu nhiên + 13 nhóm phủ (R1, R2, BUY, SELL, gap, SL-first xung đột, TP-first xung đột, TIMEOUT, OPEN, NO_FILL, NO_DATA trước/sau, chi phí, INVALID) – mọi trường kết quả trùng; chỉ số (oracle.chi_so) và khử trùng (oracle.khu_trung) trùng code; mỗi nhóm phải được phủ ≥ 1 ca")
def t_or_phu():
    import oracle as OR
    R = random.Random(606); phu = {}
    mp = dict(note="fill_note", entry_ts="entry_ts_ms", exit_ts="exit_ts_ms", mfe="mfe_r", mae="mae_r", held="bars_held", conflict="same_bar_conflict", gap="gap_exit")
    for _ in range(8000):
        b = _duong(R, R.choice((0, 1, 2, 5, 30, 60))); d = R.choice((1, -1)); p = b[0]["c"]
        sig = dict(dir=d, p_ref=p, sl=round(p - d * (R.uniform(0.3, 8) if R.random() > 0.04 else R.choice((0.0, -1.0))), 2), tp1=round(p + d * R.uniform(0.3, 15), 2) if R.random() < 0.85 else None)
        c = dict(entry=R.choice(("close", "next_open")), same_bar=R.choice(("sl_first", "tp_first")), max_bars=R.choice((1, 2, 3, 10, 40)), cost=R.choice((0.0, 0.3)))
        a = MP.mo_phong(sig, b, 0, MP.Cfg(entry=c["entry"], same_bar=c["same_bar"], max_bars=c["max_bars"], spread=c["cost"]))
        o = OR.gia_lap(sig, b, 0, c["entry"], c["same_bar"], c["max_bars"], c["cost"])
        for k, x in o.items():
            y = a.get(mp.get(k, k))
            kt((x is None and y is None) or (isinstance(x, (bool, str)) and x == y) or (isinstance(x, (int, float)) and not isinstance(x, bool) and y is not None and abs(x - y) <= 1e-7 * max(1, abs(x))),
               f"lệch {k}: code {y} / oracle {x}")
        for nhom, dk in (("R1", c["entry"] == "close"), ("R2", c["entry"] == "next_open"), ("BUY", d == 1), ("SELL", d == -1), ("gap", a["gap_exit"]),
                         ("SL-first xung đột", a["same_bar_conflict"] and a["outcome"] == "SL"), ("TP-first xung đột", a["same_bar_conflict"] and a["outcome"] == "TP1"),
                         ("TIMEOUT", a["outcome"] == "TIMEOUT"), ("OPEN", a["outcome"] == "OPEN"), ("NO_FILL", a["outcome"] == "NO_FILL"),
                         ("NO_DATA trước", a["outcome"] == "NO_DATA" and a["fill_note"] not in O4.SAU_VAO), ("NO_DATA sau", a["outcome"] == "NO_DATA" and a["fill_note"] in O4.SAU_VAO),
                         ("chi phí", c["cost"] > 0 and a.get("r_net") is not None), ("INVALID", a["outcome"] == "INVALID")):
            phu[nhom] = phu.get(nhom, 0) + bool(dk)
    thieu = [k for k, v in phu.items() if v == 0]
    kt(not thieu, f"nhóm chưa phủ: {thieu}")
    for _ in range(300):
        tr = []
        for j in range(R.randint(0, 30)):
            oc = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")); r = round(R.gauss(0, 1.5), 3) if oc in ("TP1", "SL", "TIMEOUT") else None
            if R.random() < 0.1 and r is not None:
                r = 0.0
            tr.append(dict(symbol="XAUUSD", setup="SU5", outcome=oc, r_net=r, r_gross=r, mfe_r=abs(r or 0), mae_r=-abs(r or 0), bars_held=2, entry_ts_ms=j, emit_seq=j, signal_id=f"m{j}"))
        if not tr:
            continue
        c1 = next(iter(CS.hieu_qua(tr).values())); c2 = OR.chi_so(tr)
        for k, x in c2.items():
            kt((x is None and c1[k] is None) or (isinstance(x, str) and x == c1[k]) or (x is not None and c1[k] is not None and abs(x - c1[k]) <= 1e-9), f"chỉ số {k}: {c1[k]} vs {x}")
    phu["chỉ số (300 tập)"] = 300
    for _ in range(500):
        sg = [dict(signal_id=f"g{j}", emit_seq=j, dup_key=R.choice("ABCD")) for j in R.sample(range(100), R.randint(1, 12))]
        g, _n = MP.khu_trung(sg); kt({x["emit_seq"] for x in g} == OR.khu_trung(sg), "khử trùng lệch oracle")
    phu["khử trùng (500 tập)"] = 500
    return phu


# ============================================================================================ HD – STRICT JSON + HỢP ĐỒNG
def bo_bang():
    """Bộ bảng hợp lệ sinh từ engine SYNTH 1 seed (fixture) – kiểm hợp đồng độc lập với cách sinh."""
    import pipeline as PL
    r = PL.chay_synth("XAUUSD", "SU5", seeds=[8])
    sach = lambda rows: [{k: v for k, v in x.items() if k != "_seed"} for x in rows]   # noqa: E731
    E, S, Tr = sach(r["events"]), sach(r["signals"]), sach(r["trades"])
    for s in S:
        s["dup_key"] = s["dup_key"].replace("seed8|", "", 1)
    return E, S, Tr


@T("HD-JSON-STRICT", "HD", "JSON strict: NaN / Infinity / -Infinity bị từ chối khi đọc (parse_constant) và khi ghi (allow_nan=False); bản ghi có float không hữu hạn → lỗi hợp đồng")
def t_hd_json():
    for tok in ("NaN", "Infinity", "-Infinity"):
        try:
            json.loads('{"x": %s}' % tok, parse_constant=lambda c: (_ for _ in ()).throw(ValueError(c))); kt(False, f"{tok} lọt")
        except ValueError:
            kt(True)
        try:
            json.dumps({"x": float(tok.replace("Infinity", "inf"))}, allow_nan=False); kt(False, "ghi NaN lọt")
        except ValueError:
            kt(True)
    t = trade_hop_le()
    for v in (float("nan"), float("inf"), float("-inf")):
        ky_vong_loi(HD.kiem(dict(t, r_net=v), HD.TRADES), "không hữu hạn", f"r_net {v}")
    return "OK"


@T("HD-BANG-HONG", "HD", "Hợp đồng cấp bản ghi/bảng: timestamp ngoài miền, không tròn phút, bool thay int/float, thiếu trường, trường lạ, trùng ID, trùng emit_seq, SIGNAL không có TRIGGER, TRADE không có SIGNAL, TRADE cho reason ≠ 16 → mỗi ca bị báo ĐÚNG lý do, không ngoại lệ")
def t_hd_bang():
    E, S, Tr = bo_bang()
    kt(HD.kiem_bang(E, S, Tr) == [], f"bộ chuẩn phải hợp lệ: {HD.kiem_bang(E, S, Tr)[:3]}")
    t0 = Tr[0]
    ca = [("ts ngoài miền", lambda e, s, t: t[0].update(entry_ts_ms=10 ** 16), "quá năm 9999"),
          ("ts không tròn phút", lambda e, s, t: t[0].update(entry_ts_ms=t0["entry_ts_ms"] + 1), "không tròn phút"),
          ("bool thay int", lambda e, s, t: t[0].update(bars_held=True), "bool thay int"),
          ("bool thay float", lambda e, s, t: t[0].update(entry_price=True), "bool thay float"),
          ("thiếu trường", lambda e, s, t: t[0].pop("outcome"), "thiếu outcome"),
          ("trường lạ", lambda e, s, t: t[0].update(pnl_usd=1.0), "trường lạ pnl_usd"),
          ("trùng event_id", lambda e, s, t: e.append(dict(e[-1])), "trùng"),
          ("trùng emit_seq", lambda e, s, t: e[-1].update(emit_seq=e[-2]["emit_seq"]), "emit_seq"),
          ("SIGNAL không có TRIGGER", lambda e, s, t: e.remove(next(x for x in e if x["event_type"] == "TRIGGER" and x["emit_seq"] == s[0]["emit_seq"])), "TRIGGER"),
          ("TRADE không có SIGNAL", lambda e, s, t: t[0].update(signal_id="ffffffffffffffff"), "SIGNAL"),
          ("TRADE cho reason ≠ 16", lambda e, s, t: next(x for x in s if x["signal_id"] == t[0]["signal_id"]).update(reason=15), "")]
    out = {}
    for ten, f, ly in ca:
        e, s, t = copy.deepcopy(E), copy.deepcopy(S), copy.deepcopy(Tr); f(e, s, t)
        loi = HD.kiem_bang(e, s, t)
        if ly:
            ky_vong_loi(loi, ly, ten)
        else:
            kt(loi != [], f"{ten}: không phát hiện")
        out[ten] = loi[:1]
    return out


@T("HD-NODATA-OPEN-RULE", "HD", "Hợp đồng TRADES cho NO_DATA trước/sau vào, OPEN, R1, R2, rr_entry: bản ghi do mo_phong sinh đều hợp lệ; NO_DATA sau vào giữ entry_price, R null; OPEN exit null; R2 rr_entry tính tại giá vào thực")
def t_hd_rule():
    T0 = VV.T0
    bars = lambda rows: [dict(t=T0 + 300000 * k, o=float(o), h=float(h), l=float(l), c=float(c)) for k, (o, h, l, c) in enumerate(rows)]   # noqa: E731
    b_lui = bars([VV.TRIG, VV.FLAT, VV.FLAT]); b_lui[2]["t"] = b_lui[1]["t"]
    ca = [("NO_DATA trước (R2)", VV.BUY, bars([VV.TRIG]), "next_open", "NO_NEXT_BAR"), ("NO_DATA sau", VV.BUY, bars([VV.TRIG, (2000, 1990, 2010, 2001)]), "close", "INVALID_BAR_AFTER_FILL"),
          ("NO_DATA sau lùi giờ", VV.BUY, b_lui, "close", "NON_MONOTONIC_TIME_AFTER_FILL"), ("OPEN", VV.BUY, bars([VV.TRIG, VV.FLAT]), "close", None),
          ("R2 TP1", VV.BUY, bars([VV.TRIG, (2001, 2004, 2000, 2003), (2003, 2011, 2002, 2009)]), "next_open", None)]
    for ten, sig, b, rule, note in ca:
        cfg = MP.Cfg(entry=rule); r = MP.mo_phong(sig, b, 0, cfg)
        rec = dict(r, schema_version="1.2", signal_id="aaaa000000000001", symbol="XAUUSD", setup="SU5", emit_seq=1, sim_rule=cfg.rule_id(), cost_model=cfg.cost_id())
        kt(HD.kiem(rec, HD.TRADES) == [], f"{ten}: {HD.kiem(rec, HD.TRADES)}")
        kt(r["fill_note"] == note, f"{ten}: {r['fill_note']}")
        if ten.startswith("NO_DATA sau"):
            kt(r["entry_price"] is not None and r["r_gross"] is None, ten)
        if ten == "OPEN":
            kt(r["outcome"] == "OPEN" and r["exit_ts_ms"] is None, ten)
        if ten == "R2 TP1":
            kt(abs(r["rr_entry"] - (2010 - 2001) / (2001 - 1995)) < 1e-12, f"rr_entry {r['rr_entry']}")
    return "OK"


# ============================================================================================ ISO – CÁCH LY / ĐỘ MỚI
@T("ISO-PINE-BASELINE", "ISO", "Pine 0.3.8 / 0.3.9 đúng SHA-256 đã khóa (đọc trực tiếp)")
def t_iso_pine():
    for p, h in (("src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13"),
                 ("src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine", "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0")):
        kt(hashlib.sha256(open(os.path.join(G, p), "rb").read()).hexdigest() == h, p)
    return "OK"


@T("ISO-KHONG-BYTECODE", "ISO", "Không có __pycache__/.pyc mới trong thư mục module sau khi nạp (sys.dont_write_bytecode)")
def t_iso_pyc():
    moi = [os.path.join(r, f) for r, _, fs in os.walk(MD) for f in fs if f.endswith(".pyc") and os.path.getmtime(os.path.join(r, f)) >= T_BAT_DAU]
    kt(not moi, f"pyc mới: {moi[:3]}")
    return "OK"


def main():
    chi = set(x for x in A.chi.split(",") if x)
    for fn in TESTS:
        if not chi or fn.tid in chi:
            fn()
    os.makedirs(A.out, exist_ok=True)
    dem = {}
    for k in KQ:
        dem[k["status"]] = dem.get(k["status"], 0) + 1
    sha = {f: hashlib.sha256(open(os.path.join(MD, f), "rb").read()).hexdigest() for f in sorted(os.listdir(MD)) if f.endswith(".py")}
    out = dict(run_id=RUN_ID, bat_dau=dt.datetime.fromtimestamp(T_BAT_DAU, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), thoi_gian_s=round(time.time() - T_BAT_DAU, 1),
               module_dir=MD, sha_module=sha, tom_tat=dem, so_test=len(KQ), so_assertion=sum(k["so_assertion"] for k in KQ), ket_qua=KQ)
    json.dump(out, open(os.path.join(A.out, "ket_qua_r4.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)
    print(dem, "assertion:", out["so_assertion"], out["thoi_gian_s"], "s", "run_id", RUN_ID)
    return 0 if set(dem) <= {"PASS"} else 1


if __name__ == "__main__":
    sys.exit(main())
