# -*- coding: utf-8 -*-
"""GOLDEN VECTORS – giá trị kỳ vọng TÍNH TAY từ quy ước đã khóa (mo_phong_lenh docstring), KHÔNG lấy từ code được kiểm.
Nến: (Open, High, Low, Close); nến 0 = nến trigger. Thời gian nến k = T0 + 300 000·k ms. 'held' = số nến đánh giá tới nến thoát.
BUY chuẩn: P_ref 2000, SL 1995, TP1 2010 → rủi ro 5. SELL chuẩn: P_ref 2000, SL 2005, TP1 1990 → rủi ro 5.
Mỗi vector: id, mô tả, sig, rows, cfg (entry, same_bar, max_bars, cost), kỳ vọng (chỉ các trường ghi ra được so sánh)."""
T0 = 60000 * 1000000
TRIG = (1999, 2001, 1998, 2000)
TRIG_S = (2001, 2002, 1999, 2000)
FLAT = (2000, 2001, 1999, 2000.5)
FLAT_S = (2000, 2001, 1999, 1999.5)
BUY = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
SELL = dict(dir=-1, p_ref=2000.0, sl=2005.0, tp1=1990.0)


def t(k):
    return T0 + 300000 * k


V = [
    # ---------------------------------------------------------------- R1 cơ bản (BUY)
    dict(id="G-R1-TP", mo="R1 BUY chạm TP1 ở nến 2", sig=BUY, rows=[TRIG, (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)], cfg={},
         kv=dict(outcome="TP1", exit_price=2010, exit_ts=t(2), r_gross=2.0, mfe=2.0, mae=-0.2, held=2, gap=False, conflict=False, entry_price=2000, entry_ts=t(0), rr_entry=2.0)),
    dict(id="G-R1-SL", mo="R1 BUY chạm SL ở nến 2; phía có lợi của nến thoát (1998) không tính", sig=BUY,
         rows=[TRIG, (2000, 2003, 1996, 1997), (1997, 1998, 1994, 1995)], cfg={}, kv=dict(outcome="SL", exit_price=1995, r_gross=-1.0, mfe=0.6, mae=-1.0, held=2)),
    dict(id="G-R1-SL-FAV", mo="Nến thoát SL có High 2008 vượt MFE trước (0,4) → MFE vẫn 0,4 (phía có lợi của nến thoát SL KHÔNG tính)", sig=BUY,
         rows=[TRIG, (2000, 2002, 1999, 2001), (2001, 2008, 1994, 1996)], cfg={}, kv=dict(outcome="SL", exit_price=1995, r_gross=-1.0, mfe=0.4, mae=-1.0, held=2)),
    dict(id="G-R1-TPNULL", mo="R1 TP1 null: giá lên 2050 không thoát; nến 2 chạm SL → SL, MFE 10", sig=dict(BUY, tp1=None),
         rows=[TRIG, (2000, 2050, 1999, 2040), (2040, 2041, 1990, 1992)], cfg={}, kv=dict(outcome="SL", exit_price=1995, r_gross=-1.0, mfe=10.0, mae=-1.0, held=2, rr_entry=None)),
    dict(id="G-R1-TIMEOUT", mo="max_bars 3, không chạm → TIMEOUT tại Close nến 3 (R 0,1)", sig=BUY, rows=[TRIG] + [FLAT] * 4, cfg=dict(max_bars=3),
         kv=dict(outcome="TIMEOUT", exit_price=2000.5, exit_ts=t(3), r_gross=0.1, mfe=0.2, mae=-0.2, held=3)),
    dict(id="G-R1-OPEN", mo="max_bars 5, chỉ có 2 nến sau → OPEN (R tạm 0,1, không thoát)", sig=BUY, rows=[TRIG, FLAT, FLAT], cfg=dict(max_bars=5),
         kv=dict(outcome="OPEN", exit_price=None, exit_ts=None, r_gross=0.1, mfe=0.2, mae=-0.2, held=2)),
    dict(id="G-R1-GAPSL", mo="Gap: Open nến 1 = 1990 < SL → thoát tại Open, R −2", sig=BUY, rows=[TRIG, (1990, 1992, 1988, 1991)], cfg={},
         kv=dict(outcome="SL", exit_price=1990, r_gross=-2.0, mfe=0.0, mae=-2.0, held=1, gap=True)),
    dict(id="G-R1-GAPTP", mo="Gap: Open nến 1 = 2015 > TP1 → thoát tại Open, R +3", sig=BUY, rows=[TRIG, (2015, 2016, 2014, 2015)], cfg={},
         kv=dict(outcome="TP1", exit_price=2015, r_gross=3.0, mfe=3.0, mae=0.0, held=1, gap=True)),
    dict(id="G-R1-GAPXA", mo="Gap qua xa nhiều mức: Open 1900 → R −20", sig=BUY, rows=[TRIG, (1900, 1901, 1899, 1900)], cfg={},
         kv=dict(outcome="SL", exit_price=1900, r_gross=-20.0, mfe=0.0, mae=-20.0, held=1, gap=True)),
    dict(id="G-R1-SB-SL", mo="Cùng nến chạm SL và TP1, mặc định sl_first → SL, cờ xung đột, MFE không lấy nến đó", sig=BUY, rows=[TRIG, (2000, 2012, 1994, 2001)], cfg={},
         kv=dict(outcome="SL", exit_price=1995, r_gross=-1.0, mfe=0.0, mae=-1.0, held=1, conflict=True, gap=False)),
    dict(id="G-R1-SB-TP", mo="Cùng nến, biến thể độ nhạy tp_first → TP1, MFE 2, MAE −1,2 (Low 1994 đã qua SL)", sig=BUY, rows=[TRIG, (2000, 2012, 1994, 2001)],
         cfg=dict(same_bar="tp_first"), kv=dict(outcome="TP1", exit_price=2010, r_gross=2.0, mfe=2.0, mae=-1.2, held=1, conflict=True)),
    dict(id="G-R1-NOLOOK", mo="High/Low nến trigger (2020/1990) KHÔNG được dùng ở R1 → TIMEOUT", sig=BUY, rows=[(1999, 2020, 1990, 2000)] + [FLAT] * 4, cfg=dict(max_bars=4),
         kv=dict(outcome="TIMEOUT", r_gross=0.1, mfe=0.2, mae=-0.2, held=4)),
    dict(id="G-R1-COST", mo="Chi phí 0,5 giá / rủi ro 5 → r_net = 2,0 − 0,1 = 1,9", sig=BUY, rows=[TRIG, (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)],
         cfg=dict(cost=0.5), kv=dict(outcome="TP1", r_gross=2.0, r_net=1.9)),
    dict(id="G-R1-GAPLAST", mo="max_bars 3, nến 3 (nến cuối) mở gap 1990 → SL gap tại nến 3, KHÔNG phải TIMEOUT", sig=BUY,
         rows=[TRIG, FLAT, FLAT, (1990, 1991, 1989, 1990), FLAT], cfg=dict(max_bars=3), kv=dict(outcome="SL", exit_price=1990, r_gross=-2.0, held=3, gap=True, mae=-2.0)),
    dict(id="G-R1-TIMEOUT-EXACT", mo="max_bars 3 và có ĐÚNG 3 nến sau trigger (không chạm) → TIMEOUT (không phải OPEN)", sig=BUY, rows=[TRIG] + [FLAT] * 3, cfg=dict(max_bars=3),
         kv=dict(outcome="TIMEOUT", held=3, exit_ts=t(3), r_gross=0.1)),
    dict(id="G-R1-OPEN-EXACT", mo="max_bars 3 và chỉ có 2 nến sau → OPEN, giữ 2", sig=BUY, rows=[TRIG] + [FLAT] * 2, cfg=dict(max_bars=3),
         kv=dict(outcome="OPEN", held=2, exit_ts=None)),
    dict(id="G-R1-HITLAST", mo="max_bars 3, chạm TP1 đúng nến 3 → TP1 giữ 3", sig=BUY, rows=[TRIG, FLAT, FLAT, (2000, 2011, 1999, 2005)], cfg=dict(max_bars=3),
         kv=dict(outcome="TP1", held=3, r_gross=2.0, mfe=2.0, mae=-0.2)),
    dict(id="G-R1-HITAFTER", mo="max_bars 3, chạm ở nến 4 → TIMEOUT tại nến 3", sig=BUY, rows=[TRIG, FLAT, FLAT, FLAT, (2000, 2011, 1999, 2005)], cfg=dict(max_bars=3),
         kv=dict(outcome="TIMEOUT", held=3, exit_ts=t(3), r_gross=0.1)),
    dict(id="G-R1-LASTTRIG", mo="Trigger ở nến cuối → OPEN, giữ 0, R 0", sig=BUY, rows=[TRIG], cfg={}, kv=dict(outcome="OPEN", held=0, r_gross=0.0, mfe=0.0, mae=0.0)),
    dict(id="G-R1-INVRISK", mo="SL 2001 > P_ref → INVALID INVALID_RISK", sig=dict(BUY, sl=2001.0), rows=[TRIG, FLAT], cfg={},
         kv=dict(outcome="INVALID", note="INVALID_RISK", r_gross=None, mfe=None, exit_price=None)),
    dict(id="G-R1-TPWRONG", mo="TP1 1990 dưới P_ref của BUY → INVALID TP_WRONG_SIDE", sig=dict(BUY, tp1=1990.0), rows=[TRIG, FLAT], cfg={},
         kv=dict(outcome="INVALID", note="TP_WRONG_SIDE")),
    dict(id="G-R1-DIR0", mo="dir 0 → INVALID INVALID_SIGNAL", sig=dict(BUY, dir=0), rows=[TRIG, FLAT], cfg={}, kv=dict(outcome="INVALID", note="INVALID_SIGNAL")),
    dict(id="G-R1-BADBAR", mo="Nến 1 hỏng (High < Low) sau khi đã vào → NO_DATA INVALID_BAR_AFTER_FILL", sig=BUY, rows=[TRIG, (2000, 1990, 2010, 2001)], cfg={},
         kv=dict(outcome="NO_DATA", note="INVALID_BAR_AFTER_FILL", r_gross=None)),
    # ---------------------------------------------------------------- R2 A–P (BUY)
    dict(id="G-R2-A-E", mo="R2 A+E: Open 2003 giữa ET và TP1 → khớp, rủi ro TĂNG 5 → 8, TP1 → R 7/8; rr_entry 0,875", sig=BUY,
         rows=[TRIG, (2003, 2004, 2002, 2003.5), (2003.5, 2011, 2003, 2009)], cfg=dict(entry="next_open"),
         kv=dict(outcome="TP1", entry_price=2003, entry_ts=t(1), exit_price=2010, r_gross=0.875, mfe=0.875, mae=-0.125, held=2, rr_entry=0.875)),
    dict(id="G-R2-B-F", mo="R2 B+F: Open 1997 giữa ET và SL → khớp, rủi ro GIẢM 5 → 2, TP1 → R 6,5", sig=BUY,
         rows=[TRIG, (1997, 1998, 1996, 1997.5), (1997.5, 2011, 1997, 2009)], cfg=dict(entry="next_open"),
         kv=dict(outcome="TP1", entry_price=1997, r_gross=6.5, mfe=6.5, mae=-0.5, held=2, rr_entry=6.5)),
    dict(id="G-R2-C", mo="R2 C/H: Open 1994 vượt SL → NO_FILL GAP_BEYOND_SL (giá vào không còn hợp lệ)", sig=BUY, rows=[TRIG, (1994, 1995, 1993, 1994)], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_FILL", note="GAP_BEYOND_SL", entry_ts=t(1), entry_price=1994, r_gross=None, mfe=None, exit_price=None, held=0)),
    dict(id="G-R2-C-EQ", mo="R2: Open đúng bằng SL 1995 → NO_FILL GAP_BEYOND_SL (rủi ro 0)", sig=BUY, rows=[TRIG, (1995, 1996, 1994, 1995)], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_FILL", note="GAP_BEYOND_SL")),
    dict(id="G-R2-D", mo="R2 D: Open 2015 vượt TP1 → NO_FILL GAP_BEYOND_TP", sig=BUY, rows=[TRIG, (2015, 2016, 2014, 2015), FLAT], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_FILL", note="GAP_BEYOND_TP", entry_price=2015)),
    dict(id="G-R2-D-EQ", mo="R2: Open đúng bằng TP1 2010 → NO_FILL GAP_BEYOND_TP", sig=BUY, rows=[TRIG, (2010, 2011, 2009, 2010)], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_FILL", note="GAP_BEYOND_TP")),
    dict(id="G-R2-G", mo="R2 G: RR tại giá vào 0,875 < 1,5 → VẪN khớp (R2 không chạy lại S1 – ASSUMPTION), ghi rr_entry", sig=BUY,
         rows=[TRIG, (2003, 2004, 2002, 2003.5), FLAT], cfg=dict(entry="next_open", max_bars=5), kv=dict(outcome="OPEN", rr_entry=0.875, entry_price=2003)),
    dict(id="G-R2-I", mo="R2 I: TP1 null, Open 2003 → nến 2 chạm SL → R = (1995 − 2003)/8 = −1", sig=dict(BUY, tp1=None),
         rows=[TRIG, (2003, 2004, 2002, 2003.5), (2003.5, 2030, 1994, 1996)], cfg=dict(entry="next_open"),
         kv=dict(outcome="SL", r_gross=-1.0, mfe=0.125, mae=-1.0, held=2, rr_entry=None)),
    dict(id="G-R2-J", mo="R2 J: không có nến kế → NO_DATA NO_NEXT_BAR (thiếu dữ liệu, KHÔNG phải NO_FILL)", sig=BUY, rows=[TRIG], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_DATA", note="NO_NEXT_BAR", entry_ts=t(0), entry_price=None)),
    dict(id="G-R2-K", mo="R2 K: hình học hỏng (SL trên P_ref) → INVALID trước mọi xử lý giá vào", sig=dict(BUY, sl=2001.0), rows=[TRIG, FLAT], cfg=dict(entry="next_open"),
         kv=dict(outcome="INVALID", note="INVALID_RISK")),
    dict(id="G-R2-L", mo="R2 L: nến kế hỏng (giá ≤ 0) → NO_DATA INVALID_BAR (chưa vào)", sig=BUY, rows=[TRIG, (0, 2001, 0, 2000)], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_DATA", note="INVALID_BAR")),
    dict(id="G-R2-M", mo="R2 M: khớp 2003, nến 2 mở 1980 (qua SL rất xa) → SL gap tại 1980, R −2,875", sig=BUY,
         rows=[TRIG, (2003, 2004, 2002, 2003.5), (1980, 1981, 1979, 1980)], cfg=dict(entry="next_open"), kv=dict(outcome="SL", exit_price=1980, r_gross=-2.875, gap=True, held=2)),
    dict(id="G-R2-N", mo="R2 N: nến đầu đánh giá = nến vào (Open là giá vào, không phải gap); nến 2 mở 2012 > TP1 → TP1 gap R 1,125", sig=BUY,
         rows=[TRIG, (2003, 2004, 2002, 2003.5), (2012, 2013, 2011, 2012)], cfg=dict(entry="next_open"), kv=dict(outcome="TP1", exit_price=2012, r_gross=1.125, gap=True, held=2)),
    dict(id="G-R2-O", mo="R2 O: max_bars 2, nến cuối mở gap 1990 → SL gap R −1,625 (không TIMEOUT)", sig=BUY,
         rows=[TRIG, (2003, 2004, 2002, 2003.5), (1990, 1991, 1989, 1990), FLAT], cfg=dict(entry="next_open", max_bars=2), kv=dict(outcome="SL", r_gross=-1.625, held=2, gap=True)),
    dict(id="G-R2-ENTRYBAR", mo="R2: nến vào chạm TP1 trong nến (sau Open) → TP1 giữ 1, không gap", sig=BUY, rows=[TRIG, (2001, 2011, 2000, 2008)], cfg=dict(entry="next_open"),
         kv=dict(outcome="TP1", held=1, gap=False, r_gross=1.5)),
    # ---------------------------------------------------------------- SELL viết tay (không sinh bằng phép gương)
    dict(id="G-S-R1-TP", mo="R1 SELL chạm TP1 1990 ở nến 2", sig=SELL, rows=[TRIG_S, (2000, 2001, 1996, 1997), (1997, 1998, 1989, 1991)], cfg={},
         kv=dict(outcome="TP1", exit_price=1990, r_gross=2.0, mfe=2.0, mae=-0.2, held=2)),
    dict(id="G-S-R1-GAPSL", mo="R1 SELL: Open 2010 > SL → SL gap R −2", sig=SELL, rows=[TRIG_S, (2010, 2012, 2008, 2011)], cfg={}, kv=dict(outcome="SL", exit_price=2010, r_gross=-2.0, mae=-2.0, gap=True)),
    dict(id="G-S-R2-B", mo="R2 SELL: Open 2003 giữa ET và SL → rủi ro 2, TP1 → R 6,5", sig=SELL, rows=[TRIG_S, (2003, 2004, 2002, 2002.5), (2002.5, 2003, 1989, 1991)],
         cfg=dict(entry="next_open"), kv=dict(outcome="TP1", entry_price=2003, r_gross=6.5, mfe=6.5, mae=-0.5, held=2, rr_entry=6.5)),
    dict(id="G-S-R2-D", mo="R2 SELL: Open 1988 vượt TP1 → NO_FILL GAP_BEYOND_TP", sig=SELL, rows=[TRIG_S, (1988, 1989, 1987, 1988)], cfg=dict(entry="next_open"),
         kv=dict(outcome="NO_FILL", note="GAP_BEYOND_TP")),
    dict(id="G-S-SB-TP", mo="SELL cùng nến, tp_first → TP1, MAE (2000 − 2006)/5 = −1,2", sig=SELL, rows=[TRIG_S, (2000, 2006, 1988, 1999)], cfg=dict(same_bar="tp_first"),
         kv=dict(outcome="TP1", r_gross=2.0, mfe=2.0, mae=-1.2, conflict=True)),
    dict(id="G-S-SB-SL", mo="SELL cùng nến, sl_first → SL R −1, MFE 0", sig=SELL, rows=[TRIG_S, (2000, 2006, 1988, 1999)], cfg={},
         kv=dict(outcome="SL", r_gross=-1.0, mfe=0.0, mae=-1.0, conflict=True)),
    dict(id="G-S-TIMEOUT", mo="SELL TIMEOUT tại Close 1999,5 → R 0,1", sig=SELL, rows=[TRIG_S] + [FLAT_S] * 3, cfg=dict(max_bars=3),
         kv=dict(outcome="TIMEOUT", r_gross=0.1, mfe=0.2, mae=-0.2, held=3)),
]

# --------------------------------------------------------------------- CHỈ SỐ (tính tay)
def TR(o, r):
    return dict(symbol="XAUUSD", setup="SU5", outcome=o, r_net=r, mfe_r=None if r is None else max(r, 0.0), mae_r=None if r is None else min(r, 0.0),
                bars_held=1, same_bar_conflict=False, gap_exit=False)


M = [
    dict(id="M-ZERO", mo="0 lệnh đóng (chỉ OPEN, NO_FILL, NO_DATA, INVALID)", tr=[TR("OPEN", 1.0), TR("NO_FILL", None), TR("NO_DATA", None), TR("INVALID", None)],
         kv=dict(dong=0, net_r=0.0, expectancy=None, win_rate=None, profit_factor=None, pf_trang_thai="KHONG_CO_LENH_THANG_THUA", ty_le_tp1=None, mo=1, khong_khop=1, khong_du_lieu=1, khong_hop_le=1)),
    dict(id="M-1WIN", mo="1 lệnh thắng TP1 +2", tr=[TR("TP1", 2.0)], kv=dict(dong=1, net_r=2.0, expectancy=2.0, win_rate=1.0, profit_factor=None, pf_trang_thai="KHONG_CO_LENH_THUA", ty_le_tp1=1.0)),
    dict(id="M-1LOSS", mo="1 lệnh thua SL −1", tr=[TR("SL", -1.0)], kv=dict(dong=1, expectancy=-1.0, win_rate=0.0, profit_factor=0.0, pf_trang_thai="OK", thua=1)),
    dict(id="M-1BE", mo="1 lệnh hòa vốn TIMEOUT 0", tr=[TR("TIMEOUT", 0.0)],
         kv=dict(dong=1, hoa_von=1, win_rate=0.0, win_rate_khong_hoa=None, profit_factor=None, pf_trang_thai="KHONG_CO_LENH_THANG_THUA", expectancy=0.0)),
    dict(id="M-WINONLY", mo="Chỉ thắng: TP1 +2, TIMEOUT +1,5", tr=[TR("TP1", 2.0), TR("TIMEOUT", 1.5)],
         kv=dict(net_r=3.5, expectancy=1.75, win_rate=1.0, profit_factor=None, pf_trang_thai="KHONG_CO_LENH_THUA", ty_le_tp1=0.5)),
    dict(id="M-LOSSONLY", mo="Chỉ thua: −1, −1, TIMEOUT −0,5", tr=[TR("SL", -1.0), TR("SL", -1.0), TR("TIMEOUT", -0.5)],
         kv=dict(net_r=-2.5, expectancy=-2.5 / 3, win_rate=0.0, profit_factor=0.0, pf_trang_thai="OK")),
    dict(id="M-BEONLY", mo="Chỉ hòa vốn ×2", tr=[TR("TIMEOUT", 0.0)] * 2, kv=dict(hoa_von=2, profit_factor=None, pf_trang_thai="KHONG_CO_LENH_THANG_THUA", win_rate=0.0)),
    dict(id="M-WINLOSS", mo="+2, −1, −1 → net 0, PF 1,0, win 1/3", tr=[TR("TP1", 2.0), TR("SL", -1.0), TR("SL", -1.0)],
         kv=dict(net_r=0.0, expectancy=0.0, profit_factor=1.0, win_rate=1 / 3, win_rate_khong_hoa=1 / 3)),
    dict(id="M-WINBE", mo="+2, 0 → win 0,5; win không hòa 1,0; PF null", tr=[TR("TP1", 2.0), TR("TIMEOUT", 0.0)],
         kv=dict(win_rate=0.5, win_rate_khong_hoa=1.0, profit_factor=None, pf_trang_thai="KHONG_CO_LENH_THUA")),
    dict(id="M-LOSSBE", mo="−1, 0 → win 0; win không hòa 0; PF 0", tr=[TR("SL", -1.0), TR("TIMEOUT", 0.0)], kv=dict(win_rate=0.0, win_rate_khong_hoa=0.0, profit_factor=0.0)),
    dict(id="M-OPEN", mo="OPEN không vào R: TP1 +2, OPEN +5", tr=[TR("TP1", 2.0), TR("OPEN", 5.0)], kv=dict(dong=1, mo=1, net_r=2.0, expectancy=2.0)),
    dict(id="M-TIMEOUTWIN", mo="TIMEOUT +0,5 là thắng nhưng không phải TP1; SL −1", tr=[TR("TIMEOUT", 0.5), TR("SL", -1.0)],
         kv=dict(win_rate=0.5, ty_le_tp1=0.0, profit_factor=0.5, net_r=-0.5)),
    dict(id="M-TP1NEG", mo="TP1 sau chi phí −0,05 → thua, nhưng tỷ lệ TP1 = 1", tr=[TR("TP1", -0.05)], kv=dict(win_rate=0.0, thua=1, ty_le_tp1=1.0, profit_factor=0.0)),
    dict(id="M-TP1NULLMIX", mo="Tín hiệu TP1 null kết thúc SL vẫn ở mẫu số tỷ lệ TP1: SL −1, TP1 +2", tr=[TR("SL", -1.0), TR("TP1", 2.0)], kv=dict(ty_le_tp1=0.5, profit_factor=2.0)),
    dict(id="M-POSNET", mo="Net dương: +3, −1", tr=[TR("TP1", 3.0), TR("SL", -1.0)], kv=dict(net_r=2.0, expectancy=1.0, profit_factor=3.0)),
    dict(id="M-NEGNET", mo="Net âm: +1, −1, −1", tr=[TR("TP1", 1.0), TR("SL", -1.0), TR("SL", -1.0)], kv=dict(net_r=-1.0, profit_factor=0.5)),
]
