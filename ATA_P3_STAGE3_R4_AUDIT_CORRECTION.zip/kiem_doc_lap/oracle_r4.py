# -*- coding: utf-8 -*-
"""ORACLE R4 – LỌC DANH MỤC theo quy tắc R4 (F-01), viết lại từ ĐẶC TẢ nhiệm vụ R4 mục 3, KHÔNG import và không chép code shadow_eval/.
Kiểm bằng TÍNH CHẤT khoảng thời gian (không mô phỏng lại vòng lặp tham lam của code được kiểm):
  Lệnh ĐÃ VÀO  = TP1 / SL / TIMEOUT / OPEN, hoặc NO_DATA có ghi chú sau khi vào (INVALID_BAR_AFTER_FILL, NON_MONOTONIC_TIME_AFTER_FILL).
  Hết vị thế   = exit_ts_ms với TP1 / SL / TIMEOUT; ∞ với OPEN và NO_DATA sau khi vào (kết quả không xác định).
  Thứ tự xét   = (entry_ts_ms, emit_seq, signal_id).
  P0 đầu ra là tập con của đầu vào, không lặp, giữ nguyên bản ghi.
  P1 lệnh CHƯA vào (NO_FILL, INVALID, NO_DATA trước khi vào) luôn được giữ.
  P2 các lệnh đã vào được giữ cùng (symbol, setup) không giao nhau: b vào sau a (theo thứ tự xét) thì entry(b) > hết(a) (chạm biên = giao).
  P3 mỗi lệnh đã vào bị bỏ phải giao với một lệnh được giữ cùng khóa đứng trước theo thứ tự xét.
  P4 số bị bỏ = số lệnh đã vào trong đầu vào − số lệnh đã vào được giữ.
Với thứ tự xét toàn phần, P2 + P3 xác định DUY NHẤT tập được giữ (quy nạp theo thứ tự) → oracle đủ để kiểm cả đúng lẫn đủ."""
import math

SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_TIME_AFTER_FILL")


def da_vao(t):
    return t["outcome"] in ("TP1", "SL", "TIMEOUT", "OPEN") or (t["outcome"] == "NO_DATA" and t.get("fill_note") in SAU_VAO)


def het(t):
    if t["outcome"] in ("TP1", "SL", "TIMEOUT") and t.get("exit_ts_ms") is not None:
        return t["exit_ts_ms"]
    return math.inf


def thu_tu(t):
    return (t["entry_ts_ms"], t.get("emit_seq", 0), str(t.get("signal_id", "")))


def kiem_danh_muc_r4(dau_vao, giu, so_bo):
    vi = []
    idg = [id(t) for t in giu]
    if len(idg) != len(set(idg)) or not set(idg) <= {id(t) for t in dau_vao}:
        vi.append(("P0", "đầu ra lặp hoặc chứa bản ghi lạ"))
    sg = set(idg)
    for t in dau_vao:
        if not da_vao(t) and id(t) not in sg:
            vi.append(("P1", t.get("signal_id")))
    G = [t for t in giu if da_vao(t)]
    for a in G:
        for b in G:
            if a is not b and (a["symbol"], a["setup"]) == (b["symbol"], b["setup"]) and thu_tu(a) < thu_tu(b) and b["entry_ts_ms"] <= het(a):
                vi.append(("P2", a.get("signal_id"), b.get("signal_id")))
    for t in dau_vao:
        if da_vao(t) and id(t) not in sg:
            if not any((g["symbol"], g["setup"]) == (t["symbol"], t["setup"]) and thu_tu(g) < thu_tu(t) and t["entry_ts_ms"] <= het(g) for g in G):
                vi.append(("P3", t.get("signal_id")))
    if so_bo != sum(da_vao(t) for t in dau_vao) - len(G):
        vi.append(("P4", so_bo))
    return vi
