# -*- coding: utf-8 -*-
"""ORACLE ĐỘC LẬP – viết lại từ ĐẶC TẢ, KHÔNG import và không chép code của shadow_eval/. Mục đích: đối chiếu với code được kiểm.
Khác biệt cấu trúc có chủ đích:
  • Giả lập: SELL được quy về BUY bằng phép đổi dấu giá (x → −x); chỉ có MỘT nhánh logic BUY → đối xứng BUY/SELL đúng theo cấu trúc.
    MFE/MAE tính từ danh sách "mẫu giá" thu thập theo quy ước nến thoát (không cập nhật dần).
  • Chỉ số: tính trực tiếp từ định nghĩa, phân vị không dùng ở đây.
  • Lọc danh mục: kiểm bằng tính chất khoảng thời gian (không mô phỏng lại thuật toán tham lam)."""
import math

BAR_MS = 300000


def _f(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _nen_ok(b):
    v = [b.get(k) for k in ("o", "h", "l", "c")]
    return all(_f(x) for x in v) and isinstance(b.get("t"), int) and min(v) > 0 and b["h"] >= max(b["o"], b["c"]) and b["l"] <= min(b["o"], b["c"])


def gia_lap(sig, bars, i, entry="close", same_bar="sl_first", max_bars=288, cost=0.0):
    """Trả dict(outcome, note, entry_ts, entry_price, exit_ts, exit_price, r_gross, r_net, mfe, mae, held, conflict, gap, rr_entry)."""
    d, sl, tp, pr = sig.get("dir"), sig.get("sl"), sig.get("tp1"), sig.get("p_ref")
    kq = dict(outcome=None, note=None, entry_ts=None, entry_price=None, exit_ts=None, exit_price=None, r_gross=None, r_net=None, mfe=None, mae=None,
              held=0, conflict=False, gap=False, rr_entry=None)
    if not (0 <= i < len(bars)):
        return dict(kq, outcome="INVALID", note="INVALID_SIGNAL")
    kq["entry_ts"] = bars[i]["t"]
    if d not in (1, -1) or not _f(sl) or not _f(pr) or (tp is not None and not _f(tp)):
        return dict(kq, outcome="INVALID", note="INVALID_SIGNAL")
    s = d                                                # hệ số đổi dấu: giá chuẩn hóa = s × giá
    SL, TP, P = s * sl, (s * tp if tp is not None else None), s * pr
    if P - SL <= 0:
        return dict(kq, outcome="INVALID", note="INVALID_RISK", entry_price=pr)
    if TP is not None and TP - P <= 0:
        return dict(kq, outcome="INVALID", note="TP_WRONG_SIDE", entry_price=pr)
    if not _nen_ok(bars[i]):
        return dict(kq, outcome="NO_DATA", note="INVALID_BAR")
    N = lambda b: dict(t=b["t"], o=s * b["o"], h=s * (b["h"] if s == 1 else b["l"]), l=s * (b["l"] if s == 1 else b["h"]), c=s * b["c"])   # noqa: E731
    if entry == "close":
        E, k0, danh_gia_mo_dau = P, i + 1, True
    else:
        if i + 1 >= len(bars):
            return dict(kq, outcome="NO_DATA", note="NO_NEXT_BAR")
        if not _nen_ok(bars[i + 1]):
            return dict(kq, outcome="NO_DATA", note="INVALID_BAR")
        E, k0, danh_gia_mo_dau = s * bars[i + 1]["o"], i + 1, False
        kq.update(entry_ts=bars[i + 1]["t"], entry_price=bars[i + 1]["o"])
        if E <= SL:
            return dict(kq, outcome="NO_FILL", note="GAP_BEYOND_SL")
        if TP is not None and E >= TP:
            return dict(kq, outcome="NO_FILL", note="GAP_BEYOND_TP")
    rk = E - SL
    kq.update(entry_price=s * E, rr_entry=((TP - E) / rk if TP is not None else None))
    mau = []                                              # mẫu giá chuẩn hóa dùng cho MFE/MAE
    R = lambda x: (x - E) / rk                            # noqa: E731

    def ket(outcome, k, px_chuan, gap=False, conflict=False):
        rg = R(px_chuan)
        return dict(kq, outcome=outcome, exit_ts=bars[k]["t"], exit_price=s * px_chuan, r_gross=rg, r_net=rg - cost / rk,
                    mfe=max([0.0] + [R(x) for x in mau]), mae=min([0.0] + [R(x) for x in mau]), held=k - k0 + 1, gap=gap, conflict=conflict)
    het = min(len(bars), k0 + max_bars)
    t_truoc = bars[k0 - 1]["t"] if entry == "close" else bars[k0]["t"]
    for k in range(k0, het):
        if not _nen_ok(bars[k]):
            return dict(kq, outcome="NO_DATA", note="INVALID_BAR_AFTER_FILL", rr_entry=None)
        if (entry == "close" or k > k0) and bars[k]["t"] <= t_truoc:
            return dict(kq, outcome="NO_DATA", note="NON_MONOTONIC_TIME_AFTER_FILL", rr_entry=None)
        t_truoc = bars[k]["t"]
        b = N(bars[k])
        mo_la_gia_vao = (entry == "next_open" and k == k0)
        if not mo_la_gia_vao:
            if b["o"] <= SL:
                mau.append(b["o"]); return ket("SL", k, b["o"], gap=True)
            if TP is not None and b["o"] >= TP:
                mau.append(b["o"]); return ket("TP1", k, b["o"], gap=True)
        cham_sl, cham_tp = b["l"] <= SL, TP is not None and b["h"] >= TP
        if cham_sl and (not cham_tp or same_bar == "sl_first"):
            mau.append(SL); return ket("SL", k, SL, conflict=cham_tp)
        if cham_tp:
            mau += [TP, b["l"]]; return ket("TP1", k, TP, conflict=cham_sl)
        mau += [b["h"], b["l"]]
    n = het - k0
    if k0 + max_bars > len(bars):
        cuoi = (s * bars[het - 1]["c"]) if n > 0 else (E if entry == "close" else s * bars[k0]["c"])
        return dict(kq, outcome="OPEN", r_gross=R(cuoi), r_net=R(cuoi) - cost / rk, mfe=max([0.0] + [R(x) for x in mau]), mae=min([0.0] + [R(x) for x in mau]), held=n)
    k = k0 + max_bars - 1
    return ket("TIMEOUT", k, s * bars[k]["c"])


def chi_so(trades):
    """Chỉ số tham chiếu cho MỘT nhóm, từ định nghĩa (xem chi_so.py docstring): mẫu = TP1/SL/TIMEOUT, R = r_net."""
    dong = [t for t in trades if t["outcome"] in ("TP1", "SL", "TIMEOUT")]
    R = [t["r_net"] for t in dong]
    n = len(R)
    w = [r for r in R if r > 1e-9]; l_ = [r for r in R if r < -1e-9]
    gp, gl = sum(w), -sum(l_)
    if l_:
        pf, st = gp / gl, "OK"
    elif w:
        pf, st = None, "KHONG_CO_LENH_THUA"
    else:
        pf, st = None, "KHONG_CO_LENH_THANG_THUA"
    return dict(dong=n, thang=len(w), thua=len(l_), hoa_von=n - len(w) - len(l_), net_r=sum(R) if n else 0.0, expectancy=sum(R) / n if n else None,
                win_rate=len(w) / n if n else None, win_rate_khong_hoa=len(w) / (len(w) + len(l_)) if (w or l_) else None, profit_factor=pf, pf_trang_thai=st,
                ty_le_tp1=sum(t["outcome"] == "TP1" for t in dong) / n if n else None, mo=sum(t["outcome"] == "OPEN" for t in trades),
                khong_khop=sum(t["outcome"] == "NO_FILL" for t in trades), khong_du_lieu=sum(t["outcome"] == "NO_DATA" for t in trades),
                khong_hop_le=sum(t["outcome"] == "INVALID" for t in trades))


def kiem_danh_muc(dau_vao, giu):
    """Tính chất của lọc danh mục (không mô phỏng lại thuật toán):
    P1 lệnh không vào (NO_FILL/NO_DATA/INVALID) luôn được giữ; P2 trong các lệnh đã vào được giữ, cùng (symbol, setup) không có hai khoảng
    [entry, exit] giao nhau (OPEN: exit = ∞; chạm biên tính là giao); P3 mọi lệnh đã vào bị bỏ đều giao với một lệnh được giữ cùng khóa có
    thứ tự (entry, emit_seq, signal_id) đứng trước; P4 khóa khác nhau không ảnh hưởng nhau. Trả danh sách vi phạm."""
    vi = []
    vao = lambda t: t["outcome"] in ("TP1", "SL", "TIMEOUT", "OPEN")     # noqa: E731
    het = lambda t: math.inf if t["outcome"] == "OPEN" or t.get("exit_ts_ms") is None else t["exit_ts_ms"]   # noqa: E731
    thu_tu = lambda t: (t["entry_ts_ms"], t.get("emit_seq", 0), str(t.get("signal_id", "")))   # noqa: E731
    id_giu = {id(t) for t in giu}
    for t in dau_vao:
        if not vao(t) and id(t) not in id_giu:
            vi.append(("P1", t.get("signal_id")))
    G = [t for t in giu if vao(t)]
    for a in G:
        for b in G:
            if a is not b and (a["symbol"], a["setup"]) == (b["symbol"], b["setup"]) and thu_tu(a) < thu_tu(b) and b["entry_ts_ms"] <= het(a):
                vi.append(("P2", a.get("signal_id"), b.get("signal_id")))
    for t in dau_vao:
        if vao(t) and id(t) not in id_giu:
            if not any((g["symbol"], g["setup"]) == (t["symbol"], t["setup"]) and thu_tu(g) < thu_tu(t) and t["entry_ts_ms"] <= het(g) for g in G):
                vi.append(("P3", t.get("signal_id")))
    return vi


def khu_trung(signals):
    """Tham chiếu: mỗi dup_key giữ emit_seq nhỏ nhất. Trả tập emit_seq được giữ."""
    m = {}
    for s in signals:
        m[s["dup_key"]] = min(m.get(s["dup_key"], s["emit_seq"]), s["emit_seq"])
    return set(m.values())
