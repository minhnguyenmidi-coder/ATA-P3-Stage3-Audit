# -*- coding: utf-8 -*-
"""BỘ KIỂM ĐỘC LẬP Stage 3 (KD-*). Kỳ vọng lấy từ vector tính tay (vector_vang.py) và oracle viết lại từ đặc tả (oracle.py) – không lấy từ code được kiểm.
Dùng:  python3 kiem_doc_lap/chay_doc_lap.py                 → toàn bộ, ghi ket_qua_stage3/doc_lap/ket_qua_doc_lap.json (+ csv, log)
       python3 kiem_doc_lap/chay_doc_lap.py --nhanh --module-dir <thư mục>   → tập con nhanh trên bản module khác (dùng cho kiểm đột biến)
Mã thoát: 1 nếu có FAIL. BLOCKED / NOT TESTED đếm riêng. Mỗi test ghi số assertion thực sự đã chạy."""
import argparse, copy, csv, datetime as dt, hashlib, inspect, json, math, os, random, re, shutil, subprocess, sys, tempfile, time

KD = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(KD)
ap = argparse.ArgumentParser()
ap.add_argument("--nhanh", action="store_true"); ap.add_argument("--gate", action="store_true"); ap.add_argument("--chi", default=""); ap.add_argument("--module-dir", default=os.path.join(G, "shadow_eval")); ap.add_argument("--out", default=os.path.join(G, "ket_qua_stage3", "doc_lap"))
A = ap.parse_args()
sys.path.insert(0, A.module_dir); sys.path.insert(1, KD)
import mo_phong_lenh as MP, hop_dong as HD, chi_so as CS, may_trang_thai as MT   # noqa: E402
import oracle as OR, vector_vang as VV   # noqa: E402

SHA38 = "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13"
SHA39 = "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"
KQ, TESTS = [], []
DEM = {"assert": 0}
LECH = {}          # lưu toàn bộ ca lệch (nếu có) để kiểm toán


class Sai(Exception):
    pass


def goi(fn, *a, **k):
    """Gọi code ĐƯỢC KIỂM: mọi ngoại lệ NGOÀI DỰ KIẾN thành assertion sai tường minh (lỗi của code, không phải lỗi môi trường).
    Ngoại lệ DỰ KIẾN (ví dụ ValueError của khu_trung) được test bắt riêng bằng try/except, không đi qua hàm này."""
    try:
        return fn(*a, **k)
    except Exception as ex:      # noqa: BLE001
        kt(False, f"code được kiểm ném ngoại lệ ngoài dự kiến trong {getattr(fn, '__name__', fn)}: {ex!r}")


def kt(dk, mo=""):
    DEM["assert"] += 1
    if not dk:
        raise Sai(mo)


def sha_f(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def T(tid, nhom, muc_tieu, loai="FACT", nhanh=False):
    def wrap(fn):
        def run():
            a0, t0 = DEM["assert"], time.time()
            try:
                r = fn()
                st, act = (r if isinstance(r, tuple) and isinstance(r[0], str) else ("PASS", r))
            except Sai as e:
                st, act = "FAIL", f"assertion sai: {e}"
            except Exception as e:      # noqa: BLE001
                st, act = "FAIL", f"NGOẠI LỆ: {e!r}"
            rec = dict(test_id=tid, nhom=nhom, muc_tieu=muc_tieu, phan_loai=loai, status=st, so_assertion=DEM["assert"] - a0, actual=act,
                       test_source=f"kiem_doc_lap/chay_doc_lap.py::{fn.__name__} (dòng {inspect.getsourcelines(fn)[1]})",
                       run_time=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), duration_ms=round((time.time() - t0) * 1000, 1))
            rec["hash"] = hashlib.sha256(json.dumps([tid, st, act], sort_keys=True, ensure_ascii=False, default=str, allow_nan=False).encode()).hexdigest()[:16]
            KQ.append(rec); print(f"[{st:10}] {tid:22} a={rec['so_assertion']:<6} {muc_tieu[:80]}")
        run.nhanh = nhanh; run.tid = tid
        TESTS.append(run)
        return run
    return wrap


def bars(rows):
    return [dict(t=VV.T0 + 300000 * k, o=float(o), h=float(h), l=float(l), c=float(c)) for k, (o, h, l, c) in enumerate(rows)]


def cfg_impl(c):
    return MP.Cfg(entry=c.get("entry", "close"), same_bar=c.get("same_bar", "sl_first"), max_bars=c.get("max_bars", 288), spread=c.get("cost", 0.0))


MAP = dict(note="fill_note", entry_ts="entry_ts_ms", exit_ts="exit_ts_ms", mfe="mfe_r", mae="mae_r", held="bars_held", conflict="same_bar_conflict", gap="gap_exit")


def impl(sig, rows_or_bars, i, c):
    b = rows_or_bars if rows_or_bars and isinstance(rows_or_bars[0], dict) else bars(rows_or_bars)
    r = goi(MP.mo_phong, sig, b, i, cfg_impl(c))
    return {k: r.get(MAP.get(k, k)) for k in ("outcome", "note", "entry_ts", "entry_price", "exit_ts", "exit_price", "r_gross", "r_net", "mfe", "mae", "held", "conflict", "gap", "rr_entry")}


def ora(sig, rows_or_bars, i, c):
    b = rows_or_bars if rows_or_bars and isinstance(rows_or_bars[0], dict) else bars(rows_or_bars)
    return OR.gia_lap(sig, b, i, c.get("entry", "close"), c.get("same_bar", "sl_first"), c.get("max_bars", 288), c.get("cost", 0.0))


def bang(a, b, e=1e-9):
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (bool, str)) or isinstance(b, (bool, str)):
        return a == b
    return abs(a - b) <= e * max(1.0, abs(a), abs(b))


def so_sanh(kv, got, tag):
    for k, v in kv.items():
        kt(bang(v, got[k]), f"{tag}: {k} kỳ vọng {v}, được {got[k]}")


# ================================================================================ 1. GOLDEN – GIẢ LẬP
for _v in VV.V:
    def _mk(v):
        @T(f"KD-GOLD-{v['id'][2:]}", "Golden giả lập (code được kiểm)", v["mo"], nhanh=True)
        def t_gold():
            g = impl(v["sig"], v["rows"], 0, v["cfg"]); so_sanh(v["kv"], g, "impl"); return {k: g[k] for k in v["kv"]}
        t_gold.__name__ = "t_gold_" + v["id"].replace("-", "_")
    _mk(_v)


@T("KD-ORACLE-GOLD", "Golden giả lập (oracle)", "Oracle độc lập khớp MỌI golden vector (xác nhận oracle trước khi dùng làm chuẩn so sánh)", nhanh=True)
def t_oracle_gold():
    for v in VV.V:
        so_sanh(v["kv"], ora(v["sig"], v["rows"], 0, v["cfg"]), "oracle " + v["id"])
    return f"{len(VV.V)} vector"


def guong_rows(rows, p=4000.0):
    return [(p - o, p - l, p - h, p - c) for (o, h, l, c) in rows]


def guong_sig(s, p=4000.0):
    return dict(dir=-s["dir"] if s["dir"] in (1, -1) else s["dir"], p_ref=p - s["p_ref"], sl=p - s["sl"], tp1=None if s["tp1"] is None else p - s["tp1"])


@T("KD-MIRROR-GOLD", "Đối xứng BUY/SELL", "Mỗi golden BUY → ảnh gương SELL (giá → 4000 − giá): cùng kết cục, ghi chú, R, MFE, MAE, giữ, cờ, rr_entry; giá vào/thoát = 4000 − giá BUY; code và oracle", nhanh=True)
def t_mirror_gold():
    n, bo_qua = 0, []
    for v in VV.V:
        if v["sig"]["dir"] != 1:
            continue
        # Phép gương chỉ là phép đối xứng của miền giá DƯƠNG: nến có giá ≤ 0 (không hợp lệ) có ảnh gương hợp lệ → loại khỏi kiểm gương, ghi rõ
        if any(min(r) <= 0 or 4000 - max(r) <= 0 for r in v["rows"]):
            bo_qua.append(v["id"]); continue
        for f, nm in ((impl, "impl"), (ora, "oracle")):
            a = f(v["sig"], v["rows"], 0, v["cfg"]); b = f(guong_sig(v["sig"]), guong_rows(v["rows"]), 0, v["cfg"])
            for k in ("outcome", "note", "r_gross", "r_net", "mfe", "mae", "held", "conflict", "gap", "rr_entry", "entry_ts", "exit_ts"):
                kt(bang(a[k], b[k]), f"{nm} {v['id']} {k}: BUY {a[k]} / SELL {b[k]}")
            for k in ("entry_price", "exit_price"):
                kt(bang(a[k], None if b[k] is None else 4000.0 - b[k]) if a[k] is not None else b[k] is None, f"{nm} {v['id']} {k}")
            n += 1
    return dict(so_cap=n, so_lech=0, bo_qua_ngoai_mien=bo_qua)


def duong_ngau_nhien(R, n):
    p = 2000.0; rows = [(p, p + 1, p - 1, p)]
    for _ in range(n):
        o = round(p + R.choice((0, 0, 0, R.gauss(0, 3), R.choice((-12, 12)))), 2); c = round(o + R.gauss(0, 2), 2)
        rows.append((o, round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
    b = bars(rows)
    if R.random() < 0.15 and len(b) > 1:                     # khoảng trống thời gian
        k = R.randrange(1, len(b))
        for x in b[k:]:
            x["t"] += 300000 * R.randint(1, 50)
    if R.random() < 0.05:                                    # nến hỏng
        k = R.randrange(0, len(b)); b[k]["h"] = b[k]["l"] - 1
    return b


def ca_ngau_nhien(R):
    b = duong_ngau_nhien(R, R.choice((0, 1, 2, 5, 30, 60)))
    d = R.choice((1, -1)); p = b[0]["c"]
    s = dict(dir=d, p_ref=p, sl=round(p - d * R.choice((R.uniform(0.3, 8), 0.0, -1.0) if R.random() < 0.05 else (R.uniform(0.3, 8),)), 2),
             tp1=(round(p + d * R.uniform(0.3, 15), 2) if R.random() < 0.85 else None))
    c = dict(entry=R.choice(("close", "next_open")), same_bar=R.choice(("sl_first", "tp_first")), max_bars=R.choice((1, 2, 3, 10, 40)), cost=R.choice((0.0, 0.3)))
    return s, b, c


@T("KD-MIRROR-PROP", "Đối xứng BUY/SELL", "Thuộc tính: 6.000 ca ngẫu nhiên (gap, TP1 null, R1/R2, sl/tp_first, max_bars 1…40, chi phí, khoảng trống thời gian, nến hỏng, rủi ro hỏng) – code: BUY vs ảnh gương SELL, MỌI trường; lưu mọi ca lệch")
def t_mirror_prop():
    R = random.Random(20261120); lech = []
    for k in range(6000):
        s, b, c = ca_ngau_nhien(R)
        bg = [dict(t=x["t"], o=4000 - x["o"], h=4000 - x["l"], l=4000 - x["h"], c=4000 - x["c"]) for x in b]
        a, m = impl(s, b, 0, c), impl(guong_sig(s), bg, 0, c)
        for f in ("outcome", "note", "r_gross", "r_net", "mfe", "mae", "held", "conflict", "gap", "rr_entry", "entry_ts", "exit_ts"):
            if not bang(a[f], m[f], 1e-7):
                lech.append(dict(ca=k, truong=f, buy=a[f], sell=m[f], sig=s, cfg=c)); break
    LECH["KD-MIRROR-PROP"] = lech
    kt(len(lech) == 0, f"{len(lech)} ca lệch")
    return dict(so_ca=6000, so_ca_lech=len(lech))


@T("KD-ORACLE-PROP", "Oracle vs code", "Thuộc tính: 8.000 ca ngẫu nhiên – code được kiểm và oracle độc lập cho KẾT QUẢ Y HỆT (kết cục, ghi chú, giá/thời điểm vào-thoát, R gross/net, MFE, MAE, giữ, cờ, rr_entry); lưu mọi ca lệch")
def t_oracle_prop():
    R = random.Random(7_777); lech = []; dem = {}
    for k in range(8000):
        s, b, c = ca_ngau_nhien(R)
        a, o = impl(s, b, 0, c), ora(s, b, 0, c)
        dem[a["outcome"]] = dem.get(a["outcome"], 0) + 1
        for f in a:
            if not bang(a[f], o[f], 1e-9):
                lech.append(dict(ca=k, truong=f, code=a[f], oracle=o[f], sig=s, cfg=c)); break
    LECH["KD-ORACLE-PROP"] = lech
    kt(len(lech) == 0, f"{len(lech)} ca lệch")
    kt(all(dem.get(x, 0) > 0 for x in ("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")), f"phủ kết cục {dem}")
    return dict(so_ca=8000, so_ca_lech=0, phu_ket_cuc=dem)


@T("KD-R1-NOLOOK", "R1/R2 không nhìn trước", "R1: đổi High/Low nến trigger (giữ Close) → kết quả y hệt; R1/R2: thay mọi nến SAU nến thoát bằng giá vô lý → y hệt; R2 không dùng nến trigger ngoài thời điểm (đổi O/H/L) → y hệt (2.000 ca)")
def t_nolook():
    R = random.Random(31); n = 0
    for _ in range(2000):
        s, b, c = ca_ngau_nhien(R)
        if not OR._nen_ok(b[0]):
            continue
        a = impl(s, b, 0, c)
        b2 = copy.deepcopy(b); b2[0]["h"] = max(b2[0]["o"], b2[0]["c"]) + R.uniform(0, 50); b2[0]["l"] = min(b2[0]["o"], b2[0]["c"]) - R.uniform(0, 50)
        if c["entry"] == "next_open":
            b2[0]["o"] = min(max(b2[0]["o"] + R.uniform(-3, 3), b2[0]["l"]), b2[0]["h"])
        kt(impl(s, b2, 0, c) == a, "nến trigger ảnh hưởng kết quả"); n += 1
        if a["exit_ts"] is not None:
            ke = next(i for i, x in enumerate(b) if x["t"] == a["exit_ts"])
            b3 = b[:ke + 1] + [dict(t=x["t"], o=9999.0, h=9999.0, l=1.0, c=5000.0) for x in b[ke + 1:]]
            kt(impl(s, b3, 0, c) == a, "nến sau thoát ảnh hưởng kết quả")
    return f"{n} ca"


@T("KD-ENTRY-RETRO", "R1/R2 giá vào", "Giá vào không đổi hồi tố: R1 entry = P_ref và entry_ts = nến trigger; R2 entry = Open nến kế, entry_ts = nến kế; với mọi lệnh đã vào (4.000 ca)")
def t_entry():
    R = random.Random(41); n = 0
    for _ in range(4000):
        s, b, c = ca_ngau_nhien(R)
        a = impl(s, b, 0, c)
        if a["outcome"] in ("TP1", "SL", "TIMEOUT", "OPEN"):
            if c["entry"] == "close":
                kt(a["entry_price"] == s["p_ref"] and a["entry_ts"] == b[0]["t"], "R1 giá/thời điểm vào")
            else:
                kt(a["entry_price"] == b[1]["o"] and a["entry_ts"] == b[1]["t"], "R2 giá/thời điểm vào")
            n += 1
    return f"{n} lệnh đã vào"

@T("KD-GOLD-EXTRA", "Golden giả lập (code được kiểm)", "Biên chính xác (tính tay): SL = P_ref → INVALID; Open = SL → SL gap R −1; Low = SL → SL; High = TP1 → TP1; MAE nến thoát TP1 có Low dưới giá vào (−0,6); trượt giá 0,25 → chi phí 0,5 → r_net 1,9", nhanh=True)
def t_gold_extra():
    b = lambda rows: bars([VV.TRIG] + rows)      # noqa: E731
    r = goi(MP.mo_phong, dict(VV.BUY, sl=2000.0), b([VV.FLAT]), 0); kt(r["outcome"] == "INVALID" and r["fill_note"] == "INVALID_RISK", "SL = P_ref")
    r = goi(MP.mo_phong, VV.BUY, b([(1995, 1996, 1994, 1995)]), 0); kt(r["outcome"] == "SL" and r["gap_exit"] and bang(r["r_gross"], -1.0), "Open = SL")
    r = goi(MP.mo_phong, VV.BUY, b([(1999, 2001, 1995, 1998)]), 0); kt(r["outcome"] == "SL" and not r["gap_exit"] and bang(r["r_gross"], -1.0), "Low = SL")
    r = goi(MP.mo_phong, VV.BUY, b([(2001, 2010, 1999, 2005)]), 0); kt(r["outcome"] == "TP1" and bang(r["r_gross"], 2.0), "High = TP1")
    r = goi(MP.mo_phong, VV.BUY, b([(2000, 2003, 1999.5, 2002), (2002, 2011, 1997, 2009)]), 0); kt(r["outcome"] == "TP1" and bang(r["mae_r"], -0.6) and bang(r["mfe_r"], 2.0), f"MAE TP1 {r['mae_r']}")
    r = goi(MP.mo_phong, VV.BUY, b([(2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0, MP.Cfg(slippage=0.25)); kt(bang(r["r_net"], 1.9), f"trượt giá {r['r_net']}")
    r = goi(MP.mo_phong, VV.BUY, b([(2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0, MP.Cfg(commission=0.5)); kt(bang(r["r_net"], 1.9), "phí")
    return "7 biên"


@T("KD-PCT", "Bootstrap", "Phân vị đối xứng (tính tay): B = 10 → (0, 9); B = 30 → (0, 29); B = 70 → (1, 68); B = 2000 → (50, 1949)", nhanh=True)
def t_pct():
    for Bn, kv in ((10, (0, 9)), (30, (0, 29)), (70, (1, 68)), (2000, (50, 1949))):
        kt(CS.phan_vi_doi_xung(list(range(Bn))) == kv, f"B={Bn}: {CS.phan_vi_doi_xung(list(range(Bn)))}")
    return "4 giá trị B"


@T("KD-SM-TRADE-NEG", "Máy trạng thái", "Vòng đời lệnh – vi phạm dựng tay: R2 vào TẠI nến trigger, R1 vào sau trigger, NO_FILL tại nến trigger → bị bắt", nhanh=True)
def t_sm_trade_neg():
    t0 = VV.T0; sg = dict(reason=16, trigger_ts_ms=t0)
    base = dict(outcome="TP1", fill_note=None, entry_ts_ms=t0, entry_price=2000.0, exit_ts_ms=t0 + 600000)
    kt(MT.kiem_lenh(base, sg, "next_open") != [], "R2 vào tại trigger lọt")
    kt(MT.kiem_lenh(dict(base, entry_ts_ms=t0 + 300000), sg, "close") != [], "R1 vào sau trigger lọt")
    kt(MT.kiem_lenh(dict(base, outcome="NO_FILL", fill_note="GAP_BEYOND_SL", exit_ts_ms=None), sg, "next_open") != [], "NO_FILL tại trigger lọt")
    kt(MT.kiem_lenh(dict(base, entry_ts_ms=t0 + 300000), sg, "next_open") == [], "R2 hợp lệ bị bác")
    return "4 ca"


# ================================================================================ 2. MÁY TRẠNG THÁI
def EVS(seq, setup="SU5"):
    return [dict(setup_id="x", emit_seq=i, event_type=e, setup=setup) for i, e in enumerate(seq)]


@T("KD-SM-TABLE", "Máy trạng thái", "Bảng chuyển tiếp: 9 chuỗi hợp lệ → 0 lỗi; 10 chuỗi không hợp lệ (CREATED→ARMED, STEP→STEP, CREATED→TRIGGER, sau kết thúc, SKIP ở SU-3, END ở SU-5, không có CREATED, 2 CREATED, ARMED→STEP, TRIGGER→VOID) → bắt hết", nhanh=True)
def t_sm_table():
    ok = [(["CREATED", "VOID"], "SU5"), (["CREATED", "EXPIRED"], "SU3"), (["CREATED", "STEP", "ARMED", "TRIGGER"], "SU5"), (["CREATED", "STEP", "ARMED", "VOID"], "SU3"),
          (["CREATED", "STEP", "ARMED", "EXPIRED"], "SU5"), (["CREATED", "STEP", "SKIP"], "SU5"), (["CREATED", "STEP", "END_NO_EVENT"], "SU3"), (["CREATED", "STEP", "VOID"], "SU5"),
          (["CREATED", "STEP"], "SU3")]
    sai = [(["CREATED", "ARMED", "TRIGGER"], "SU5"), (["CREATED", "STEP", "STEP"], "SU5"), (["CREATED", "TRIGGER"], "SU5"), (["CREATED", "VOID", "STEP"], "SU5"),
           (["CREATED", "STEP", "SKIP"], "SU3"), (["CREATED", "STEP", "END_NO_EVENT"], "SU5"), (["STEP", "ARMED"], "SU5"), (["CREATED", "CREATED"], "SU5"),
           (["CREATED", "STEP", "ARMED", "STEP"], "SU5"), (["CREATED", "STEP", "ARMED", "TRIGGER", "VOID"], "SU3")]
    for q, su in ok:
        kt(MT.kiem_vong_doi(EVS(q, su)) == [], f"hợp lệ bị bác: {q}")
    for q, su in sai:
        kt(MT.kiem_vong_doi(EVS(q, su)) != [], f"không hợp lệ lọt: {q} {su}")
    return dict(hop_le=len(ok), khong_hop_le=len(sai))


@T("KD-SM-ENGINE", "Máy trạng thái", "Đầu ra engine thật (khối Pine nguyên văn qua adapter): 40 seed SYNTH + kịch bản SU-3 định hướng → mọi chuyển tiếp thuộc bảng; thống kê chuyển tiếp quan sát được")
def t_sm_engine():
    import chuan_hoa as CH
    tk = {}; loi = []
    for sd in range(40):
        ev = CH.replay_synth(sd)["events"]; loi += MT.kiem_vong_doi(ev)
        th = {}
        for e in ev:
            th.setdefault(e["setup_id"], []).append(e["event_type"])
        for v in th.values():
            for a, b in zip(["(bắt đầu)"] + v, v):
                tk[f"{a}→{b}"] = tk.get(f"{a}→{b}", 0) + 1
    loi += MT.kiem_vong_doi(CH.replay_su3_co_dinh()["events"])
    kt(not loi, f"{len(loi)} vi phạm: {loi[:3]}")
    kt(all(k.split("→")[1] in MT.CHUYEN.get(k.split("→")[0], set()) for k in tk), "chuyển tiếp ngoài bảng")
    return dict(chuyen_tiep_quan_sat=tk)


@T("KD-SM-TRADE", "Máy trạng thái", "Vòng đời lệnh: mọi đầu ra của code (5.000 ca) thỏa máy trạng thái lệnh; 8 vi phạm dựng tay (vào trước trigger, thoát trước vào, NO_FILL ở R1, OPEN có thoát, TIMEOUT không thoát, đã vào thiếu giá vào, lệnh cho tín hiệu bị bỏ, ghi chú lạ) đều bị bắt")
def t_sm_trade():
    R = random.Random(51); n = 0
    for _ in range(5000):
        s, b, c = ca_ngau_nhien(R)
        r = goi(MP.mo_phong, s, b, 0, cfg_impl(c))
        sg = dict(reason=16, trigger_ts_ms=b[0]["t"])
        kt(MT.kiem_lenh(r, sg, c["entry"]) == [], f"lệnh hợp lệ bị bác {r['outcome']} {r['fill_note']}"); n += 1
    t0 = VV.T0
    base = dict(outcome="TP1", fill_note=None, entry_ts_ms=t0, entry_price=2000.0, exit_ts_ms=t0 + 600000)
    sg = dict(reason=16, trigger_ts_ms=t0)
    sai = [(dict(base, entry_ts_ms=t0 - 300000), "close"), (dict(base, exit_ts_ms=t0 - 300000), "close"), (dict(base, outcome="NO_FILL", fill_note="GAP_BEYOND_SL", exit_ts_ms=None, entry_ts_ms=t0 + 300000), "close"),
           (dict(base, outcome="OPEN"), "close"), (dict(base, outcome="TIMEOUT", exit_ts_ms=None), "close"), (dict(base, entry_price=None), "close"),
           (base, None), (dict(base, outcome="NO_DATA", fill_note="LA"), "close")]
    for tr, rule in sai:
        kt(MT.kiem_lenh(tr, dict(sg, reason=15) if rule is None else sg, rule or "close") != [], f"vi phạm lọt: {tr}")
    return dict(hop_le=n, vi_pham_bat=len(sai))

# ================================================================================ 3. KHỬ TRÙNG / THỨ TỰ
def SG(seq, sym="XAUUSD", su="SU3", d=1, t=5, reason=16):
    # signal_id cố ý NGƯỢC thứ tự emit_seq để phát hiện sắp xếp theo id (F2)
    return dict(signal_id=f"id{999 - seq:03d}", emit_seq=seq, symbol=sym, setup=su, dir=d, trigger_ts_ms=t, reason=reason, dup_key=f"{sym}|{su}|{d}|{t}")


@T("KD-DUP-GOLD", "Khử trùng", "Golden: cùng symbol/setup/chiều/nến → trùng (giữ emit_seq nhỏ); khác chiều / khác setup / khác symbol / khác nến → KHÔNG trùng; tín hiệu bị bỏ (lý do 1) phát trước bản đạt S1 không che bản đạt S1 (F26)", nhanh=True)
def t_dup_gold():
    import pipeline as PL
    a = [SG(3), SG(1), SG(2, d=-1), SG(4, su="SU5"), SG(5, sym="BTCUSD"), SG(6, t=10)]
    g, n = goi(MP.khu_trung, a)
    kt([s["emit_seq"] for s in g] == [1, 2, 4, 5, 6] and n == 1, f"giữ {[s['emit_seq'] for s in g]}, loại {n}")
    g2, n2 = PL.chon_tin_hieu_lenh([SG(1, reason=1), SG(2, reason=16)])
    kt([s["emit_seq"] for s in g2] == [2] and n2 == 0, "F26: bản đạt S1 bị che")
    g3, n3 = PL.chon_tin_hieu_lenh([SG(1, reason=16), SG(2, reason=16), SG(3, reason=15)])
    kt([s["emit_seq"] for s in g3] == [1] and n3 == 1, "hai bản đạt S1 trùng phải giữ bản đầu")
    for bad in ([dict(SG(1), emit_seq=None)], [SG(1), dict(SG(2), emit_seq=1)], [dict(SG(1), emit_seq=True)]):
        try:
            MP.khu_trung(bad); kt(False, "thiếu/trùng/bool emit_seq không bị từ chối")
        except ValueError:
            kt(True)
    return "ok"


@T("KD-DUP-PROP", "Khử trùng", "Thuộc tính: 800 tập ngẫu nhiên (va chạm thời điểm, chéo symbol/setup/chiều) × 5 lần xáo trộn → tập giữ = oracle (min emit_seq mỗi khóa), không phụ thuộc thứ tự đầu vào")
def t_dup_prop():
    R = random.Random(61)
    for _ in range(800):
        n = R.randint(1, 25); seqs = R.sample(range(100), n)
        a = [SG(q, sym=R.choice(("XAUUSD", "BTCUSD")), su=R.choice(("SU3", "SU5")), d=R.choice((1, -1)), t=R.choice((5, 10, 15))) for q in seqs]
        ref = OR.khu_trung(a)
        for _ in range(5):
            R.shuffle(a); g, nb = goi(MP.khu_trung, a)
            kt({s["emit_seq"] for s in g} == ref and nb == len(a) - len(ref), "lệch oracle")
            kt([s["emit_seq"] for s in g] == sorted(s["emit_seq"] for s in g), "đầu ra không theo emit_seq")
    return "800 × 5"


@T("KD-DUP-SEED", "Khử trùng", "Va chạm chéo seed: gộp 2 lượt replay KHÔNG tiền tố → bộ kiểm cấp bảng báo trùng emit_seq/ID; pipeline gộp có tiền tố seed → phễu 'trùng' = số khử trùng thật")
def t_dup_seed():
    import chuan_hoa as CH, pipeline as PL
    a, b = CH.replay_synth(1), CH.replay_synth(2)
    loi = HD.kiem_bang(a["events"] + b["events"], a["signals"] + b["signals"], [])
    kt(any("trùng" in x for x in loi), "gộp seed không bị phát hiện")
    syn = PL.chay_synth("XAUUSD", "SU5", seeds=range(12))
    kt(syn["phieu"]["trung"] == syn["bo_trung"], f"phễu {syn['phieu']['trung']} ≠ {syn['bo_trung']}")
    return dict(loi_gop=loi[:2], trung=syn["bo_trung"], trung_s1=syn["bo_trung_s1"])

# ================================================================================ 4. LỌC DANH MỤC
def TP_(e, x, o="TP1", sym="XAUUSD", su="SU5", seq=0, sid=None):
    return dict(symbol=sym, setup=su, entry_ts_ms=e, exit_ts_ms=x, outcome=o, emit_seq=seq, signal_id=sid or f"{sym}{su}{e}{seq}")


@T("KD-OCC-GOLD", "Lọc danh mục", "Golden: NO_FILL/NO_DATA/INVALID không chiếm; OPEN chiếm tới hết; TP1/SL/TIMEOUT giải phóng sau thoát; vào ĐÚNG thời điểm thoát → bỏ (quy ước bảo thủ); vào sau → giữ; chéo symbol/setup không chặn; cùng thời điểm vào → theo emit_seq rồi signal_id", nhanh=True)
def t_occ_gold():
    ca = [([TP_(1, None, "NO_FILL"), TP_(2, None, "NO_DATA"), TP_(3, None, "INVALID"), TP_(4, 9)], 0),
          ([TP_(1, None, "OPEN"), TP_(5, 9), TP_(5, 9, su="SU3"), TP_(5, 9, sym="BTCUSD")], 1),
          ([TP_(1, 10, "SL"), TP_(11, 20, "TIMEOUT"), TP_(21, 30)], 0), ([TP_(1, 10), TP_(10, 20)], 1), ([TP_(1, 10, "TIMEOUT"), TP_(10, 20)], 1),
          ([TP_(5, 9, seq=2), TP_(5, 9, seq=1)], 1), ([TP_(5, 9, seq=1, sid="b"), TP_(5, 9, seq=1, sid="a")], 1)]
    for tr, kv in ca:
        g, n = goi(MP.khong_chong, tr)
        kt(n == kv, f"bỏ {n} ≠ {kv}"); kt(OR.kiem_danh_muc(tr, g) == [], f"tính chất sai {OR.kiem_danh_muc(tr, g)}")
    g, _ = goi(MP.khong_chong, [TP_(5, 9, seq=2), TP_(5, 9, seq=1)]); kt(g[0]["emit_seq"] == 1, "tie emit_seq")
    g, _ = goi(MP.khong_chong, [TP_(5, 9, seq=1, sid="b"), TP_(5, 9, seq=1, sid="a")]); kt(g[0]["signal_id"] == "a", "tie signal_id")
    return f"{len(ca)} ca"


@T("KD-OCC-PROP", "Lọc danh mục", "Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ 7 kết cục, va chạm biên, chéo khóa) × 4 lần xáo trộn → thỏa P1–P4 của oracle và đầu ra không phụ thuộc thứ tự")
def t_occ_prop():
    R = random.Random(71)
    for _ in range(1000):
        tr = []
        for j in range(R.randint(1, 20)):
            o = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")); e = R.randint(0, 30)
            tr.append(TP_(e, (e + R.randint(0, 8)) if o in ("TP1", "SL", "TIMEOUT") else None, o, sym=R.choice(("XAUUSD", "BTCUSD")), su=R.choice(("SU3", "SU5")), seq=R.randint(0, 5), sid=f"id{j}"))
        ref = None
        for _ in range(4):
            R.shuffle(tr); g, n = goi(MP.khong_chong, tr)
            kt(OR.kiem_danh_muc(tr, g) == [], "vi phạm tính chất")
            k = sorted(t["signal_id"] for t in g); ref = ref or k; kt(k == ref, "phụ thuộc thứ tự")
    return "1.000 × 4"

# ================================================================================ 5. HỢP ĐỒNG – ĐỘT BIẾN CÓ PHÁN QUYẾT BIẾT TRƯỚC
def bo_chuan(dir_=1, tp=True):
    """Bộ dữ liệu hợp lệ dựng TAY (độc lập pipeline): một thể hiện CREATED→STEP→ARMED→TRIGGER, một tín hiệu đạt S1, lệnh R1 TP1 (hoặc SL nếu TP null)."""
    t0 = 1767323100000; sid = "aaaa000000000001"
    E = lambda k, et, st, rs, sq: dict(schema_version="1.2", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", tf="5", setup="SU5", mode="SHADOW", setup_id=sid,   # noqa: E731
                                        event_id=HD.hid(sid, et, t0 + 300000 * k, sq), emit_seq=sq, event_type=et, step=st, ts=HD.ts_tu_ms(t0 + 300000 * k), ts_ms=t0 + 300000 * k,
                                        dir=dir_, state={"TRIGGER": 17, "ARMED": 2}.get(et, 0), reason=16 if et == "TRIGGER" else 0, anchor_price=2000.0, ext_price=5.0)
    ev = [E(0, "CREATED", 0, 0, 0), E(1, "STEP", 1, 0, 1), E(2, "ARMED", 2, 0, 2), E(3, "TRIGGER", 2, 16, 3)]
    tt = t0 + 900000; p, sl = 2000.0, 2000.0 - dir_ * 5
    tp1 = 2000.0 + dir_ * 10 if tp else None
    sg = [dict(schema_version="1.2", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", setup="SU5", setup_id=sid, signal_id=HD.hid(sid, tt), emit_seq=3, dir=dir_,
               trigger_ts=HD.ts_tu_ms(tt), trigger_ts_ms=tt, p_ref=p, sl=sl, tp1=tp1, rr=2.0 if tp else None, reason=16, perm_reg=None, perm_vol=None, dup_key=f"XAUUSD|SU5|{dir_}|{tt}")]
    if tp:
        tr = dict(outcome="TP1", exit_price=tp1, r_gross=2.0, r_net=1.9, mfe_r=2.0, mae_r=-0.2, rr_entry=2.0)
    else:
        tr = dict(outcome="SL", exit_price=sl, r_gross=-1.0, r_net=-1.1, mfe_r=0.4, mae_r=-1.0, rr_entry=None)
    trs = [dict(schema_version="1.2", signal_id=sg[0]["signal_id"], symbol="XAUUSD", setup="SU5", emit_seq=3, sim_rule="R-close-sl_first-288", cost_model="C-s0.5-c0.0-sl0.0",
                entry_ts_ms=tt, entry_price=p, risk=5.0, fill_note=None, exit_ts_ms=tt + 600000, bars_held=2, same_bar_conflict=False, gap_exit=False, time_gaps=0, max_gap_ms=0, **tr)]
    return ev, sg, trs


SUA_OUTCOME = lambda e, s, t: t[0].update(outcome="SL" if t[0]["outcome"] == "TP1" else "TP1")     # noqa: E731
# (tên, hàm đột biến, từ khóa lỗi KỲ VỌNG – ít nhất một phải có trong thông báo của bộ kiểm)
DOT_BIEN = [
    ("xóa trường bắt buộc (EVENTS.reason)", lambda e, s, t: e[0].pop("reason"), ["thiếu reason"]),
    ("xóa trường bắt buộc (TRADES.outcome)", lambda e, s, t: t[0].pop("outcome"), ["thiếu outcome"]),
    ("thêm trường lạ", lambda e, s, t: s[0].update(la=1), ["trường lạ la"]),
    ("sai kiểu (p_ref chuỗi)", lambda e, s, t: s[0].update(p_ref="2000"), ["p_ref: kiểu"]),
    ("bool giả int (dir = True)", lambda e, s, t: e[1].update(dir=True), ["dir: bool"]),
    ("bool giả int (bars_held = True)", lambda e, s, t: t[0].update(bars_held=True), ["bars_held: bool"]),
    ("sai timestamp (ts ≠ ts_ms)", lambda e, s, t: e[2].update(ts_ms=e[2]["ts_ms"] + 300000), ["ts ≠ ts_ms"]),
    ("sai timestamp (trigger_ts lệch)", lambda e, s, t: s[0].update(trigger_ts="2026-01-01T00:00:00Z"), ["trigger_ts ≠ trigger_ts_ms"]),
    ("sai timestamp (ngoài miền năm 9999)", lambda e, s, t: e[0].update(ts_ms=10 ** 20), ["quá năm 9999", "ts ≠ ts_ms"]),
    ("sai ID (signal_id không tái lập)", lambda e, s, t: (s[0].update(signal_id="ffffffffffffffff"), t[0].update(signal_id="ffffffffffffffff")), ["không tái lập"]),
    ("trùng sự kiện", lambda e, s, t: e.append(dict(e[1])), ["trùng event_id"]),
    ("trùng lệnh", lambda e, s, t: t.append(dict(t[0])), ["trùng (signal_id, sim_rule, cost_model)"]),
    ("sai thứ tự (emit_seq ngược thời gian)", lambda e, s, t: (e[1].update(emit_seq=2), e[2].update(emit_seq=1)), ["có ts_ms nhỏ hơn"]),
    ("sai R (r_gross ≠ giá thoát)", lambda e, s, t: t[0].update(r_gross=t[0]["r_gross"] * 1.1, r_net=t[0]["r_gross"] * 1.1 - 0.1,
                                                                mfe_r=max(t[0]["mfe_r"], t[0]["r_gross"] * 1.1), mae_r=min(t[0]["mae_r"], t[0]["r_gross"] * 1.1)), ["|r_gross|×risk"]),
    ("sai risk (lệch giá)", lambda e, s, t: t[0].update(risk=4.0), ["|r_gross|×risk", "risk ≠"]),
    ("sai risk (nhất quán nội bộ bản ghi)", lambda e, s, t: t[0].update(risk=4.0, exit_price=t[0]["entry_price"] + 8.0 * s[0]["dir"], r_gross=2.0, r_net=2.0 - 0.5 / 4.0)
     if t[0]["outcome"] == "TP1" else t[0].update(risk=4.0, gap_exit=True, exit_price=t[0]["entry_price"] - 6.0 * s[0]["dir"], r_gross=-1.5, r_net=-1.5 - 0.5 / 4.0, mae_r=-1.5),
     ["risk ≠ (entry − SL)×dir"]),
    ("sai outcome (đảo TP1 ↔ SL)", SUA_OUTCOME, ["SL không gap", "TP1 phải r_gross > 0", "TP1 khi tín hiệu không có TP1"]),
    ("sai hình học (SL sai phía)", lambda e, s, t: s[0].update(sl=s[0]["p_ref"] + 5 * s[0]["dir"]), ["SL không nằm phía rủi ro"]),
    ("sai vòng đời (CREATED → ARMED)", lambda e, s, t: e.pop(1), ["CREATED → ARMED"]),
    ("sai vòng đời (sự kiện sau TRIGGER)", lambda e, s, t: e.append(dict(e[3], event_type="VOID", event_id="z", emit_seq=4, ts_ms=e[3]["ts_ms"] + 300000,
                                                                           ts=HD.ts_tu_ms(e[3]["ts_ms"] + 300000), state=6, reason=6)), ["sau sự kiện kết thúc"]),
    ("NaN", lambda e, s, t: t[0].update(mfe_r=float("nan")), ["mfe_r: không hữu hạn"]),
    ("Infinity", lambda e, s, t: s[0].update(sl=float("inf")), ["sl: không hữu hạn"]),
    ("−Infinity", lambda e, s, t: e[0].update(anchor_price=float("-inf")), ["anchor_price: không hữu hạn"]),
    ("NO_FILL có R", lambda e, s, t: t[0].update(outcome="NO_FILL", fill_note="GAP_BEYOND_SL"), ["NO_FILL: risk phải null"]),
    ("OPEN có thoát", lambda e, s, t: t[0].update(outcome="OPEN"), ["OPEN: exit phải null"]),
    ("chi phí không khớp cost_model", lambda e, s, t: t[0].update(r_net=t[0]["r_gross"] - 0.05), ["chi phí (theo cost_model)"]),
    ("rr_entry sai", lambda e, s, t: t[0].update(rr_entry=1.0), ["rr_entry"]),
    ("lệnh cho tín hiệu bị bỏ (reason 15)", lambda e, s, t: (s[0].update(reason=15), e[3].update(reason=15, state=4)), ["không đạt S1"]),
    ("ID chéo seed (gộp hai bộ giống hệt)", lambda e, s, t: (e.extend([dict(x) for x in e]), s.extend([dict(x) for x in s])), ["trùng event_id", "trùng emit_seq"]),
]
FIXTURE = [(1, True), (-1, True), (1, False), (-1, False)]


def chay_dot_bien_hop_dong():
    """Phân loại từng lần thực thi: PHAT_HIEN_DUNG / PHAT_HIEN_SAI_LY_DO / KHONG_PHAT_HIEN / KHONG_AP_DUNG / LOI_TEST (hàm đột biến lỗi) /
    DOT_BIEN_KHONG_HOP_LE (dữ liệu không đổi) / VALIDATOR_CRASH (bộ kiểm ném ngoại lệ – KHÔNG tính là phát hiện)."""
    bang = []
    for dir_, tp in FIXTURE:
        e0, s0, t0 = bo_chuan(dir_, tp)
        goc = json.dumps([e0, s0, t0], sort_keys=True, allow_nan=False)
        for ten, f, kw in DOT_BIEN:
            row = dict(dot_bien=ten, fixture=f"{'BUY' if dir_ == 1 else 'SELL'}-{'TP1' if tp else 'TPnull'}", ky_vong=kw)
            e, s, t = copy.deepcopy(e0), copy.deepcopy(s0), copy.deepcopy(t0)
            try:
                f(e, s, t)
            except Exception as ex:      # noqa: BLE001
                bang.append(dict(row, ket_qua="LOI_TEST", chi_tiet=repr(ex))); continue
            try:
                khong_doi = json.dumps([e, s, t], sort_keys=True, default=str, allow_nan=False) == goc
            except ValueError:
                khong_doi = False                              # đột biến đưa NaN/∞ vào → dữ liệu ĐÃ đổi
            if khong_doi:
                bang.append(dict(row, ket_qua="DOT_BIEN_KHONG_HOP_LE", chi_tiet="dữ liệu không đổi")); continue
            try:
                loi = HD.kiem_bang(e, s, t)
            except Exception as ex:      # noqa: BLE001
                bang.append(dict(row, ket_qua="VALIDATOR_CRASH", chi_tiet=repr(ex))); continue
            if not loi:
                bang.append(dict(row, ket_qua="KHONG_PHAT_HIEN", chi_tiet=""))
            elif any(k in x for k in kw for x in loi):
                bang.append(dict(row, ket_qua="PHAT_HIEN_DUNG", chi_tiet=next(x for x in loi if any(k in x for k in kw))[:120], so_loi=len(loi)))
            else:
                bang.append(dict(row, ket_qua="PHAT_HIEN_SAI_LY_DO", chi_tiet=" | ".join(loi[:3])[:200]))
        kt(json.dumps([e0, s0, t0], sort_keys=True, allow_nan=False) == goc, "fixture gốc bị đột biến làm thay đổi")
    return bang


@T("KD-HD-MUT", "Hợp đồng dữ liệu", "Đột biến hợp đồng có phân loại: 29 loại × 4 fixture (BUY/SELL × TP1/TP-null); chỉ PHÁT HIỆN ĐÚNG LÝ DO mới tính; validator crash, lỗi hàm đột biến, đột biến không đổi dữ liệu, phát hiện sai lý do đều FAIL; fixture gốc hợp lệ và không bị thay đổi", nhanh=True)
def t_hd_mut():
    for dir_, tp in FIXTURE:
        e0, s0, t0 = bo_chuan(dir_, tp)
        kt(HD.kiem_bang(e0, s0, t0) == [], f"fixture {dir_},{tp} không hợp lệ: {HD.kiem_bang(e0, s0, t0)[:2]}")
    bang = chay_dot_bien_hop_dong()
    dem = {}
    for r in bang:
        dem[r["ket_qua"]] = dem.get(r["ket_qua"], 0) + 1
    os.makedirs(A.out, exist_ok=True)
    json.dump(bang, open(os.path.join(A.out, "bang_dot_bien_hop_dong.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False)
    xau = [r for r in bang if r["ket_qua"] != "PHAT_HIEN_DUNG"]
    kt(len(bang) == len(DOT_BIEN) * len(FIXTURE), "số lần thực thi sai")
    kt(not xau, f"{len(xau)} lần không đạt: {[(r['dot_bien'], r['fixture'], r['ket_qua']) for r in xau[:4]]}")
    return dict(so_loai=len(DOT_BIEN), so_fixture=len(FIXTURE), so_lan_thuc_thi=len(bang), phan_loai=dem, bo_qua=0)


@T("KD-HD-FUZZ", "Hợp đồng dữ liệu", "Độ bền bộ kiểm: 20.000 bộ dữ liệu bị làm hỏng ngẫu nhiên (xóa/thêm trường, None, bool, chuỗi, list, dict, NaN, ±∞, số khổng lồ, bản ghi không phải object, bảng không phải list) → bộ kiểm KHÔNG BAO GIỜ ném ngoại lệ (F36)", nhanh=True)
def t_hd_fuzz():
    R = random.Random(36); RAC = [None, True, False, "x", "", [], {}, float("nan"), float("inf"), float("-inf"), -1, 0, 1.5, 10 ** 20, -10 ** 20, 2 ** 63]
    bi_bac = 0
    for k in range(20000):
        e, s, t = bo_chuan(R.choice((1, -1)), R.random() < 0.6)
        for _ in range(R.randint(1, 3)):
            bang_ = R.choice((e, s, t)); dicts = [x for x in bang_ if isinstance(x, dict)]
            if not dicts:
                continue
            rec = R.choice(dicts); key = R.choice(list(rec.keys()) + ["moi"])
            x = R.random()
            if x < 0.15:
                rec.pop(key, None)
            elif x < 0.18:
                bang_[R.randrange(len(bang_))] = R.choice(RAC)
            else:
                rec[key] = R.choice(RAC)
        args = [e, s, t]
        if R.random() < 0.02:
            args[R.randrange(3)] = R.choice(RAC)
        try:
            bi_bac += HD.kiem_bang(*args) != []
        except Exception as ex:      # noqa: BLE001
            kt(False, f"bộ kiểm ném ngoại lệ ở ca {k}: {ex!r}")
    # assertion có nội dung (thay kt(True) rỗng): phần lớn bộ hỏng phải bị bác – nếu bộ kiểm "im lặng" với dữ liệu hỏng thì FAIL
    kt(bi_bac >= 0.9 * 20000, f"chỉ {bi_bac}/20000 bộ hỏng bị bác")
    return dict(so_ca=20000, bi_bac=bi_bac, ngoai_le=0)


@T("KD-HD-VALID", "Hợp đồng dữ liệu", "Không báo nhầm: 8 bộ hợp lệ (BUY, SELL, TP1 null, R2 NO_FILL, R2 khớp, OPEN, NO_DATA sau khi vào, INVALID) → 0 lỗi", nhanh=True)
def t_hd_valid():
    e, s, t = bo_chuan(1, True); kt(HD.kiem_bang(e, s, t) == [], "BUY")
    e, s, t = bo_chuan(-1, True); kt(HD.kiem_bang(e, s, t) == [], "SELL")
    e, s, t = bo_chuan(1, False); kt(HD.kiem_bang(e, s, t) == [], "TP null")
    tt = s[0]["trigger_ts_ms"]
    nf = dict(t[0], sim_rule="R-next_open-sl_first-288", outcome="NO_FILL", fill_note="GAP_BEYOND_SL", entry_ts_ms=tt + 300000, entry_price=1994.0, risk=None, r_gross=None, r_net=None,
              mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, rr_entry=None)
    e, s, t = bo_chuan(1, False); kt(HD.kiem_bang(e, s, [nf]) == [], f"R2 NO_FILL {HD.kiem_bang(e, s, [nf])[:2]}")
    e, s, t = bo_chuan(1, True)
    r2 = dict(t[0], sim_rule="R-next_open-sl_first-288", entry_ts_ms=tt + 300000, entry_price=2001.0, risk=6.0, exit_price=2010.0, r_gross=1.5, r_net=1.5 - 0.5 / 6, mfe_r=1.5, mae_r=-0.1, rr_entry=1.5)
    kt(HD.kiem_bang(e, s, [r2]) == [], f"R2 khớp {HD.kiem_bang(e, s, [r2])[:2]}")
    op = dict(t[0], outcome="OPEN", exit_ts_ms=None, exit_price=None, r_gross=0.4, r_net=0.3, mfe_r=0.5, mae_r=-0.1)
    kt(HD.kiem_bang(e, s, [op]) == [], f"OPEN {HD.kiem_bang(e, s, [op])[:2]}")
    nd = dict(t[0], outcome="NO_DATA", fill_note="INVALID_BAR_AFTER_FILL", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, rr_entry=None)
    kt(HD.kiem_bang(e, s, [nd]) == [], f"NO_DATA sau vào {HD.kiem_bang(e, s, [nd])[:2]}")
    iv = dict(nd, outcome="INVALID", fill_note="INVALID_RISK")
    kt(HD.kiem_bang(e, s, [iv]) == [], f"INVALID {HD.kiem_bang(e, s, [iv])[:2]}")
    return "8 bộ"


import ast

PHAM_VI_PY = ["shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py", "shadow_eval/may_trang_thai.py", "shadow_eval/chuan_hoa.py",
              "shadow_eval/du_lieu.py", "shadow_eval/pipeline.py", "shadow_eval/kiem_thu_stage3.py", "kiem_doc_lap/oracle.py", "kiem_doc_lap/vector_vang.py",
              "kiem_doc_lap/chay_doc_lap.py", "kiem_doc_lap/tai_hien.py", "token_budget/cong_token.py", "kiem_toan_stage3/tao_ma_tran.py", "kiem_toan_stage3/dong_goi_v2.py",
              "kiem_toan_stage3/tao_bao_cao_test_v2.py", "kiem_toan_r3/tao_bao_cao_r3.py", "kiem_toan_r3/dong_goi_r3.py"]
NGOAI_PHAM_VI_PY = {"shadow_eval/kiem_thu_shadow_eval.py": "bộ test gốc – KHÔNG được sửa (quy tắc test cũ); đầu ra lịch sử được miễn từng file bên dưới",
                    "token_budget/mo_hinh_token.py": "công cụ cũ vòng trước, thay bằng cong_token.py (F34)",
                    "shadow_eval/tao_capsule_stage3.py": "công cụ capsule cũ, không ghi JSON", "kiem_toan_stage3/dong_goi.py": "công cụ đóng gói vòng 1, không ghi JSON",
                    "kiem_toan_stage3/tao_bao_cao_test.py": "sinh báo cáo vòng 1, không ghi JSON", "kiem_toan_stage3/bang_chung_truoc_sua.py": "bằng chứng vòng 1 chạy trên bản TRƯỚC SỬA"}
# Miễn LỊCH SỬ: đúng file + đúng SHA-256 + đúng vị trí giá trị không hữu hạn. File khác / SHA khác / vị trí khác / JSON hỏng → KHÔNG miễn.
MIEN_LICH_SU = {
    "ket_qua_shadow_eval/ket_qua_truoc_sua.json": dict(sha="b47c7d0cf6cc9035827ffa2e8f982e6c006e2126a4ae73cdeeb824d9e7858077",
                                                     vi_tri=[["ket_qua", 14, "actual", "BTCUSD-SU5", "profit_factor"]], loi="Infinity",
                                                     ly_do="đầu ra bộ test gốc chạy trên bản TRƯỚC SỬA – bằng chứng F10 (PF = ∞); giữ nguyên"),
    "ket_qua_shadow_eval/ket_qua.json": dict(sha="b47c7d0cf6cc9035827ffa2e8f982e6c006e2126a4ae73cdeeb824d9e7858077",
                                            vi_tri=[["ket_qua", 14, "actual", "BTCUSD-SU5", "profit_factor"]], loi="Infinity",
                                            ly_do="bản sao y hệt file trên (bộ test gốc ghi đè rồi được khôi phục) – cùng SHA"),
}


def quet_json_site(path):
    """AST: mọi lời gọi json.dump / json.dumps (kể cả 'from json import dump', bí danh 'import json as j'). Trả list (dòng, hàm, strict, lý do)."""
    src = open(os.path.join(G, path), encoding="utf-8").read()
    tree = ast.parse(src)
    ten_mod, ten_ham = {"json"}, {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name == "json":
                    ten_mod.add(a.asname or "json")
        if isinstance(n, ast.ImportFrom) and n.module == "json":
            for a in n.names:
                if a.name in ("dump", "dumps"):
                    ten_ham[a.asname or a.name] = a.name
    out = []
    for n in ast.walk(tree):
        if not isinstance(n, ast.Call):
            continue
        f = n.func; ham = None
        if isinstance(f, ast.Attribute) and f.attr in ("dump", "dumps") and isinstance(f.value, ast.Name) and f.value.id in ten_mod:
            ham = f.attr
        elif isinstance(f, ast.Name) and f.id in ten_ham:
            ham = ten_ham[f.id]
        if not ham:
            continue
        kw = {k.arg: k.value for k in n.keywords if k.arg}
        strict = "allow_nan" in kw and isinstance(kw["allow_nan"], ast.Constant) and kw["allow_nan"].value is False
        co_kwargs = any(k.arg is None for k in n.keywords)
        out.append(dict(file=path, dong=n.lineno, ham=f"json.{ham}", strict=strict, ly_do="" if strict else ("**kwargs – không xác định" if co_kwargs else "thiếu allow_nan=False")))
    return out


def vi_tri_khong_huu_han(text):
    S = "\u0000NONFINITE\u0000"
    d = json.loads(text, parse_constant=lambda x: S + x)       # JSON hỏng → JSONDecodeError (không được miễn)
    out = []

    def walk(o, p):
        if isinstance(o, dict):
            for k, v in o.items():
                walk(v, p + [k])
        elif isinstance(o, list):
            for i, v in enumerate(o):
                walk(v, p + [i])
        elif isinstance(o, str) and o.startswith(S):
            out.append((p, o[len(S):]))
    walk(d, [])
    return out


@T("KD-JSON", "JSON strict", "JSON strict: (1) AST quét MỌI lời gọi json.dump/json.dumps trong phạm vi – tất cả phải allow_nan=False; (2) quét TOÀN BỘ cây gói tìm *.json, parse strict; (3) miễn lịch sử chỉ cho đúng file + đúng SHA + đúng vị trí ∞; JSON hỏng không được miễn; (4) PF không xác định → null + trạng thái; null/biên tuần tự hóa đúng")
def t_json():
    sites = []
    for p in PHAM_VI_PY:
        if os.path.exists(os.path.join(G, p)):
            sites += quet_json_site(p)
    khong = [x for x in sites if not x["strict"]]
    kt(not khong, f"lời gọi không strict: {[(x['file'], x['dong']) for x in khong]}")
    tep = []
    for root, dirs, fs in os.walk(G):
        dirs[:] = [d for d in dirs if d not in ("__pycache__",)]
        tep += [os.path.relpath(os.path.join(root, f), G) for f in fs if f.endswith(".json")]
    tep.sort()
    kq_tep, mien = [], []
    for p in tep:
        raw = open(os.path.join(G, p), encoding="utf-8").read()
        try:
            vt = vi_tri_khong_huu_han(raw)
        except json.JSONDecodeError as ex:
            kq_tep.append(dict(file=p, ket_qua="JSON_HONG", chi_tiet=str(ex))); continue
        if not vt:
            kq_tep.append(dict(file=p, ket_qua="STRICT_OK")); continue
        m = MIEN_LICH_SU.get(p)
        ok = m is not None and sha_f(os.path.join(G, p)) == m["sha"] and [list(x[0]) for x in vt] == m["vi_tri"] and all(x[1] == m["loi"] for x in vt)
        kq_tep.append(dict(file=p, ket_qua="MIEN_LICH_SU" if ok else "KHONG_STRICT", chi_tiet=str(vt)[:200]))
        if ok:
            mien.append(dict(file=p, sha=m["sha"], vi_tri=m["vi_tri"], loi=m["loi"], ly_do=m["ly_do"]))
    xau = [x for x in kq_tep if x["ket_qua"] in ("JSON_HONG", "KHONG_STRICT")]
    kt(not xau, f"JSON không đạt: {xau[:3]}")
    kt(len(mien) <= len(MIEN_LICH_SU), "miễn vượt danh sách")
    # tự kiểm cơ chế miễn: JSON hỏng có chữ Infinity, file khác chứa ∞, cùng file nhưng thêm ∞ ở vị trí khác → đều KHÔNG được miễn
    try:
        vi_tri_khong_huu_han('{"a": Infinity, ')
        kt(False, "JSON hỏng không bị bắt")
    except json.JSONDecodeError:
        kt(True)
    kt(vi_tri_khong_huu_han('{"b": [1, -Infinity, NaN]}') == [(["b", 1], "-Infinity"), (["b", 2], "NaN")], "định vị ∞/NaN sai")
    # tuần tự hóa biên
    for v in (None, 0.0, -0.0, 1e-300, 1.7976931348623157e308, -5, 10 ** 18):
        kt(json.loads(json.dumps({"v": v}, allow_nan=False))["v"] == v, f"tuần tự hóa {v}")
    for v in (float("nan"), float("inf"), float("-inf")):
        try:
            json.dumps({"v": v}, allow_nan=False); kt(False, f"{v} lọt")
        except ValueError:
            kt(True)
    h = CS.hieu_qua([dict(symbol="X", setup="S", outcome="TP1", r_net=1.0, r_gross=1.0, mfe_r=1.0, mae_r=0.0, bars_held=1, same_bar_conflict=False, gap_exit=False)] * 3)
    json.dumps({str(k): v for k, v in h.items()}, allow_nan=False)
    kt(h[("X", "S")]["profit_factor"] is None and h[("X", "S")]["pf_trang_thai"] == "KHONG_CO_LENH_THUA", "PF ∞")
    os.makedirs(A.out, exist_ok=True)
    json.dump(dict(sites=sites, ngoai_pham_vi=NGOAI_PHAM_VI_PY, file_json=kq_tep, mien_lich_su=mien), open(os.path.join(A.out, "bao_cao_json_strict.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, allow_nan=False)
    dem = {}
    for x in kq_tep:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    return dict(so_site=len(sites), site_khong_strict=0, so_file_json=len(tep), phan_loai_file=dem, mien=[m["file"] for m in mien])


# ================================================================================ 6. CHỈ SỐ
for _m in VV.M:
    def _mk2(m):
        @T(f"KD-MET-{m['id'][2:]}", "Golden chỉ số", m["mo"], nhanh=True)
        def t_met():
            h = goi(CS.hieu_qua, m["tr"])[("XAUUSD", "SU5")]; o = OR.chi_so(m["tr"])
            for k, v in m["kv"].items():
                kt(bang(v, h[k]), f"code {k}: kỳ vọng {v}, được {h[k]}"); kt(bang(v, o[k]), f"oracle {k}: kỳ vọng {v}, được {o[k]}")
            json.dumps(h, allow_nan=False)
            return {k: h[k] for k in m["kv"]}
        t_met.__name__ = "t_met_" + m["id"].replace("-", "_")
    _mk2(_m)


@T("KD-MET-PROP", "Chỉ số", "Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ kết cục, R = 0 đúng, chi phí âm sau TP1) – code = oracle trên mọi trường chung; tách nhóm (symbol, setup) không rò rỉ")
def t_met_prop():
    R = random.Random(81)
    for _ in range(1000):
        tr = []
        for _ in range(R.randint(0, 30)):
            o = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID"))
            r = None if o in ("NO_FILL", "NO_DATA", "INVALID") else R.choice((0.0, -1.0, 2.0, round(R.uniform(-3, 3), 3), -0.05))
            tr.append(dict(VV.TR(o, r), symbol=R.choice(("XAUUSD", "BTCUSD")), setup=R.choice(("SU3", "SU5"))))
        h = goi(CS.hieu_qua, tr)
        for k, v in h.items():
            o = OR.chi_so([t for t in tr if (t["symbol"], t["setup"]) == k])
            for f in o:
                kt(bang(o[f], v[f]), f"{k} {f}: code {v[f]} oracle {o[f]}")
    return "1.000 tập"


@T("KD-BOOT", "Bootstrap", "CI i.i.d. và moving-block: xác định theo seed; i.i.d. không phụ thuộc thứ tự; n < 2 → null; R hằng → suy biến; L = round(n^(1/3)); chuỗi tự tương quan mạnh → CI khối rộng hơn i.i.d.; mọi giá trị hữu hạn")
def t_boot():
    R = random.Random(91)
    x = [round(R.uniform(-1, 2), 3) for _ in range(60)]
    kt(CS.bootstrap_ci(x, 7, ("a",)) == CS.bootstrap_ci(list(reversed(x)), 7, ("a",)), "i.i.d. phụ thuộc thứ tự")
    kt(CS.bootstrap_khoi(x, 7, ("a",)) == CS.bootstrap_khoi(x, 7, ("a",)), "khối không xác định")
    kt(CS.bootstrap_khoi([1.0], 7, ("a",))[1] == "N_NHO_HON_2" and CS.bootstrap_ci([1.0], 7, ("a",))[0] is None, "n<2")
    kt(CS.bootstrap_khoi([0.5] * 10, 7, ("a",))[0] == [0.5, 0.5], "hằng")
    kt(CS.bootstrap_khoi(x, 7, ("a",))[2] == round(60 ** (1 / 3)), "L")
    ac = [2.0] * 30 + [-1.0] * 30                                  # tự tương quan cực mạnh theo thời gian
    ci_i, _ = CS.bootstrap_ci(ac, 7, ("b",)); ci_k, _, _ = CS.bootstrap_khoi(ac, 7, ("b",), L=10)
    kt(ci_k[1] - ci_k[0] > ci_i[1] - ci_i[0], f"khối {ci_k} không rộng hơn iid {ci_i}")
    kt(all(math.isfinite(v) for v in ci_i + ci_k), "không hữu hạn")
    return dict(iid=ci_i, khoi_L10=ci_k, ghi_chu="chỉ kiểm cơ chế – không phải bằng chứng thống kê thị trường")


@T("KD-FUNNEL", "Phễu", "Golden phễu có mẫu số KHÓA: tỷ lệ = tử / mẫu theo MAU_SO; mẫu = 0 → null; đếm NO_FILL / NO_DATA / INVALID / đã vào từ TRADES; SU-3 và SU-5 tách riêng", nhanh=True)
def t_funnel():
    E = lambda et, su="SU3", r=0: dict(symbol="XAUUSD", setup=su, event_type=et, reason=r)     # noqa: E731
    ev = [E("CREATED")] * 4 + [E("ARMED")] * 2 + [E("VOID", r=6), E("EXPIRED", r=7), E("END_NO_EVENT")] + [E("CREATED", "SU5")]
    sg = [dict(symbol="XAUUSD", setup="SU3", reason=r, dup_key=k) for r, k in ((16, "a"), (16, "a"), (15, "b"), (1, "c"))]
    tr = [dict(symbol="XAUUSD", setup="SU3", outcome=o) for o in ("TP1", "NO_FILL", "NO_DATA", "INVALID", "OPEN")]
    f = CS.phieu(ev, sg, tr); a, b = f[("XAUUSD", "SU3")], f[("XAUUSD", "SU5")]
    kv = dict(tao=4, armed=2, trigger=4, s1_dat=2, bo_quyen=1, bo_khac=1, trung=1, lenh_gia_lap=5, khong_khop=1, khong_du_lieu=1, khong_hop_le=1, da_vao=2,
              ty_le_armed=0.5, ty_le_void=0.25, ty_le_het_han=0.25, ty_le_ket_thuc_khong_su_kien=0.25, ty_le_trigger_tren_armed=2.0, ty_le_s1_dat=0.5, ty_le_bo_quyen=0.25,
              ty_le_bo_khac=0.25, ty_le_trung=0.25, ty_le_khong_khop=0.2, ty_le_khong_du_lieu=0.2, ty_le_khong_hop_le=0.2, ty_le_da_vao=0.4)
    for k, v in kv.items():
        kt(bang(v, a[k]), f"{k}: {v} vs {a[k]}")
    kt(b["tao"] == 1 and b["ty_le_armed"] == 0.0 and b["ty_le_trigger_tren_armed"] is None and b["ty_le_s1_dat"] is None, "SU5 / mẫu 0")
    return {k: a[k] for k in kv}

# ================================================================================ 7. BASELINE, HỒI QUY, ĐỘT BIẾN MÃ NGUỒN
@T("KD-BASELINE", "Baseline", "SHA-256 tính TRỰC TIẾP trên source Pine 0.3.8 và 0.3.9 trùng giá trị chuẩn", nhanh=True)
def t_base():
    a = sha_f(os.path.join(G, "src038", "ATA_P3_Build_0.3.8_Candidate_Indicator.pine")); b = sha_f(os.path.join(G, "src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine"))
    kt(a == SHA38 and b == SHA39, f"{a} / {b}")
    return dict(v038=a, v039=b)


# ================================================================================ R3. HỒI QUY CÓ OUTPUT SẠCH + RUN_ID
LOI_THOI_S3 = {
    "OT-05": dict(ly_do="Assertion cũ đòi fill_note = INVALID_BAR cho nến hỏng SAU khi đã vào; vòng 2 tách trạng thái (F29) → INVALID_BAR_AFTER_FILL", thay_the="KD-REPL-OT05"),
    "OT-06": dict(ly_do="Assertion cũ đòi NON_MONOTONIC_TIME; sau khi vào nay là NON_MONOTONIC_TIME_AFTER_FILL (F29)", thay_the="KD-REPL-OT06"),
    "HD-01": dict(ly_do="Fixture cũ có CREATED → ARMED (thiếu STEP); máy trạng thái bác ĐÚNG MỘT lỗi này", thay_the="KD-REPL-HD01S3"),
}
LOI_THOI_CU = {
    "HD-01": dict(ly_do="Bản ghi mẫu thiếu emit_seq (schema ≥ 1.1); bản ghi sai cũ kỳ vọng đúng 4 lỗi nhưng bộ kiểm dừng sớm ở outcome lạ", thay_the="KD-REPL-CU-HD01"),
    "E2E-01": dict(ly_do="Fixture trigger_ts cố định sai (F17) + thiếu emit_seq", thay_the="E2E-01 (Stage 3) + RP-03 + KD-SM-ENGINE"),
    "DUP-01": dict(ly_do="Tín hiệu mẫu không có emit_seq; khu_trung từ chối đoán thứ tự (F2) → bộ cũ dừng tại đây khi chạy nguyên trạng", thay_the="KD-REPL-CU-DUP01"),
}
CAY_HOI_QUY = ["shadow_eval", "kiem_toan034a", "kiem_toan035", "kiem_toan039", "cong_tien_md6", "token_budget", "ket_qua039", "ket_qua_shadow_eval"]


@T("KD-REG-S3", "Hồi quy", "Hồi quy có OUTPUT SẠCH: chạy bộ Stage 3 (88 test, không sửa assertion) trong BẢN SAO cây không có ket_qua_stage3, gắn run_id; kiểm exit code, file mới tạo sau thời điểm bắt đầu, run_id, số test, PASS/FAIL/BLOCKED/NOT TESTED/ERROR; FAIL phải ĐÚNG BẰNG tập lỗi thời đã chứng minh; REG-01 (bộ gốc 22) và REG-02 (bộ 0.3.9 chạy MỚI trong vòng này) phải PASS")
def t_reg():
    import uuid
    bd = "/tmp/reg039_batdau.txt"
    kt(os.path.exists(bd) and os.path.exists("/tmp/reg039/ket_qua039/ket_qua_039.json"), "bộ 0.3.9 chưa chạy mới trong vòng này")
    kt(os.path.getmtime("/tmp/reg039/ket_qua039/ket_qua_039.json") >= int(open(bd).read()), "output bộ 0.3.9 cũ hơn thời điểm bắt đầu lần chạy mới")
    tmp = tempfile.mkdtemp(prefix="kd_reg_")
    try:
        for d in CAY_HOI_QUY:
            # _truoc_sua là PHỤ THUỘC của MUT-01…05 (nạp bản trước sửa) – không được loại khỏi bản sao (lỗi môi trường phát hiện ở lần chạy 19:08)
            shutil.copytree(os.path.join(G, d), os.path.join(tmp, d), ignore=shutil.ignore_patterns("__pycache__"))
        for d in [x for x in os.listdir(G) if x.startswith("src0")]:
            shutil.copytree(os.path.join(G, d), os.path.join(tmp, d))
        kt(not os.path.exists(os.path.join(tmp, "ket_qua_stage3")), "thư mục output không sạch")
        run_id = str(uuid.uuid4()); t0 = time.time()
        p = subprocess.run([sys.executable, os.path.join(tmp, "shadow_eval", "kiem_thu_stage3.py")], capture_output=True, text=True, cwd=tmp, timeout=1800,
                           env=dict(os.environ, KT_RUN_ID=run_id))
        os.makedirs(os.path.join(A.out, "hoi_quy"), exist_ok=True)
        open(os.path.join(A.out, "hoi_quy", "stdout_kiem_thu_stage3.log"), "w", encoding="utf-8").write(p.stdout + "\n--- stderr ---\n" + p.stderr)
        f = os.path.join(tmp, "ket_qua_stage3", "ket_qua_kiem_thu.json")
        kt(os.path.exists(f), f"subprocess không tạo output (exit {p.returncode})")
        kt(os.path.getmtime(f) >= t0, "output không thuộc lần chạy này (mtime)")
        r = json.load(open(f, encoding="utf-8"))
        kt(r.get("run_id") == run_id, f"run_id {r.get('run_id')} ≠ {run_id}")
        kt(r["so_test"] == 88 and len(r["ket_qua"]) == 88, f"số test {r['so_test']}")
        dem = {"PASS": 0, "FAIL": 0, "BLOCKED": 0, "NOT TESTED": 0, "ERROR": 0}
        for x in r["ket_qua"]:
            if x["status"] == "FAIL" and str(x["actual"]).startswith("NGOẠI LỆ"):
                dem["ERROR"] += 1
            else:
                dem[x["status"]] += 1
        kt(sum(dem.values()) == 88, "tổng trạng thái ≠ 88")
        kt(dem["ERROR"] == 0, f"ERROR {[x['test_id'] for x in r['ket_qua'] if str(x['actual']).startswith('NGOẠI LỆ')]}")
        fails = sorted(x["test_id"] for x in r["ket_qua"] if x["status"] == "FAIL")
        kt(fails == sorted(LOI_THOI_S3), f"tập FAIL {fails} ≠ tập lỗi thời đã chứng minh {sorted(LOI_THOI_S3)}")
        kt((p.returncode == 1) == bool(fails), f"exit code {p.returncode} không khớp số FAIL")
        st = {x["test_id"]: x["status"] for x in r["ket_qua"]}
        kt(st["REG-01"] == "PASS" and st["REG-02"] == "PASS", f"REG-01 {st['REG-01']} / REG-02 {st['REG-02']}")
        f2 = os.path.join(tmp, "ket_qua_stage3", "hoi_quy_bo_cu_tren_module_moi.json")
        kt(os.path.exists(f2) and os.path.getmtime(f2) >= t0, "output bộ gốc 22 không mới")
        c = json.load(open(f2, encoding="utf-8"))
        fc = sorted(x["test_id"] for x in c["chay_b_shim"] if x["result"] == "FAIL")
        kt(len(c["chay_b_shim"]) == 22 and fc == sorted(k for k in LOI_THOI_CU if k != "DUP-01"), f"bộ gốc FAIL {fc}")
        kt("emit_seq" in c["chay_a"]["loi_cuoi"] and not c["chay_a"]["ghi_file"], "chạy nguyên trạng bộ gốc không dừng đúng tại DUP-01")
        shutil.copy(f, os.path.join(A.out, "hoi_quy", "ket_qua_kiem_thu.json")); shutil.copy(f2, os.path.join(A.out, "hoi_quy", "hoi_quy_bo_cu_tren_module_moi.json"))
        return dict(run_id=run_id, exit=p.returncode, dem=dem, fail=fails, lien_ket_loi_thoi_s3=LOI_THOI_S3, lien_ket_loi_thoi_cu=LOI_THOI_CU,
                    bo_039_batdau=int(open(bd).read()), bo_039_mtime=int(os.path.getmtime("/tmp/reg039/ket_qua039/ket_qua_039.json")))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@T("KD-REPL-OT05", "Thay thế test lỗi thời", "Thay OT-05: cùng 3 kiểu nến hỏng (High < Low, NaN, giá ≤ 0) ở nến 1 sau khi R1 đã vào → NO_DATA INVALID_BAR_AFTER_FILL (giữ entry, R null); cùng nến hỏng làm nến vào của R2 → NO_DATA INVALID_BAR (chưa vào); nến hỏng SAU nến thoát → TP1; code = oracle", nhanh=True)
def t_repl_ot05():
    flat = (2000, 2001, 1999, 2000.5)
    for hong in ((2000, 1990, 2010, 2001), (2000, float("nan"), 1999, 2000), (0, 2001, 0, 2000)):
        r = goi(MP.mo_phong, VV.BUY, bars([flat, hong]), 0)
        kt(r["outcome"] == "NO_DATA" and r["fill_note"] == "INVALID_BAR_AFTER_FILL" and r["entry_price"] == 2000.0 and r["r_gross"] is None, f"R1 {hong}: {r['fill_note']}")
        r2 = goi(MP.mo_phong, VV.BUY, bars([flat, hong]), 0, MP.Cfg(entry="next_open"))
        kt(r2["outcome"] == "NO_DATA" and r2["fill_note"] == "INVALID_BAR" and r2["entry_price"] is None, f"R2 {hong}: {r2['fill_note']}")
        for c in (dict(), dict(entry="next_open")):
            kt(impl(VV.BUY, [flat, hong], 0, c) == ora(VV.BUY, [flat, hong], 0, c), "code ≠ oracle")
    r = goi(MP.mo_phong, VV.BUY, bars([flat, (2000, 2011, 1999, 2005), (2000, 1990, 2010, 2001)]), 0)
    kt(r["outcome"] == "TP1", "nến hỏng sau thoát ảnh hưởng kết quả")
    return "3 kiểu × R1/R2 + sau thoát"


@T("KD-REPL-OT06", "Thay thế test lỗi thời", "Thay OT-06: nến 3 trùng thời gian nến 2, và nến 3 lùi thời gian → NO_DATA NON_MONOTONIC_TIME_AFTER_FILL (R1 và R2); code = oracle", nhanh=True)
def t_repl_ot06():
    for c in (dict(), dict(entry="next_open")):
        for lui in (0, 300000):
            b = bars([VV.FLAT] * 4); b[2]["t"] = b[1]["t"] - lui
            r = impl(VV.BUY, b, 0, c)
            kt(r["outcome"] == "NO_DATA" and r["note"] == "NON_MONOTONIC_TIME_AFTER_FILL", f"{c} lùi {lui}: {r['note']}")
            kt(r == ora(VV.BUY, b, 0, c), "code ≠ oracle")
    return "trùng + lùi × R1/R2"


def bo0_s3(co_step):
    """Fixture HD-01 của bộ Stage 3 (y nguyên giá trị) – tùy chọn chèn sự kiện STEP giữa CREATED và ARMED."""
    t1, t2, t3 = 1767323100000, 1767323400000, 1767324000000
    E = lambda **k: dict(dict(schema_version="1.1", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", tf="5", setup="SU5", mode="SHADOW", setup_id="aaaa",   # noqa: E731
                              event_id="e1", emit_seq=0, event_type="CREATED", step=0, ts=HD.ts_tu_ms(t1), ts_ms=t1, dir=1, state=0, reason=0, anchor_price=2000.0, ext_price=5.0), **k)
    ev = [E()] + ([E(event_id="eS", emit_seq=1, event_type="STEP", step=1, ts=HD.ts_tu_ms(t2), ts_ms=t2)] if co_step else []) + \
         [E(event_id="e2", emit_seq=2 if co_step else 1, event_type="ARMED", state=2, ts=HD.ts_tu_ms(t2), ts_ms=t2),
          E(event_id="e3", emit_seq=3 if co_step else 2, event_type="TRIGGER", state=17, reason=16, ts=HD.ts_tu_ms(t3), ts_ms=t3)]
    seq = 3 if co_step else 2
    sg = [dict(schema_version="1.1", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", setup="SU5", setup_id="aaaa", signal_id=HD.hid("aaaa", t3), emit_seq=seq, dir=1,
               trigger_ts=HD.ts_tu_ms(t3), trigger_ts_ms=t3, p_ref=2000.0, sl=1995.0, tp1=2010.0, rr=2.0, reason=16, perm_reg=None, perm_vol=None, dup_key=f"XAUUSD|SU5|1|{t3}")]
    T0 = dict(schema_version="1.1", signal_id=sg[0]["signal_id"], symbol="XAUUSD", setup="SU5", emit_seq=seq, sim_rule="R-close-sl_first-288", cost_model="C-0", entry_ts_ms=t3,
              entry_price=2000.0, risk=5.0, outcome="TP1", fill_note=None, exit_ts_ms=t3 + 600000, exit_price=2010.0, r_gross=2.0, r_net=1.9, mfe_r=2.0, mae_r=-0.2, bars_held=2,
              same_bar_conflict=False, gap_exit=False, time_gaps=0, max_gap_ms=0)
    nul = dict(risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0)
    tr = [T0, dict(T0, outcome="OPEN", exit_ts_ms=None, exit_price=None, r_gross=0.4, r_net=0.4, mfe_r=0.5, mae_r=-0.1, sim_rule="R-close-sl_first-1"),
          dict(T0, outcome="NO_FILL", fill_note="GAP_BEYOND_SL", entry_ts_ms=t3 + 300000, sim_rule="R-next_open-sl_first-288", **nul),
          dict(T0, outcome="NO_DATA", fill_note="NO_NEXT_BAR", sim_rule="R-next_open-tp_first-288", **nul),
          dict(T0, outcome="INVALID", fill_note="INVALID_RISK", cost_model="C-x", **nul)]
    return ev, sg, tr


@T("KD-REPL-HD01S3", "Thay thế test lỗi thời", "Thay HD-01 (Stage 3): fixture GỐC (không STEP) bị bác bởi ĐÚNG MỘT lỗi – chuyển tiếp CREATED → ARMED (chứng minh lý do lỗi thời chính xác); cùng fixture có STEP → 0 lỗi (đủ 5 TRADE: TP1, OPEN, NO_FILL, NO_DATA, INVALID)", nhanh=True)
def t_repl_hd01():
    l0 = HD.kiem_bang(*bo0_s3(False))
    kt(len(l0) == 1 and "CREATED → ARMED" in l0[0], f"fixture gốc: {l0}")
    l1 = HD.kiem_bang(*bo0_s3(True))
    kt(l1 == [], f"fixture có STEP: {l1[:3]}")
    return dict(goc=l0, co_step=l1)


@T("KD-REPL-CU-HD01", "Thay thế test lỗi thời", "Thay HD-01 (bộ gốc): bản ghi EVENTS mẫu + emit_seq → 0 lỗi; bản ghi sai → ≥ 5 lỗi; TRADE mẫu → 0 lỗi; 4 vi phạm TRADE cũ (risk ≤ 0, MFE < 0, MAE > 0, outcome lạ) – MỖI vi phạm kiểm RIÊNG đều bị báo (mạnh hơn kiểm tổng 4 lỗi)", nhanh=True)
def t_repl_cu_hd01():
    e = dict(schema_version="1.0", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", tf="5", setup="SU5", mode="SHADOW", setup_id=HD.hid("XAUUSD", "SU5", 1, 123),
             event_id=HD.hid("x", "ARMED", 123), emit_seq=0, event_type="ARMED", ts="2026-01-02T03:05:00Z", ts_ms=1767323100000, dir=1, state=2, reason=0, anchor_price=2000.0, ext_price=5.0)
    kt(HD.kiem(e, HD.EVENTS) == [], f"event mẫu: {HD.kiem(e, HD.EVENTS)}")
    bad = dict(e, symbol="EURUSD", ts="2026-01-02 03:05", dir=0, extra=1); del bad["reason"]
    kt(len(HD.kiem(bad, HD.EVENTS)) >= 5, f"event sai: {HD.kiem(bad, HD.EVENTS)}")
    t_ok = dict(schema_version="1.0", signal_id="s", sim_rule="R-close-sl_first-288", cost_model="C-0", entry_ts_ms=0, entry_price=2000.0, risk=5.0, outcome="TP1",
                exit_ts_ms=600000, exit_price=2010.0, r_gross=2.0, r_net=1.9, mfe_r=2.0, mae_r=-0.2, bars_held=2, same_bar_conflict=False, gap_exit=False)
    kt(HD.kiem(t_ok, HD.TRADES) == [], f"trade mẫu: {HD.kiem(t_ok, HD.TRADES)}")
    for k, v, kw in (("risk", 0.0, "risk ≤ 0"), ("mfe_r", -0.1, "mfe_r < 0"), ("mae_r", 0.3, "mae_r > 0"), ("outcome", "WIN", "outcome ngoài danh sách")):
        l_ = HD.kiem(dict(t_ok, **{k: v}), HD.TRADES)
        kt(any(kw in x for x in l_), f"{k}={v}: {l_}")
    return "4 vi phạm riêng lẻ"


@T("KD-REPL-CU-DUP01", "Thay thế test lỗi thời", "Thay DUP-01 (bộ gốc): cùng 5 tín hiệu (khóa a, a, b, c, a) với emit_seq = thứ tự trong danh sách → loại 2, giữ khóa {a, b, c}, bản giữ của 'a' là bản phát đầu tiên", nhanh=True)
def t_repl_cu_dup01():
    sg = [dict(signal_id=f"s{i}", trigger_ts_ms=t, dup_key=k, emit_seq=i) for i, (t, k) in enumerate([(1, "a"), (1, "a"), (2, "b"), (1, "c"), (3, "a")])]
    g, n = goi(MP.khu_trung, sg)
    kt(n == 2 and sorted(x["dup_key"] for x in g) == ["a", "b", "c"] and next(x for x in g if x["dup_key"] == "a")["emit_seq"] == 0, f"{[(x['dup_key'], x['emit_seq']) for x in g]}, {n}")
    return dict(giu=[(x["dup_key"], x["emit_seq"]) for x in g], loai=n)


# ================================================================================ R3. TÁI HIỆN F26 / F28 / F29 / F32 (trước sửa = bản lưu, sau sửa = bản hiện tại)
def _mod_cu(ten, thu_muc="_truoc_sua_v2"):
    import importlib.util as iu
    p = os.path.join(G, "shadow_eval", thu_muc, ten + ".py")
    spec = iu.spec_from_file_location(f"{ten}_{thu_muc}", p); m = iu.module_from_spec(spec); spec.loader.exec_module(m)
    if hasattr(m, "G"):
        m.G = G
    return m


def SGx(seq, reason=16, d=1, su="SU3", sym="XAUUSD", t=5, sid=None):
    return dict(signal_id=sid or f"id{999 - seq:03d}", emit_seq=seq, symbol=sym, setup=su, dir=d, trigger_ts_ms=t, reason=reason, dup_key=f"{sym}|{su}|{d}|{t}")


@T("KD-F26", "Tái hiện F26", "F26: (trước) mã pipeline cũ khử trùng trên MỌI tín hiệu rồi mới lọc S1 → cặp [lý do 1 phát trước, lý do 16 phát sau] cho 0 lệnh; (sau) chon_tin_hieu_lenh: 9 ca – một bị S1 loại, hai cùng lý do 16, hai khác lý do bị bỏ, khác chiều, khác setup, khác emit_seq, khác signal_id, xáo trộn, chéo seed – đúng giữ/bỏ; lọc danh mục không đổi kết quả khử trùng", nhanh=True)
def t_f26():
    import pipeline as PL
    src_cu = open(os.path.join(G, "shadow_eval", "_truoc_sua_v2", "pipeline.py"), encoding="utf-8").read()
    kt("giu, n = MP.khu_trung(sg); bo_trung += n" in src_cu and 'if s["reason"] != 16:' in src_cu, "không tìm thấy đoạn mã cũ")
    MPc = _mod_cu("mo_phong_lenh")
    def cu(sg):                       # tái hiện nguyên văn logic cũ (khử trùng trước, lọc S1 sau)
        giu, _ = MPc.khu_trung(sg); return [s for s in giu if s["reason"] == 16]
    kt([s["emit_seq"] for s in cu([SGx(1, reason=1), SGx(2)])] == [], "trước sửa phải mất tín hiệu hợp lệ")
    ca = [([SGx(1, reason=1), SGx(2)], [2], 0), ([SGx(1), SGx(2)], [1], 1), ([SGx(1, reason=15), SGx(2, reason=1)], [], 0),
          ([SGx(1), SGx(2, d=-1)], [1, 2], 0), ([SGx(1), SGx(2, su="SU5")], [1, 2], 0), ([SGx(5), SGx(2)], [2], 1),
          ([SGx(1, sid="zzz"), SGx(2, sid="aaa")], [1], 1), ([SGx(1, reason=8), SGx(3), SGx(2, reason=16)], [2], 1), ([SGx(1, sym="BTCUSD"), SGx(2)], [1, 2], 0)]
    R = random.Random(26)
    for inp, giu, bo in ca:
        for _ in range(6):
            x = inp[:]; R.shuffle(x); g, n = PL.chon_tin_hieu_lenh(x)
            kt([s["emit_seq"] for s in g] == giu and n == bo, f"{[(s['emit_seq'], s['reason']) for s in inp]} → {[s['emit_seq'] for s in g]}, {n}")
    syn = PL.chay_synth("XAUUSD", "SU5", seeds=range(6))
    keys = [t["signal_id"] for t in syn["trades"]]
    kt(len(keys) == len(set(keys)), "trùng lệnh sau khử trùng")
    giu_dl, _ = goi(MP.khong_chong, [dict(t, entry_ts_ms=t["entry_ts_ms"]) for t in syn["trades"] if t["_seed"] == 0])
    kt({t["signal_id"] for t in giu_dl} <= set(keys), "lọc danh mục tạo tín hiệu ngoài tập khử trùng")
    return dict(truoc="0 lệnh (mất tín hiệu đạt S1)", sau_so_ca=len(ca), xao_tron=6)


class _Arr:
    def __init__(s):
        s.v = []


class _Obj:
    def __init__(s, **f):
        s.f = f


class _IP:
    def bar(s, blk):
        blk()


class _Drv:
    """Driver giả lập tối giản cho adapter: kịch bản điều khiển trực tiếp mảng sh / evS (kiểm adapter CÔ LẬP khỏi engine)."""
    def __init__(s):
        s.g = {"sh": _Arr(), "evS": _Arr()}; s.T = VV.T0; s.ip = _IP(); s.pre = None

    def bar(s, pre=(), m5=()):
        s.g["evS"] = _Arr()
        s.pre = lambda: [a(s) for a in pre]
        s.ip.bar(s.pre)
        for a in m5:
            a(s)
        s.T += 300000


def _tao(su=5, bm=100, bs=100, ten=None):
    def a(dv):
        x = _Obj(su=su, d=1, bm=bm, bs=bs, t0=dv.T, st=0, lv=2000.0, ext=5.0); dv.g["sh"].v.append(x); dv.__dict__.setdefault("x", {})[ten or "x"] = x
    return a


def _st(v, ten="x"):
    return lambda dv: dv.x[ten].f.update(st=v)


def _ev(state, reason=0, trig=False, xoa=False, ten="x"):
    def a(dv):
        x = dv.x[ten]
        dv.g["evS"].v.append(_Obj(su=x.f["su"], dir=1, bosMin=x.f["bm"], baseMin=x.f["bs"], trig=trig, state=state, reason=reason, pRef=2005.0, sl=1995.0, tp1=2025.0))
        if xoa:
            dv.g["sh"].v.remove(x)
    return a


def _xoa(ten="x"):
    return lambda dv: dv.g["sh"].v.remove(dv.x[ten])


KB_F28 = {   # kịch bản → (các nến [(pre, m5)], chuỗi kỳ vọng theo tên thể hiện)
    "A tạo + bước 2 cùng nến": ([((_tao(),), (_st(1),))], {"x": ["CREATED", "STEP"]}),
    "B tạo + bước 2 + ARMED cùng nến": ([((_tao(),), (_st(1), _st(2), _ev(2)))], {"x": ["CREATED", "STEP", "ARMED"]}),
    "C tạo + STEP + ARMED + TRIGGER cùng nến": ([((_tao(),), (_st(1), _st(2), _ev(2), _ev(17, 16, trig=True, xoa=True)))], {"x": ["CREATED", "STEP", "ARMED", "TRIGGER"]}),
    "D bước 2 rồi kết thúc không sự kiện cùng nến (IP-20)": ([((_tao(su=3),), ()), ((_st(1),), (_xoa(),))], {"x": ["CREATED", "STEP", "END_NO_EVENT"]}),
    "E bước 2 rồi VOID cùng nến": ([((_tao(),), ()), ((), (_st(1), _ev(6, 6, xoa=True)))], {"x": ["CREATED", "STEP", "VOID"]}),
    "F EXPIRED ở khối tiền-kích hoạt (st 0)": ([((_tao(),), ()), ((_ev(5, 7, xoa=True),), ())], {"x": ["CREATED", "EXPIRED"]}),
    "G hai thể hiện trùng khóa: VOID thuộc bản bị gỡ": ([((_tao(su=3, ten="x1"), _tao(su=3, ten="x2")), ()), ((), (_st(1, "x2"), _ev(6, 6, xoa=True, ten="x2"))), ((_st(1, "x1"),), (_xoa("x1"),))],
                                                         {"x1": ["CREATED", "STEP", "END_NO_EVENT"], "x2": ["CREATED", "STEP", "VOID"]}),
}


def _chay_kb(CHm, kb):
    sys.path.insert(0, os.path.join(G, "kiem_toan039"))
    dv = _Drv(); bg = CHm.BoGhi(dv, "XAUUSD"); bg.gan(dv)
    so_ev_engine = 0
    for pre, m5 in kb:
        dv.bar(pre, m5); so_ev_engine += len(dv.g["evS"].v)
    ten_cua = {id(o): k for k, o in dv.x.items()}
    sid_ten = {i["setup_id"]: ten_cua[id(i["obj"])] for i in bg.theo_doi.values()}
    chuoi = {}
    for e in bg.events:
        chuoi.setdefault(sid_ten[e["setup_id"]], []).append(e["event_type"])
    return bg, chuoi, so_ev_engine


@T("KD-F28-ADAPTER", "Tái hiện F28", "F28 (adapter CÔ LẬP, driver giả lập): 7 kịch bản nhiều chuyển tiếp cùng nến (CREATED/STEP/ARMED/TRIGGER/VOID/EXPIRED/END_NO_EVENT, trùng khóa) – (trước) adapter cũ cho chuỗi thiếu STEP; (sau) chuỗi ĐÚNG Y kỳ vọng, emit_seq tăng liên tục, cùng nến cùng ts, không trùng event_id, không mất sự kiện engine, máy trạng thái 0 lỗi", nhanh=True)
def t_f28_adapter():
    import chuan_hoa as CH
    CHc = _mod_cu("chuan_hoa")
    truoc, sau = {}, {}
    for ten, (kb, kv) in KB_F28.items():
        _, ch_cu, _ = _chay_kb(CHc, kb); truoc[ten] = ch_cu
        bg, ch, n_eng = _chay_kb(CH, kb); sau[ten] = ch
        kt(ch == kv, f"{ten}: {ch} ≠ {kv}")
        ev = bg.events
        kt([e["emit_seq"] for e in ev] == list(range(len(ev))), f"{ten}: emit_seq không liên tục")
        kt(all(b["ts_ms"] >= a["ts_ms"] for a, b in zip(ev, ev[1:])), f"{ten}: ts lùi")
        kt(len({e["event_id"] for e in ev}) == len(ev), f"{ten}: trùng event_id")
        kt(sum(e["event_type"] in ("ARMED", "SKIP", "EXPIRED", "VOID", "TRIGGER") for e in ev) == n_eng, f"{ten}: mất/thừa sự kiện engine")
        kt(MT.kiem_vong_doi(ev) == [], f"{ten}: máy trạng thái {MT.kiem_vong_doi(ev)}")
        if "TRIGGER" in sum(kv.values(), []):
            kt(HD.kiem_bang(ev, bg.signals, []) == [], f"{ten}: liên kết SIGNAL {HD.kiem_bang(ev, bg.signals, [])[:2]}")
    thieu = [k for k in KB_F28 if truoc[k] != KB_F28[k][1]]
    kt(len(thieu) >= 4, f"trước sửa phải tái hiện thiếu STEP ở ≥ 4 kịch bản, được {thieu}")
    return dict(truoc_sai=thieu, truoc=truoc, sau=sau)


@T("KD-F28-SEEDS", "Tái hiện F28", "F28 trên 60 seed engine thật: (trước) adapter cũ vi phạm máy trạng thái; (sau) 0 vi phạm; bỏ mọi STEP khỏi chuỗi trước và sau → giống hệt, TRỪ các thể hiện mà chuỗi cũ tự vi phạm máy trạng thái (F28b: nhiều ARMED gán cho một thể hiện trùng khóa) – mọi khác biệt đó được lưu; mỗi thể hiện ≤ 1 STEP; lưu event trace trước/sau")
def t_f28_seeds():
    import chuan_hoa as CH
    CHc = _mod_cu("chuan_hoa")
    vp_truoc = vp_sau = khac = 0; nhieu_step = 0; trace = {}; f28b = []
    for sd in range(60):
        a, b = CHc.replay_synth(sd)["events"], CH.replay_synth(sd)["events"]
        vp_truoc += len(MT.kiem_vong_doi(a)); vp_sau += len(MT.kiem_vong_doi(b))
        ca, cb = {}, {}
        for e in a:
            ca.setdefault(e["setup_id"], []).append(f"{e['event_type']}@{e['ts_ms'] % 10 ** 8}")
        for e in b:
            cb.setdefault(e["setup_id"], []).append(f"{e['event_type']}@{e['ts_ms'] % 10 ** 8}")
        kt(set(ca) == set(cb), f"seed {sd}: tập thể hiện khác")
        # toàn seed: TẬP (đa tập) sự kiện ngoài STEP phải y hệt → adapter mới không thêm/bớt sự kiện engine, chỉ có thể GÁN LẠI cho thể hiện khác
        kt(sorted(x for v in ca.values() for x in v if not x.startswith("STEP")) == sorted(x for v in cb.values() for x in v if not x.startswith("STEP")),
           f"seed {sd}: đa tập sự kiện ngoài STEP khác nhau")
        vp_seed_cu = MT.kiem_vong_doi(a)
        for k in ca:
            if [x for x in ca[k] if not x.startswith("STEP")] != [x for x in cb[k] if not x.startswith("STEP")]:
                # gán lại chỉ chấp nhận khi chuỗi CŨ của seed có vi phạm (F28b: nhiều ARMED gán cho MỘT thể hiện trùng khóa IP-21)
                kt(vp_seed_cu != [], f"seed {sd} {k}: gán lại sự kiện nhưng seed cũ không vi phạm: {ca[k]} vs {cb[k]}")
                khac += 1; f28b.append(dict(seed=sd, the_hien=k, cu=ca[k], moi=cb[k], vi_pham_cu=vp_seed_cu[:3]))
            nhieu_step += sum(x.startswith("STEP") for x in cb[k]) > 1
        if sd < 5:
            trace[sd] = dict(truoc=ca, sau=cb)
    os.makedirs(A.out, exist_ok=True)
    json.dump(trace, open(os.path.join(A.out, "f28_event_trace_seed0_4.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False)
    json.dump(f28b, open(os.path.join(A.out, "f28b_gan_ARMED_trung_khoa.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False)
    kt(vp_truoc > 0 and vp_sau == 0 and nhieu_step == 0, f"trước {vp_truoc}, sau {vp_sau}, >1 STEP {nhieu_step}")
    return dict(seed=60, vi_pham_truoc=vp_truoc, vi_pham_sau=vp_sau, the_hien_khac_ngoai_STEP=khac, ghi_chu="mọi khác biệt ngoài STEP đều là chuỗi cũ vi phạm (F28b)")


@T("KD-F29", "Tái hiện F29", "F29: bảng trạng thái NO_DATA trước/sau khi vào – (trước) bản cũ ghi INVALID_BAR cho cả hai; (sau) NO_NEXT_BAR / INVALID_BAR (chưa vào: entry_price null) và INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL (đã vào: entry_ts/entry_price giữ, risk/R/MFE/MAE/exit null, bars_held 0); vòng đời, hợp đồng, chỉ số (không vào R), phễu (đã vào + 'vào rồi mất dữ liệu'), oracle nhất quán", nhanh=True)
def t_f29():
    MPc = _mod_cu("mo_phong_lenh")
    b_sau = bars([VV.TRIG, (2000, 1990, 2010, 2001)])
    kt(MPc.mo_phong(VV.BUY, b_sau, 0)["fill_note"] == "INVALID_BAR" == MPc.mo_phong(VV.BUY, bars([VV.TRIG, (0, 2001, 0, 2000)]), 0, MPc.Cfg(entry="next_open"))["fill_note"],
       "trước sửa phải gộp ghi chú")
    b_lui = bars([VV.TRIG, VV.FLAT, VV.FLAT]); b_lui[2]["t"] = b_lui[1]["t"]
    ca = [("NO_NEXT_BAR", VV.BUY, bars([VV.TRIG]), "next_open", False), ("INVALID_BAR", VV.BUY, bars([VV.TRIG, (0, 2001, 0, 2000)]), "next_open", False),
          ("INVALID_BAR", VV.BUY, bars([(2000, 1990, 2010, 2001)]), "close", False), ("INVALID_BAR_AFTER_FILL", VV.BUY, b_sau, "close", True),
          ("NON_MONOTONIC_TIME_AFTER_FILL", VV.BUY, b_lui, "close", True), ("INVALID_BAR_AFTER_FILL", VV.SELL, bars([VV.TRIG_S, (2000, 1990, 2010, 2001)]), "close", True)]
    bang = []; trades = []
    for note, sig, b, rule, vao in ca:
        r = goi(MP.mo_phong, sig, b, 0, MP.Cfg(entry=rule))
        kt(r["outcome"] == "NO_DATA" and r["fill_note"] == note, f"{note}: {r['outcome']} {r['fill_note']}")
        kt(all(r[k] is None for k in ("risk", "r_gross", "r_net", "mfe_r", "mae_r", "exit_ts_ms", "exit_price", "rr_entry")) and r["bars_held"] == 0, f"{note}: trường số phải null")
        kt((r["entry_price"] is not None) == vao, f"{note}: entry_price")
        if vao:
            kt(r["entry_ts_ms"] == b[0]["t"] and r["entry_price"] == sig["p_ref"], f"{note}: entry R1")
        kt(MT.kiem_lenh(r, dict(reason=16, trigger_ts_ms=b[0]["t"]), rule) == [], f"{note}: vòng đời {MT.kiem_lenh(r, dict(reason=16, trigger_ts_ms=b[0]['t']), rule)}")
        kt(impl(sig, b, 0, dict(entry=rule)) == ora(sig, b, 0, dict(entry=rule)), f"{note}: code ≠ oracle")
        kt(HD.kiem(dict(r, schema_version="1.2", signal_id="s", sim_rule=f"R-{rule}-sl_first-288", cost_model="C-0"), HD.TRADES) == [], f"{note}: hợp đồng")
        bang.append(dict(fill_note=note, quy_tac=rule, da_vao=vao, entry_price=r["entry_price"], risk=r["risk"], r=r["r_gross"], bars_held=r["bars_held"]))
        trades.append(dict(r, symbol="XAUUSD", setup="SU5"))
    trades.append(dict(MP.mo_phong(VV.BUY, bars([VV.TRIG, (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0), symbol="XAUUSD", setup="SU5"))
    h = CS.hieu_qua(trades)[("XAUUSD", "SU5")]
    kt(h["dong"] == 1 and h["khong_du_lieu"] == 6 and bang_(h["expectancy"], 2.0), f"chỉ số: dong {h['dong']} nd {h['khong_du_lieu']}")
    f = CS.phieu([], [], trades)[("XAUUSD", "SU5")]
    kt(f["khong_du_lieu"] == 6 and f["vao_roi_mat_du_lieu"] == 3 and f["da_vao"] == 4 and bang_(f["ty_le_da_vao"], 4 / 7), f"phễu: {f['khong_du_lieu']} {f['vao_roi_mat_du_lieu']} {f['da_vao']}")
    return dict(bang_trang_thai=bang, phieu=dict(da_vao=f["da_vao"], vao_roi_mat_du_lieu=f["vao_roi_mat_du_lieu"]))


def bang_(a, b):
    return bang(a, b)


@T("KD-F32", "Tái hiện F32", "F32: (trước) bản cũ giữ lệnh khác nhau khi đảo thứ tự hai lệnh trùng (entry_ts, emit_seq); (sau) khóa (entry_ts, emit_seq, signal_id): 400 tập ngẫu nhiên × 25 lần xáo trộn → cùng kết quả; signal_id trùng → ValueError; thời gian vẫn là ưu tiên số 1 (lệnh vào trước thắng dù emit_seq/signal_id lớn hơn); chéo symbol/setup, BUY/SELL, OPEN/NO_FILL/NO_DATA/INVALID", nhanh=True)
def t_f32():
    MPc = _mod_cu("mo_phong_lenh")
    a = dict(symbol="X", setup="S", entry_ts_ms=5, exit_ts_ms=9, outcome="TP1", emit_seq=1, signal_id="a"); b = dict(a, signal_id="b")
    kt(MPc.khong_chong([a, b])[0][0]["signal_id"] != MPc.khong_chong([b, a])[0][0]["signal_id"], "trước sửa phải phụ thuộc thứ tự")
    kt(goi(MP.khong_chong, [a, b])[0][0]["signal_id"] == goi(MP.khong_chong, [b, a])[0][0]["signal_id"] == "a", "sau sửa phải tất định")
    try:
        MP.khong_chong([a, dict(a)]); kt(False, "signal_id trùng không bị từ chối")
    except ValueError:
        kt(True)
    sm = dict(a, entry_ts_ms=4, emit_seq=9, signal_id="zzz")
    kt([t["signal_id"] for t in goi(MP.khong_chong, [a, sm])[0]] == ["zzz"], "thời gian không còn là ưu tiên số 1")
    R = random.Random(32)
    for _ in range(400):
        tr = []
        for j in range(R.randint(2, 14)):
            o = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")); e = R.choice((5, 5, 10, 15))
            tr.append(dict(symbol=R.choice(("XAUUSD", "BTCUSD")), setup=R.choice(("SU3", "SU5")), dir=R.choice((1, -1)), entry_ts_ms=e, outcome=o,
                           exit_ts_ms=(e + R.choice((0, 5, 10))) if o in ("TP1", "SL", "TIMEOUT") else None, emit_seq=R.choice((1, 1, 2)), signal_id=f"s{R.getrandbits(20)}_{j}"))
        ref = None
        for _ in range(25):
            R.shuffle(tr); g, n = goi(MP.khong_chong, tr)
            k = [t["signal_id"] for t in g]; ref = ref or sorted(k); kt(sorted(k) == ref, "phụ thuộc thứ tự")
            kt(OR.kiem_danh_muc(tr, g) == [], "vi phạm tính chất danh mục")
    return dict(truoc="phụ thuộc thứ tự", tap=400, xao_tron=25)


@T("KD-FIRST", "Nguyên lý đầu (không dựa quy ước MFE/MAE)", "Kiểm bằng nguyên lý đầu trên 4.000 ca: giá thoát nằm trong [Low, High] của nến thoát (hoặc = Open khi gap); SL không gap thoát đúng SL, TP1 không gap đúng TP1; R tính lại từ giá; MFE ≥ mức có lợi lớn nhất của các nến đánh giá TRỌN VẸN, MAE ≤ mức bất lợi nhỏ nhất của chúng; giữ = chỉ số nến thoát − chỉ số nến bắt đầu + 1")
def t_first():
    R = random.Random(4004); n = 0
    for _ in range(4000):
        s, b, c = ca_ngau_nhien(R)
        r = goi(MP.mo_phong, s, b, 0, cfg_impl(c))
        if r["outcome"] not in ("TP1", "SL", "TIMEOUT", "OPEN"):
            continue
        d, E, rk = s["dir"], r["entry_price"], r["risk"]
        st = 1 if c["entry"] == "close" else 1
        if r["exit_ts_ms"] is not None:
            k = next(i for i, x in enumerate(b) if x["t"] == r["exit_ts_ms"]); x = b[k]
            if r["gap_exit"]:
                kt(r["exit_price"] == x["o"], "gap phải thoát tại Open")
            else:
                kt(x["l"] - 1e-9 <= r["exit_price"] <= x["h"] + 1e-9, "giá thoát ngoài nến")
            if r["outcome"] == "SL" and not r["gap_exit"]:
                kt(r["exit_price"] == s["sl"], "SL không gap")
            if r["outcome"] == "TP1" and not r["gap_exit"]:
                kt(r["exit_price"] == s["tp1"], "TP1 không gap")
            kt(bang((r["exit_price"] - E) * d / rk, r["r_gross"]), "R từ giá")
            kt(r["bars_held"] == k - st + 1, "giữ")
            tron = b[st:k]
        else:
            tron = b[st:st + r["bars_held"]]
        if tron:
            kt(r["mfe_r"] + 1e-9 >= max(((x["h"] if d == 1 else x["l"]) - E) * d / rk for x in tron), "MFE nhỏ hơn nến trọn")
            kt(r["mae_r"] - 1e-9 <= min(((x["l"] if d == 1 else x["h"]) - E) * d / rk for x in tron), "MAE lớn hơn nến trọn")
        n += 1
    return f"{n} lệnh đã vào"


TRm = lambda o, r, rg=None, sym="XAUUSD", su="SU5", conf=False, gap=False, mfe=None, mae=None, held=1: dict(symbol=sym, setup=su, outcome=o, r_net=r, r_gross=rg if rg is not None else r,   # noqa: E731
                                                                                                            mfe_r=mfe if mfe is not None else max(r, 0.0), mae_r=mae if mae is not None else min(r, 0.0), bars_held=held, same_bar_conflict=conf, gap_exit=gap)


@T("KD-MET-R3", "Golden chỉ số", "Golden bổ sung (tính tay): gross_r vs net_r có chi phí; MFE/MAE/giữ trung bình; đếm xung đột cùng nến và thoát gap; mẫu nhỏ n = 2, 3; tách (symbol, setup) không rò rỉ; TP1 null; khi thiếu r_gross → gross_r null", nhanh=True)
def t_met_r3():
    tr = [TRm("TP1", 1.9, 2.0, mfe=2.0, mae=-0.2, held=2), TRm("SL", -1.1, -1.0, conf=True, mfe=0.4, mae=-1.0, held=1), TRm("SL", -2.1, -2.0, gap=True, mfe=0.0, mae=-2.0, held=3),
          TRm("TP1", 3.0, sym="BTCUSD"), TRm("SL", -1.0, su="SU3")]
    h = goi(CS.hieu_qua, tr); x = h[("XAUUSD", "SU5")]
    for k, v in dict(dong=3, net_r=-1.3, gross_r=-1.0, mfe_tb=0.8, mae_tb=-3.2 / 3, giu_tb_nen=2.0, xung_dot_cung_nen=1, thoat_gap=1, profit_factor=1.9 / 3.2, win_rate=1 / 3).items():
        kt(bang(v, x[k]), f"{k}: {v} vs {x[k]}")
    kt(bang(h[("BTCUSD", "SU5")]["net_r"], 3.0) and h[("BTCUSD", "SU5")]["dong"] == 1 and bang(h[("XAUUSD", "SU3")]["net_r"], -1.0), "rò rỉ nhóm")
    h2 = CS.hieu_qua([TRm("TP1", 2.0), TRm("SL", -1.0)])[("XAUUSD", "SU5")]
    kt(bang(h2["expectancy"], 0.5) and h2["expectancy_ci95"] is not None and all(math.isfinite(v) for v in h2["expectancy_ci95"]), "n = 2")
    tr3 = [dict(TRm("SL", -1.0)), dict(TRm("TP1", 2.0))]; del tr3[0]["r_gross"]
    kt(CS.hieu_qua(tr3)[("XAUUSD", "SU5")]["gross_r"] is None, "thiếu r_gross phải null")
    kt(CS.hieu_qua([TRm("OPEN", 1.0)])[("XAUUSD", "SU5")]["gross_r"] == 0.0, "0 lệnh đóng → gross_r 0")
    return {k: x[k] for k in ("net_r", "gross_r", "mfe_tb", "mae_tb", "xung_dot_cung_nen", "thoat_gap")}


@T("KD-BOOT-R3", "Bootstrap", "Bootstrap tái lập giữa HAI TIẾN TRÌNH (cùng seed → cùng CI i.i.d. và moving-block); mọi CI hữu hạn trên 300 mẫu ngẫu nhiên (n 2…80); không tuyên bố hiệu quả thị trường")
def t_boot_r3():
    code = ("import sys,json;sys.path.insert(0,%r);import chi_so as C,random;R=random.Random(3);x=[round(R.uniform(-1,2),3) for _ in range(50)];"
            "print(json.dumps([C.bootstrap_ci(x,7,('a',)),C.bootstrap_khoi(x,7,('a',))], allow_nan=False))") % A.module_dir
    o1 = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout
    o2 = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout
    kt(o1 == o2 and o1.strip(), "không tái lập giữa tiến trình")
    R = random.Random(300)
    for _ in range(300):
        x = [R.choice((2.0, -1.0, 0.0, R.uniform(-3, 5))) for _ in range(R.randint(2, 80))]
        for ci in (CS.bootstrap_ci(x, 7, ("b",), n_boot=200)[0], CS.bootstrap_khoi(x, 7, ("b",), n_boot=200)[0]):
            kt(ci is None or all(math.isfinite(v) for v in ci), "CI không hữu hạn")
    return dict(tai_lap=json.loads(o1))


@T("KD-FUNNEL-R3", "Phễu", "Golden phễu bổ sung: NO_DATA trước khi vào KHÔNG là đã vào; NO_DATA sau khi vào LÀ đã vào (F35) và đếm riêng; mẫu số lenh_gia_lap; tách XAUUSD/BTCUSD", nhanh=True)
def t_funnel_r3():
    tr = [dict(symbol="XAUUSD", setup="SU5", outcome=o, fill_note=n) for o, n in (("TP1", None), ("NO_DATA", "NO_NEXT_BAR"), ("NO_DATA", "INVALID_BAR_AFTER_FILL"),
                                                                                 ("NO_FILL", "GAP_BEYOND_TP"), ("OPEN", None))] + [dict(symbol="BTCUSD", setup="SU5", outcome="SL", fill_note=None)]
    f = CS.phieu([], [], tr); a, b = f[("XAUUSD", "SU5")], f[("BTCUSD", "SU5")]
    for k, v in dict(lenh_gia_lap=5, khong_du_lieu=2, vao_roi_mat_du_lieu=1, da_vao=3, khong_khop=1, ty_le_da_vao=0.6, ty_le_khong_du_lieu=0.4, ty_le_khong_khop=0.2).items():
        kt(bang(v, a[k]), f"{k}: {v} vs {a[k]}")
    kt(b["lenh_gia_lap"] == 1 and b["da_vao"] == 1, "tách symbol")
    return {k: a[k] for k in ("lenh_gia_lap", "da_vao", "vao_roi_mat_du_lieu")}


# ================================================================================ R3. KIỂM ĐỘT BIẾN MÃ NGUỒN CÓ BASELINE SẠCH + ÁNH XẠ TEST
DB = [  # (file, đoạn gốc – phải xuất hiện ĐÚNG 1 lần, đoạn đột biến, mô tả, test KỲ VỌNG bắt – khai báo TRƯỚC khi chạy)
    ("mo_phong_lenh.py", "if (pr - sl) * d <= 0:", "if (pr - sl) * d < 0:", "biên rủi ro 0", ["KD-GOLD-EXTRA"]),
    ("mo_phong_lenh.py", "if (entry - sl) * d <= 0:", "if (entry - sl) * d < 0:", "R2 Open = SL", ["KD-GOLD-R2-C-EQ"]),
    ("mo_phong_lenh.py", "if tp is not None and (entry - tp) * d >= 0:", "if tp is not None and (entry - tp) * d > 0:", "R2 Open = TP1", ["KD-GOLD-R2-D-EQ"]),
    ("mo_phong_lenh.py", "if d * (b[\"o\"] - sl) <= 0:", "if d * (b[\"o\"] - sl) < 0:", "gap SL biên", ["KD-GOLD-EXTRA"]),
    ("mo_phong_lenh.py", "hit_sl = d * (adv - sl) <= 0", "hit_sl = d * (adv - sl) < 0", "chạm SL biên", ["KD-GOLD-EXTRA"]),
    ("mo_phong_lenh.py", "hit_tp = tp is not None and d * (fav - tp) >= 0", "hit_tp = tp is not None and d * (fav - tp) > 0", "chạm TP biên", ["KD-GOLD-EXTRA"]),
    ("mo_phong_lenh.py", "if cfg.same_bar == \"sl_first\":", "if cfg.same_bar != \"sl_first\":", "đảo quy tắc cùng nến", ["KD-GOLD-R1-SB-SL", "KD-GOLD-R1-SB-TP"]),
    ("mo_phong_lenh.py", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), min(mae, R(adv)))\n", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), mae)\n", "MAE nến thoát TP1", ["KD-GOLD-EXTRA"]),
    ("mo_phong_lenh.py", "return ra(\"SL\", k, sl, mfe, min(mae, -1.0))\n        if hit_tp", "return ra(\"SL\", k, sl, max(mfe, R(fav)), min(mae, -1.0))\n        if hit_tp", "MFE nến thoát SL", ["KD-GOLD-R1-SL-FAV"]),
    ("mo_phong_lenh.py", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), min(mae, R(adv)), same_bar_conflict=True)", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), mae, same_bar_conflict=True)", "F3 tái phát", ["KD-GOLD-R1-SB-TP", "KD-GOLD-S-SB-TP"]),
    ("mo_phong_lenh.py", "end = min(len(bars), start + cfg.max_bars)", "end = min(len(bars), start + cfg.max_bars + 1)", "max_bars lệch 1", ["KD-GOLD-R1-HITAFTER"]),
    ("mo_phong_lenh.py", "if start + cfg.max_bars > len(bars):", "if start + cfg.max_bars >= len(bars):", "biên OPEN/TIMEOUT", ["KD-GOLD-R1-TIMEOUT-EXACT"]),
    ("mo_phong_lenh.py", "first = (k == start and cfg.entry == \"next_open\")", "first = (k == start)", "R1 bỏ kiểm gap nến đầu", ["KD-GOLD-R1-GAPSL", "KD-GOLD-R1-GAPTP"]),
    ("mo_phong_lenh.py", "cost = cfg.spread + cfg.commission + 2 * cfg.slippage", "cost = cfg.spread + cfg.commission + cfg.slippage", "chi phí trượt giá 1 lần", ["KD-GOLD-EXTRA"]),
    ("mo_phong_lenh.py", "        ie, entry, start = i_trig, pr, i_trig + 1", "        ie, entry, start = i_trig, pr, i_trig", "R1 dùng nến trigger (nhìn trước)", ["KD-GOLD-R1-NOLOOK"]),
    ("mo_phong_lenh.py", "if t.get(\"outcome\") in KHONG_VAO:\n            giu.append(t); continue", "if t.get(\"outcome\") == \"NO_DATA\":\n            giu.append(t); continue", "F1 tái phát", ["KD-OCC-GOLD"]),
    ("mo_phong_lenh.py", "if k in mo and t[\"entry_ts_ms\"] <= mo[k]:", "if k in mo and t[\"entry_ts_ms\"] < mo[k]:", "biên vào = thoát", ["KD-OCC-GOLD"]),
    ("mo_phong_lenh.py", "for s in sorted(signals, key=lambda x: x[\"emit_seq\"]):", "for s in sorted(signals, key=lambda x: x[\"signal_id\"]):", "F2 tái phát", ["KD-DUP-GOLD"]),
    ("mo_phong_lenh.py", "x.get(\"emit_seq\", 0), str(x.get(\"signal_id\", \"\"))", "x.get(\"emit_seq\", 0)", "bỏ khóa phụ signal_id (F32)", ["KD-OCC-GOLD"]),
    ("mo_phong_lenh.py", "if len(ids) != len(set(ids)):", "if False:", "bỏ kiểm signal_id trùng (F32)", ["KD-F32"]),
    ("mo_phong_lenh.py", "key=lambda x: (x[\"entry_ts_ms\"] if x.get(\"entry_ts_ms\") is not None else -1, x.get(\"emit_seq\", 0)", "key=lambda x: (x.get(\"emit_seq\", 0), x[\"entry_ts_ms\"] if x.get(\"entry_ts_ms\") is not None else -1", "đảo ưu tiên thời gian", ["KD-F32"]),
    ("mo_phong_lenh.py", "\"INVALID_BAR_AFTER_FILL\" if why else", "\"INVALID_BAR\" if why else", "F29 tái phát", ["KD-F29", "KD-REPL-OT05"]),
    ("chi_so.py", "thang = [r for r in R if r > EPS_R]; thua = [r for r in R if r < -EPS_R]", "thang = [r for r in R if r > EPS_R]; thua = [r for r in R if r <= EPS_R]", "hòa vốn tính là thua", ["KD-MET-1BE"]),
    ("chi_so.py", "pf, pfs = None, (\"KHONG_CO_LENH_THUA\" if thang else \"KHONG_CO_LENH_THANG_THUA\")", "pf, pfs = float(\"inf\"), \"OK\"", "F10 tái phát", ["KD-MET-1WIN"]),
    ("chi_so.py", "win_rate=len(thang) / n if n else None,", "win_rate=len(thang) / (len(thang) + len(thua)) if (thang or thua) else None,", "mẫu số win rate", ["KD-MET-WINBE"]),
    ("chi_so.py", "dong = [t for t in ts if t[\"outcome\"] in DONG]", "dong = [t for t in ts if t[\"outcome\"] in DONG + (\"OPEN\",)]", "OPEN vào R", ["KD-MET-OPEN"]),
    ("chi_so.py", "k = (B * int(round(alpha * 1000))) // 2000", "k = (B * int(round(alpha * 1000))) // 1000", "phân vị sai", ["KD-PCT"]),
    ("chi_so.py", "o[k][\"trung\"] = sum(1 for x in ds if x is not None) - len({x for x in ds if x is not None})", "o[k][\"trung\"] = 0", "F11 tái phát", ["KD-FUNNEL"]),
    ("chi_so.py", "r[\"da_vao\"] += t[\"outcome\"] in DONG + (\"OPEN\",) or sau_vao", "r[\"da_vao\"] += t[\"outcome\"] in DONG + (\"OPEN\",)", "F35 tái phát", ["KD-F29", "KD-FUNNEL-R3"]),
    ("chi_so.py", "gross_r=(sum(t[\"r_gross\"] for t in dong)", "gross_r=(sum(t[\"r_net\"] for t in dong)", "gross_r dùng r_net", ["KD-MET-R3"]),
    ("hop_dong.py", "if t is float and not math.isfinite(v):", "if False:", "F12 tái phát (NaN)", ["KD-HD-MUT"]),
    ("hop_dong.py", "if isinstance(ms, int) and not isinstance(ms, bool) and int(t.timestamp() * 1000) != ms:", "if False:", "bỏ ts ↔ ts_ms", ["KD-HD-MUT"]),
    ("hop_dong.py", "if t in (int, float) and isinstance(v, bool):", "if False:", "bool giả int", ["KD-HD-MUT"]),
    ("hop_dong.py", "if abs(t[\"risk\"] - (t[\"entry_price\"] - s[\"sl\"]) * d) > 1e-6:", "if False:", "bỏ kiểm risk cấp bảng", ["KD-HD-MUT"]),
    ("hop_dong.py", "loi += [f\"MÁY TRẠNG THÁI: {x}\" for x in MT.kiem_vong_doi(events)]", "pass", "bỏ máy trạng thái sự kiện", ["KD-HD-MUT", "KD-REPL-HD01S3"]),
    ("hop_dong.py", "if not isinstance(ms, int) or isinstance(ms, bool) or not 0 <= ms <= MS_MAX:\n        return", "if False:\n        return", "F36 tái phát (crash ts ngoài miền)", ["KD-HD-FUZZ", "KD-HD-MUT"]),
    ("hop_dong.py", "    if not isinstance(rec, dict):\n        return", "    if False:\n        return", "bỏ kiểm bản ghi không phải object", ["KD-HD-FUZZ"]),
    ("may_trang_thai.py", "\"CREATED\": {\"STEP\", \"VOID\", \"EXPIRED\"}", "\"CREATED\": {\"STEP\", \"VOID\", \"EXPIRED\", \"ARMED\"}", "nới CREATED → ARMED", ["KD-SM-TABLE"]),
    ("may_trang_thai.py", "if rule == \"next_open\" and t[\"entry_ts_ms\"] <= s[\"trigger_ts_ms\"]:", "if False:", "bỏ kiểm R2 vào sau trigger", ["KD-SM-TRADE-NEG"]),
    ("pipeline.py", "return MP.khu_trung([s for s in signals if s[\"reason\"] == 16])", "g, n = MP.khu_trung(signals)\n    return [s for s in g if s[\"reason\"] == 16], n", "F26 tái phát", ["KD-F26", "KD-DUP-GOLD"]),
    ("chuan_hoa.py", "            self._buoc_trung_gian(info, ts)\n            if f[\"trig\"]:", "            if f[\"trig\"]:", "F28 tái phát (STEP trước sự kiện engine)", ["KD-F28-ADAPTER"]),
    ("chuan_hoa.py", "self.theo_doi[id(x)] = info = dict(obj=x, setup_id=sid, st=0,", "self.theo_doi[id(x)] = info = dict(obj=x, setup_id=sid, st=f[\"st\"],", "F28 tái phát (CREATED lấy st cuối nến)", ["KD-F28-ADAPTER"]),
]
GATE_BO = {"KD-REG-S3", "KD-MUT-SRC"}


def _chay_gate(thu_muc_module, out):
    p = subprocess.run([sys.executable, os.path.abspath(__file__), "--gate", "--module-dir", thu_muc_module, "--out", out], capture_output=True, text=True, timeout=1800,
                       env=dict(os.environ, ATA_GOC=G))
    f = os.path.join(out, "ket_qua_doc_lap.json")
    if not os.path.exists(f):
        return p.returncode, None, p.stdout[-2000:] + p.stderr[-2000:]
    return p.returncode, json.load(open(f, encoding="utf-8")), p.stdout[-500:] + p.stderr[-1000:]


def _ban_sao(mut=None):
    tmp = tempfile.mkdtemp(prefix="kd_mut_")
    for x in os.listdir(A.module_dir):
        if x.endswith(".py"):
            shutil.copy(os.path.join(A.module_dir, x), tmp)
    if mut:
        f, a, b = mut
        src = open(os.path.join(tmp, f), encoding="utf-8").read()
        open(os.path.join(tmp, f), "w", encoding="utf-8").write(src.replace(a, b, 1))
    return tmp


def _phan_loai(rc, r, kv):
    if r is None:
        return "ENV_ERROR", [], []
    hong = [x for x in r["ket_qua"] if x["status"] == "FAIL"]
    ass = [x["test_id"] for x in hong if str(x["actual"]).startswith("assertion sai")]
    exc = [x["test_id"] for x in hong if str(x["actual"]).startswith("NGOẠI LỆ")]
    if len(exc) >= 0.8 * len(r["ket_qua"]):
        return "ENV_ERROR", ass, exc                          # gần như mọi test lỗi ngoại lệ → lỗi import/môi trường
    if any(t in ass for t in kv):
        return "KILLED_EXPECTED", ass, exc
    if ass:
        return "KILLED_OTHER", ass, exc
    if exc:
        return "TEST_ERROR", ass, exc
    return "SURVIVED", ass, exc


@T("KD-MUT-SRC", "Đột biến mã nguồn", "Kiểm đột biến mã nguồn có cổng: (1) chạy bộ GATE (mọi test trừ hồi quy/đột biến) trên bản sao KHÔNG đột biến – phải sạch; (2) mỗi đột biến: đoạn gốc đúng 1 lần, biên dịch được, chạy GATE cô lập; phân loại KILLED_EXPECTED (test kỳ vọng FAIL bằng assertion) / KILLED_OTHER / SURVIVED / TEST_ERROR (chỉ ngoại lệ) / ENV_ERROR / INVALID; cổng PASS khi 100 % KILLED_EXPECTED")
def t_mut_src():
    if A.nhanh or A.gate:
        return "NOT TESTED", "chế độ nhanh/gate"
    import py_compile
    from concurrent.futures import ThreadPoolExecutor
    log = []
    tmp0 = _ban_sao(); out0 = tempfile.mkdtemp(prefix="kd_out_")
    try:
        rc0, r0, tail0 = _chay_gate(tmp0, out0)
    finally:
        shutil.rmtree(tmp0, ignore_errors=True)
    kt(r0 is not None and rc0 == 0 and r0["tom_tat"].get("FAIL", 0) == 0 and r0["che_do"] == "gate", f"BASELINE KHÔNG SẠCH: rc {rc0} {r0 and r0['tom_tat']} {tail0[-300:]}")
    ids0 = {x["test_id"] for x in r0["ket_qua"]}
    for f, a, b, mo, kv in DB:
        kt(all(t in ids0 for t in kv), f"test kỳ vọng không có trong gate: {mo} {kv}")
    baseline = dict(rc=rc0, tom_tat=r0["tom_tat"], so_test=len(r0["ket_qua"]), so_assertion=r0["so_assertion"])

    def mot(item):
        f, a, b, mo, kv = item
        src = open(os.path.join(A.module_dir, f), encoding="utf-8").read()
        if src.count(a) != 1:
            return dict(dot_bien=mo, file=f, ket_qua="INVALID", ly_do=f"đoạn gốc xuất hiện {src.count(a)} lần", ky_vong=kv)
        tmp = _ban_sao((f, a, b)); out = tempfile.mkdtemp(prefix="kd_out_")
        try:
            moi = open(os.path.join(tmp, f), encoding="utf-8").read()
            if moi == src:
                return dict(dot_bien=mo, file=f, ket_qua="INVALID", ly_do="nguồn không đổi", ky_vong=kv)
            try:
                py_compile.compile(os.path.join(tmp, f), doraise=True)
            except py_compile.PyCompileError as ex:
                return dict(dot_bien=mo, file=f, ket_qua="INVALID", ly_do=f"không biên dịch: {ex}", ky_vong=kv)
            rc, r, tail = _chay_gate(tmp, out)
            kq, ass, exc = _phan_loai(rc, r, kv)
            return dict(dot_bien=mo, file=f, ket_qua=kq, ky_vong=kv, test_bat_bang_assertion=ass, test_loi_ngoai_le=exc, rc=rc,
                        sha_dot_bien=hashlib.sha256(moi.encode()).hexdigest()[:16], log=(tail[-300:] if kq in ("ENV_ERROR", "TEST_ERROR") else ""))
        finally:
            shutil.rmtree(tmp, ignore_errors=True); shutil.rmtree(out, ignore_errors=True)
    with ThreadPoolExecutor(max_workers=max(2, os.cpu_count() or 2)) as ex:
        bang = list(ex.map(mot, DB))
    dem = {}
    for x in bang:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    os.makedirs(A.out, exist_ok=True)
    with open(os.path.join(A.out, "log_dot_bien_nguon.txt"), "w", encoding="utf-8") as lg:
        lg.write(f"BASELINE (bản sao không đột biến, chế độ gate): {baseline}\n")
        for x in bang:
            lg.write(f"[{x['ket_qua']:16}] {x['file']:18} {x['dot_bien']:45} kỳ vọng={x['ky_vong']} bắt_bằng_assertion={x.get('test_bat_bang_assertion')} "
                     f"ngoại_lệ={x.get('test_loi_ngoai_le')} rc={x.get('rc')} sha={x.get('sha_dot_bien')} {x.get('ly_do', '')}\n")
    json.dump(dict(baseline=baseline, dot_bien=bang, phan_loai=dem), open(os.path.join(A.out, "bao_cao_dot_bien_nguon.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, allow_nan=False)
    kt(len(bang) == len(DB), "số đột biến chạy ≠ khai báo")
    xau = [(x["dot_bien"], x["ket_qua"]) for x in bang if x["ket_qua"] != "KILLED_EXPECTED"]
    kt(not xau, f"không đạt: {xau}")
    return dict(baseline=baseline, tong=len(DB), phan_loai=dem)


def main():
    os.makedirs(A.out, exist_ok=True)
    t0 = time.time()
    for t in TESTS:
        if A.nhanh and not t.nhanh:
            continue
        if A.gate and t.tid in GATE_BO:
            continue
        if A.chi and t.tid not in A.chi.split(","):
            continue
        t()
    if not A.nhanh and not A.gate and not A.chi:
        st = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for tid, mo, ly in (("KD-REAL-XAU-SU3", "Đánh giá SU-3 dữ liệu thật XAUUSD", "Không có OHLCV lịch sử có nguồn (mạng của công cụ tắt) và chưa có replay bối cảnh từ OHLCV"),
                            ("KD-REAL-XAU-SU5", "Đánh giá SU-5 dữ liệu thật XAUUSD", "Như trên"), ("KD-REAL-BTC-SU3", "Đánh giá SU-3 dữ liệu thật BTCUSD", "Như trên"),
                            ("KD-REAL-BTC-SU5", "Đánh giá SU-5 dữ liệu thật BTCUSD", "Như trên"),
                            ("KD-REPLAY-EQ", "Tương đương Python ↔ TradingView", "Không có dữ liệu đối chứng; Data Window chỉ giữ một phần sự kiện SHADOW (B-1)"),
                            ("KD-TV-TOKEN", "Token biên dịch thật 0.3.9", "TradingView không in số token khi compile thành công")):
            KQ.append(dict(test_id=tid, nhom="BLOCKED", muc_tieu=mo, phan_loai="FACT", status="BLOCKED", so_assertion=0, actual=ly, test_source="—", run_time=st, duration_ms=0, hash="-"))
        KQ.append(dict(test_id="KD-REPLAY-FULL", nhom="NOT TESTED", muc_tieu="Replay toàn script từ OHLCV (f_struct, MD-3/4/5, request.security, ta.*)", phan_loai="FACT", status="NOT TESTED",
                       so_assertion=0, actual="Chưa hiện thực – ngoài phạm vi (không xây full Pine interpreter)", test_source="—", run_time=st, duration_ms=0, hash="-"))
    dem = {}
    for x in KQ:
        dem[x["status"]] = dem.get(x["status"], 0) + 1
    tong = dict(tom_tat=dem, so_test=len(KQ), so_assertion=DEM["assert"], che_do="nhanh" if A.nhanh else ("gate" if A.gate else ("chon:" + A.chi if A.chi else "day_du")), module_dir=A.module_dir,
                thoi_gian_s=round(time.time() - t0, 1), python=sys.version.split()[0], ket_qua=KQ, ca_lech=LECH,
                sha_module={f: sha_f(os.path.join(A.module_dir, f)) for f in ("mo_phong_lenh.py", "hop_dong.py", "chi_so.py", "may_trang_thai.py", "chuan_hoa.py", "pipeline.py") if os.path.exists(os.path.join(A.module_dir, f))},
                sha_oracle={f: sha_f(os.path.join(KD, f)) for f in ("oracle.py", "vector_vang.py", "chay_doc_lap.py")})
    json.dump(tong, open(os.path.join(A.out, "ket_qua_doc_lap.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)
    with open(os.path.join(A.out, "ket_qua_doc_lap.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f); w.writerow(["test_id", "nhom", "status", "so_assertion", "phan_loai", "muc_tieu", "hash"])
        for x in KQ:
            w.writerow([x["test_id"], x["nhom"], x["status"], x["so_assertion"], x["phan_loai"], x["muc_tieu"], x["hash"]])
    print(dem, "assertion:", DEM["assert"], f"{tong['thoi_gian_s']} s")
    sys.exit(1 if dem.get("FAIL") else 0)


if __name__ == "__main__":
    main()
