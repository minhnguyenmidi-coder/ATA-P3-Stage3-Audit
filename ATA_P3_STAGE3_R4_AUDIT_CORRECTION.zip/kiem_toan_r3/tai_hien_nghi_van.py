# -*- coding: utf-8 -*-
"""TÁI HIỆN NGHI VẤN CỦA KIỂM TOÁN VIÊN trên RUNNER ROUND 2 (bản đã bàn giao, cây cô lập /tmp/r2base). Không sửa gì của Round 2.
Mỗi nghi vấn: dựng tình huống xấu có chủ đích → xem runner Round 2 phản ứng thế nào → XÁC NHẬN / BÁC BỎ / MỘT PHẦN.
python3 REMEDIATION/tai_hien_nghi_van.py /tmp/r2base → REMEDIATION/ket_qua/tai_hien_nghi_van.json"""
import importlib.util, json, os, re, shutil, subprocess, sys, tempfile, textwrap
R2 = sys.argv[1] if len(sys.argv) > 1 else "/tmp/r2base"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket_qua"); os.makedirs(OUT, exist_ok=True)   # kiem_toan_r3/ket_qua
KQ = []


def ghi(nv, ket_luan, mo_ta, bang_chung):
    KQ.append(dict(nghi_van=nv, ket_luan=ket_luan, mo_ta=mo_ta, bang_chung=bang_chung)); print(f"[{ket_luan:10}] {nv}: {mo_ta}")


def nap_runner_r2(module_dir):
    """Nạp runner Round 2 như một module (đăng ký test, KHÔNG chạy main)."""
    argv0 = sys.argv
    sys.argv = ["chay_doc_lap.py", "--nhanh", "--module-dir", module_dir, "--out", tempfile.mkdtemp()]
    for m in ("mo_phong_lenh", "hop_dong", "chi_so", "may_trang_thai", "pipeline", "chuan_hoa", "oracle", "vector_vang"):
        sys.modules.pop(m, None)
    spec = importlib.util.spec_from_file_location("runner_r2", os.path.join(R2, "kiem_doc_lap", "chay_doc_lap.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    sys.argv = argv0
    return m


# ---------------------------------------------------------------- NV1: KD-HD-MUT tính exception là phát hiện?
m = nap_runner_r2(os.path.join(R2, "shadow_eval"))
goc = m.HD.kiem_bang
m.HD.kiem_bang = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("validator crash có chủ đích"))
m.t_hd_mut(); r_crash = m.KQ[-1]
# giữ NGUYÊN tập dữ liệu bị bác (fixture hợp lệ vẫn 0 lỗi) nhưng thay mọi thông báo bằng một lỗi vô nghĩa không liên quan đột biến
m.HD.kiem_bang = lambda *a, **k: (["lỗi vô nghĩa không liên quan"] if goc(*a, **k) else [])
m.t_hd_mut(); r_sai = m.KQ[-1]
m.HD.kiem_bang = goc
ghi("NV1-a KD-HD-MUT: exception của validator có được tính là 'đã phát hiện'?",
    "BÁC BỎ" if r_crash["status"] == "FAIL" else "XÁC NHẬN",
    f"validator luôn ném ngoại lệ → runner Round 2 cho KD-HD-MUT = {r_crash['status']} (exception bị tính là KHÔNG phát hiện, không phải 'killed')",
    dict(status=r_crash["status"], actual=str(r_crash["actual"])[:300]))
ghi("NV1-b KD-HD-MUT: phát hiện SAI LÝ DO có bị tính là đạt?",
    "XÁC NHẬN" if r_sai["status"] == "PASS" else "BÁC BỎ",
    f"validator vẫn bác đúng các bộ đột biến nhưng chỉ trả MỘT thông báo vô nghĩa (không nêu vi phạm nào) → runner Round 2 cho KD-HD-MUT = {r_sai['status']}: "
    "không kiểm lý do bị bác, nên một đột biến bị bắt vì lỗi KHÁC cũng được tính là đạt; không phân loại; fixture thiếu SELL-TPnull",
    dict(status=r_sai["status"], actual=str(r_sai["actual"])[:300]))

# ---------------------------------------------------------------- NV2: KD-JSON regex 3 dòng
src_r2 = open(os.path.join(R2, "kiem_doc_lap", "chay_doc_lap.py"), encoding="utf-8").read()
mau = textwrap.dedent('''
    import json
    from json import dump as luu
    json.dump(
        x,
        f,
        indent=1,
        allow_nan=False)
    luu(x, f)
    j = json
''')


def regex_r2(src):
    """Đúng logic kiểm của runner Round 2: re.finditer(r'json\\.dump\\(') + xét 3 dòng."""
    out = {}
    for mm in re.finditer(r"json\.dump\(", src):
        cau = "\n".join(src[mm.start():].split("\n")[:3])
        out[src[:mm.start()].count("\n") + 1] = "allow_nan=False" in cau
    return out


co_dung_logic = "split(\"\\n\")[:3]" in src_r2 or "[:3]" in src_r2
kq_regex = regex_r2(mau)
ghi("NV2 KD-JSON: regex giới hạn 3 dòng có bỏ sót / kết luận sai?", "XÁC NHẬN" if co_dung_logic and list(kq_regex.values()) == [False] else "KHÔNG RÕ",
    f"mẫu nguồn có 2 lời gọi: json.dump kéo dài 5 dòng (CÓ allow_nan=False ở dòng 5) và 'luu(x, f)' (bí danh của json.dump, KHÔNG strict). Logic Round 2 thấy {kq_regex} → "
    "báo nhầm lời gọi strict là không strict, và BỎ SÓT hoàn toàn lời gọi qua bí danh; json.dumps cũng không được quét",
    dict(logic_r2_trong_runner=co_dung_logic, ket_qua_regex=kq_regex))

# ---------------------------------------------------------------- NV3: KD-REG-S3 đọc output cũ
tmp = tempfile.mkdtemp(prefix="nv3_")
try:
    for d in ("shadow_eval", "kiem_doc_lap", "ket_qua_stage3", "ket_qua_shadow_eval"):
        shutil.copytree(os.path.join(R2, d), os.path.join(tmp, d), ignore=shutil.ignore_patterns("__pycache__"))
    # thay bộ Stage 3 bằng script HỎNG (thoát ngay, không ghi output); giữ file kết quả CŨ có sẵn
    open(os.path.join(tmp, "shadow_eval", "kiem_thu_stage3.py"), "w").write("import sys\nsys.exit(3)\n")
    m3 = None
    src = open(os.path.join(R2, "kiem_doc_lap", "chay_doc_lap.py"), encoding="utf-8").read()
    i = src.index("def t_reg():"); j = src.index("\nDB = [")
    tham = re.search(r"G, \"ket_qua_stage3\", \"ket_qua_kiem_thu.json\"", src[i:j]) is not None
    co_kiem_mtime = "getmtime" in src[i:j] or "run_id" in src[i:j]
    old = json.load(open(os.path.join(tmp, "ket_qua_stage3", "ket_qua_kiem_thu.json"), encoding="utf-8"))
    p = subprocess.run([sys.executable, os.path.join(tmp, "shadow_eval", "kiem_thu_stage3.py")], cwd=tmp)
    van_doc_duoc = os.path.exists(os.path.join(tmp, "ket_qua_stage3", "ket_qua_kiem_thu.json"))
    ghi("NV3 KD-REG-S3: có thể đọc output CŨ khi subprocess hỏng?", "XÁC NHẬN" if tham and not co_kiem_mtime and van_doc_duoc else "BÁC BỎ",
        f"bộ Stage 3 bị thay bằng script thoát ngay (exit {p.returncode}, không ghi gì) – file ket_qua_kiem_thu.json CŨ vẫn còn và runner Round 2 đọc đúng đường dẫn đó, "
        f"không kiểm mtime/run_id/exit code → sẽ chấm trên kết quả cũ ({old['tom_tat']})",
        dict(doc_duong_dan_co_dinh=tham, co_kiem_mtime_hoac_run_id=co_kiem_mtime, exit_subprocess=p.returncode, file_cu_con=van_doc_duoc))
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# ---------------------------------------------------------------- NV4: KD-MUT-SRC tính exit code ≠ 0 là 'killed'
tmp = tempfile.mkdtemp(prefix="nv4_")
try:
    for x in os.listdir(os.path.join(R2, "shadow_eval")):
        if x.endswith(".py"):
            shutil.copy(os.path.join(R2, "shadow_eval", x), tmp)
    s = open(os.path.join(tmp, "mo_phong_lenh.py"), encoding="utf-8").read()
    open(os.path.join(tmp, "mo_phong_lenh.py"), "w", encoding="utf-8").write("import mo_dun_khong_ton_tai_xyz\n" + s)      # lỗi MÔI TRƯỜNG, không phải đột biến logic
    p = subprocess.run([sys.executable, os.path.join(R2, "kiem_doc_lap", "chay_doc_lap.py"), "--nhanh", "--module-dir", tmp, "--out", tempfile.mkdtemp()],
                       capture_output=True, text=True)
    i = src_r2.index("def t_mut_src():"); j = src_r2.index("def main():")
    tinh_theo_rc = "p.returncode != 0" in src_r2[i:j]
    ghi("NV4 KD-MUT-SRC: lỗi import/môi trường có bị tính là 'killed'?", "XÁC NHẬN" if p.returncode != 0 and tinh_theo_rc else "BÁC BỎ",
        f"bản module có 'import mo_dun_khong_ton_tai_xyz' (lỗi import, KHÔNG phải đột biến logic) → runner nhanh Round 2 thoát mã {p.returncode}; "
        "KD-MUT-SRC Round 2 xếp loại bằng 'p.returncode != 0' → sẽ tính là KILLED. Không có baseline sạch, không ánh xạ test",
        dict(exit=p.returncode, xep_loai_theo_exit_code=tinh_theo_rc, stderr_cuoi=p.stderr.strip().splitlines()[-1][:160] if p.stderr.strip() else ""))
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# ---------------------------------------------------------------- NV5: MUT-01…05 (bộ Stage 3 cũ) tính ngoại lệ là bắt được
s3 = open(os.path.join(R2, "shadow_eval", "kiem_thu_stage3.py"), encoding="utf-8").read()
ghi("NV5 MUT-01…05 (bộ Stage 3 vòng 1): ngoại lệ được tính là 'bắt được'?", "XÁC NHẬN" if 'r[t.tid] = "FAIL(ngoại lệ)"' in s3 else "BÁC BỎ",
    "_dot_bien() ghi 'FAIL(ngoại lệ)' khi test ném ngoại lệ và MUT-0x coi mọi giá trị ≠ 'PASS' là bắt được. Không sửa test cũ (nguyên tắc 4–5); "
    "được THAY bằng KD-MUT-SRC (phân loại KILLED_EXPECTED / TEST_ERROR / ENV_ERROR)", dict(dong=s3[:s3.index('r[t.tid] = "FAIL(ngoại lệ)"')].count("\n") + 1 if 'FAIL(ngoại lệ)' in s3 else None))

# (ghi chung ở cuối file)


# ================================================================ SAU SỬA: cùng các kịch bản xấu trên RUNNER MỚI (cây hiện tại)
G_MOI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # gốc dự án (kiem_toan_r3/..)


def nap_runner_moi(module_dir):
    argv0 = sys.argv
    sys.argv = ["chay_doc_lap.py", "--nhanh", "--module-dir", module_dir, "--out", tempfile.mkdtemp()]
    for x in ("mo_phong_lenh", "hop_dong", "chi_so", "may_trang_thai", "pipeline", "chuan_hoa", "oracle", "vector_vang"):
        sys.modules.pop(x, None)
    spec = importlib.util.spec_from_file_location("runner_moi", os.path.join(G_MOI, "kiem_doc_lap", "chay_doc_lap.py"))
    mm = importlib.util.module_from_spec(spec); spec.loader.exec_module(mm)
    sys.argv = argv0
    return mm


SAU = []
n = nap_runner_moi(os.path.join(G_MOI, "shadow_eval"))
g2 = n.HD.kiem_bang
n.HD.kiem_bang = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("validator crash có chủ đích"))
try:
    b = n.chay_dot_bien_hop_dong(); kq_a = sorted({r["ket_qua"] for r in b})
except Exception as ex:      # noqa: BLE001
    kq_a = [f"NGOẠI LỆ {ex!r}"]
n.HD.kiem_bang = lambda *a, **k: (["lỗi vô nghĩa không liên quan"] if g2(*a, **k) else [])
kq_b = sorted({r["ket_qua"] for r in n.chay_dot_bien_hop_dong()})
n.HD.kiem_bang = g2
SAU.append(dict(nghi_van="NV1", sau_sua=dict(validator_crash=kq_a, thong_bao_vo_nghia=kq_b), dat=kq_a == ["VALIDATOR_CRASH"] and kq_b == ["PHAT_HIEN_SAI_LY_DO"]))
tmpf = tempfile.mkdtemp(); open(os.path.join(tmpf, "mau.py"), "w").write(mau)
G0 = n.G; n.G = tmpf
sites = n.quet_json_site("mau.py"); n.G = G0
SAU.append(dict(nghi_van="NV2", sau_sua=[(x["dong"], x["ham"], x["strict"]) for x in sites],
                dat=sorted((x["ham"], x["strict"]) for x in sites) == [("json.dump", False), ("json.dump", True)]))
tmp = tempfile.mkdtemp(prefix="nv3moi_")
try:
    for d in n.CAY_HOI_QUY:
        shutil.copytree(os.path.join(G_MOI, d), os.path.join(tmp, d), ignore=shutil.ignore_patterns("__pycache__"))
    for d in [x for x in os.listdir(G_MOI) if x.startswith("src0")]:
        os.symlink(os.path.join(G_MOI, d), os.path.join(tmp, d))
    os.makedirs(os.path.join(tmp, "ket_qua_stage3"))
    shutil.copy(os.path.join(G_MOI, "ket_qua_stage3", "ket_qua_kiem_thu.json"), os.path.join(tmp, "ket_qua_stage3"))   # output CŨ cài sẵn
    open(os.path.join(tmp, "shadow_eval", "kiem_thu_stage3.py"), "w").write("import sys\nsys.exit(3)\n")
    G0 = n.G; n.G = tmp
    n.t_reg(); r3 = n.KQ[-1]; n.G = G0
    SAU.append(dict(nghi_van="NV3", sau_sua=dict(status=r3["status"], actual=str(r3["actual"])[:200]), dat=r3["status"] == "FAIL" and "không tạo output" in str(r3["actual"])))
finally:
    shutil.rmtree(tmp, ignore_errors=True)
tmp = tempfile.mkdtemp(prefix="nv4moi_")
try:
    for x in os.listdir(os.path.join(G_MOI, "shadow_eval")):
        if x.endswith(".py"):
            shutil.copy(os.path.join(G_MOI, "shadow_eval", x), tmp)
    s_ = open(os.path.join(tmp, "mo_phong_lenh.py"), encoding="utf-8").read()
    open(os.path.join(tmp, "mo_phong_lenh.py"), "w", encoding="utf-8").write("import mo_dun_khong_ton_tai_xyz\n" + s_)
    rc, r, tail = n._chay_gate(tmp, tempfile.mkdtemp())
    pl = n._phan_loai(rc, r, ["KD-GOLD-EXTRA"])[0]
    SAU.append(dict(nghi_van="NV4", sau_sua=dict(rc=rc, phan_loai=pl), dat=pl == "ENV_ERROR"))
finally:
    shutil.rmtree(tmp, ignore_errors=True)
for x in SAU:
    print(f"[SAU SỬA {'ĐẠT' if x['dat'] else 'KHÔNG ĐẠT'}] {x['nghi_van']}: {json.dumps(x['sau_sua'], ensure_ascii=False)[:220]}")
json.dump(dict(truoc_sua_runner_R2=KQ, sau_sua_runner_moi=SAU), open(os.path.join(OUT, "tai_hien_nghi_van.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False)
