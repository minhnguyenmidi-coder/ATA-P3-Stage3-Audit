# -*- coding: utf-8 -*-
"""Đóng gói ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION. Chạy SAU khi mọi test kết thúc.
1) kiểm trước đóng gói (baseline, file bắt buộc, file rỗng, tham chiếu, trùng, nhất quán báo cáo ↔ JSON) → MANIFEST_VALIDATION.txt
2) manifest SHA-256 tính trực tiếp (không tự liệt kê) → ZIP
3) giải nén vào thư mục tạm, sha256sum -c, so tập file → log hậu kiểm (file riêng cạnh ZIP)."""
import hashlib, json, os, re, shutil, subprocess, sys, tempfile, zipfile, datetime as dt
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs"
TEN = "ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION"
MAN = "BAN_GIAO_R3/ATA_P3_STAGE3_R3_MANIFEST_SHA256.txt"
VAL = "BAN_GIAO_R3/ATA_P3_STAGE3_R3_MANIFEST_VALIDATION.txt"
THU_MUC = ["BAN_GIAO_R3", "kiem_toan_r3", "kiem_doc_lap", "shadow_eval", "token_budget", "kiem_toan_stage3", "ket_qua_stage3", "ket_qua_shadow_eval", "BAN_GIAO_STAGE3C",
           "BAN_GIAO_STAGE3B", "kiem_toan034a", "kiem_toan035", "kiem_toan039", "cong_tien_md6", "ket_qua039"]
BAT_BUOC = ["ATA_P3_STAGE3_R3_REMEDIATION_REPORT.md", "ATA_P3_STAGE3_R3_FINDINGS_MATRIX.csv", "ATA_P3_STAGE3_R3_TEST_MATRIX.csv", "ATA_P3_STAGE3_R3_REPRO_F26.md",
            "ATA_P3_STAGE3_R3_REPRO_F28.md", "ATA_P3_STAGE3_R3_REPRO_F29.md", "ATA_P3_STAGE3_R3_REPRO_F32.md", "ATA_P3_STAGE3_R3_REGRESSION_REPORT.md",
            "ATA_P3_STAGE3_R3_MUTATION_REPORT.md", "ATA_P3_STAGE3_R3_STRICT_JSON_REPORT.md", "ATA_P3_STAGE3_R3_METRICS_REPORT.md", "ATA_P3_STAGE3_R3_FUNNEL_REPORT.md",
            "ATA_P3_STAGE3_R3_BOOTSTRAP_REPORT.md", "ATA_P3_STAGE3_R3_BASELINE_HASHES.txt", "ATA_P3_STAGE3_R3_SOURCE_HASHES.txt", "ATA_P3_STAGE3_R3_DIFF.patch",
            "ATA_P3_STAGE3_R3_FILE_KHONG_SUA.txt", "ATA_P3_STAGE3_R3_TEST_KHONG_CHAY.md", "ATA_P3_STAGE3_R3_BLOCKED.md", "ATA_P3_STAGE3_R3_NOT_TESTED.md",
            "ATA_P3_STAGE3_R3_LOI_CON_TON_TAI.md", "ATA_P3_STAGE3_R3_OWNER_DECISIONS.md", "ATA_P3_STAGE3_ORACLE_INDEPENDENCE.md",
            "ATA_P3_STAGE3_R3_TAI_HIEN_NGHI_VAN.md"]
LOG = ["kiem_toan_r3/log/chay_day_du.log", "kiem_toan_r3/log/chay_nhanh.log", "kiem_toan_r3/ket_qua/log_dot_bien_nguon.txt", "kiem_toan_r3/ket_qua/hoi_quy/stdout_kiem_thu_stage3.log",
       "kiem_toan_r3/log/reg039_stdout.txt", "kiem_toan_r3/log/baseline_truoc_sua_full.log", "kiem_toan_r3/log/tai_hien_nghi_van.log"]
SHA = {"src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine": "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13",
       "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine": "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"}


def sha(p):
    return hashlib.sha256(open(os.path.join(G, p), "rb").read()).hexdigest()


def ds():
    out = []
    for d in THU_MUC:
        for root, dirs, files in os.walk(os.path.join(G, d)):
            dirs[:] = sorted(x for x in dirs if x != "__pycache__")
            out += [os.path.relpath(os.path.join(root, f), G) for f in sorted(files) if not f.endswith(".pyc") and not f.startswith("_tam_")]
    for d in sorted(x for x in os.listdir(G) if x.startswith("src0") and os.path.isdir(os.path.join(G, x))):
        out += [f"{d}/{f}" for f in sorted(os.listdir(os.path.join(G, d))) if f.endswith(".pine")]
    return sorted(set(out) - {MAN})


def kiem_truoc(files):
    L, ok = [f"KIỂM MANIFEST TRƯỚC ĐÓNG GÓI – {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}", f"Số file trong phạm vi: {len(files)}"], True
    for f, h in SHA.items():
        c = sha(f) == h; ok &= c; L.append(f"baseline {f}: {'KHỚP' if c else 'SAI'} {sha(f)}")
    for f in BAT_BUOC:
        p = os.path.join("BAN_GIAO_R3", f) if not f.startswith("ATA_P3_STAGE3_ORACLE") else os.path.join("BAN_GIAO_R3", f)
        c = os.path.exists(os.path.join(G, p)) and os.path.getsize(os.path.join(G, p)) > 0; ok &= c; L.append(f"bắt buộc {'OK ' if c else 'THIẾU/RỖNG'} {p}")
    for f in LOG:
        c = os.path.exists(os.path.join(G, f)) and os.path.getsize(os.path.join(G, f)) > 0; ok &= c; L.append(f"log {'OK ' if c else 'THIẾU/RỖNG'} {f}")
    rong = [f for f in files if os.path.getsize(os.path.join(G, f)) == 0]
    rong_xau = [f for f in rong if f.startswith(("BAN_GIAO_R3", "kiem_doc_lap", "kiem_toan_r3"))]
    ok &= not rong_xau; L.append(f"file rỗng: {rong or 'không'} (trong phạm vi vòng 3: {rong_xau or 'không'})")
    thieu = []
    for f in [x for x in files if x.startswith("BAN_GIAO_R3/") and x.endswith(".md")]:
        for m in re.findall(r"`((?:shadow_eval|kiem_doc_lap|kiem_toan_r3|kiem_toan_stage3|ket_qua_stage3|token_budget)/[^`\s]+)`", open(os.path.join(G, f), encoding="utf-8").read()):
            if not os.path.exists(os.path.join(G, m)):
                thieu.append((f, m))
    ok &= not thieu; L.append(f"tham chiếu đường dẫn bị thiếu: {thieu or 'không'}")
    nhom = {}
    for f in files:
        nhom.setdefault(sha(f), []).append(f)
    L.append(f"nhóm trùng nội dung (thông tin): {sum(1 for v in nhom.values() if len(v) > 1)}")
    L += [f"   {v}" for v in nhom.values() if len(v) > 1][:30]
    R = json.load(open(os.path.join(G, "kiem_toan_r3", "ket_qua", "ket_qua_doc_lap.json"), encoding="utf-8"))
    bc = open(os.path.join(G, "BAN_GIAO_R3", "ATA_P3_STAGE3_R3_REMEDIATION_REPORT.md"), encoding="utf-8").read()
    c = json.dumps(R["tom_tat"], ensure_ascii=False, allow_nan=False) in bc and str(R["so_assertion"]) in bc
    ok &= c; L.append(f"nhất quán báo cáo ↔ JSON (tóm tắt + số assertion): {'KHỚP' if c else 'LỆCH'}")
    c = R["che_do"] == "day_du" and R["tom_tat"].get("FAIL", 0) == 0
    ok &= c; L.append(f"kết quả đầy đủ không FAIL: {'ĐÚNG' if c else 'SAI'} {R['tom_tat']}")
    L.append("KẾT LUẬN: ĐẠT" if ok else "KẾT LUẬN: KHÔNG ĐẠT")
    return ok, "\n".join(L) + "\n"


def main():
    os.makedirs(OUT, exist_ok=True)
    files = ds()
    ok, log = kiem_truoc(files)
    open(os.path.join(G, VAL), "w", encoding="utf-8").write(log); print(log)
    if not ok:
        sys.exit(2)
    files = ds()
    man = "".join(f"{sha(f)}  ./{f}\n" for f in files)
    open(os.path.join(G, MAN), "w", encoding="utf-8").write(man)
    pz = os.path.join(OUT, TEN + ".zip")
    with zipfile.ZipFile(pz, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(os.path.join(G, f), f)
        z.write(os.path.join(G, MAN), MAN)
    hz = hashlib.sha256(open(pz, "rb").read()).hexdigest()
    tmp = tempfile.mkdtemp(prefix="kd_goi_")
    try:
        zipfile.ZipFile(pz).extractall(tmp)
        # manifest dùng đường dẫn './…' tương đối gốc gói → kiểm từ gốc
        p = subprocess.run(["sha256sum", "-c", "--quiet", MAN], cwd=tmp, capture_output=True, text=True)
        co = set()
        for root, _, fs in os.walk(tmp):
            co |= {os.path.relpath(os.path.join(root, f), tmp) for f in fs}
        ngoai = co - set(files) - {MAN}; thieu = set(files) - co
        post = [f"HẬU KIỂM GÓI – {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}", f"ZIP: {pz}", f"SHA-256 ZIP: {hz}", f"file trong manifest: {len(files)}",
                f"sha256sum -c: {'MỌI FILE KHỚP' if p.returncode == 0 else 'LỆCH: ' + p.stdout[-500:]}", f"file ngoài manifest: {sorted(ngoai) or 'không'}", f"file thiếu: {sorted(thieu) or 'không'}",
                f"baseline trong gói: " + ", ".join(f"{k} {'KHỚP' if hashlib.sha256(open(os.path.join(tmp, k), 'rb').read()).hexdigest() == v else 'SAI'}" for k, v in SHA.items()),
                "KẾT LUẬN: ĐẠT" if p.returncode == 0 and not ngoai and not thieu else "KẾT LUẬN: KHÔNG ĐẠT"]
        open(os.path.join(OUT, TEN + "_HAU_KIEM.txt"), "w", encoding="utf-8").write("\n".join(post) + "\n")
        print("\n".join(post))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
