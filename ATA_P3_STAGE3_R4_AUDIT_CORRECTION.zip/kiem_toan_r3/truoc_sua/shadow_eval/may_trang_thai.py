# -*- coding: utf-8 -*-
"""MÁY TRẠNG THÁI Shadow Evaluation (ngoài Pine). Bảng chuyển tiếp TƯỜNG MINH, suy từ mã 0.3.9 (dẫn dòng) – không thêm trạng thái mới.

A. VÒNG ĐỜI THỂ HIỆN (EVENTS theo setup_id)
   Trạng thái engine: st 0 (bước 1 xong) → st 1 (SU-3: MSS H1 bước 2, dòng 2834 · SU-5: rời mức bước 2, dòng 3559) → st 2 (ARMED: SU-3 dòng 3556, SU-5 dòng 3563; sự kiện dòng 3569).
   Sự kiện: CREATED (thể hiện mới, SH.new dòng 2851/2865) · STEP (st 0→1) · ARMED (evS SS_WAIT, dòng 3569) · TRIGGER (f_shS1, dòng 3592; trạng thái
   17 nếu đạt, 4/8 nếu bị bỏ) · VOID (6: vùng/neo vô hiệu dòng 2828/2832/2821/3552; 5: P4 dòng 3575) · EXPIRED (7: dòng 2823/2839/2843/3595) ·
   SKIP (4: SU-5 gap bước 3, dòng 3565) · END_NO_EVENT (SU-3 bước 3 không có vùng, IP-20, dòng 3550).
   Chuyển tiếp hợp lệ:
     (bắt đầu)    → CREATED
     CREATED      → STEP, VOID, EXPIRED
     STEP         → ARMED, VOID, EXPIRED, SKIP (chỉ SU-5), END_NO_EVENT (chỉ SU-3)
     ARMED        → TRIGGER, VOID, EXPIRED
     TRIGGER, VOID, EXPIRED, SKIP, END_NO_EVENT: KẾT THÚC (không có sự kiện nào sau).
   Không hợp lệ (ví dụ): CREATED → ARMED (bỏ qua st 1), STEP → STEP (chỉ có một bước trung gian), CREATED → TRIGGER, mọi sự kiện sau kết thúc.

B. VÒNG ĐỜI LỆNH (một TRADE cho một SIGNAL đạt S1 = reason 16, theo một sim_rule)
     SIGNAL(16) → INVALID                         (tín hiệu hỏng – không vào)
     SIGNAL(16) → NO_DATA [NO_NEXT_BAR | INVALID_BAR]   (thiếu/hỏng dữ liệu TRƯỚC khi vào)
     SIGNAL(16) → NO_FILL [GAP_BEYOND_SL | GAP_BEYOND_TP] (chỉ R2)
     SIGNAL(16) → FILL → OPEN | TP1 | SL | TIMEOUT | NO_DATA [INVALID_BAR_AFTER_FILL | NON_MONOTONIC_TIME_AFTER_FILL]
   Quy tắc: không vào trước nến trigger (R1 vào tại nến trigger, giá Close; R2 tại nến kế, giá Open); không thoát trước khi vào; OPEN không có thoát;
   TP1/SL/TIMEOUT là lệnh ĐÓNG có thoát; NO_FILL/INVALID/NO_DATA-trước-vào không có giá vào thực (R1 INVALID giữ P_ref để tham chiếu)."""

BAT_DAU = "(bắt đầu)"
KET_THUC = ("TRIGGER", "VOID", "EXPIRED", "SKIP", "END_NO_EVENT")
CHUYEN = {BAT_DAU: {"CREATED"}, "CREATED": {"STEP", "VOID", "EXPIRED"}, "STEP": {"ARMED", "VOID", "EXPIRED", "SKIP", "END_NO_EVENT"},
          "ARMED": {"TRIGGER", "VOID", "EXPIRED"}}
CHI_SETUP = {"SKIP": "SU5", "END_NO_EVENT": "SU3"}

LENH_DONG = ("TP1", "SL", "TIMEOUT")
NOTE_TRUOC_VAO = {"INVALID": {"INVALID_SIGNAL", "INVALID_RISK", "TP_WRONG_SIDE"}, "NO_DATA": {"NO_NEXT_BAR", "INVALID_BAR"},
                  "NO_FILL": {"GAP_BEYOND_SL", "GAP_BEYOND_TP"}}
NOTE_SAU_VAO = {"INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_TIME_AFTER_FILL"}


def kiem_vong_doi(events):
    """events: list bản ghi EVENTS (mọi setup_id). Trả danh sách lỗi chuyển tiếp."""
    loi, theo = [], {}
    for e in sorted(events, key=lambda r: r["emit_seq"]):
        theo.setdefault(e["setup_id"], []).append(e)
    for sid, es in theo.items():
        cu = BAT_DAU
        for e in es:
            et = e["event_type"]
            if cu in KET_THUC:
                loi.append(f"{sid}: {et} sau sự kiện kết thúc {cu}"); break
            if et not in CHUYEN.get(cu, set()):
                loi.append(f"{sid}: chuyển tiếp không hợp lệ {cu} → {et}"); break
            if et in CHI_SETUP and e["setup"] != CHI_SETUP[et]:
                loi.append(f"{sid}: {et} chỉ hợp lệ cho {CHI_SETUP[et]}"); break
            cu = et
    return loi


def kiem_lenh(t, s, rule):
    """Một TRADE t với SIGNAL s theo quy tắc vào 'close' (R1) hoặc 'next_open' (R2). Trả danh sách lỗi vòng đời lệnh."""
    loi, o, nt = [], t["outcome"], t.get("fill_note")
    if s["reason"] != 16:
        loi.append("lệnh cho tín hiệu không đạt S1")
    if o in NOTE_TRUOC_VAO:
        if nt in NOTE_TRUOC_VAO[o]:
            if o == "NO_FILL" and rule != "next_open":
                loi.append("NO_FILL chỉ có ở R2")
        elif not (o == "NO_DATA" and nt in NOTE_SAU_VAO):
            loi.append(f"{o} với fill_note {nt} không thuộc vòng đời")
    vao = o in LENH_DONG + ("OPEN",) or (o == "NO_DATA" and nt in NOTE_SAU_VAO)
    if vao:
        if t.get("entry_price") is None:
            loi.append("đã vào nhưng thiếu entry_price")
        if rule == "close" and t["entry_ts_ms"] != s["trigger_ts_ms"]:
            loi.append("R1 phải vào tại nến trigger")
        if rule == "next_open" and t["entry_ts_ms"] <= s["trigger_ts_ms"]:
            loi.append("R2 phải vào sau nến trigger (không vào trước/tại trigger)")
    if o == "NO_FILL" and t["entry_ts_ms"] <= s["trigger_ts_ms"]:
        loi.append("NO_FILL phải ở nến sau trigger")
    if o in LENH_DONG and (t.get("exit_ts_ms") is None or t["exit_ts_ms"] < t["entry_ts_ms"]):
        loi.append("lệnh đóng phải có thoát không sớm hơn vào")
    if o not in LENH_DONG and t.get("exit_ts_ms") is not None:
        loi.append(f"{o} không được có thoát")
    return loi
