# -*- coding: utf-8 -*-
"""BỘ KIỂM THỬ STAGE 3 – AUDIT CORRECTION (ngoài Pine). python3 shadow_eval/kiem_thu_stage3.py → ket_qua_stage3/ket_qua_kiem_thu.json (+ .csv)
Mỗi test ghi: test_id, nhóm, mục tiêu, input, expected, actual, status, evidence, test_source, version (SHA module), run_time, duration_ms, hash.
Trạng thái: PASS / FAIL / BLOCKED / NOT TESTED (đếm riêng). Có FAIL → mã thoát 1. Dữ liệu SYNTH chỉ kiểm cơ chế, KHÔNG đánh giá hiệu quả chiến lược."""
import copy, csv, datetime as dt, hashlib, importlib.util, inspect, io, json, math, os, random, subprocess, sys, time
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D); sys.path.insert(0, os.path.join(G, "token_budget"))
import hop_dong as HD, mo_phong_lenh as MP, chi_so as CS, du_lieu as DL, chuan_hoa as CH, pipeline as PL   # noqa: E402
import cong_token as TG   # noqa: E402

OUT = os.path.join(G, "ket_qua_stage3"); os.makedirs(OUT, exist_ok=True)
KQ = []
SHA38 = "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13"
SHA39 = "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"
P38 = os.path.join(G, "src038", "ATA_P3_Build_0.3.8_Candidate_Indicator.pine")
P39 = os.path.join(G, "src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine")


def sha_f(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


VER = {m: sha_f(os.path.join(D, m + ".py"))[:12] for m in ("hop_dong", "mo_phong_lenh", "chi_so", "du_lieu", "chuan_hoa", "pipeline")}
VER["cong_token"] = sha_f(os.path.join(G, "token_budget", "cong_token.py"))[:12]
VER["kiem_thu_stage3"] = sha_f(os.path.abspath(__file__))[:12]


def T(tid, nhom, muc_tieu, modules, inp, kv):
    """Bộ trang trí: hàm test trả (ok, actual) hoặc (status_str, actual)."""
    def wrap(fn):
        def run():
            t0 = time.time(); start = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            try:
                ok, act = fn()
                st = ok if isinstance(ok, str) else ("PASS" if ok else "FAIL")
            except Exception as ex:      # noqa: BLE001
                st, act = "FAIL", f"NGOẠI LỆ: {ex!r}"
            src = f"shadow_eval/kiem_thu_stage3.py::{fn.__name__} (dòng {inspect.getsourcelines(fn)[1]})"
            r = dict(test_id=tid, nhom=nhom, muc_tieu=muc_tieu, input=inp, expected=kv, actual=act, status=st, evidence=f"ket_qua_stage3/ket_qua_kiem_thu.json#{tid}",
                     test_source=src, version={m: VER[m] for m in modules}, run_time=start, duration_ms=round((time.time() - t0) * 1000, 1))
            r["hash"] = hashlib.sha256(json.dumps([inp, kv, act, st], ensure_ascii=False, default=str, sort_keys=True).encode()).hexdigest()[:16]
            KQ.append(r); print(f"[{st:10}] {tid} – {muc_tieu[:100]}")
            return st, act
        run.tid, run.fn = tid, fn
        TESTS.append(run)
        return run
    return wrap


TESTS = []


def B(rows, t0=60000 * 1000000, step=300000):
    return [dict(t=t0 + step * i, o=float(o), h=float(h), l=float(l), c=float(c)) for i, (o, h, l, c) in enumerate(rows)]


def gan(a, b, e=1e-9):
    return a is not None and b is not None and abs(a - b) < e


def ngau_nhien(R, n=60, p=2000.0, gap=False):
    rows = [(p, p + 1, p - 1, p)]
    for _ in range(n):
        o = p + (R.choice((0, 0, 0, R.gauss(0, 3))) if gap else 0)
        c = round(o + R.gauss(0, 2), 2)
        rows.append((round(o, 2), round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
    return B(rows)


def mirror(bars, p=4000.0):
    return [dict(t=b["t"], o=p - b["o"], h=p - b["l"], l=p - b["h"], c=p - b["c"]) for b in bars]


TR_BASE = dict(schema_version="1.1", signal_id="s", sim_rule="R-close-sl_first-288", cost_model="C-0")


def as_trade(t, sig_id="s"):
    return dict(TR_BASE, signal_id=sig_id, **{k: v for k, v in t.items()})


S0 = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
NUL = ("risk", "r_gross", "r_net", "mfe_r", "mae_r", "exit_ts_ms", "exit_price")

# ================================================================================================ R1 / R2


@T("R1R2-01", "Giả lập R1/R2", "R1 BUY chạm TP1: vào Close nến trigger, thoát TP1, R = 2,0; SELL ảnh gương cho kết quả y hệt", ["mo_phong_lenh"],
   "E 2000, SL 1995, TP1 2010; nến 2 High 2011", "TP1, R 2,0, MFE 2,0, MAE −0,2, giữ 2 nến; SELL giống")
def t_r1_tp():
    b = B([(1999, 2001, 1998, 2000), (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)])
    a = MP.mo_phong(S0, b, 0); m = MP.mo_phong(dict(dir=-1, p_ref=2000.0, sl=2005.0, tp1=1990.0), mirror(b), 0)
    ok = a["outcome"] == "TP1" and gan(a["r_gross"], 2) and gan(a["mfe_r"], 2) and gan(a["mae_r"], -0.2) and a["bars_held"] == 2
    ok = ok and all(gan(a[k], m[k]) for k in ("r_gross", "mfe_r", "mae_r")) and m["outcome"] == "TP1"
    return ok, {k: a[k] for k in ("outcome", "r_gross", "mfe_r", "mae_r", "bars_held")}


@T("R1R2-02", "Giả lập R1/R2", "R2: Open nến kế VƯỢT SL (và đúng bằng SL) → NO_FILL GAP_BEYOND_SL; risk/R/MFE/MAE/exit = null", ["mo_phong_lenh"],
   "Open 1994 (< SL 1995) và Open 1995", "NO_FILL GAP_BEYOND_SL ×2, các trường số = null")
def t_r2_sl():
    r = [MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (o, o + 1, o - 1, o)]), 0, MP.Cfg(entry="next_open")) for o in (1994, 1995)]
    return all(x["outcome"] == "NO_FILL" and x["fill_note"] == "GAP_BEYOND_SL" and all(x[k] is None for k in NUL) and x["bars_held"] == 0 for x in r), [(x["outcome"], x["fill_note"], x["risk"]) for x in r]


@T("R1R2-03", "Giả lập R1/R2", "R2: Open nến kế ĐÃ ĐẠT/VƯỢT TP1 → NO_FILL GAP_BEYOND_TP (bản cũ ra TP1 với R âm – F4)", ["mo_phong_lenh"],
   "Open 2015 và Open 2010 (TP1 2010)", "NO_FILL GAP_BEYOND_TP ×2")
def t_r2_tp():
    r = [MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (o, o + 1, o - 1, o), (o, o + 1, o - 1, o)]), 0, MP.Cfg(entry="next_open")) for o in (2015, 2010)]
    return all(x["outcome"] == "NO_FILL" and x["fill_note"] == "GAP_BEYOND_TP" and x["risk"] is None for x in r), [(x["outcome"], x["fill_note"]) for x in r]


@T("R1R2-04", "Giả lập R1/R2", "R2: Open nằm GIỮA P_ref và SL → khớp tại Open, rủi ro = Open − SL (nhỏ hơn), R tính theo rủi ro mới", ["mo_phong_lenh"],
   "Open 1997 (SL 1995), sau đó chạm TP1 2010", "TP1, risk 2, R = 13/2 = 6,5")
def t_r2_giua():
    r = MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (1997, 1998, 1996, 1997.5), (1997.5, 2011, 1997, 2009)]), 0, MP.Cfg(entry="next_open"))
    return r["outcome"] == "TP1" and gan(r["risk"], 2.0) and gan(r["r_gross"], 6.5) and r["entry_price"] == 1997, {k: r[k] for k in ("outcome", "risk", "r_gross", "entry_price", "bars_held")}


@T("R1R2-05", "Giả lập R1/R2", "TP1 = null: không bao giờ ra TP1 (R1 và R2); kết thúc SL / TIMEOUT / OPEN", ["mo_phong_lenh"],
   "TP1 null, giá tăng mạnh rồi giảm chạm SL; và đường đi ngang", "SL; TIMEOUT; OPEN – không có TP1")
def t_tp_none():
    s = dict(S0, tp1=None)
    a = MP.mo_phong(s, B([(2000, 2001, 1999, 2000), (2000, 2050, 1999, 2040), (2040, 2041, 1990, 1992)]), 0)
    b = MP.mo_phong(s, B([(2000, 2001, 1999, 2000)] + [(2000, 2030, 1999, 2001)] * 4), 0, MP.Cfg(max_bars=3))
    c = MP.mo_phong(s, B([(2000, 2001, 1999, 2000)] + [(2000, 2030, 1999, 2001)] * 2), 0, MP.Cfg(max_bars=3, entry="next_open"))
    return (a["outcome"], b["outcome"], c["outcome"]) == ("SL", "TIMEOUT", "OPEN"), (a["outcome"], b["outcome"], c["outcome"], a["mfe_r"])


@T("R1R2-06", "Giả lập R1/R2", "R2 không có nến kế → NO_DATA NO_NEXT_BAR (thiếu dữ liệu, KHÔNG gộp với NO_FILL – F6)", ["mo_phong_lenh"], "trigger ở nến cuối", "NO_DATA NO_NEXT_BAR")
def t_r2_nonext():
    r = MP.mo_phong(S0, B([(1999, 2001, 1998, 2000)]), 0, MP.Cfg(entry="next_open"))
    return r["outcome"] == "NO_DATA" and r["fill_note"] == "NO_NEXT_BAR" and r["risk"] is None, (r["outcome"], r["fill_note"])


@T("R1R2-07", "Giả lập R1/R2", "Rủi ro không hợp lệ (SL sai phía, SL = P_ref) → INVALID INVALID_RISK, risk = null (bản cũ: NO_FILL với risk giả – F5)", ["mo_phong_lenh"],
   "BUY SL 2001 > P_ref 2000; SL = 2000; SELL SL 1999 < P_ref", "INVALID INVALID_RISK ×3")
def t_invalid_risk():
    b = B([(2000, 2001, 1999, 2000), (2000, 2001, 1999, 2000)])
    r = [MP.mo_phong(dict(S0, sl=2001.0), b, 0), MP.mo_phong(dict(S0, sl=2000.0), b, 0), MP.mo_phong(dict(dir=-1, p_ref=2000.0, sl=1999.0, tp1=1990.0), b, 0, MP.Cfg(entry="next_open"))]
    return all(x["outcome"] == "INVALID" and x["fill_note"] == "INVALID_RISK" and x["risk"] is None for x in r), [(x["outcome"], x["fill_note"]) for x in r]


@T("R1R2-08", "Giả lập R1/R2", "Tín hiệu hỏng (dir 0, SL NaN, P_ref ∞, TP1 sai phía) → INVALID với lý do; không ngoại lệ", ["mo_phong_lenh"],
   "4 tín hiệu hỏng", "INVALID_SIGNAL ×3, TP_WRONG_SIDE ×1")
def t_invalid_sig():
    b = B([(2000, 2001, 1999, 2000), (2000, 2001, 1999, 2000)])
    r = [MP.mo_phong(dict(S0, dir=0), b, 0), MP.mo_phong(dict(S0, sl=float("nan")), b, 0), MP.mo_phong(dict(S0, p_ref=float("inf")), b, 0), MP.mo_phong(dict(S0, tp1=1990.0), b, 0)]
    return [x["fill_note"] for x in r] == ["INVALID_SIGNAL"] * 3 + ["TP_WRONG_SIDE"] and all(x["outcome"] == "INVALID" for x in r), [x["fill_note"] for x in r]


@T("R1R2-09", "Giả lập R1/R2", "R2: nến vào được đánh giá High/Low sau Open – chạm TP1 ngay nến vào → TP1, giữ 1 nến", ["mo_phong_lenh"], "Open 2001, High 2011", "TP1, bars_held 1")
def t_r2_entrybar():
    r = MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (2001, 2011, 2000, 2008)]), 0, MP.Cfg(entry="next_open"))
    return r["outcome"] == "TP1" and r["bars_held"] == 1 and not r["gap_exit"], {k: r[k] for k in ("outcome", "bars_held", "r_gross")}


@T("R1R2-10", "Giả lập R1/R2", "R1: Open nến đầu tiên sau trigger đã vượt SL → thoát tại Open (R < −1), gap_exit; vượt TP1 → thoát tại Open (R > R_TP1)", ["mo_phong_lenh"],
   "Open 1990 / 2015", "SL R −2,0; TP1 R +3,0")
def t_r1_gap():
    a = MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (1990, 1992, 1988, 1991)]), 0)
    b = MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (2015, 2016, 2014, 2015)]), 0)
    return a["outcome"] == "SL" and gan(a["r_gross"], -2) and a["gap_exit"] and b["outcome"] == "TP1" and gan(b["r_gross"], 3) and b["gap_exit"], ((a["outcome"], a["r_gross"]), (b["outcome"], b["r_gross"]))

# ================================================================================================ OPEN / TIMEOUT
FLAT = (2000, 2001, 1999, 2000.5)


@T("OT-01", "OPEN/TIMEOUT", "Biên max_bars: chạm TP1 đúng ở nến thứ max_bars → TP1 (giữ = max_bars); chạm ở nến max_bars+1 → TIMEOUT tại nến max_bars", ["mo_phong_lenh"],
   "max_bars 5; TP1 ở nến 5 / nến 6", "TP1 giữ 5; TIMEOUT giữ 5, R = 0,1")
def t_ot_edge():
    hit = (2000, 2011, 1999, 2005)
    a = MP.mo_phong(S0, B([FLAT] + [FLAT] * 4 + [hit] + [FLAT] * 3), 0, MP.Cfg(max_bars=5))
    b = MP.mo_phong(S0, B([FLAT] + [FLAT] * 5 + [hit] + [FLAT] * 3), 0, MP.Cfg(max_bars=5))
    return a["outcome"] == "TP1" and a["bars_held"] == 5 and b["outcome"] == "TIMEOUT" and b["bars_held"] == 5 and gan(b["r_gross"], 0.1), ((a["outcome"], a["bars_held"]), (b["outcome"], b["bars_held"], b["r_gross"]))


@T("OT-02", "OPEN/TIMEOUT", "Dữ liệu sau trigger có đúng max_bars nến → TIMEOUT; max_bars − 1 nến → OPEN (giữ max_bars − 1, exit = null); max_bars + 1 → TIMEOUT", ["mo_phong_lenh"],
   "max_bars 4; 4 / 3 / 5 nến sau trigger", "TIMEOUT / OPEN / TIMEOUT")
def t_ot_count():
    r = [MP.mo_phong(S0, B([FLAT] * (1 + n)), 0, MP.Cfg(max_bars=4)) for n in (4, 3, 5)]
    ok = [x["outcome"] for x in r] == ["TIMEOUT", "OPEN", "TIMEOUT"] and r[1]["bars_held"] == 3 and r[1]["exit_ts_ms"] is None and r[0]["bars_held"] == 4 == r[2]["bars_held"]
    return ok, [(x["outcome"], x["bars_held"]) for x in r]


@T("OT-03", "OPEN/TIMEOUT", "Trigger ở nến cuối (R1) → OPEN, giữ 0, R = 0; 1 nến sau với max_bars 1 → TIMEOUT; với max_bars 2 → OPEN", ["mo_phong_lenh"],
   "0 / 1 / 1 nến sau trigger", "OPEN 0; TIMEOUT 1; OPEN 1")
def t_ot_last():
    a = MP.mo_phong(S0, B([FLAT]), 0)
    b = MP.mo_phong(S0, B([FLAT, FLAT]), 0, MP.Cfg(max_bars=1)); c = MP.mo_phong(S0, B([FLAT, FLAT]), 0, MP.Cfg(max_bars=2))
    ok = a["outcome"] == "OPEN" and a["bars_held"] == 0 and gan(a["r_gross"], 0) and b["outcome"] == "TIMEOUT" and b["bars_held"] == 1 and c["outcome"] == "OPEN" and c["bars_held"] == 1
    return ok, [(x["outcome"], x["bars_held"]) for x in (a, b, c)]


@T("OT-04", "OPEN/TIMEOUT", "Thiếu nến (khoảng trống thời gian) KHÁC gap giá: khoảng trống thời gian → đếm time_gaps, max_gap_ms, KHÔNG đổi kết cục; gap giá không có khoảng thời gian → gap_exit, time_gaps 0", ["mo_phong_lenh"],
   "nến 3 cách nến 2 thêm 10 giờ (giá liền mạch); và gap giá Open 1990 không thiếu nến", "kết cục như đường liền; time_gaps 1; gap giá: time_gaps 0, gap_exit")
def t_ot_gap():
    rows = [FLAT, FLAT, FLAT, (2000, 2011, 1999, 2005)]
    b1 = B(rows); b2 = copy.deepcopy(b1)
    for x in b2[2:]:
        x["t"] += 36000000
    a, g = MP.mo_phong(S0, b1, 0), MP.mo_phong(S0, b2, 0)
    p = MP.mo_phong(S0, B([FLAT, (1990, 1992, 1988, 1991)]), 0)
    ok = a["outcome"] == g["outcome"] == "TP1" and a["bars_held"] == g["bars_held"] and a["time_gaps"] == 0 and g["time_gaps"] == 1 and g["max_gap_ms"] == 36300000 and p["gap_exit"] and p["time_gaps"] == 0
    return ok, dict(lien=(a["outcome"], a["time_gaps"]), khoang=(g["outcome"], g["time_gaps"], g["max_gap_ms"]), gap_gia=(p["gap_exit"], p["time_gaps"]))


@T("OT-05", "OPEN/TIMEOUT", "Nến hỏng TRONG cửa sổ (High < Low, giá NaN, giá ≤ 0) → NO_DATA INVALID_BAR; nến hỏng SAU nến thoát → không ảnh hưởng (F8)", ["mo_phong_lenh"],
   "3 kiểu nến hỏng ở nến 2; nến hỏng sau khi TP1", "NO_DATA ×3; TP1")
def t_ot_bad():
    hong = [(2000, 1990, 2010, 2001), (2000, float("nan"), 1999, 2000), (0, 2001, 0, 2000)]
    r = [MP.mo_phong(S0, B([FLAT, x]), 0) for x in hong]
    sau = MP.mo_phong(S0, B([FLAT, (2000, 2011, 1999, 2005), (2000, 1990, 2010, 2001)]), 0)
    return all(x["outcome"] == "NO_DATA" and x["fill_note"] == "INVALID_BAR" for x in r) and sau["outcome"] == "TP1", ([x["outcome"] for x in r], sau["outcome"])


@T("OT-06", "OPEN/TIMEOUT", "Thời gian trùng hoặc lùi trong cửa sổ → NO_DATA NON_MONOTONIC_TIME", ["mo_phong_lenh"], "nến 3 trùng thời gian nến 2; nến 3 lùi", "NO_DATA ×2")
def t_ot_mono():
    b1 = B([FLAT] * 4); b1[2]["t"] = b1[1]["t"]
    b2 = B([FLAT] * 4); b2[2]["t"] = b2[1]["t"] - 300000
    r = [MP.mo_phong(S0, b, 0) for b in (b1, b2)]
    return all(x["outcome"] == "NO_DATA" and x["fill_note"] == "NON_MONOTONIC_TIME" for x in r), [x["fill_note"] for x in r]

# ================================================================================================ MFE / MAE


@T("MM-01", "MFE/MAE", "Quy tắc nến thoát bảo thủ: thoát SL → phía có lợi của nến đó không tính, MAE = −1; thoát TP1 → MFE chặn tại TP1, phía bất lợi tính đủ", ["mo_phong_lenh"],
   "SL: nến thoát High 2008; TP1: nến thoát Low 1997", "SL: MFE 0,6 (từ nến trước), MAE −1; TP1: MFE 2,0, MAE −0,6")
def t_mm_rule():
    a = MP.mo_phong(S0, B([FLAT, (2000, 2003, 1999, 2001), (2001, 2008, 1994, 1996)]), 0)
    b = MP.mo_phong(S0, B([FLAT, (2000, 2002, 1999.5, 2001), (2001, 2012, 1997, 2010)]), 0)
    return a["outcome"] == "SL" and gan(a["mfe_r"], 0.6) and gan(a["mae_r"], -1) and b["outcome"] == "TP1" and gan(b["mfe_r"], 2) and gan(b["mae_r"], -0.6), ((a["mfe_r"], a["mae_r"]), (b["mfe_r"], b["mae_r"]))


@T("MM-02", "MFE/MAE", "Xung đột cùng nến (chạm cả SL và TP1): sl_first → SL, MFE không lấy nến đó; tp_first → TP1 nhưng MAE ≤ −1 vì giá đã chạm SL (bản cũ MAE = 0 – F3)", ["mo_phong_lenh"],
   "nến High 2012, Low 1994", "sl_first: SL, MFE 0, MAE −1,2? (chặn −1); tp_first: TP1, MFE 2, MAE −1,2")
def t_mm_conflict():
    b = B([FLAT, (2000, 2012, 1994, 2001)])
    a = MP.mo_phong(S0, b, 0); c = MP.mo_phong(S0, b, 0, MP.Cfg(same_bar="tp_first"))
    ok = a["outcome"] == "SL" and a["same_bar_conflict"] and gan(a["mfe_r"], 0) and gan(a["mae_r"], -1) and c["outcome"] == "TP1" and c["same_bar_conflict"] and gan(c["mfe_r"], 2) and gan(c["mae_r"], -1.2)
    return ok, dict(sl_first=(a["outcome"], a["mfe_r"], a["mae_r"]), tp_first=(c["outcome"], c["mfe_r"], c["mae_r"]))


def _thuoc_tinh(n, seed):
    R = random.Random(seed); sai = []
    for k in range(n):
        bs = ngau_nhien(R, 50, gap=True); d = R.choice((1, -1))
        s = dict(dir=d, p_ref=2000.0, sl=2000 - d * R.uniform(0.5, 6), tp1=(2000 + d * R.uniform(0.5, 12)) if R.random() < 0.85 else None)
        cfg = MP.Cfg(entry=R.choice(("close", "next_open")), same_bar=R.choice(("sl_first", "tp_first")), max_bars=R.choice((1, 2, 5, 20, 40)),
                     spread=R.choice((0, 0.2)), slippage=R.choice((0, 0.05)))
        a = MP.mo_phong(s, bs, 0, cfg)
        loi = HD.kiem(as_trade(dict(a, symbol="XAUUSD", setup="SU5")), HD.TRADES)
        if a["outcome"] in ("TP1", "SL", "TIMEOUT", "OPEN"):
            if not (a["mfe_r"] >= 0 >= a["mae_r"] and a["mae_r"] - 1e-9 <= a["r_gross"] <= a["mfe_r"] + 1e-9):
                loi.append("bất biến MFE/MAE")
            if a["outcome"] == "SL" and not a["gap_exit"] and not gan(a["r_gross"], -1):
                loi.append("SL ≠ −1")
        if s["tp1"] is None and a["outcome"] == "TP1":
            loi.append("TP1 khi tp1 null")
        if loi:
            sai.append((k, a["outcome"], loi[:2]))
    return sai


@T("MM-03", "MFE/MAE", "Thuộc tính trên 3.000 đường ngẫu nhiên (có gap, TP1 null, R1/R2, sl_first/tp_first, max_bars 1…40, chi phí): mọi bản ghi qua bộ kiểm TRADES; MFE ≥ 0 ≥ MAE; MAE ≤ R ≤ MFE; SL không gap = −1", ["mo_phong_lenh", "hop_dong"],
   "3.000 đường, seed 11", "0 vi phạm")
def t_mm_prop():
    sai = _thuoc_tinh(3000, 11)
    return not sai, dict(vi_pham=len(sai), mau=sai[:3])


@T("MM-04", "MFE/MAE", "Đối xứng BUY/SELL: 600 đường và ảnh gương (giá → 4000 − giá), R1 và R2 → cùng kết cục, R, MFE, MAE, thời gian giữ, ghi chú", ["mo_phong_lenh"], "600 cặp", "0 khác")
def t_mm_mirror():
    R = random.Random(5); sai = 0
    for k in range(600):
        bs = ngau_nhien(R, 40, gap=True)
        s = dict(dir=1, p_ref=2000.0, sl=round(2000 - R.uniform(1, 8), 2), tp1=round(2000 + R.uniform(1, 15), 2))
        sm = dict(dir=-1, p_ref=2000.0, sl=4000 - s["sl"], tp1=4000 - s["tp1"])
        cfg = MP.Cfg(max_bars=30, entry=("close", "next_open")[k % 2])
        a, b = MP.mo_phong(s, bs, 0, cfg), MP.mo_phong(sm, mirror(bs), 0, cfg)
        same = a["outcome"] == b["outcome"] and a["bars_held"] == b["bars_held"] and a["fill_note"] == b["fill_note"]
        for f in ("r_gross", "mfe_r", "mae_r"):
            same = same and ((a[f] is None and b[f] is None) or gan(a[f], b[f], 1e-7))
        sai += not same
    return sai == 0, f"khác {sai}"


@T("MM-05", "MFE/MAE", "Không nhìn trước: (a) High/Low nến trigger không dùng ở R1; (b) 400 đường: thay mọi nến SAU nến thoát bằng giá vô lý → kết quả y hệt", ["mo_phong_lenh"], "400 đường", "(a) TIMEOUT; (b) 0 khác")
def t_mm_lookahead():
    a = MP.mo_phong(S0, B([(1999, 2020, 1990, 2000)] + [FLAT] * 4), 0, MP.Cfg(max_bars=4))
    R = random.Random(3); sai = 0
    for _ in range(400):
        bs = ngau_nhien(R, 80); d = R.choice((1, -1))
        s = dict(dir=d, p_ref=2000.0, sl=2000 - d * R.uniform(2, 6), tp1=2000 + d * R.uniform(3, 12))
        x = MP.mo_phong(s, bs, 0, MP.Cfg(max_bars=60))
        if x["outcome"] in ("TP1", "SL", "TIMEOUT"):
            ke = next(i for i, b in enumerate(bs) if b["t"] == x["exit_ts_ms"])
            bs2 = bs[:ke + 1] + [dict(t=b["t"], o=9999.0, h=9999.0, l=1.0, c=5000.0) for b in bs[ke + 1:]]
            sai += MP.mo_phong(s, bs2, 0, MP.Cfg(max_bars=60)) != x
    return a["outcome"] == "TIMEOUT" and sai == 0, dict(a=a["outcome"], b_khac=sai)


@T("MM-06", "MFE/MAE", "Chi phí: r_net = r_gross − (spread + phí + 2×trượt giá)/rủi ro", ["mo_phong_lenh"], "spread 0,3, phí 0,1, trượt 0,05, rủi ro 5", "2,0 − 0,1 = 1,9")
def t_mm_cost():
    r = MP.mo_phong(S0, B([(1999, 2001, 1998, 2000), (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0, MP.Cfg(spread=0.3, commission=0.1, slippage=0.05))
    return gan(r["r_net"], 1.9), r["r_net"]

# ================================================================================================ LỌC DANH MỤC / KHỬ TRÙNG
def TRD(e, x, o="TP1", sym="XAUUSD", su="SU5", seq=0):
    return dict(symbol=sym, setup=su, entry_ts_ms=e, exit_ts_ms=x, outcome=o, emit_seq=seq)


@T("PF-01", "Lọc danh mục", "NO_FILL (exit null) KHÔNG chặn khóa (symbol, setup) – bản cũ chặn vĩnh viễn (F1)", ["mo_phong_lenh"], "NO_FILL@1, TP1@100→200, SL@300→400", "giữ cả 3, bỏ 0")
def t_pf_nofill():
    g, n = MP.khong_chong([TRD(1, None, "NO_FILL"), TRD(100, 200), TRD(300, 400, "SL")])
    return n == 0 and len(g) == 3, dict(giu=[(t["entry_ts_ms"], t["outcome"]) for t in g], bo=n)


@T("PF-02", "Lọc danh mục", "NO_DATA / INVALID không chiếm vị thế, vẫn có mặt trong đầu ra (để đếm)", ["mo_phong_lenh"], "NO_DATA@1, INVALID@2, TP1@3→9", "giữ 3, bỏ 0")
def t_pf_nodata():
    g, n = MP.khong_chong([TRD(1, None, "NO_DATA"), TRD(2, None, "INVALID"), TRD(3, 9)])
    return n == 0 and [t["outcome"] for t in g] == ["NO_DATA", "INVALID", "TP1"], ([t["outcome"] for t in g], n)


@T("PF-03", "Lọc danh mục", "OPEN chiếm vị thế tới hết dữ liệu → chặn mọi lệnh sau cùng khóa, không chặn khóa khác", ["mo_phong_lenh"], "OPEN@10; TP1@50 cùng khóa; TP1@50 SU3", "bỏ 1 (cùng khóa)")
def t_pf_open():
    g, n = MP.khong_chong([TRD(10, None, "OPEN"), TRD(50, 60), TRD(50, 60, su="SU3")])
    return n == 1 and [(t["setup"], t["entry_ts_ms"]) for t in g] == [("SU5", 10), ("SU3", 50)], ([(t["setup"], t["entry_ts_ms"]) for t in g], n)


@T("PF-04", "Lọc danh mục", "Biên thời gian: vào tại đúng thời điểm thoát của lệnh trước (cùng nến) → bỏ (ASSUMPTION bảo thủ); vào sau → giữ", ["mo_phong_lenh"], "TP1 1→10, vào @10, vào @11", "bỏ @10, giữ @11")
def t_pf_edge():
    g, n = MP.khong_chong([TRD(1, 10), TRD(10, 20), TRD(11, 30)])
    return n == 1 and [t["entry_ts_ms"] for t in g] == [1, 11], ([t["entry_ts_ms"] for t in g], n)


@T("PF-05", "Lọc danh mục", "Không chặn chéo SU-3/SU-5 hay XAUUSD/BTCUSD; cùng entry_ts xếp theo emit_seq", ["mo_phong_lenh"], "4 khóa khác nhau + 2 lệnh cùng khóa cùng thời điểm (seq 7, 3)", "giữ seq 3, bỏ seq 7")
def t_pf_cross():
    tr = [TRD(5, 9, sym="BTCUSD"), TRD(5, 9, su="SU3"), TRD(5, 9, sym="BTCUSD", su="SU3"), TRD(5, 9, seq=7), TRD(5, 9, seq=3)]
    g, n = MP.khong_chong(tr)
    xa = [t for t in g if (t["symbol"], t["setup"]) == ("XAUUSD", "SU5")]
    return n == 1 and len(g) == 4 and xa[0]["emit_seq"] == 3, ([(t["symbol"], t["setup"], t["emit_seq"]) for t in g], n)


def SG(seq, key, sid):
    return dict(signal_id=sid, emit_seq=seq, dup_key=key, trigger_ts_ms=5)


@T("DUP-01", "Khử trùng", "Giữ bản PHÁT RA TRƯỚC theo emit_seq, không theo băm signal_id (F2)", ["mo_phong_lenh"], "cùng dup_key: seq 1 id 'ffff', seq 2 id '0000'", "giữ seq 1")
def t_dup_order():
    g, n = MP.khu_trung([SG(2, "k", "0000"), SG(1, "k", "ffff")])
    return n == 1 and g[0]["emit_seq"] == 1, ([(s["emit_seq"], s["signal_id"]) for s in g], n)


@T("DUP-02", "Khử trùng", "Thiếu emit_seq hoặc emit_seq trùng → ValueError (không đoán thứ tự)", ["mo_phong_lenh"], "thiếu / trùng", "ValueError ×2")
def t_dup_err():
    out = []
    for bad in ([dict(signal_id="a", dup_key="k", trigger_ts_ms=1)], [SG(1, "k", "a"), SG(1, "j", "b")]):
        try:
            MP.khu_trung(bad); out.append("không lỗi")
        except ValueError:
            out.append("ValueError")
    return out == ["ValueError"] * 2, out


@T("DUP-03", "Khử trùng", "Không phụ thuộc thứ tự đầu vào: 200 lần xáo trộn → cùng tập giữ, đầu ra theo emit_seq", ["mo_phong_lenh"], "30 tín hiệu, 8 khóa", "200/200 giống")
def t_dup_shuffle():
    R = random.Random(2)
    base = [SG(i, f"k{R.randint(0, 7)}", f"{R.getrandbits(32):08x}") for i in range(30)]
    ref, _ = MP.khu_trung(base); ok = 0
    for _ in range(200):
        x = base[:]; R.shuffle(x)
        ok += [s["emit_seq"] for s in MP.khu_trung(x)[0]] == [s["emit_seq"] for s in ref]
    return ok == 200, f"{ok}/200"


@T("DUP-04", "Khử trùng", "Trên replay thật của khối Pine (SYNTH, 40 seed): với mọi dup_key có > 1 tín hiệu, bản giữ là emit_seq nhỏ nhất; số bị loại = tổng (n−1)", ["mo_phong_lenh", "chuan_hoa"],
   "40 seed", "khớp tuyệt đối")
def t_dup_replay():
    tong = loai = 0; sai = 0
    for sd in range(40):
        r = CH.replay_synth(sd)
        g, n = MP.khu_trung(r["signals"]); loai += n
        nh = {}
        for s in r["signals"]:
            nh.setdefault(s["dup_key"], []).append(s["emit_seq"])
        tong += sum(len(v) - 1 for v in nh.values())
        sai += sorted(s["emit_seq"] for s in g) != sorted(min(v) for v in nh.values())
    return sai == 0 and tong == loai, dict(nhom_trung=tong, loai=loai, sai=sai, ghi_chu="SYNTH ngẫu nhiên có thể không sinh trùng – DUP-01…03 kiểm cơ chế")

# ================================================================================================ HỢP ĐỒNG DỮ LIỆU


def EV0(**kw):
    e = dict(schema_version="1.1", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", tf="5", setup="SU5", mode="SHADOW", setup_id="aaaa", event_id="e1", emit_seq=0,
             event_type="CREATED", step=0, ts="2026-01-02T03:05:00Z", ts_ms=1767323100000, dir=1, state=0, reason=0, anchor_price=2000.0, ext_price=5.0)
    e.update(kw); return e


def SIG0(**kw):
    s = dict(schema_version="1.1", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", setup="SU5", setup_id="aaaa", signal_id=HD.hid("aaaa", 1767324000000), emit_seq=2, dir=1,
             trigger_ts="2026-01-02T03:20:00Z", trigger_ts_ms=1767324000000, p_ref=2000.0, sl=1995.0, tp1=2010.0, rr=2.0, reason=16, perm_reg=None, perm_vol=None,
             dup_key="XAUUSD|SU5|1|1767324000000")
    s.update(kw); return s


def TR0(**kw):
    t = dict(schema_version="1.1", signal_id=SIG0()["signal_id"], symbol="XAUUSD", setup="SU5", emit_seq=2, sim_rule="R-close-sl_first-288", cost_model="C-0", entry_ts_ms=1767324000000,
             entry_price=2000.0, risk=5.0, outcome="TP1", fill_note=None, exit_ts_ms=1767324600000, exit_price=2010.0, r_gross=2.0, r_net=1.9, mfe_r=2.0, mae_r=-0.2, bars_held=2,
             same_bar_conflict=False, gap_exit=False, time_gaps=0, max_gap_ms=0)
    t.update(kw); return t


def BO0():
    ev = [EV0(), EV0(event_id="e2", emit_seq=1, event_type="ARMED", state=2, ts="2026-01-02T03:10:00Z", ts_ms=1767323400000),
          EV0(event_id="e3", emit_seq=2, event_type="TRIGGER", state=17, reason=16, ts="2026-01-02T03:20:00Z", ts_ms=1767324000000)]
    return ev, [SIG0()], [TR0()]


@T("HD-01", "Hợp đồng dữ liệu", "Bộ bản ghi đúng (EVENTS, SIGNALS, TRADES đủ ngoại lệ OPEN/NO_FILL/NO_DATA/INVALID) → 0 lỗi bản ghi và cấp bảng", ["hop_dong"], "bộ chuẩn + 4 TRADE ngoại lệ", "0 lỗi")
def t_hd_ok():
    ev, sg, tr = BO0()
    ngoai = [TR0(outcome="OPEN", exit_ts_ms=None, exit_price=None, r_gross=0.4, r_net=0.4, mfe_r=0.5, mae_r=-0.1, sim_rule="R-close-sl_first-1"),
             TR0(outcome="NO_FILL", fill_note="GAP_BEYOND_SL", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, entry_ts_ms=1767324300000, sim_rule="R-next_open-sl_first-288"),
             TR0(outcome="NO_DATA", fill_note="NO_NEXT_BAR", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, sim_rule="R-next_open-tp_first-288"),
             TR0(outcome="INVALID", fill_note="INVALID_RISK", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, cost_model="C-x")]
    loi = HD.kiem_bang(ev, sg, tr + ngoai)
    return not loi, loi[:5]


FLOAT_FIELDS = {"EVENTS": [n for n, t, _, _ in HD.EVENTS if t is float], "SIGNALS": [n for n, t, _, _ in HD.SIGNALS if t is float], "TRADES": [n for n, t, _, _ in HD.TRADES if t is float]}


@T("HD-02", "Hợp đồng dữ liệu", "Mọi trường số thực của 3 bảng: NaN, +∞, −∞ → bị báo 'không hữu hạn' (F12)", ["hop_dong"], "mỗi trường float × 3 giá trị", "100 % bị bắt")
def t_hd_finite():
    miss = []
    for nm, mk, sc in (("EVENTS", EV0, HD.EVENTS), ("SIGNALS", SIG0, HD.SIGNALS), ("TRADES", TR0, HD.TRADES)):
        for f in FLOAT_FIELDS[nm]:
            for v in (float("nan"), float("inf"), float("-inf")):
                if not any("không hữu hạn" in x for x in HD.kiem(mk(**{f: v}), sc)):
                    miss.append((nm, f, v))
    n = sum(len(v) for v in FLOAT_FIELDS.values()) * 3
    return not miss, dict(so_ca=n, lot=miss)


@T("HD-03", "Hợp đồng dữ liệu", "Kiểu sai (bool thay int/float, chuỗi thay số, số thay chuỗi), thiếu trường bắt buộc, trường lạ → bị báo; null ở trường tùy chọn → hợp lệ", ["hop_dong"],
   "7 biến thể", "6 bị báo, 1 hợp lệ")
def t_hd_types():
    ca = [HD.kiem(EV0(dir=True), HD.EVENTS), HD.kiem(SIG0(p_ref="2000"), HD.SIGNALS), HD.kiem(EV0(symbol=1), HD.EVENTS), HD.kiem(TR0(r_net=False), HD.TRADES)]
    x = EV0(); del x["reason"]; ca.append(HD.kiem(x, HD.EVENTS))
    ca.append(HD.kiem(EV0(la=1), HD.EVENTS))
    ok_null = HD.kiem(SIG0(tp1=None, rr=None, perm_reg=None), HD.SIGNALS)
    return all(ca) and not ok_null, dict(so_loi=[len(c) for c in ca], null_tuy_chon=ok_null)


@T("HD-04", "Hợp đồng dữ liệu", "Thời gian: sai định dạng, ngày không tồn tại, ts ≠ ts_ms, trigger_ts ≠ trigger_ts_ms (F13/F14), ms không tròn phút, ms âm → bị báo", ["hop_dong"], "6 biến thể", "6/6 bị báo")
def t_hd_ts():
    ca = [EV0(ts="2026-01-02 03:05"), EV0(ts="2026-13-45T99:99:99Z"), EV0(ts_ms=1767323100000 + 300000), (SIG0(trigger_ts="2026-01-01T00:00:00Z"), HD.SIGNALS),
          EV0(ts_ms=1767323100001, ts="2026-01-02T03:05:00Z"), EV0(ts_ms=-60000, ts="1969-12-31T23:59:00Z")]
    r = [HD.kiem(c[0], c[1]) if isinstance(c, tuple) else HD.kiem(c, HD.EVENTS) for c in ca]
    return all(r), [x[:2] for x in r]


@T("HD-05", "Hợp đồng dữ liệu", "Danh mục và miền: symbol, setup, source, event_type, outcome, mode, dir, state 0…17, reason 0…16, schema_version", ["hop_dong"], "10 biến thể", "10/10 bị báo")
def t_hd_enum():
    ca = [HD.kiem(EV0(symbol="EURUSD"), HD.EVENTS), HD.kiem(EV0(setup="SU4"), HD.EVENTS), HD.kiem(EV0(source="X"), HD.EVENTS), HD.kiem(EV0(event_type="WIN"), HD.EVENTS),
          HD.kiem(TR0(outcome="WIN"), HD.TRADES), HD.kiem(EV0(mode="LIVE"), HD.EVENTS), HD.kiem(EV0(dir=0), HD.EVENTS), HD.kiem(EV0(state=18), HD.EVENTS),
          HD.kiem(EV0(reason=17), HD.EVENTS), HD.kiem(EV0(schema_version="2.0"), HD.EVENTS)]
    return all(ca), [len(c) for c in ca]


@T("HD-06", "Hợp đồng dữ liệu", "Hình học SIGNAL: SL sai phía, TP1 sai phía, rr sai, reason ngoài 16/8/15/14/9/1/2, dup_key không khớp; SELL đúng → hợp lệ", ["hop_dong"], "5 sai + 1 SELL đúng", "5 bị báo, SELL 0 lỗi")
def t_hd_geo():
    ca = [SIG0(sl=2001.0), SIG0(tp1=1990.0, rr=None), SIG0(rr=3.0), SIG0(reason=3), SIG0(dup_key="x")]
    r = [HD.kiem(c, HD.SIGNALS) for c in ca]
    sell = HD.kiem(SIG0(dir=-1, sl=2005.0, tp1=1990.0, rr=2.0, dup_key="XAUUSD|SU5|-1|1767324000000"), HD.SIGNALS)
    return all(r) and not sell, dict(loi=[x[0] for x in r], sell=sell)


@T("HD-07", "Hợp đồng dữ liệu", "Ngoại lệ TRADES: NO_FILL có risk ≠ null / thiếu fill_note / bars_held ≠ 0; OPEN có exit; lệnh đóng thiếu exit; lệnh đóng có fill_note → bị báo", ["hop_dong"], "6 biến thể", "6/6 bị báo")
def t_hd_exc():
    nf = dict(outcome="NO_FILL", fill_note="GAP_BEYOND_SL", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0)
    ca = [TR0(**dict(nf, risk=5.0)), TR0(**dict(nf, fill_note=None)), TR0(**dict(nf, bars_held=3)), TR0(outcome="OPEN"), TR0(exit_ts_ms=None), TR0(fill_note="GAP_BEYOND_SL")]
    r = [HD.kiem(c, HD.TRADES) for c in ca]
    return all(r), [x[:1] for x in r]


@T("HD-08", "Hợp đồng dữ liệu", "Nhất quán R trong TRADE: R ngoài [MAE, MFE], r_net > r_gross, SL không gap R ≠ −1, |R|×risk ≠ |exit − entry|, exit trước entry, bars_held < 1, MFE < 0, MAE > 0, risk ≤ 0", ["hop_dong"],
   "9 biến thể", "9/9 bị báo")
def t_hd_r():
    ca = [TR0(r_gross=2.5, r_net=2.4), TR0(r_net=2.1), TR0(outcome="SL", exit_price=1995.0, r_gross=-0.9, r_net=-0.9, mfe_r=0.5, mae_r=-1.0), TR0(exit_price=2011.0),
          TR0(exit_ts_ms=1767323700000), TR0(bars_held=0), TR0(mfe_r=-0.1), TR0(mae_r=0.1), TR0(risk=0.0)]
    r = [HD.kiem(c, HD.TRADES) for c in ca]
    return all(r), [x[:1] for x in r]


@T("HD-09", "Hợp đồng dữ liệu", "Kiểm cấp bảng (F15): trùng event_id / signal_id / emit_seq, emit_seq ngược thời gian, sự kiện đầu ≠ CREATED, sự kiện sau kết thúc, SIGNAL không có setup, trigger trước CREATED, thiếu sự kiện TRIGGER, TRADE không có SIGNAL, TRADE cho tín hiệu bị bỏ, R1 vào sai nến, risk ≠ (entry − SL)×dir, R sai chiều, SL thoát sai giá, TP1 khi tín hiệu không TP1, signal_id không tái lập",
   ["hop_dong"], "17 biến thể làm hỏng bộ chuẩn", "17/17 bị báo")
def t_hd_table():
    def bo():
        return [copy.deepcopy(x) for x in BO0()]
    ca = []
    ev, sg, tr = bo(); ev[1]["event_id"] = "e1"; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); sg.append(dict(sg[0], emit_seq=9)); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); ev[1]["emit_seq"] = 0; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); ev[1].update(ts="2026-01-02T03:00:00Z", ts_ms=1767322800000); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); ev[0].update(event_type="STEP"); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); ev.append(EV0(event_id="e4", emit_seq=3, event_type="VOID", state=6, reason=6, ts="2026-01-02T03:25:00Z", ts_ms=1767324300000)); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); sg[0]["setup_id"] = "bbbb"; sg[0]["signal_id"] = HD.hid("bbbb", sg[0]["trigger_ts_ms"]); tr[0]["signal_id"] = sg[0]["signal_id"]; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); ev[0].update(ts="2026-01-02T03:25:00Z", ts_ms=1767324300000, emit_seq=5); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); ev = ev[:2]; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); tr[0]["signal_id"] = "zzzz"; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); sg[0]["reason"] = 15; ev[2]["reason"] = 15; ev[2]["state"] = 4; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); tr[0]["entry_ts_ms"] = 1767324300000; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); tr[0].update(risk=4.0, r_gross=2.5, r_net=2.4, mfe_r=2.5); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); sg[0].update(dir=-1, sl=2005.0, tp1=1990.0, dup_key="XAUUSD|SU5|-1|1767324000000"); [e.update(dir=-1) for e in ev]; ca.append((ev, sg, tr))
    ev, sg, tr = bo(); tr[0].update(outcome="SL", exit_price=1994.0, r_gross=-1.0, r_net=-1.0, mfe_r=0.2, mae_r=-1.0, exit_ts_ms=1767324600000); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); sg[0].update(tp1=None, rr=None); ca.append((ev, sg, tr))
    ev, sg, tr = bo(); sg[0]["signal_id"] = "ffff0000ffff0000"; tr[0]["signal_id"] = "ffff0000ffff0000"; ca.append((ev, sg, tr))
    r = [HD.kiem_bang(*c) for c in ca]
    return all(r), [x[0][:70] if x else "KHÔNG BẮT" for x in r]


@T("HD-10", "Hợp đồng dữ liệu", "Đột biến ngẫu nhiên trên đầu ra replay thật (SYNTH): 300 lần đổi 1 trường quan trọng (ts_ms, emit_seq, setup_id, dir, sl, p_ref, reason, event_type, risk, r_gross, exit_price) → bộ kiểm bắt được", ["hop_dong", "chuan_hoa"],
   "seed 3 + lệnh giả lập; 300 đột biến", "≥ 97 % bị bắt; liệt kê ca lọt")
def t_hd_mut():
    r = CH.replay_synth(3); ev, sg = r["events"], r["signals"]
    tr = []
    for s in sg:
        if s["reason"] == 16:
            t = MP.mo_phong(s, r["bars"], r["idx"][s["trigger_ts_ms"]], MP.Cfg(max_bars=60, spread=0.2, slippage=0.05))
            cf = MP.Cfg(max_bars=60, spread=0.2, slippage=0.05)
            tr.append(dict(t, schema_version="1.1", signal_id=s["signal_id"], symbol=s["symbol"], setup=s["setup"], emit_seq=s["emit_seq"], sim_rule=cf.rule_id(), cost_model=cf.cost_id()))
    assert not HD.kiem_bang(ev, sg, tr), "bộ gốc phải sạch"
    R = random.Random(8); lot = []; n = 300
    for k in range(n):
        E, S, Tt = copy.deepcopy(ev), copy.deepcopy(sg), copy.deepcopy(tr)
        bang = R.choice(["E", "S"] + (["T"] if Tt else []))
        if bang == "E":
            x = R.choice(E); f = R.choice(("ts_ms", "emit_seq", "setup_id", "dir", "event_type"))
            x[f] = {"ts_ms": x["ts_ms"] + 300000, "emit_seq": x["emit_seq"] + 10 ** 6, "setup_id": "deadbeefdeadbeef", "dir": -x["dir"], "event_type": "STEP" if x["event_type"] == "CREATED" else "CREATED"}[f]
        elif bang == "S":
            x = R.choice(S); f = R.choice(("sl", "p_ref", "reason", "dir", "trigger_ts_ms"))
            x[f] = {"sl": x["sl"] + 0.5 * x["dir"], "p_ref": x["p_ref"] + 0.3, "reason": 15 if x["reason"] == 16 else 16, "dir": -x["dir"], "trigger_ts_ms": x["trigger_ts_ms"] + 300000}[f]
        else:
            x = R.choice(Tt); f = R.choice(("risk", "r_gross", "exit_price"))
            if x[f] is None:
                x[f] = 1.0
            else:
                x[f] = x[f] + (0.37 if f != "risk" else 1.0)
        if not HD.kiem_bang(E, S, Tt):
            lot.append((bang, f))
    ty = 1 - len(lot) / n
    return ty >= 0.97, dict(ty_le_bat=round(ty, 4), lot=lot[:10])


@T("HD-11", "Hợp đồng dữ liệu", "JSON chuẩn: mọi đầu ra pipeline SYNTH (sự kiện, tín hiệu, lệnh, chỉ số) ghi được với allow_nan=False (không NaN/Infinity)", ["hop_dong", "chi_so", "pipeline"], "ô XAUUSD-SU5 SYNTH", "ghi được")
def t_hd_json():
    syn = PL.chay_synth("XAUUSD", "SU5", seeds=range(10))
    json.dumps(dict(e=syn["events"], s=syn["signals"], t=syn["trades"], c=syn["chi_so"], p=syn["phieu"]), allow_nan=False, default=str)
    return True, dict(su_kien=len(syn["events"]), lenh=len(syn["trades"]))

# ================================================================================================ CHỈ SỐ


def TC(o, r, sym="XAUUSD", su="SU5"):
    return dict(symbol=sym, setup=su, outcome=o, r_net=r, mfe_r=max(r or 0, 0) + 0.1 if r is not None else None, mae_r=min(r or 0, 0) - 0.1 if r is not None else None,
                bars_held=5, same_bar_conflict=False, gap_exit=False)


@T("CS-01", "Chỉ số", "Định nghĩa: thắng r_net > 0, thua < 0, hòa vốn = 0 TÁCH RIÊNG; win_rate = thắng/đóng; win_rate_khong_hoa = thắng/(thắng+thua); tỷ lệ TP1 là tỷ lệ KẾT CỤC (TP1 sau chi phí âm vẫn là TP1)", ["chi_so"],
   "TP1 +2, TP1 −0,05 (chi phí), SL −1, TIMEOUT 0, TIMEOUT +0,5, OPEN +3, NO_FILL", "đóng 5; thắng 2, thua 2, hòa 1; win 0,4; win không hòa 0,5; TP1 0,4")
def t_cs_def():
    h = CS.hieu_qua([TC("TP1", 2.0), TC("TP1", -0.05), TC("SL", -1.0), TC("TIMEOUT", 0.0), TC("TIMEOUT", 0.5), TC("OPEN", 3.0), TC("NO_FILL", None)])[("XAUUSD", "SU5")]
    ok = (h["dong"], h["thang"], h["thua"], h["hoa_von"], h["mo"], h["khong_khop"]) == (5, 2, 2, 1, 1, 1) and gan(h["win_rate"], 0.4) and gan(h["win_rate_khong_hoa"], 0.5) and gan(h["ty_le_tp1"], 0.4)
    ok = ok and gan(h["net_r"], 1.45) and gan(h["profit_factor"], 2.5 / 1.05)
    return ok, {k: h[k] for k in ("dong", "thang", "thua", "hoa_von", "win_rate", "win_rate_khong_hoa", "ty_le_tp1", "net_r", "profit_factor")}


@T("CS-02", "Chỉ số", "Profit factor biên (F10): không có thua → null + 'KHONG_CO_LENH_THUA'; chỉ hòa vốn → null + 'KHONG_CO_LENH_THANG_THUA'; chỉ thua → 0,0; JSON allow_nan=False ghi được", ["chi_so"],
   "3 nhóm", "null/null/0,0; JSON OK")
def t_cs_pf():
    h = CS.hieu_qua([TC("TP1", 2.0)] * 3 + [TC("TIMEOUT", 0.0, su="SU3")] * 2 + [TC("SL", -1.0, sym="BTCUSD")] * 2)
    a, b, c = h[("XAUUSD", "SU5")], h[("XAUUSD", "SU3")], h[("BTCUSD", "SU5")]
    json.dumps({str(k): v for k, v in h.items()}, allow_nan=False)
    ok = a["profit_factor"] is None and a["pf_trang_thai"] == "KHONG_CO_LENH_THUA" and b["profit_factor"] is None and b["pf_trang_thai"] == "KHONG_CO_LENH_THANG_THUA" and c["profit_factor"] == 0.0
    return ok, [(x["profit_factor"], x["pf_trang_thai"]) for x in (a, b, c)]


@T("CS-03", "Chỉ số", "Phân vị bootstrap đối xứng (F9): với B = 10, 30, 50, 70, 999, 2000 chỉ số trên = B − 1 − chỉ số dưới, dưới = ⌊0,025·B⌋", ["chi_so"], "6 giá trị B", "đối xứng 6/6")
def t_cs_pct():
    out = {}
    for Bn in (10, 30, 50, 70, 999, 2000):
        s = list(range(Bn)); lo, hi = CS.phan_vi_doi_xung(s)
        out[Bn] = (lo, hi)
    return all(hi == Bn - 1 - lo and lo == (Bn * 25) // 1000 for Bn, (lo, hi) in out.items()), out


@T("CS-04", "Chỉ số", "Biên mẫu: n = 0 (chỉ OPEN) → chỉ số null, CI null; n = 1 → CI null 'N_NHO_HON_2'; mọi R bằng nhau → CI suy biến [r, r]; ngoại lai 1 lệnh +50R → CI chứa expectancy, PF hữu hạn", ["chi_so"],
   "4 nhóm", "như mô tả")
def t_cs_edge():
    h = CS.hieu_qua([TC("OPEN", 1.0)] + [TC("SL", -1.0, su="SU3")] + [TC("TP1", 1.5, sym="BTCUSD")] * 5 + [TC("SL", -1.0, sym="BTCUSD", su="SU3")] * 29 + [TC("TP1", 50.0, sym="BTCUSD", su="SU3")])
    a, b, c, d = h[("XAUUSD", "SU5")], h[("XAUUSD", "SU3")], h[("BTCUSD", "SU5")], h[("BTCUSD", "SU3")]
    ok = a["dong"] == 0 and a["win_rate"] is None and a["expectancy"] is None and a["expectancy_ci95"] is None
    ok = ok and b["expectancy_ci95"] is None and b["ci_trang_thai"] == "N_NHO_HON_2"
    ok = ok and c["expectancy_ci95"] == [1.5, 1.5] and c["ci_trang_thai"] == "SUY_BIEN"
    ok = ok and d["expectancy_ci95"][0] <= d["expectancy"] <= d["expectancy_ci95"][1] and math.isfinite(d["profit_factor"]) and d["du_mau"]
    return ok, dict(n0=(a["dong"], a["expectancy_ci95"]), n1=b["ci_trang_thai"], bang=c["expectancy_ci95"], ngoai_lai=(d["expectancy"], d["expectancy_ci95"], d["profit_factor"]))


@T("CS-05", "Chỉ số", "Seed xác định và không phụ thuộc thứ tự: chạy 2 lần → CI y hệt; xáo trộn thứ tự lệnh 20 lần → CI y hệt", ["chi_so"], "40 lệnh", "giống tuyệt đối")
def t_cs_seed():
    R = random.Random(4)
    tr = [TC(R.choice(("TP1", "SL", "TIMEOUT")), round(R.uniform(-1, 2.5), 3)) for _ in range(40)]
    a = CS.hieu_qua(tr)[("XAUUSD", "SU5")]["expectancy_ci95"]; b = CS.hieu_qua(tr)[("XAUUSD", "SU5")]["expectancy_ci95"]
    same = 0
    for _ in range(20):
        x = tr[:]; R.shuffle(x); same += CS.hieu_qua(x)[("XAUUSD", "SU5")]["expectancy_ci95"] == a
    return a == b and same == 20, dict(ci=a, xao_tron_giong=same)


@T("CS-06", "Chỉ số", "Độ phủ CI bootstrap (kiểm hợp lý, giả định i.i.d.): 120 mẫu n = 60 từ phân phối có kỳ vọng đã biết, B = 400 → tỷ lệ CI chứa kỳ vọng thật trong [0,85; 0,99]", ["chi_so"],
   "120 mẫu, seed 21", "độ phủ ∈ [0,85; 0,99]")
def t_cs_cover():
    R = random.Random(21); trung = 0
    for i in range(120):
        tr = [TC("TP1" if x > 0 else "SL", x) for x in (R.choice((2.0, -1.0, -1.0, 0.5)) + R.gauss(0, 0.1) for _ in range(60))]
        ci, _ = CS.bootstrap_ci([t["r_net"] for t in tr], 7, ("x", i), n_boot=400)
        trung += ci[0] <= 0.125 <= ci[1]
    return 0.85 <= trung / 120 <= 0.99, dict(do_phu=round(trung / 120, 3))


@T("CS-07", "Chỉ số", "Phễu theo (symbol, setup) riêng: tạo, ARMED, VOID, hết hạn, gap bỏ, kết thúc không sự kiện, trigger, đạt S1, bỏ quyền, bỏ khác, TRÙNG (F11) và các tỷ lệ", ["chi_so"],
   "sự kiện + tín hiệu 2 setup; 3 tín hiệu SU3 cùng dup_key", "SU3: trùng 2, …; SU5 tách riêng")
def t_cs_funnel():
    E = lambda et, su="SU3", r=0: dict(symbol="XAUUSD", setup=su, event_type=et, reason=r)     # noqa: E731
    ev = [E("CREATED"), E("CREATED"), E("ARMED"), E("VOID", r=6), E("EXPIRED", r=7), E("END_NO_EVENT"), E("CREATED", "SU5"), E("SKIP", "SU5", 4)]
    sg = [dict(symbol="XAUUSD", setup="SU3", reason=r, dup_key="a") for r in (16, 15, 8)] + [dict(symbol="XAUUSD", setup="SU5", reason=16, dup_key="b")]
    f = CS.phieu(ev, sg); a, b = f[("XAUUSD", "SU3")], f[("XAUUSD", "SU5")]
    ok = (a["tao"], a["armed"], a["void"], a["het_han"], a["ket_thuc_khong_su_kien"], a["trigger"], a["s1_dat"], a["bo_quyen"], a["bo_khac"], a["trung"]) == (2, 1, 1, 1, 1, 3, 1, 1, 1, 2)
    ok = ok and (b["tao"], b["gap_bo"], b["trigger"], b["trung"]) == (1, 1, 1, 0) and gan(a["ty_le_trigger_tren_armed"], 3.0)
    return ok, dict(SU3=a, SU5={k: b[k] for k in ("tao", "gap_bo", "trigger", "trung")})

# ================================================================================================ REPLAY / ADAPTER


def _h(o):
    return hashlib.sha256(json.dumps(o, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


@T("RP-01", "Replay", "Replay xác định: cùng seed chạy 2 lần (2 tiến trình Python riêng) → băm EVENTS/SIGNALS/nến y hệt (10 seed)", ["chuan_hoa"], "seed 0…9", "10/10 giống")
def t_rp_det():
    code = ("import sys,json,hashlib;sys.path.insert(0,%r);import chuan_hoa as C;"
            "print(json.dumps({s:hashlib.sha256(json.dumps({k:v for k,v in C.replay_synth(s).items() if k!='idx'},sort_keys=True,default=str).encode()).hexdigest() for s in range(10)}))") % D
    a = json.loads(subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout)
    b = json.loads(subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout)
    return a == b and len(a) == 10, dict(giong=sum(a[k] == b[k] for k in a), mau=list(a.values())[0][:16])


@T("RP-02", "Replay", "Adapter KHÔNG can thiệp engine: chạy PIPE có và không có bộ ghi → đầu ra mọi nến (sự kiện, trigger, vùng, ô Data Window) y hệt; số sự kiện evS thô = số sự kiện engine trong EVENTS", ["chuan_hoa"],
   "seed 0…14", "0 khác")
def t_rp_nonint():
    sys.path.insert(0, os.path.join(G, "kiem_toan039"))
    import kiem_cach_ly as CL
    from khung039 import S39
    khac = 0; lech = 0
    for sd in range(15):
        outs = []
        for co in (False, True):
            r2 = random.Random(sd)
            pp = CL.PIPE(S39, True); pp.ctx(r2.choice((1, 2, 3, 4)))
            bg = CH.BoGhi(pp, "XAUUSD")
            if co:
                bg.gan(pp)
            # cùng kịch bản như replay_synth
            from khung039 import zone
            p = 2000.0
            for _ in range(2):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(2, 8), 1)
                pp.g["zones"].v.append(zone(pp.ip, 60, d, b0 - 2, b0 + 2, bm=pp.T // 60000 - 600, pos=1))
            for _ in range(3):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(1, 6), 1)
                pp.g["zones"].v.append(zone(pp.ip, 15, d, b0 - 1, b0 + 1, bm=pp.T // 60000 + r2.choice((15, 30, 60)), bs=r2.randint(0, 99), pos=1))
            cl = sorted(round(p + r2.uniform(-8, 8), 1) for _ in range(3))
            pp.g.update(cLo=CL.PArr([x - 0.4 for x in cl]), cHi=CL.PArr([x + 0.4 for x in cl]), cRank=CL.PArr([r2.randint(1, 5) for _ in cl]))
            o_, n_evs = [], 0
            for j in range(120):
                o = p; c = round(p + r2.gauss(0, 1.8), 1); h = round(max(o, c) + abs(r2.gauss(0, 0.7)), 1); l = round(min(o, c) - abs(r2.gauss(0, 0.7)), 1)
                m15 = j % 3 == 0
                bb = dict(o=o, h=h, l=l, c=c, m15=m15, ev=r2.choice((0, 0, 1, 2, 3, 4)) if m15 else 0, ref=round(p + r2.uniform(-3, 3), 1),
                          h1=(c, r2.choice((0, 3, 4)), r2.random() < 0.6) if (m15 and j % 12 == 0) else None, pend=False)
                o_.append(pp.bar(bb)); n_evs += len(pp.g["evS"].v); p = c
            outs.append((o_, n_evs, bg))
        khac += _h(outs[0][0]) != _h(outs[1][0])
        n_eng = sum(e["event_type"] in ("ARMED", "SKIP", "EXPIRED", "VOID", "TRIGGER") for e in outs[1][2].events)
        lech += n_eng != outs[1][1]
    return khac == 0 and lech == 0, dict(khac_dau_ra=khac, lech_so_su_kien=lech)


@T("RP-03", "Replay", "EVENTS/SIGNALS do adapter tạo qua bộ kiểm cấp bảng cho 40 seed SYNTH (vòng đời, liên kết, thứ tự, emit_seq)", ["chuan_hoa", "hop_dong"], "seed 0…39", "0 lỗi")
def t_rp_contract():
    loi, ne, ns, mh = [], 0, 0, 0
    for sd in range(40):
        r = CH.replay_synth(sd); ne += len(r["events"]); ns += len(r["signals"]); mh += r["thong_ke"]["mo_ho"]
        loi += HD.kiem_bang(r["events"], r["signals"], [])
        loi += [] if r["thong_ke"]["khong_ghep"] == 0 else [f"seed {sd}: {r['thong_ke']['khong_ghep']} sự kiện không ghép được"]
    return not loi, dict(su_kien=ne, tin_hieu=ns, ghep_mo_ho_IP21=mh, loi=loi[:5])


@T("RP-04", "Replay", "Kịch bản SU-3 có định hướng (dữ liệu S3-11): vòng đời CREATED → STEP → ARMED → TRIGGER 17/16; SIGNAL P_ref 2005,2, SL 1991,4 (= min(2001,0; 1993 − 0,2×8)); qua hợp đồng; giả lập ra lệnh hợp lệ", ["chuan_hoa", "hop_dong", "mo_phong_lenh"],
   "kịch bản S3-11 + 5 nến tăng", "đúng vòng đời, đúng giá, 0 lỗi")
def t_rp_su3():
    r = CH.replay_su3_co_dinh([(2005.2, 2008, 2004.8, 2007.5)] * 5)
    s = r["signals"]
    tr = [dict(MP.mo_phong(x, r["bars"], r["idx"][x["trigger_ts_ms"]], MP.Cfg(max_bars=60)), schema_version="1.1", signal_id=x["signal_id"], symbol="XAUUSD", setup="SU3", emit_seq=x["emit_seq"],
               sim_rule="R-close-sl_first-60", cost_model="C-0") for x in s]
    loi = HD.kiem_bang(r["events"], s, tr)
    chuoi = {}
    for e in r["events"]:
        chuoi.setdefault(e["setup_id"], []).append(e["event_type"])
    co_trig = [v for v in chuoi.values() if "TRIGGER" in v]
    ok = len(s) == 1 and s[0]["setup"] == "SU3" and s[0]["reason"] == 16 and gan(s[0]["p_ref"], 2005.2) and gan(s[0]["sl"], 1991.4) and co_trig == [["CREATED", "STEP", "ARMED", "TRIGGER"]] and not loi
    return ok, dict(vong_doi=chuoi, tin_hieu=[(x["p_ref"], x["sl"], x["tp1"], x["reason"]) for x in s], lenh=[(t["outcome"], t["bars_held"]) for t in tr], loi=loi[:3])


@T("RP-05", "Replay", "emit_seq tăng nghiêm ngặt theo thứ tự phát, thời gian không giảm; event_id duy nhất kể cả khi thể hiện trùng khóa (IP-21)", ["chuan_hoa"], "seed 0…19", "0 vi phạm")
def t_rp_seq():
    v = 0
    for sd in range(20):
        ev = CH.replay_synth(sd)["events"]
        v += any(b["emit_seq"] != a["emit_seq"] + 1 or b["ts_ms"] < a["ts_ms"] for a, b in zip(ev, ev[1:]))
        v += len({e["event_id"] for e in ev}) != len(ev)
    return v == 0, f"vi phạm {v}"

# ================================================================================================ ĐẦU-CUỐI


@T("E2E-01", "Đầu-cuối (SYNTH)", "Ô XAUUSD-SU5 SYNTH: replay khối Pine nguyên văn → EVENTS/SIGNALS → khử trùng emit_seq → giả lập R1 → TRADES → kiểm cấp bảng → chỉ số + phễu; phễu 'trùng' = số bị khử trùng (không phải hiệu quả chiến lược)", ["pipeline", "chuan_hoa", "hop_dong", "mo_phong_lenh", "chi_so"],
   "40 seed", "có tín hiệu, có lệnh, 0 lỗi hợp đồng, chỉ số tính được")
def t_e2e_su5():
    syn = PL.chay_synth("XAUUSD", "SU5")
    ok = len(syn["signals"]) > 0 and len(syn["trades"]) > 0 and not syn["loi_hop_dong"] and syn["chi_so"] is not None and syn["phieu"]["trigger"] == len(syn["signals"])
    ok = ok and syn["phieu"]["trung"] == syn["bo_trung"]          # phễu 'trung' phải khớp số bị khử trùng thật (F25: dup_key trùng giữa các seed)
    # lọc danh mục phải chạy riêng từng seed (F25): đối chiếu với lọc độc lập từng seed
    doc_lap = sum(MP.khong_chong([t for t in syn["trades"] if t["_seed"] == sd])[1] for sd in {t["_seed"] for t in syn["trades"]})
    ok = ok and syn["bo_chong_lan"] == doc_lap
    return ok, dict(su_kien=len(syn["events"]), tin_hieu=len(syn["signals"]), lenh=len(syn["trades"]), loi=syn["loi_hop_dong"][:3], phieu={k: syn["phieu"][k] for k in ("tao", "armed", "trigger", "s1_dat", "trung")}, bo_trung=syn["bo_trung"], bo_chong_lan=syn["bo_chong_lan"])


@T("E2E-02", "Đầu-cuối (SYNTH)", "Ô SU-3 trên kịch bản có định hướng: chuỗi đầy đủ tới TRADES + chỉ số; ô SU-3 SYNTH ngẫu nhiên được chạy và báo 0 trigger (không bịa)", ["pipeline", "chuan_hoa"], "S3-11 + 40 seed ngẫu nhiên", "1 lệnh SU-3; ngẫu nhiên: 0 trigger, 0 lỗi")
def t_e2e_su3():
    r = CH.replay_su3_co_dinh([(2005.2, 2008, 2004.8, 2007.5)] * 5)
    s = MP.khu_trung(r["signals"])[0]
    tr = [dict(MP.mo_phong(x, r["bars"], r["idx"][x["trigger_ts_ms"]], MP.Cfg(max_bars=60)), schema_version="1.1", signal_id=x["signal_id"], symbol="XAUUSD", setup="SU3", emit_seq=x["emit_seq"],
               sim_rule="R-close-sl_first-60", cost_model="C-0") for x in s if x["reason"] == 16]
    h = CS.hieu_qua(tr).get(("XAUUSD", "SU3"))
    syn = PL.chay_synth("XAUUSD", "SU3")
    ok = len(tr) == 1 and h is not None and not HD.kiem_bang(r["events"], r["signals"], tr) and not syn["loi_hop_dong"] and len(syn["signals"]) == 0
    return ok, dict(lenh_dinh_huong=[(t["outcome"], t["r_gross"]) for t in tr], ngau_nhien=dict(su_kien=len(syn["events"]), tin_hieu=len(syn["signals"])))


@T("E2E-03", "Đầu-cuối (thật)", "4 ô dữ liệu thật khi KHÔNG có file: bước 1–9 đều BLOCKED với lý do; không bước nào PASS giả; bước 4 nêu rõ replay toàn script chưa hiện thực", ["pipeline"], "4 ô, không dữ liệu", "100 % BLOCKED, có lý do")
def t_e2e_blocked():
    out = {}
    for sym, su in PL.O_LIST:
        bc = PL.chay_o(sym, su, None)
        out[f"{sym}-{su}"] = [b["trang_thai"] for b in bc["buoc"]]
        ok = all(b["trang_thai"] == "BLOCKED" and b["chi_tiet"] for b in bc["buoc"]) and "chưa hiện thực" in [b for b in bc["buoc"] if b["buoc"].startswith("4")][0]["chi_tiet"]
        if not ok:
            return False, out
    return True, out

# ================================================================================================ ĐƯỜNG ỐNG DỮ LIỆU


def _csv_tv(rows, iso=False, tz="+00:00"):
    s = io.StringIO(); w = csv.writer(s); w.writerow(["time", "open", "high", "low", "close", "Volume"])
    for t, o, h, l, c in rows:
        w.writerow([dt.datetime.fromtimestamp(t / 1000, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S") + tz if iso else t // 1000, o, h, l, c, 1])
    return s.getvalue()


T0 = int(dt.datetime(2026, 1, 5, 0, 0, tzinfo=dt.timezone.utc).timestamp() * 1000)     # thứ Hai


@T("DL-01", "Đường ống dữ liệu", "Nhập TradingView: Unix giây, ISO có múi giờ (+07:00 → đổi về UTC), ISO KHÔNG múi giờ → báo lỗi (không đoán) trừ khi khai báo UTC", ["du_lieu"], "3 file", "ms UTC đúng; dòng không múi giờ bị báo")
def t_dl_tv():
    rows = [(T0 + 300000 * i, 2000, 2001, 1999, 2000.5) for i in range(3)]
    a, la = DL.nhap(_csv_tv(rows), "TV")
    b, lb = DL.nhap(_csv_tv([(t + 7 * 3600000, *x) for t, *x in rows], iso=True, tz="+07:00"), "TV")
    c, lc = DL.nhap(_csv_tv(rows, iso=True, tz=""), "TV")
    c2, _ = DL.nhap(_csv_tv(rows, iso=True, tz=""), "TV", mui_gio_mac_dinh_utc=True)
    ok = [x["t"] for x in a] == [r[0] for r in rows] and not la and [x["t"] for x in b] == [r[0] for r in rows] and not lb and not c and len(lc) == 3 and [x["t"] for x in c2] == [r[0] for r in rows]
    return ok, dict(unix=[x["t"] for x in a][:1], iso_tz=[x["t"] for x in b][:1], khong_tz_loi=len(lc))


@T("DL-02", "Đường ống dữ liệu", "Nhập MT5 (tab, <DATE> <TIME>, giờ máy chủ): lech_phut = 120 → trừ 2 giờ về UTC; thiếu lech_phut → từ chối", ["du_lieu"], "file MT5 2 dòng", "UTC đúng; thiếu tham số → lỗi")
def t_dl_mt5():
    txt = "<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\n2026.01.05\t02:00:00\t2000\t2001\t1999\t2000.5\t10\n2026.01.05\t02:05\t2000.5\t2002\t2000\t2001\t12\n"
    a, la = DL.nhap(txt, "MT5", lech_phut=120); b, lb = DL.nhap(txt, "MT5")
    return [x["t"] for x in a] == [T0, T0 + 300000] and not la and not b and lb, dict(utc=[x["t"] for x in a], thieu=lb)


@T("DL-03", "Đường ống dữ liệu", "Kiểm OHLCV: nến hỏng, lệch khung, trùng mâu thuẫn → FAIL; trùng giống hệt + đảo thứ tự → WARN; dữ liệu sạch → PASS", ["du_lieu"], "4 bộ", "FAIL / FAIL / FAIL / WARN; sạch PASS")
def t_dl_val():
    sach = [dict(t=T0 + 300000 * i, o=2000.0, h=2001.0, l=1999.0, c=2000.5) for i in range(12)]
    hong = copy.deepcopy(sach); hong[3]["h"] = 1990.0
    lech = copy.deepcopy(sach); lech[4]["t"] += 60000
    mau = copy.deepcopy(sach) + [dict(sach[5], c=2000.9)]
    warn = copy.deepcopy(sach) + [dict(sach[5])]; warn[1], warn[2] = warn[2], warn[1]
    st = [DL.kiem_ohlcv(x, "BTCUSD")["trang_thai"] for x in (hong, lech, mau, warn, sach)]
    return st == ["FAIL", "FAIL", "FAIL", "WARN", "PASS"], st


@T("DL-04", "Đường ống dữ liệu", "Phân loại khoảng trống (lịch GIẢ ĐỊNH): XAU nghỉ cuối tuần thứ Sáu 21:00 → Chủ nhật 23:00 UTC = ứng viên nghỉ; XAU nghỉ 1 giờ lúc 21:00 = ứng viên nghỉ hằng ngày; XAU thiếu 30 phút giữa phiên = THIẾU; BTC cuối tuần = THIẾU", ["du_lieu"],
   "4 khoảng", "NGHI_CUOI_TUAN / NGHI_HANG_NGAY / THIEU / THIEU")
def t_dl_gap():
    fri = int(dt.datetime(2026, 1, 9, 20, 55, tzinfo=dt.timezone.utc).timestamp() * 1000); sun = int(dt.datetime(2026, 1, 11, 23, 0, tzinfo=dt.timezone.utc).timestamp() * 1000)
    d1 = int(dt.datetime(2026, 1, 6, 20, 55, tzinfo=dt.timezone.utc).timestamp() * 1000)
    m1 = int(dt.datetime(2026, 1, 6, 10, 0, tzinfo=dt.timezone.utc).timestamp() * 1000)
    r = [DL.phan_loai_khoang("XAUUSD", fri, sun, 300000), DL.phan_loai_khoang("XAUUSD", d1, d1 + 3900000, 300000), DL.phan_loai_khoang("XAUUSD", m1, m1 + 2100000, 300000),
         DL.phan_loai_khoang("BTCUSD", fri, sun, 300000)]
    return r == ["NGHI_CUOI_TUAN_UNG_VIEN", "NGHI_HANG_NGAY_UNG_VIEN", "THIEU_DU_LIEU", "THIEU_DU_LIEU"], r


def _tuan_xau(lech_gio=0):
    """Một tuần XAU M5 giả lập: thứ Hai 00:00 → thứ Sáu 20:55, nghỉ 21:00–22:00 mỗi ngày; thêm thứ Hai tuần sau. lech_gio: dịch toàn bộ (mô phỏng sai múi giờ)."""
    out, t = [], T0
    end = T0 + 7 * 86400000 + 3600000
    while t < end:
        u = dt.datetime.fromtimestamp(t / 1000, dt.timezone.utc)
        mo = not (u.weekday() == 4 and u.hour >= 21) and u.weekday() != 5 and not (u.weekday() == 6 and u.hour < 22) and u.hour != 21
        if mo:
            out.append(dict(t=t + lech_gio * 3600000, o=2000.0, h=2001.0, l=1999.0, c=2000.5))
        t += 300000
    return out


@T("DL-05", "Đường ống dữ liệu", "Độ phủ và phiên: tuần XAU đầy đủ theo lịch giả định → độ phủ 1,0, 0 nến THIẾU; bỏ 10 nến giữa phiên → THIẾU 10, độ phủ giảm đúng; phân bố phiên UTC có đủ 4 nhóm", ["du_lieu"],
   "tuần XAU giả lập", "1,0; THIẾU 10")
def t_dl_cov():
    w = _tuan_xau(); a = DL.kiem_ohlcv(w, "XAUUSD")
    w2 = w[:500] + w[510:]; b = DL.kiem_ohlcv(w2, "XAUUSD")
    ok = a["do_phu"] == 1.0 and a["nen_thieu"] == 0 and b["nen_thieu"] == 10 and gan(b["do_phu"], len(w2) / len(w), 1e-6) and all(v > 0 for v in a["phien"].values())
    return ok, dict(day_du=(a["do_phu"], a["nen_thieu"], a["nen_nghi_ung_vien"]), thieu=(b["do_phu"], b["nen_thieu"]), phien=a["phien"])


@T("DL-06", "Đường ống dữ liệu", "Phát hiện lệch múi giờ: cùng tuần XAU bị dịch +5 giờ (khai nhầm múi giờ) → cảnh báo khoảng nghỉ ≥ 24 giờ không rơi vào cuối tuần UTC", ["du_lieu"], "dịch +5 giờ", "có cảnh báo; bản đúng không cảnh báo")
def t_dl_tz():
    a = DL.kiem_ohlcv(_tuan_xau(), "XAUUSD"); b = DL.kiem_ohlcv(_tuan_xau(5), "XAUUSD")
    co = lambda r: any("múi giờ" in c for c in r["canh_bao"])      # noqa: E731
    return not co(a) and co(b), dict(dung=a["canh_bao"], lech=b["canh_bao"])


@T("DL-07", "Đường ống dữ liệu", "Chuẩn hóa: sắp xếp, bỏ dòng trùng giống hệt, KHÔNG sửa giá, KHÔNG lấp khoảng trống", ["du_lieu"], "12 nến xáo trộn + 2 trùng + 1 khoảng", "12 nến, giá giữ nguyên, khoảng còn")
def t_dl_norm():
    s = [dict(t=T0 + 300000 * i, o=2000.0 + i, h=2001.0 + i, l=1999.0 + i, c=2000.5 + i) for i in range(13) if i != 6]
    x = s[::-1] + [dict(s[2]), dict(s[3])]
    n = DL.chuan_hoa(x)
    return [b["t"] for b in n] == [b["t"] for b in s] and all(a == b for a, b in zip(n, s)), dict(so_nen=len(n), khoang=[b["t"] for b in n][5:7])


@T("DL-08", "Đường ống dữ liệu", "Phát hiện cột TradingView: không giả định có đủ plot – file chỉ OHLC → 'KHÔNG'; có đủ ô 1 → 'MỘT PHẦN' kèm giới hạn K.5 (ô đầy làm mất sự kiện SHADOW, thiếu mã SU, thiếu giá)", ["du_lieu"],
   "2 header", "KHÔNG / MỘT PHẦN")
def t_dl_tvcols():
    a = DL.phat_hien_cot_tv(["time", "open", "high", "low", "close"])
    b = DL.phat_hien_cot_tv(["time", "open", "high", "low", "close"] + [f"Ô1 {f}" for f in ("phút BOS", "phút base", "khung × chiều", "trạng thái setup", "lý do")])
    return a["co_the_doi_chieu"] == "KHÔNG" and b["co_the_doi_chieu"].startswith("MỘT PHẦN") and len(b["gioi_han"]) == 3, (a["co_the_doi_chieu"], b["co_the_doi_chieu"])


@T("DL-09", "Đường ống dữ liệu", "Chạy ô với file CSV thật về định dạng (dữ liệu tổng hợp ghi ra đĩa): bước 1–3 chạy (PASS/WARN), bước 4–9 BLOCKED – không bịa kết quả", ["du_lieu", "pipeline"], "tuần XAU ghi CSV kiểu TV", "1–3 chạy; 4–9 BLOCKED")
def t_dl_cell():
    p = os.path.join(OUT, "_tam_tuan_xau_tv.csv")
    open(p, "w", encoding="utf-8").write(_csv_tv([(b["t"], b["o"], b["h"], b["l"], b["c"]) for b in _tuan_xau()]))
    bc = PL.chay_o("XAUUSD", "SU5", (p, "TV", None))
    os.remove(p)
    st = [b["trang_thai"] for b in bc["buoc"]]
    return st[:3] == ["PASS", "PASS", "PASS"] and all(x == "BLOCKED" for x in st[3:]), st

# ================================================================================================ TOKEN GATE
GATE = {}


def _gate():
    if not GATE:
        GATE["r"] = TG.chay(P38, P39)
    return GATE["r"]


@T("TG-01", "Token Gate", "Phân tích 0.3.9: 82 hàm; hàm không gọi f_srcList, f_srcPush kèm bằng chứng (dòng định nghĩa, tham chiếu ngoài thân chỉ từ hàm chết); 8 request.security, 4 lệnh kéo f_struct", ["cong_token"],
   "0.3.8 → 0.3.9", "đúng như mô tả")
def t_tg_struct():
    r = _gate(); p = r["phan_tich_candidate"]
    sec = p["request_security"]
    ok = p["so_ham"] == 82 and p["ham_khong_goi"] == ["f_srcList", "f_srcPush"] and p["bang_chung_ham_chet"]["f_srcList"]["tham_chieu_ngoai_than"] == []
    ok = ok and p["bang_chung_ham_chet"]["f_srcPush"]["chi_duoc_goi_boi_ham_chet"] and len(sec) == 8 and sum("f_struct" in s["ham_trong_bieu_thuc"] for s in sec) == 4
    return ok, dict(so_ham=p["so_ham"], chet=p["bang_chung_ham_chet"], security=[(s["dong"], s["ham_trong_bieu_thuc"]) for s in sec])


@T("TG-02", "Token Gate", "Ước lượng: nhiều mô hình, hiệu chỉnh trên điểm FAIL duy nhất có số thật; mô hình 'lex' và 'once' MÂU THUẪN với quan sát; ≥ 2 mô hình nhất quán; trạng thái ESTIMATE kèm khoảng và bất định – không có số 'token thật'", ["cong_token"],
   "5 quan sát compile", "lex/once mâu thuẫn; ≥ 2 nhất quán; ESTIMATE")
def t_tg_models():
    u = _gate()["uoc_luong"]
    ok = u["trang_thai"] == "ESTIMATE" and not u["mo_hinh"]["lex"]["nhat_quan"] and not u["mo_hinh"]["once"]["nhat_quan"] and len(u["mo_hinh_nhat_quan"]) >= 2 and u["so_diem_so_that"] == 1 and len(u["bat_dinh"]) >= 3
    return ok, dict(muc=u["muc"], khoang=u["khoang_uoc_luong"], du_dia=u["du_dia_khoang"], nhat_quan=u["mo_hinh_nhat_quan"])


@T("TG-03", "Token Gate", "Độ nhạy của cổng (chuỗi trong bộ nhớ, KHÔNG ghi file Pine, KHÔNG dùng để đo trên TradingView): thêm câu lệnh vào f_struct → cảnh báo 'hàm bị request.security kéo theo'; thêm hàm không gọi → nhận diện là hàm chết", ["cong_token"],
   "2 biến thể văn bản", "cảnh báo + hàm chết")
def t_tg_sens():
    s = open(P39, encoding="utf-8").read()
    i = s.index("f_struct(simple int N"); j = s.index("\n", i)
    s1 = s[:j + 1] + "    float _thu = 1.0 + 2.0\n" + s[j + 1:]
    s2 = s + "\nf_khongGoi(int a) =>\n    a + 1\n"
    pb = TG.phan_tich(s)
    c1 = TG.so_sanh(pb, TG.phan_tich(s1)); p2 = TG.phan_tich(s2)
    ok = any("request.security" in c for c in c1["canh_bao"]) and "f_khongGoi" in p2["ham_khong_goi"]
    return ok, dict(canh_bao=c1["canh_bao"], chet=p2["ham_khong_goi"])


@T("TG-04", "Token Gate", "Kiểm mô hình cũ (F20): tên 'sec8' giả định 8 bản f_struct nhưng chỉ 4 lệnh request.security gọi f_struct; hệ số 1 tham số khớp được nhiều công thức → khoảng ước lượng rộng (> 3.000 token)", ["cong_token"],
   "0.3.9", "4 lệnh gọi; khoảng > 3.000")
def t_tg_old():
    u = _gate()["uoc_luong"]
    w = u["khoang_uoc_luong"][1] - u["khoang_uoc_luong"][0]
    return u["n_goi_f_struct_qua_security"] == 4 and w > 3000, dict(n_goi=u["n_goi_f_struct_qua_security"], do_rong=w, khoang=u["khoang_uoc_luong"])


@T("TG-05", "Token Gate", "Cổng chỉ đọc: SHA 0.3.8 và 0.3.9 không đổi sau khi chạy; CLI trả mã 0 và ghi token_gate.json hợp lệ (allow_nan=False)", ["cong_token"], "chạy CLI", "SHA giữ nguyên, exit 0")
def t_tg_ro():
    a = (sha_f(P38), sha_f(P39))
    rc = subprocess.run([sys.executable, os.path.join(G, "token_budget", "cong_token.py")], capture_output=True, text=True).returncode
    json.load(open(os.path.join(OUT, "token_gate", "token_gate.json"), encoding="utf-8"))
    return rc == 0 and a == (sha_f(P38), sha_f(P39)) == (SHA38, SHA39), dict(rc=rc, sha=[x[:12] for x in a])

# ================================================================================================ ĐỘT BIẾN (bản cũ phải bị bắt)


def _cu(ten):
    spec = importlib.util.spec_from_file_location(ten + "_cu", os.path.join(D, "_truoc_sua", ten + ".py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


MUT_KQ = {}


def _dot_bien(mod, attr, cu, tests):
    goc = getattr(mod, attr); setattr(mod, attr, cu)
    try:
        r = {}
        for t in tests:
            try:
                ok, _ = t.fn()
                r[t.tid] = "PASS" if ok is True else "FAIL"
            except Exception:      # noqa: BLE001
                r[t.tid] = "FAIL(ngoại lệ)"
    finally:
        setattr(mod, attr, goc)
    return r


@T("MUT-01", "Đột biến", "Thay khong_chong bằng bản TRƯỚC SỬA → PF-01 phải FAIL (bộ test bắt được F1)", ["mo_phong_lenh"], "monkeypatch bản cũ", "PF-01 FAIL")
def t_mut1():
    r = _dot_bien(MP, "khong_chong", _cu("mo_phong_lenh").khong_chong, [t_pf_nofill]); return r["PF-01"] != "PASS", r


@T("MUT-02", "Đột biến", "Thay khu_trung bằng bản TRƯỚC SỬA → DUP-01 hoặc DUP-02 phải FAIL (F2)", ["mo_phong_lenh"], "monkeypatch bản cũ", "≥ 1 FAIL")
def t_mut2():
    r = _dot_bien(MP, "khu_trung", _cu("mo_phong_lenh").khu_trung, [t_dup_order, t_dup_err]); return any(v != "PASS" for v in r.values()), r


@T("MUT-03", "Đột biến", "Thay mo_phong bằng bản TRƯỚC SỬA → R1R2-03 (F4), R1R2-06 (F6), R1R2-07 (F5), OT-05 (F8), MM-02 (F3) đều FAIL", ["mo_phong_lenh"], "monkeypatch bản cũ", "5/5 FAIL")
def t_mut3():
    r = _dot_bien(MP, "mo_phong", _cu("mo_phong_lenh").mo_phong, [t_r2_tp, t_r2_nonext, t_invalid_risk, t_ot_bad, t_mm_conflict]); return all(v != "PASS" for v in r.values()), r


@T("MUT-04", "Đột biến", "Thay hieu_qua / phieu bằng bản TRƯỚC SỬA → CS-01 (hòa vốn), CS-02 (PF ∞), CS-07 (trùng) FAIL", ["chi_so"], "monkeypatch bản cũ", "3/3 FAIL")
def t_mut4():
    cu = _cu("chi_so")
    r = _dot_bien(CS, "hieu_qua", cu.hieu_qua, [t_cs_def, t_cs_pf]); r.update(_dot_bien(CS, "phieu", cu.phieu, [t_cs_funnel])); return all(v != "PASS" for v in r.values()), r


@T("MUT-05", "Đột biến", "Thay kiem bằng bản TRƯỚC SỬA → HD-02 (NaN/∞) và HD-04 (ts ↔ ts_ms) FAIL", ["hop_dong"], "monkeypatch bản cũ", "2/2 FAIL")
def t_mut5():
    r = _dot_bien(HD, "kiem", _cu("hop_dong").kiem, [t_hd_finite, t_hd_ts]); return all(v != "PASS" for v in r.values()), r

# ================================================================================================ BASELINE, HỒI QUY, CHƯA LÀM ĐƯỢC


@T("BL-01", "Bảo vệ baseline", "Source Pine 0.3.8 và 0.3.9 không đổi (SHA-256) sau toàn bộ lượt chạy", [], "SHA", f"{SHA38[:12]}… / {SHA39[:12]}…")
def t_bl():
    a, b = sha_f(P38), sha_f(P39)
    return a == SHA38 and b == SHA39, (a[:16], b[:16])


# Phân loại assertion cũ đã LỖI THỜI (không sửa test cũ) – mỗi mục: lý do + test thay thế
LOI_THOI = {
    "HD-01": ("Hợp đồng 1.1 bắt buộc emit_seq (bản ghi mẫu cũ không có) và trả lỗi sớm khi outcome ngoài danh mục (bản ghi sai cũ kỳ vọng đúng 4 lỗi).", "HD-01, HD-03, HD-05, HD-07, HD-08 (bộ mới)"),
    "E2E-01": ("Fixture cũ gán trigger_ts cố định '2026-01-01T00:00:00Z' không khớp trigger_ts_ms (F17) và thiếu emit_seq – bộ kiểm 1.1 bắt đúng lỗi này.", "E2E-01, E2E-02, RP-03, RP-04 (bộ mới)"),
    "DUP-01": ("Tín hiệu mẫu cũ không có emit_seq; khu_trung 1.1 từ chối đoán thứ tự (F2).", "DUP-01…DUP-04 (bộ mới)"),
}


SHIM = r"""
import sys, os, json
sys.path.insert(0, %r)
import mo_phong_lenh as MP
_goc = MP.khu_trung
def _shim(sg):
    # SHIM TƯƠNG THÍCH (chỉ dùng trong REG-01b): tín hiệu thiếu emit_seq được gán emit_seq = vị trí trong danh sách đầu vào
    # (bộ cũ liệt kê tín hiệu theo thứ tự phát). Không đổi logic khử trùng; không sửa file test cũ.
    if all("emit_seq" not in x for x in sg):
        sg = [dict(x, emit_seq=i) for i, x in enumerate(sg)]
    return _goc(sg)
MP.khu_trung = _shim
import importlib.util
spec = importlib.util.spec_from_file_location("bo_cu", %r)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
try:
    m.main()
except SystemExit:
    pass
"""


@T("REG-01", "Hồi quy", "Chạy LẠI bộ Stage 3 cũ (shadow_eval/kiem_thu_shadow_eval.py, KHÔNG sửa) trên module mới. (a) chạy nguyên trạng; (b) chạy với shim tương thích emit_seq ở tầng harness để các assertion sau điểm dừng vẫn được thực thi. Mọi FAIL / điểm dừng phải thuộc danh sách lỗi thời đã phân loại, có test thay thế",
   ["kiem_thu_stage3"], "bộ cũ 22 test", "(a) dừng tại DUP-01 (lỗi thời); (b) FAIL ⊆ {HD-01, E2E-01}")
def t_reg_old():
    kq = os.path.join(G, "ket_qua_shadow_eval", "ket_qua.json")
    bk = os.path.join(G, "ket_qua_shadow_eval", "ket_qua_truoc_sua.json")
    if not os.path.exists(bk):
        open(bk, "wb").write(open(kq, "rb").read())
    old = os.path.join(D, "kiem_thu_shadow_eval.py")
    try:
        os.remove(kq)
        pa = subprocess.run([sys.executable, old], capture_output=True, text=True, cwd=G)
        a_co_file = os.path.exists(kq)
        dung = [l for l in pa.stdout.splitlines() if l.startswith("[")]
        loi_a = (pa.stderr.strip().splitlines() or [""])[-1]
        pb = subprocess.run([sys.executable, "-c", SHIM % (D, old)], capture_output=True, text=True, cwd=G)
        r = json.load(open(kq, encoding="utf-8"))["ket_qua"] if os.path.exists(kq) else []
        if r:
            json.dump(dict(chay_a=dict(exit=pa.returncode, ghi_file=a_co_file, test_da_chay=len(dung), loi_cuoi=loi_a), chay_b_shim=r),
                      open(os.path.join(OUT, "hoi_quy_bo_cu_tren_module_moi.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)   # F27: JSON strict
    finally:
        open(kq, "wb").write(open(bk, "rb").read())
    fails = [x["test_id"] for x in r if x["result"] == "FAIL"]
    lot = [f for f in fails if f not in LOI_THOI]
    dem = {}
    for x in r:
        dem[x["result"]] = dem.get(x["result"], 0) + 1
    a_dung_dup = (not a_co_file) and "emit_seq" in loi_a and len(dung) == 10
    ok = bool(r) and len(r) == 22 and a_dung_dup and not lot
    return ok, dict(a=dict(exit=pa.returncode, test_chay_truoc_khi_dung=len(dung), loi=loi_a[:90]), b_shim=dem, fail_b=fails, chua_phan_loai=lot,
                    phan_loai={k: v[0][:70] for k, v in LOI_THOI.items() if k in fails or k == "DUP-01"})


@T("REG-02", "Hồi quy", "Chạy LẠI bộ 0.3.9 đầy đủ (kiem_toan039/chay_tat_ca_039.sh) trên BẢN SAO cây thư mục: kết quả trùng lần chạy gốc (47 PASS / 1 FAIL lịch sử T-01 / 7 BLOCKED / 1 NOT TESTED)", [],
   "bản sao /tmp/reg039", "bộ 0.3.9: trùng từng test (47/1/7/1; T-01 là FAIL lịch sử đã bị compile thật bác bỏ); bộ 0.3.8 trên 0.3.9: trùng đếm (67/9/5/1, FAIL lịch sử đã phân loại ở 0.3.9)")
def t_reg_039():
    p = "/tmp/reg039/ket_qua039/ket_qua_039.json"
    if not os.path.exists(p) or not os.path.exists("/tmp/reg039_stdout.txt") or "rc=" not in open("/tmp/reg039_stdout.txt").read():
        return "BLOCKED", "lần chạy hồi quy 0.3.9 chưa xong"
    moi = json.load(open(p, encoding="utf-8")); goc = json.load(open(os.path.join(G, "ket_qua039", "ket_qua_039.json"), encoding="utf-8"))
    f_moi = sorted(x["test_id"] for x in moi["results"] if x["result"] == "FAIL")
    kq_moi = {x["test_id"]: x["result"] for x in moi["results"]}; kq_goc = {x["test_id"]: x["result"] for x in goc["results"]}
    import ast, re as _re
    def dem_038(path):
        m = [l for l in open(path, encoding="utf-8").read().splitlines() if l.startswith("{'PASS'")]
        return _re.sub(r"\} [0-9.]+ s$", "}", m[-1]) if m else None
    d_moi = dem_038("/tmp/reg039/ket_qua039/hoi_quy_bo_038_tren_039/nhat_ky.txt"); d_goc = dem_038(os.path.join(G, "ket_qua039", "hoi_quy_bo_038_tren_039", "nhat_ky.txt"))
    ok038 = d_moi is not None and ast.literal_eval(d_moi) == ast.literal_eval(d_goc)
    return ok038 and moi["summary"]["counts"] == goc["summary"]["counts"] and f_moi == ["T-01"] and kq_moi == kq_goc, dict(bo_038_tren_039=dict(moi=d_moi, goc=d_goc),moi=moi["summary"]["counts"], goc=goc["summary"]["counts"], fail=f_moi,
                                                                                                                    khac_tung_test=[k for k in kq_goc if kq_moi.get(k) != kq_goc[k]])


BLOCKED = [("REAL-XAU-SU3", "Đánh giá SU-3 trên dữ liệu thật XAUUSD"), ("REAL-XAU-SU5", "Đánh giá SU-5 trên dữ liệu thật XAUUSD"),
           ("REAL-BTC-SU3", "Đánh giá SU-3 trên dữ liệu thật BTCUSD"), ("REAL-BTC-SU5", "Đánh giá SU-5 trên dữ liệu thật BTCUSD")]


def main():
    t0 = time.time()
    for t in TESTS:
        t()
    st = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    for tid, mo in BLOCKED:
        KQ.append(dict(test_id=tid, nhom="Thị trường thật", muc_tieu=mo, input="—", expected="chỉ số theo ô", actual="Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực",
                       status="BLOCKED", evidence="ket_qua_stage3/o_*/bao_cao_o.json", test_source="pipeline.chay_o", version={}, run_time=st, duration_ms=0, hash="-"))
    KQ.append(dict(test_id="REPLAY-EQ", nhom="Tương đương", muc_tieu="Python replay ↔ TradingView", input="—", expected="khớp sự kiện từng nến",
                   actual="Chưa có dữ liệu đối chứng từ TradingView; Data Window chỉ chứa một phần sự kiện SHADOW (K.5) – không tuyên bố PASS", status="BLOCKED",
                   evidence="du_lieu.phat_hien_cot_tv", test_source="—", version={}, run_time=st, duration_ms=0, hash="-"))
    KQ.append(dict(test_id="TV-TOKEN", nhom="Token", muc_tieu="Token biên dịch thật của 0.3.9", input="—", expected="số token", actual="TradingView không in số token khi compile thành công",
                   status="BLOCKED", evidence="token_budget/quan_sat_compile.json", test_source="—", version={}, run_time=st, duration_ms=0, hash="-"))
    for tid, mo, ly in (("REPLAY-FULL", "Replay toàn script từ OHLCV (f_struct, MD-3, MD-4, MD-5, request.security)", "Chưa hiện thực – ngoài phạm vi nhiệm vụ (không tự xây full Pine interpreter)"),
                        ("DL-REAL-FILE", "Nhập file xuất thật từ TradingView / MT5 Exness", "Chưa có file thật; định dạng được kiểm bằng file tổng hợp (DL-01, DL-02, DL-09)"),
                        ("FUNNEL-REAL", "Phễu SU-3/SU-5 trên dữ liệu thật", "Phụ thuộc REPLAY-FULL và dữ liệu thật")):
        KQ.append(dict(test_id=tid, nhom="Chưa kiểm", muc_tieu=mo, input="—", expected="—", actual=ly, status="NOT TESTED", evidence="—", test_source="—", version={}, run_time=st, duration_ms=0, hash="-"))
    dem = {}
    for x in KQ:
        dem[x["status"]] = dem.get(x["status"], 0) + 1
    tong = dict(tom_tat=dem, so_test=len(KQ), thoi_gian_s=round(time.time() - t0, 1), python=sys.version.split()[0], phien_ban_module=VER,
                baseline=dict(v038=sha_f(P38), v039=sha_f(P39)), ket_qua=KQ)
    json.dump(tong, open(os.path.join(OUT, "ket_qua_kiem_thu.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)
    with open(os.path.join(OUT, "ket_qua_kiem_thu.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f); w.writerow(["test_id", "nhom", "status", "muc_tieu", "duration_ms", "hash", "test_source"])
        for x in KQ:
            w.writerow([x["test_id"], x["nhom"], x["status"], x["muc_tieu"], x["duration_ms"], x["hash"], x["test_source"]])
    print(dem, f"{tong['thoi_gian_s']} s")
    sys.exit(1 if dem.get("FAIL") else 0)


if __name__ == "__main__":
    main()
