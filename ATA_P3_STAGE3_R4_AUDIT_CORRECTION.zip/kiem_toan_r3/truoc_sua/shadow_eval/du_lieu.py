# -*- coding: utf-8 -*-
"""ĐƯỜNG ỐNG DỮ LIỆU OHLCV: nhập → kiểm → chuẩn hóa (UTC ms). Ngoài Pine.

Định dạng nhập hỗ trợ
  • TV  – TradingView "Export chart data": CSV có header, cột time (Unix giây, hoặc ISO-8601 có/không múi giờ), open, high, low, close, [cột khác].
          Cột plot/Data Window có thể có hoặc không – KHÔNG giả định (xem phat_hien_cot_tv).
  • MT5 – MetaTrader 5 xuất lịch sử: tách bằng TAB hoặc dấu phẩy, header <DATE> <TIME> <OPEN> <HIGH> <LOW> <CLOSE> [...]; ngày YYYY.MM.DD,
          giờ HH:MM[:SS] theo GIỜ MÁY CHỦ → cần lech_phut (giờ máy chủ − UTC, phút). Không đoán múi giờ: thiếu tham số → lỗi.
Kiểm (kiem_ohlcv): giá hữu hạn > 0; High ≥ max(Open, Close); Low ≤ min(Open, Close); thời gian tròn theo khung; thứ tự; trùng (giống hệt / mâu thuẫn);
khoảng trống (phân loại ỨNG VIÊN nghỉ thị trường vs THIẾU DỮ LIỆU theo lịch GIẢ ĐỊNH, chưa xác minh với lịch broker); độ phủ; phân bố phiên;
dấu hiệu lệch múi giờ (XAU: khoảng nghỉ cuối tuần phải bắt đầu tối thứ Sáu UTC)."""
import csv, datetime as _dt, io, math

TF_MS = {"1": 60000, "5": 300000, "15": 900000, "60": 3600000}
PHIEN = (("A_CHAU", 0, 7), ("LONDON", 7, 13), ("NEW_YORK", 13, 21), ("CUOI_NGAY", 21, 24))   # giờ UTC – nhãn GIẢ ĐỊNH


def _so(x):
    try:
        v = float(str(x).strip())
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _ms_tv(s):
    s = str(s).strip()
    v = _so(s)
    if v is not None:
        return int(round(v * 1000)) if v < 1e11 else int(round(v))      # giây hoặc ms
    s2 = s.replace("Z", "+00:00")
    try:
        t = _dt.datetime.fromisoformat(s2)
    except ValueError:
        return None
    if t.tzinfo is None:
        return "NO_TZ"
    return int(t.timestamp() * 1000)


def nhap(van_ban, dinh_dang, lech_phut=None, mui_gio_mac_dinh_utc=False):
    """Trả (bars, loi_dong). bars: list dict(t, o, h, l, c) theo thứ tự trong file (chưa sắp xếp, chưa khử trùng)."""
    bars, loi = [], []
    if dinh_dang == "TV":
        rd = csv.DictReader(io.StringIO(van_ban))
        cot = {c.strip().lower(): c for c in (rd.fieldnames or [])}
        thieu = [c for c in ("time", "open", "high", "low", "close") if c not in cot]
        if thieu:
            return [], [f"header thiếu cột {thieu}"]
        for i, row in enumerate(rd, start=2):
            t = _ms_tv(row[cot["time"]])
            if t == "NO_TZ":
                if not mui_gio_mac_dinh_utc:
                    loi.append(f"dòng {i}: thời gian không có múi giờ (không đoán)"); continue
                t = int(_dt.datetime.fromisoformat(row[cot["time"]].strip()).replace(tzinfo=_dt.timezone.utc).timestamp() * 1000)
            v = [_so(row[cot[c]]) for c in ("open", "high", "low", "close")]
            if t is None or None in v:
                loi.append(f"dòng {i}: không đọc được số/thời gian"); continue
            bars.append(dict(t=t, o=v[0], h=v[1], l=v[2], c=v[3]))
        return bars, loi
    if dinh_dang == "MT5":
        if lech_phut is None:
            return [], ["MT5: thiếu lech_phut (giờ máy chủ − UTC) – không đoán múi giờ"]
        dong = van_ban.splitlines()
        if not dong:
            return [], ["file rỗng"]
        sep = "\t" if "\t" in dong[0] else ","
        hd = [h.strip().strip("<>").upper() for h in dong[0].split(sep)]
        try:
            ix = {k: hd.index(k) for k in ("DATE", "TIME", "OPEN", "HIGH", "LOW", "CLOSE")}
        except ValueError:
            return [], [f"header MT5 không đúng: {hd}"]
        for i, ln in enumerate(dong[1:], start=2):
            if not ln.strip():
                continue
            p = ln.split(sep)
            try:
                hm = p[ix["TIME"]].strip()
                t = _dt.datetime.strptime(p[ix["DATE"]].strip() + " " + (hm if hm.count(":") == 2 else hm + ":00"), "%Y.%m.%d %H:%M:%S").replace(tzinfo=_dt.timezone.utc)
                ms = int(t.timestamp() * 1000) - lech_phut * 60000
            except (ValueError, IndexError):
                loi.append(f"dòng {i}: ngày/giờ hỏng"); continue
            v = [_so(p[ix[c]]) if ix[c] < len(p) else None for c in ("OPEN", "HIGH", "LOW", "CLOSE")]
            if None in v:
                loi.append(f"dòng {i}: không đọc được số"); continue
            bars.append(dict(t=ms, o=v[0], h=v[1], l=v[2], c=v[3]))
        return bars, loi
    return [], [f"định dạng không hỗ trợ: {dinh_dang}"]


def _utc(ms):
    return _dt.datetime.fromtimestamp(ms / 1000, _dt.timezone.utc)


def phan_loai_khoang(symbol, t_a, t_b, tf_ms):
    """Khoảng trống giữa nến t_a và nến kế t_b (mở nến). Phân loại ỨNG VIÊN theo lịch GIẢ ĐỊNH:
    XAUUSD: nghỉ cuối tuần (bắt đầu thứ Sáu ≥ 20:00 UTC, kết thúc Chủ nhật/thứ Hai) → NGHI_CUOI_TUAN_UNG_VIEN;
            nghỉ hằng ngày ≤ 75 phút bắt đầu 20:00–23:00 UTC → NGHI_HANG_NGAY_UNG_VIEN; còn lại → THIEU_DU_LIEU.
    BTCUSD: giao dịch 24/7 → mọi khoảng là THIEU_DU_LIEU (có thể do bảo trì broker – không xác minh được)."""
    a, b = _utc(t_a + tf_ms), _utc(t_b)          # a = thời điểm lẽ ra có nến kế
    phut = (t_b - t_a - tf_ms) // 60000
    if symbol == "XAUUSD":
        mon = _dt.datetime(a.year, a.month, a.day, tzinfo=_dt.timezone.utc) - _dt.timedelta(days=a.weekday())
        if mon + _dt.timedelta(days=4, hours=20) <= a and b <= mon + _dt.timedelta(days=7, hours=1):
            return "NGHI_CUOI_TUAN_UNG_VIEN"
        if 20 <= a.hour <= 23 and phut <= 75:
            return "NGHI_HANG_NGAY_UNG_VIEN"
    return "THIEU_DU_LIEU"


def kiem_ohlcv(bars, symbol, tf="5"):
    """Kiểm dữ liệu thô (thứ tự trong file). Trả dict báo cáo; trang_thai = PASS / WARN / FAIL."""
    tf_ms = TF_MS[tf]
    bc = dict(symbol=symbol, tf=tf, so_dong=len(bars), nen_hong=[], lech_khung=[], dao_thu_tu=0, trung_giong=0, trung_mau_thuan=[], khoang=[], loi=[], canh_bao=[])
    for b in bars:
        o, h, l, c = b["o"], b["h"], b["l"], b["c"]
        if min(o, h, l, c) <= 0 or h < max(o, c) or l > min(o, c):
            bc["nen_hong"].append(b["t"])
        if b["t"] % tf_ms:
            bc["lech_khung"].append(b["t"])
    bc["dao_thu_tu"] = sum(1 for x, y in zip(bars, bars[1:]) if y["t"] < x["t"])
    theo = {}
    for b in bars:
        theo.setdefault(b["t"], []).append(b)
    for t, bs in theo.items():
        if len(bs) > 1:
            if all((x["o"], x["h"], x["l"], x["c"]) == (bs[0]["o"], bs[0]["h"], bs[0]["l"], bs[0]["c"]) for x in bs):
                bc["trung_giong"] += len(bs) - 1
            else:
                bc["trung_mau_thuan"].append(t)
    ts = sorted(theo)
    for a, b in zip(ts, ts[1:]):
        if b - a > tf_ms:
            bc["khoang"].append(dict(tu=_utc(a).strftime("%Y-%m-%dT%H:%M:%SZ"), den=_utc(b).strftime("%Y-%m-%dT%H:%M:%SZ"), so_nen_thieu=(b - a) // tf_ms - 1,
                                     loai=phan_loai_khoang(symbol, a, b, tf_ms)))
    thieu = sum(k["so_nen_thieu"] for k in bc["khoang"] if k["loai"] == "THIEU_DU_LIEU")
    nghi = sum(k["so_nen_thieu"] for k in bc["khoang"] if k["loai"] != "THIEU_DU_LIEU")
    if ts:
        ky_vong = (ts[-1] - ts[0]) // tf_ms + 1 - nghi
        bc["do_phu"] = round(len(ts) / ky_vong, 6) if ky_vong > 0 else None
        bc["tu"], bc["den"] = _utc(ts[0]).strftime("%Y-%m-%dT%H:%M:%SZ"), _utc(ts[-1]).strftime("%Y-%m-%dT%H:%M:%SZ")
    else:
        bc["do_phu"] = None
    bc["nen_thieu"], bc["nen_nghi_ung_vien"] = thieu, nghi
    bc["phien"] = {n: sum(1 for t in ts if a_ <= _utc(t).hour < b_) for n, a_, b_ in PHIEN}
    if symbol == "XAUUSD":
        cuoi_tuan = [k for k in bc["khoang"] if k["so_nen_thieu"] * tf_ms >= 24 * 3600000]
        lech = [k for k in cuoi_tuan if k["loai"] != "NGHI_CUOI_TUAN_UNG_VIEN"]
        if lech:
            bc["canh_bao"].append(f"{len(lech)} khoảng nghỉ ≥ 24 giờ không rơi vào cuối tuần UTC – nghi lệch múi giờ hoặc thiếu dữ liệu")
    if bc["nen_hong"]:
        bc["loi"].append(f"{len(bc['nen_hong'])} nến hỏng")
    if bc["lech_khung"]:
        bc["loi"].append(f"{len(bc['lech_khung'])} nến không tròn theo khung {tf}")
    if bc["trung_mau_thuan"]:
        bc["loi"].append(f"{len(bc['trung_mau_thuan'])} thời điểm trùng mâu thuẫn")
    if bc["dao_thu_tu"]:
        bc["canh_bao"].append(f"{bc['dao_thu_tu']} lần đảo thứ tự (sẽ sắp xếp lại)")
    if bc["trung_giong"]:
        bc["canh_bao"].append(f"{bc['trung_giong']} dòng trùng giống hệt (sẽ bỏ)")
    if thieu:
        bc["canh_bao"].append(f"{thieu} nến THIEU_DU_LIEU")
    bc["trang_thai"] = "FAIL" if bc["loi"] else ("WARN" if bc["canh_bao"] else "PASS")
    return bc


def chuan_hoa(bars):
    """Sắp xếp theo t, bỏ dòng trùng GIỐNG HỆT. Không sửa giá, không lấp khoảng trống. Gọi sau kiem_ohlcv trạng thái ≠ FAIL."""
    out, seen = [], set()
    for b in sorted(bars, key=lambda x: x["t"]):
        if b["t"] in seen:
            continue
        seen.add(b["t"]); out.append(dict(t=int(b["t"]), o=float(b["o"]), h=float(b["h"]), l=float(b["l"]), c=float(b["c"])))
    return out


def phat_hien_cot_tv(header):
    """Cột nào của hợp đồng có thể đối chiếu từ một file TV export. Không giả định có đủ plot Data Window."""
    h = [x.strip() for x in header]
    co = lambda n: n in h      # noqa: E731
    o_ = {f"Ô{i}": all(co(f"Ô{i} {f}") for f in ("phút BOS", "phút base", "khung × chiều", "trạng thái setup", "lý do")) for i in (1, 2, 3)}
    return dict(ohlc=all(any(x.lower() == n for x in h) for n in ("time", "open", "high", "low", "close")),
                o_du_lieu=o_, ma_loai_setup=co("MÃ LOẠI SETUP"), gia_tin_hieu_chinh=all(co(n) for n in ("TT P_ref", "TT SL", "TT TP1")),
                gioi_han=["Sự kiện SHADOW chỉ điền ô còn trống sau sự kiện actionable (tối đa 3 ô) – có thể mất khi ô đầy",
                          "Ô không có mã SU-3/SU-5 riêng; 'MÃ LOẠI SETUP' chỉ cho tín hiệu chính",
                          "Ô không có P_ref/SL/TP1 của sự kiện SHADOW → không tái lập SIGNALS đầy đủ từ CSV"],
                co_the_doi_chieu="MỘT PHẦN (trạng thái/lý do/khóa vùng của sự kiện còn ô)" if any(o_.values()) else "KHÔNG")
