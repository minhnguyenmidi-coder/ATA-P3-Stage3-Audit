# -*- coding: utf-8 -*-
"""DATA CONTRACT – Shadow Evaluation ATA P3, schema 1.1 (Stage 3 – Audit Correction). Ngoài Pine.
Ba bảng (JSONL, UTF-8): EVENTS (vòng đời), SIGNALS (trigger + S1), TRADES (kết quả giả lập).

QUY ƯỚC
  • Thời gian: chuỗi ISO-8601 UTC 'YYYY-MM-DDTHH:MM:SSZ' = thời điểm MỞ nến, kèm số nguyên ms Unix; hai giá trị phải trùng nhau,
    ms chia hết cho 60 000 (nến phút).
  • Số thực phải HỮU HẠN (không NaN/Infinity). Giá trị không xác định (Pine na) = null. JSON xuất phải dùng allow_nan=False.
  • emit_seq: số nguyên tăng dần, duy nhất trong một lượt replay, theo thứ tự engine phát sự kiện (nến trước → sau; trong nến theo thứ tự
    đẩy vào evS). Là thứ tự THẬT dùng cho khử trùng; không dùng băm để xếp thứ tự.
  • Mã trạng thái/lý do giữ nguyên mã engine (2 CHỜ, 4 BỎ QUA, 5 HẾT HẠN, 6 VÔ HIỆU, 8 BẤT BIẾN, 17 SHADOW; lý do 0…16).
  • Ngoại lệ đã định nghĩa của TRADES: OPEN (đã vào, chưa đóng: exit = null); NO_FILL / NO_DATA / INVALID (không vào: risk, R, MFE, MAE,
    exit = null; fill_note bắt buộc).
Thay đổi so với 1.0: thêm emit_seq (EVENTS, SIGNALS bắt buộc), TRADES thêm symbol/setup/emit_seq/fill_note/time_gaps/max_gap_ms, outcome thêm
NO_DATA/INVALID, risk/R/MFE/MAE cho phép null theo ngoại lệ; bổ sung kiểm hữu hạn, ts↔ts_ms, hình học, nhất quán R, và kiểm cấp bảng.
Thay đổi 1.2: TRADES thêm rr_entry (tùy chọn); fill_note tách NO_DATA trước/sau khi vào; kiểm cấp bảng gọi máy trạng thái (may_trang_thai.py)."""
import datetime as _dt
import hashlib, math, re
import may_trang_thai as MT

SCHEMA_VERSION = "1.2"
SCHEMA_CHAP_NHAN = ("1.0", "1.1", "1.2")
TS = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
SYMBOLS = ("XAUUSD", "BTCUSD")
SETUPS = ("SU3", "SU5")
SOURCES = ("PY_REPLAY", "TV_EXPORT", "SYNTH")
EVENT_TYPES = ("CREATED", "STEP", "ARMED", "TRIGGER", "VOID", "EXPIRED", "SKIP", "END_NO_EVENT")
KET_THUC = ("TRIGGER", "VOID", "EXPIRED", "SKIP", "END_NO_EVENT")
OUTCOMES = ("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")
DONG = ("TP1", "SL", "TIMEOUT")
DA_VAO = DONG + ("OPEN",)
KHONG_VAO = ("NO_FILL", "NO_DATA", "INVALID")
FILL_NOTES = ("GAP_BEYOND_SL", "GAP_BEYOND_TP", "NO_NEXT_BAR", "INVALID_BAR", "INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_TIME_AFTER_FILL",
              "INVALID_SIGNAL", "INVALID_RISK", "TP_WRONG_SIDE")
LY_DO_SIGNAL = (16, 8, 15, 14, 9, 1, 2)
CHI_PHI = re.compile(r"^C-s([0-9.]+)-c([0-9.]+)-sl([0-9.]+)$")      # mã chi phí do mo_phong_lenh.Cfg.cost_id() sinh
EPS = 1e-9

EVENTS = [("schema_version", str, True, "phiên bản hợp đồng"), ("engine_version", str, True, "ví dụ 0.3.9"), ("source", str, True, "PY_REPLAY / TV_EXPORT / SYNTH"),
          ("symbol", str, True, "XAUUSD / BTCUSD"), ("tf", str, True, "khung chạy engine, ví dụ 5"), ("setup", str, True, "SU3 / SU5"), ("mode", str, True, "SHADOW"),
          ("setup_id", str, True, "băm xác định của thể hiện (symbol, setup, dir, khóa lúc tạo, ts tạo, thứ tự trong nến)"),
          ("event_id", str, True, "băm (setup_id, event_type, ts_ms, emit_seq)"), ("emit_seq", int, True, "thứ tự phát (xem quy ước)"),
          ("event_type", str, True, "CREATED/STEP/ARMED/TRIGGER/VOID/EXPIRED/SKIP/END_NO_EVENT"), ("step", int, False, "bước J.2/J.4 (st của thể hiện)"),
          ("ts", str, True, "thời điểm mở nến M5 xử lý sự kiện (UTC)"), ("ts_ms", int, True, "như trên, ms"), ("dir", int, True, "+1 BUY / −1 SELL"),
          ("state", int, True, "mã trạng thái engine"), ("reason", int, True, "mã lý do engine"), ("anchor_price", float, False, "SU-3 MỐC / SU-5 Lv"),
          ("ext_price", float, False, "SU-3 ĐÁY/ĐỈNH FINAL / SU-5 A")]
SIGNALS = [("schema_version", str, True, ""), ("engine_version", str, True, ""), ("source", str, True, ""), ("symbol", str, True, ""), ("setup", str, True, ""),
           ("setup_id", str, True, ""), ("signal_id", str, True, "băm (setup_id, trigger_ts_ms)"), ("emit_seq", int, True, "thứ tự phát của sự kiện TRIGGER"),
           ("dir", int, True, ""), ("trigger_ts", str, True, "nến trigger (UTC, mở nến)"), ("trigger_ts_ms", int, True, ""), ("p_ref", float, True, "Close nến trigger"),
           ("sl", float, True, ""), ("tp1", float, False, "na → null"), ("rr", float, False, "|TP1 − P_ref| / |P_ref − SL|"),
           ("reason", int, True, "16 = đạt S1; 8/15/14/9/1/2 = bị bỏ"), ("perm_reg", int, False, "REG H4 tại trigger"), ("perm_vol", int, False, "lớp VOL tại trigger"),
           ("dup_key", str, True, "'symbol|setup|dir|trigger_ts_ms' – khử trùng IP-21")]
TRADES = [("schema_version", str, True, ""), ("signal_id", str, True, ""), ("symbol", str, False, "sao từ SIGNALS"), ("setup", str, False, "sao từ SIGNALS"),
          ("emit_seq", int, False, "sao từ SIGNALS"), ("sim_rule", str, True, "mã quy tắc giả lập"), ("cost_model", str, True, "mã chi phí"),
          ("entry_ts_ms", int, True, "nến vào (mở nến)"), ("entry_price", float, False, "null khi INVALID_SIGNAL/NO_DATA"), ("risk", float, False, "(entry − SL)×dir > 0; null khi không vào"),
          ("outcome", str, True, "TP1/SL/TIMEOUT/OPEN/NO_FILL/NO_DATA/INVALID"), ("fill_note", str, False, "lý do khi không vào"),
          ("exit_ts_ms", int, False, ""), ("exit_price", float, False, ""), ("r_gross", float, False, ""), ("r_net", float, False, "sau chi phí"),
          ("mfe_r", float, False, "≥ 0"), ("mae_r", float, False, "≤ 0"), ("bars_held", int, True, "số nến đánh giá tới nến thoát"),
          ("same_bar_conflict", bool, True, "nến chạm cả SL và TP1"), ("gap_exit", bool, True, "thoát ở Open do gap"),
          ("time_gaps", int, False, "số khoảng trống thời gian > 1 nến trong cửa sổ"), ("max_gap_ms", int, False, "khoảng trống lớn nhất"),
          ("rr_entry", float, False, "(TP1 − entry)×dir / risk tại giá vào thực; null nếu không TP1 hoặc không vào")]


def hid(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:16]


def ts_tu_ms(ms):
    return _dt.datetime.fromtimestamp(ms / 1000, _dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _huu_han(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _kiem_ts(loi, rec, ten_ts, ten_ms):
    s, ms = rec.get(ten_ts), rec.get(ten_ms)
    if s is None:
        return
    if not TS.match(str(s)):
        loi.append(f"{ten_ts} sai định dạng"); return
    try:
        t = _dt.datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=_dt.timezone.utc)
    except ValueError:
        loi.append(f"{ten_ts} không phải ngày giờ hợp lệ"); return
    if isinstance(ms, int) and not isinstance(ms, bool) and int(t.timestamp() * 1000) != ms:
        loi.append(f"{ten_ts} ≠ {ten_ms} ({s} vs {ts_tu_ms(ms)})")


def kiem(rec, schema):
    """Kiểm MỘT bản ghi. Trả danh sách lỗi (rỗng = hợp lệ)."""
    loi = []
    ten = {n for n, _, _, _ in schema}
    for n, t, bb, _ in schema:
        if n not in rec or rec[n] is None:
            if bb:
                loi.append(f"thiếu {n}")
            continue
        v = rec[n]
        if t is float and isinstance(v, int) and not isinstance(v, bool):
            v = float(v)
        if t in (int, float) and isinstance(v, bool):
            loi.append(f"{n}: bool thay {t.__name__}"); continue
        if not isinstance(v, t):
            loi.append(f"{n}: kiểu {type(v).__name__} ≠ {t.__name__}"); continue
        if t is float and not math.isfinite(v):
            loi.append(f"{n}: không hữu hạn ({v})")
    for n in rec:
        if n not in ten:
            loi.append(f"trường lạ {n}")
    if rec.get("schema_version") is not None and rec["schema_version"] not in SCHEMA_CHAP_NHAN:
        loi.append("schema_version không hỗ trợ")
    for a, b in (("ts", "ts_ms"), ("trigger_ts", "trigger_ts_ms")):
        if a in ten:
            _kiem_ts(loi, rec, a, b)
    for n in ("ts_ms", "trigger_ts_ms", "entry_ts_ms", "exit_ts_ms"):
        v = rec.get(n)
        if isinstance(v, int) and not isinstance(v, bool) and (v < 0 or v % 60000):
            loi.append(f"{n} âm hoặc không tròn phút")
    for n, ds in (("symbol", SYMBOLS), ("setup", SETUPS), ("source", SOURCES), ("event_type", EVENT_TYPES), ("outcome", OUTCOMES)):
        if rec.get(n) is not None and rec[n] not in ds:
            loi.append(f"{n} ngoài danh sách")
    if rec.get("mode") is not None and rec["mode"] != "SHADOW":
        loi.append("mode phải SHADOW")
    if rec.get("dir") is not None and rec["dir"] not in (1, -1):
        loi.append("dir phải ±1")
    if isinstance(rec.get("emit_seq"), int) and rec["emit_seq"] < 0:
        loi.append("emit_seq âm")
    if isinstance(rec.get("state"), int) and not 0 <= rec["state"] <= 17:
        loi.append("state ngoài 0…17")
    if isinstance(rec.get("reason"), int) and not 0 <= rec["reason"] <= 16:
        loi.append("reason ngoài 0…16")
    if loi:
        return loi
    if schema is SIGNALS:
        d, p, sl, tp = rec["dir"], rec["p_ref"], rec["sl"], rec.get("tp1")
        if (p - sl) * d <= 0:
            loi.append("hình học: SL không nằm phía rủi ro của P_ref")
        if tp is not None and (tp - p) * d <= 0:
            loi.append("hình học: TP1 không nằm phía lợi nhuận của P_ref")
        if rec.get("rr") is not None and tp is not None and (p - sl) * d > 0 and abs(rec["rr"] - abs(tp - p) / abs(p - sl)) > 1e-6:
            loi.append("rr ≠ |TP1 − P_ref| / |P_ref − SL|")
        if rec["reason"] not in LY_DO_SIGNAL:
            loi.append("reason của SIGNAL ngoài 16/8/15/14/9/1/2")
        if rec["dup_key"] != f"{rec['symbol']}|{rec['setup']}|{d}|{rec['trigger_ts_ms']}":
            loi.append("dup_key không khớp symbol|setup|dir|trigger_ts_ms")
    if schema is TRADES:
        loi += _kiem_trade(rec)
    return loi


def _kiem_trade(r):
    loi, o = [], r["outcome"]
    num = ("risk", "r_gross", "r_net", "mfe_r", "mae_r")
    if r["bars_held"] < 0:
        loi.append("bars_held âm")
    if o in KHONG_VAO:
        if r.get("fill_note") not in FILL_NOTES:
            loi.append(f"{o}: fill_note thiếu/ngoài danh sách")
        for n in num + ("exit_ts_ms", "exit_price", "rr_entry"):
            if r.get(n) is not None:
                loi.append(f"{o}: {n} phải null")
        if r["bars_held"] != 0:
            loi.append(f"{o}: bars_held phải 0")
        if r["same_bar_conflict"] or r["gap_exit"]:
            loi.append(f"{o}: cờ thoát phải false")
        return loi
    if r.get("fill_note") is not None:
        loi.append(f"{o}: fill_note phải null")
    for n in num + ("entry_price",):
        if r.get(n) is None:
            loi.append(f"{o}: thiếu {n}")
    if loi:
        return loi
    if not r["risk"] > 0:
        loi.append("risk ≤ 0")
    if r["mfe_r"] < 0:
        loi.append("mfe_r < 0")
    if r["mae_r"] > 0:
        loi.append("mae_r > 0")
    if not r["mae_r"] - EPS <= r["r_gross"] <= r["mfe_r"] + EPS:
        loi.append("r_gross ngoài [mae_r, mfe_r]")
    if r["r_net"] > r["r_gross"] + EPS:
        loi.append("r_net > r_gross (chi phí âm)")
    m = CHI_PHI.match(str(r.get("cost_model", "")))
    if m and r["risk"] > 0:
        cp = float(m.group(1)) + float(m.group(2)) + 2 * float(m.group(3))
        if abs((r["r_gross"] - r["r_net"]) - cp / r["risk"]) > 1e-9:
            loi.append("r_gross − r_net ≠ chi phí (theo cost_model) / risk")
    if r["same_bar_conflict"] and r["gap_exit"]:
        loi.append("same_bar_conflict và gap_exit cùng đúng")
    if o == "OPEN":
        if r.get("exit_ts_ms") is not None or r.get("exit_price") is not None:
            loi.append("OPEN: exit phải null")
        return loi
    if r.get("exit_ts_ms") is None or r.get("exit_price") is None:
        loi.append(f"{o}: thiếu exit"); return loi
    if r["exit_ts_ms"] < r["entry_ts_ms"]:
        loi.append("exit_ts_ms < entry_ts_ms")
    if r["bars_held"] < 1:
        loi.append(f"{o}: bars_held < 1")
    if abs(abs(r["r_gross"]) * r["risk"] - abs(r["exit_price"] - r["entry_price"])) > 1e-6 * max(1.0, abs(r["entry_price"])):
        loi.append("|r_gross|×risk ≠ |exit − entry|")
    if o == "SL" and not r["gap_exit"] and abs(r["r_gross"] + 1) > 1e-9:
        loi.append("SL không gap phải r_gross = −1")
    if o == "SL" and r["gap_exit"] and r["r_gross"] > -1 + 1e-9:
        loi.append("SL gap phải r_gross ≤ −1")
    if o == "TP1" and not r["r_gross"] > 0:
        loi.append("TP1 phải r_gross > 0")
    if o == "TIMEOUT" and (r["gap_exit"] or r["same_bar_conflict"]):
        loi.append("TIMEOUT: cờ thoát phải false")
    return loi


def kiem_bang(events, signals, trades, entry_rule=None):
    """Kiểm CẤP BẢNG: bản ghi, trùng ID, thứ tự thời gian, liên kết, nhất quán R/hình học theo tín hiệu. Trả danh sách lỗi."""
    loi = []
    for nm, rows, sc in (("EVENTS", events, EVENTS), ("SIGNALS", signals, SIGNALS), ("TRADES", trades, TRADES)):
        for i, r in enumerate(rows):
            loi += [f"{nm}[{i}] {x}" for x in kiem(r, sc)]
    if loi:
        return loi
    for nm, rows, key in (("EVENTS", events, "event_id"), ("SIGNALS", signals, "signal_id")):
        ids = [r[key] for r in rows]
        if len(set(ids)) != len(ids):
            loi.append(f"{nm}: trùng {key}")
    k3 = [(t["signal_id"], t["sim_rule"], t["cost_model"]) for t in trades]
    if len(set(k3)) != len(k3):
        loi.append("TRADES: trùng (signal_id, sim_rule, cost_model)")
    for nm, rows in (("EVENTS", events), ("SIGNALS", signals)):
        sq = [r["emit_seq"] for r in rows]
        if len(set(sq)) != len(sq):
            loi.append(f"{nm}: trùng emit_seq")
    for nm, rows in (("EVENTS", events), ("SIGNALS", signals)):
        for f in ("engine_version", "source"):
            if len({r[f] for r in rows}) > 1:
                loi.append(f"{nm}: {f} không đồng nhất trong một lô")
    # thứ tự: emit_seq tăng ⇒ thời gian không giảm
    ev = sorted(events, key=lambda r: r["emit_seq"])
    for a, b in zip(ev, ev[1:]):
        if b["ts_ms"] < a["ts_ms"]:
            loi.append(f"EVENTS: emit_seq {b['emit_seq']} có ts_ms nhỏ hơn emit_seq {a['emit_seq']}"); break
    sg = sorted(signals, key=lambda r: r["emit_seq"])
    for a, b in zip(sg, sg[1:]):
        if b["trigger_ts_ms"] < a["trigger_ts_ms"]:
            loi.append("SIGNALS: emit_seq không theo thời gian"); break
    # vòng đời theo setup_id
    theo = {}
    for e in ev:
        theo.setdefault(e["setup_id"], []).append(e)
    for sid, es in theo.items():
        if es[0]["event_type"] != "CREATED":
            loi.append(f"EVENTS {sid}: sự kiện đầu không phải CREATED")
        if sum(e["event_type"] == "CREATED" for e in es) > 1:
            loi.append(f"EVENTS {sid}: nhiều CREATED")
        kt = [i for i, e in enumerate(es) if e["event_type"] in KET_THUC]
        if len(kt) > 1 or (kt and kt[0] != len(es) - 1):
            loi.append(f"EVENTS {sid}: có sự kiện sau sự kiện kết thúc hoặc nhiều sự kiện kết thúc")
        if len({(e["symbol"], e["setup"], e["dir"]) for e in es}) > 1:
            loi.append(f"EVENTS {sid}: symbol/setup/dir thay đổi trong vòng đời")
    loi += [f"MÁY TRẠNG THÁI: {x}" for x in MT.kiem_vong_doi(events)]
    # SIGNALS ↔ EVENTS
    trig = {(e["setup_id"], e["ts_ms"]): e for e in events if e["event_type"] == "TRIGGER"}
    for s in signals:
        es = theo.get(s["setup_id"])
        if not es:
            loi.append(f"SIGNAL {s['signal_id']}: setup_id không có trong EVENTS"); continue
        if (es[0]["symbol"], es[0]["setup"], es[0]["dir"]) != (s["symbol"], s["setup"], s["dir"]):
            loi.append(f"SIGNAL {s['signal_id']}: symbol/setup/dir khác EVENTS")
        if es[0]["ts_ms"] > s["trigger_ts_ms"]:
            loi.append(f"SIGNAL {s['signal_id']}: trigger trước CREATED")
        e = trig.get((s["setup_id"], s["trigger_ts_ms"]))
        if e is None:
            loi.append(f"SIGNAL {s['signal_id']}: không có sự kiện TRIGGER cùng setup_id và nến")
        elif e["emit_seq"] != s["emit_seq"] or e["reason"] != s["reason"]:
            loi.append(f"SIGNAL {s['signal_id']}: emit_seq/reason khác sự kiện TRIGGER")
        if s["signal_id"] != hid(s["setup_id"], s["trigger_ts_ms"]):
            loi.append(f"SIGNAL {s['signal_id']}: signal_id không tái lập được từ (setup_id, trigger_ts_ms)")
    n_trig = sum(e["event_type"] == "TRIGGER" for e in events)
    if n_trig != len(signals):
        loi.append(f"số sự kiện TRIGGER ({n_trig}) ≠ số SIGNALS ({len(signals)})")
    # TRADES ↔ SIGNALS
    S = {s["signal_id"]: s for s in signals}
    for t in trades:
        s = S.get(t["signal_id"])
        if s is None:
            loi.append(f"TRADE {t['signal_id']}: không có SIGNAL"); continue
        tag = f"TRADE {t['signal_id']}"
        if s["reason"] != 16:
            loi.append(f"{tag}: tín hiệu không đạt S1 (reason {s['reason']}) nhưng có TRADE")
        for f in ("symbol", "setup", "emit_seq"):
            if t.get(f) is not None and t[f] != s[f]:
                loi.append(f"{tag}: {f} khác SIGNAL")
        rule = entry_rule or ("next_open" if "next_open" in t["sim_rule"] else "close")
        loi += [f"{tag}: MÁY TRẠNG THÁI: {x}" for x in MT.kiem_lenh(t, s, rule)]
        if t["outcome"] in DA_VAO and t.get("rr_entry") is not None:
            if s.get("tp1") is None:
                loi.append(f"{tag}: rr_entry có giá trị khi tín hiệu không có TP1")
            elif abs(t["rr_entry"] - (s["tp1"] - t["entry_price"]) * s["dir"] / t["risk"]) > 1e-6:
                loi.append(f"{tag}: rr_entry ≠ (TP1 − entry)×dir / risk")
        if rule == "close" and t["entry_ts_ms"] != s["trigger_ts_ms"]:
            loi.append(f"{tag}: R1 phải vào tại nến trigger")
        if rule == "next_open" and t["outcome"] not in ("NO_DATA", "INVALID") and t["entry_ts_ms"] <= s["trigger_ts_ms"]:
            loi.append(f"{tag}: R2 phải vào sau nến trigger")
        if t["outcome"] in DA_VAO:
            d = s["dir"]
            if rule == "close" and abs(t["entry_price"] - s["p_ref"]) > 1e-9:
                loi.append(f"{tag}: R1 entry_price ≠ p_ref")
            if abs(t["risk"] - (t["entry_price"] - s["sl"]) * d) > 1e-6:
                loi.append(f"{tag}: risk ≠ (entry − SL)×dir")
            if t["outcome"] in DONG and abs(t["r_gross"] - (t["exit_price"] - t["entry_price"]) * d / t["risk"]) > 1e-6:
                loi.append(f"{tag}: r_gross ≠ (exit − entry)×dir / risk")
            if t["outcome"] == "SL" and not t["gap_exit"] and abs(t["exit_price"] - s["sl"]) > 1e-9:
                loi.append(f"{tag}: SL không gap phải thoát tại SL")
            if t["outcome"] == "TP1":
                if s.get("tp1") is None:
                    loi.append(f"{tag}: TP1 khi tín hiệu không có TP1")
                elif not t["gap_exit"] and abs(t["exit_price"] - s["tp1"]) > 1e-9:
                    loi.append(f"{tag}: TP1 không gap phải thoát tại TP1")
    return loi
