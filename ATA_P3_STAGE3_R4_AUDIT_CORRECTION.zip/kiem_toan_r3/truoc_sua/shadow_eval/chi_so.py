# -*- coding: utf-8 -*-
"""Chỉ số đánh giá 1.1 – tính RIÊNG cho từng (symbol, setup); không gộp SU-3/SU-5, không gộp XAUUSD/BTCUSD.

ĐỊNH NGHĨA (Stage 3 – Audit Correction)
  • Mẫu R = lệnh ĐÓNG (TP1, SL, TIMEOUT), dùng r_net (sau chi phí). OPEN / NO_FILL / NO_DATA / INVALID chỉ đếm.
  • Thắng: r_net > +EPS_R; Thua: r_net < −EPS_R; Hòa vốn: |r_net| ≤ EPS_R (EPS_R = 1e-9). Hòa vốn TÁCH RIÊNG.
    win_rate = thắng / số lệnh đóng (hòa vốn nằm ở mẫu số); win_rate_khong_hoa = thắng / (thắng + thua).
  • Tỷ lệ TP1 (ty_le_tp1) là tỷ lệ KẾT CỤC TP1, khác win_rate (TIMEOUT dương là thắng; TP1 sau chi phí có thể không thắng).
  • Profit factor = tổng R thắng / |tổng R thua|. Không có lệnh thua: profit_factor = null, pf_trang_thai = "KHONG_CO_LENH_THUA"
    (nếu có thắng) hoặc "KHONG_CO_LENH_THANG_THUA"; chỉ có thua: 0,0, "OK". Không bao giờ ghi Infinity/NaN.
  • Bootstrap CI 95 % của expectancy: lấy mẫu lại có hoàn lại, GIẢ ĐỊNH các lệnh độc lập cùng phân phối (i.i.d.) – không đúng nếu lệnh
    tương quan theo chế độ thị trường, nên chỉ là khoảng tham khảo. Phân vị đối xứng: k = ⌊α/2 · B⌋ tính bằng số nguyên,
    dưới = s[k], trên = s[B−1−k]. Seed xác định: seed gốc + băm ổn định của (symbol, setup); R được sắp xếp trước khi lấy mẫu → không phụ thuộc thứ tự lệnh đầu vào. n < 2 → ci = null, ci_trang_thai = "N_NHO_HON_2";
    mọi R bằng nhau → CI suy biến [r, r], ci_trang_thai = "SUY_BIEN".
  • n < N_TOI_THIEU (30, ASSUMPTION) → du_mau = false: chỉ báo số liệu, không đưa nhận định."""
import hashlib, random

N_TOI_THIEU = 30
EPS_R = 1e-9
DONG = ("TP1", "SL", "TIMEOUT")
_PHIEU0 = ("tao", "armed", "void", "het_han", "gap_bo", "ket_thuc_khong_su_kien", "trigger", "s1_dat", "bo_quyen", "bo_khac", "trung")


MAU_SO = dict(ty_le_armed="armed / tao", ty_le_void="void / tao", ty_le_het_han="het_han / tao", ty_le_ket_thuc_khong_su_kien="ket_thuc_khong_su_kien / tao",
              ty_le_trigger_tren_armed="trigger / armed", ty_le_s1_dat="s1_dat / trigger", ty_le_bo_quyen="bo_quyen / trigger", ty_le_bo_khac="bo_khac / trigger",
              ty_le_trung="trung / trigger", ty_le_khong_khop="khong_khop / lenh_gia_lap", ty_le_khong_du_lieu="khong_du_lieu / lenh_gia_lap",
              ty_le_khong_hop_le="khong_hop_le / lenh_gia_lap", ty_le_da_vao="da_vao / lenh_gia_lap")


def phieu(events, signals, trades=None):
    """Phễu theo (symbol, setup). Mẫu số KHÓA trong MAU_SO (dùng chung cho dashboard và báo cáo); mẫu số = 0 → tỷ lệ null.
    'trung' = số tín hiệu bị loại khi khử trùng theo dup_key trên MỌI tín hiệu (IP-21). trades (tùy chọn): đếm NO_FILL / NO_DATA / INVALID / đã vào."""
    o = {}
    mk = lambda k: o.setdefault(k, {f: 0 for f in _PHIEU0 + ("lenh_gia_lap", "khong_khop", "khong_du_lieu", "khong_hop_le", "da_vao")})      # noqa: E731
    for e in events:
        r = mk((e["symbol"], e["setup"]))
        et = e["event_type"]
        r["tao"] += et == "CREATED"; r["armed"] += et == "ARMED"; r["void"] += et == "VOID"; r["het_han"] += et == "EXPIRED"
        r["gap_bo"] += et == "SKIP" and e["reason"] == 4; r["ket_thuc_khong_su_kien"] += et == "END_NO_EVENT"
    keys = {}
    for s in signals:
        k = (s["symbol"], s["setup"])
        r = mk(k)
        r["trigger"] += 1
        r["s1_dat"] += s["reason"] == 16
        r["bo_quyen"] += s["reason"] == 15
        r["bo_khac"] += s["reason"] not in (15, 16)
        keys.setdefault(k, []).append(s.get("dup_key"))
    for k, ds in keys.items():
        o[k]["trung"] = sum(1 for x in ds if x is not None) - len({x for x in ds if x is not None})
    for t in trades or []:
        r = mk((t["symbol"], t["setup"]))
        r["lenh_gia_lap"] += 1
        r["khong_khop"] += t["outcome"] == "NO_FILL"; r["khong_du_lieu"] += t["outcome"] == "NO_DATA"; r["khong_hop_le"] += t["outcome"] == "INVALID"
        r["da_vao"] += t["outcome"] in DONG + ("OPEN",)
    for k, r in o.items():
        for ten, ct in MAU_SO.items():
            tu, mau = [x.strip() for x in ct.split("/")]
            r[ten] = r[tu] / r[mau] if r[mau] else None
        r["mau_so"] = MAU_SO
    return o


def phan_vi_doi_xung(s, alpha=0.05):
    """s đã sắp xếp, độ dài B. Trả (dưới, trên) với k = ⌊α/2·B⌋ (số học nguyên trên phần nghìn)."""
    B = len(s)
    k = (B * int(round(alpha * 1000))) // 2000
    return s[k], s[B - 1 - k]


def _seed(seed, key):
    return seed * 1000003 + int(hashlib.sha256(repr(key).encode()).hexdigest()[:8], 16)


def bootstrap_ci(R, seed, key, n_boot=2000, alpha=0.05):
    n = len(R)
    if n < 2:
        return None, "N_NHO_HON_2"
    if max(R) - min(R) <= EPS_R:
        return [R[0], R[0]], "SUY_BIEN"
    if n_boot < 40:
        raise ValueError("n_boot < 40 không đủ cho CI 95 %")
    R = sorted(R)                      # không phụ thuộc thứ tự đầu vào
    rnd = random.Random(_seed(seed, key))
    bs = sorted(sum(rnd.choice(R) for _ in range(n)) / n for _ in range(n_boot))
    lo, hi = phan_vi_doi_xung(bs, alpha)
    return [lo, hi], "OK"


def bootstrap_khoi(R_theo_thoi_gian, seed, key, n_boot=2000, alpha=0.05, L=None):
    """Moving-block bootstrap VÒNG (circular) trên chuỗi R theo THỨ TỰ THỜI GIAN – độ nhạy cho phụ thuộc thời gian/chế độ thị trường.
    L mặc định = max(1, round(n^(1/3))). Trả (ci, trạng thái, L). Cùng quy ước phân vị đối xứng và seed xác định như bootstrap i.i.d."""
    R = list(R_theo_thoi_gian); n = len(R)
    if n < 2:
        return None, "N_NHO_HON_2", None
    L = L or max(1, round(n ** (1 / 3)))
    if max(R) - min(R) <= EPS_R:
        return [R[0], R[0]], "SUY_BIEN", L
    rnd = random.Random(_seed(seed, ("khoi",) + tuple(key) if isinstance(key, tuple) else ("khoi", key)))
    so_khoi = -(-n // L); bs = []
    for _ in range(n_boot):
        x = []
        for _ in range(so_khoi):
            a = rnd.randrange(n); x += [R[(a + j) % n] for j in range(L)]
        bs.append(sum(x[:n]) / n)
    bs.sort()
    lo, hi = phan_vi_doi_xung(bs, alpha)
    return [lo, hi], "OK", L


def hieu_qua(trades, seed=7, n_boot=2000):
    o, nhom = {}, {}
    for t in trades:
        nhom.setdefault((t["symbol"], t["setup"]), []).append(t)
    for k, ts in nhom.items():
        dong = [t for t in ts if t["outcome"] in DONG]
        R = [t["r_net"] for t in dong]
        n = len(R)
        thang = [r for r in R if r > EPS_R]; thua = [r for r in R if r < -EPS_R]; hoa = n - len(thang) - len(thua)
        if thua:
            pf, pfs = sum(thang) / -sum(thua), "OK"
        else:
            pf, pfs = None, ("KHONG_CO_LENH_THUA" if thang else "KHONG_CO_LENH_THANG_THUA")
        tb = lambda f: (sum(t[f] for t in dong) / n) if n else None      # noqa: E731
        r_ = dict(so_lenh=len(ts), dong=n, mo=sum(t["outcome"] == "OPEN" for t in ts), khong_khop=sum(t["outcome"] == "NO_FILL" for t in ts),
                  khong_du_lieu=sum(t["outcome"] == "NO_DATA" for t in ts), khong_hop_le=sum(t["outcome"] == "INVALID" for t in ts),
                  thang=len(thang), thua=len(thua), hoa_von=hoa,
                  win_rate=len(thang) / n if n else None, win_rate_khong_hoa=len(thang) / (len(thang) + len(thua)) if (thang or thua) else None,
                  net_r=sum(R) if n else 0.0, expectancy=sum(R) / n if n else None,
                  profit_factor=pf, pf_trang_thai=pfs,
                  ty_le_tp1=sum(t["outcome"] == "TP1" for t in dong) / n if n else None, ty_le_sl=sum(t["outcome"] == "SL" for t in dong) / n if n else None,
                  ty_le_timeout=sum(t["outcome"] == "TIMEOUT" for t in dong) / n if n else None,
                  mfe_tb=tb("mfe_r"), mae_tb=tb("mae_r"), giu_tb_nen=tb("bars_held"),
                  xung_dot_cung_nen=sum(bool(t.get("same_bar_conflict")) for t in dong), thoat_gap=sum(bool(t.get("gap_exit")) for t in dong),
                  du_mau=n >= N_TOI_THIEU, gia_dinh_ci="i.i.d. (lệnh độc lập) – chỉ tham khảo")
        r_["avg_r"] = r_["expectancy"]
        r_["expectancy_ci95"], r_["ci_trang_thai"] = bootstrap_ci(R, seed, k, n_boot)
        theo_tg = [t["r_net"] for t in sorted(dong, key=lambda t: (t.get("entry_ts_ms") or 0, t.get("emit_seq") or 0, str(t.get("signal_id", ""))))]
        r_["expectancy_ci95_khoi"], r_["ci_khoi_trang_thai"], r_["khoi_L"] = bootstrap_khoi(theo_tg, seed, k, n_boot)
        r_["phuong_phap_ci"] = dict(iid="bootstrap i.i.d. (lệnh độc lập) – mốc tham chiếu", khoi="moving-block vòng theo entry_ts – độ nhạy phụ thuộc thời gian",
                                    tong_the="lệnh ĐÓNG (TP1/SL/TIMEOUT) của một (symbol, setup)", n=n, B=n_boot, seed=seed, do_tin_cay=0.95,
                                    gioi_han="không xử lý phụ thuộc chéo giữa ô, phiên, cụm; SYNTH không phải bằng chứng thị trường")
        o[k] = r_
    return o
