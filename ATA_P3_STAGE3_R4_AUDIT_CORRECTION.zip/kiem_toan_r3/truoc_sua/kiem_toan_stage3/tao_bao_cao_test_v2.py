# -*- coding: utf-8 -*-
"""Sinh ATA_P3_STAGE3_TEST_REPORT.md (vòng Correction 2) từ kết quả CHẠY THỰC: bộ độc lập (ket_qua_doc_lap.json) + hồi quy Stage 3 (ket_qua_kiem_thu.json)."""
import json, os, sys
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(G, "BAN_GIAO_STAGE3C", "ATA_P3_STAGE3_TEST_REPORT.md")
K = json.load(open(os.path.join(G, "ket_qua_stage3", "doc_lap", "ket_qua_doc_lap.json"), encoding="utf-8"))
S = json.load(open(os.path.join(G, "ket_qua_stage3", "ket_qua_kiem_thu.json"), encoding="utf-8"))
C = json.load(open(os.path.join(G, "ket_qua_stage3", "hoi_quy_bo_cu_tren_module_moi.json"), encoding="utf-8"))
R2 = next(x for x in S["ket_qua"] if x["test_id"] == "REG-02")
dc = {}
for x in C["chay_b_shim"]:
    dc[x["result"]] = dc.get(x["result"], 0) + 1
f = lambda d: " · ".join(f"{k} {v}" for k, v in sorted(d.items()))      # noqa: E731
L = ["# ATA P3 · STAGE 3 · BÁO CÁO KIỂM THỬ – CORRECTION VÒNG 2", "",
     "Sinh tự động từ kết quả của lần chạy này (không dùng kết quả cũ làm bằng chứng). Lệnh tái lập từ thư mục gốc gói: `python3 kiem_doc_lap/chay_doc_lap.py`.", "",
     "## 1. Tổng hợp", "", "| Bộ | Số test | Kết quả | Assertion thực chạy |", "|---|---|---|---|",
     f"| Bộ ĐỘC LẬP (KD-*): kỳ vọng tính tay + oracle viết lại | {K['so_test']} | {f(K['tom_tat'])} | {str(K['so_assertion'])[:-3] + '.' + str(K['so_assertion'])[-3:]} |",
     f"| Hồi quy: bộ Stage 3 trước (88 test, KHÔNG sửa) | {len(S['ket_qua'])} | {f(S['tom_tat'])} | (bộ cũ không đếm assertion) |",
     f"| Hồi quy: bộ Stage 3 gốc (22 test, KHÔNG sửa) qua shim harness | {len(C['chay_b_shim'])} | {f(dc)} | — |",
     f"| Hồi quy: bộ 0.3.9 (56 test) + bộ 0.3.8 trên 0.3.9 – qua REG-02 | 56 + 82 | REG-02 = {R2['status']}: {json.dumps(R2['actual'], ensure_ascii=False)[:260]} | — |", "",
     f"Thời gian bộ độc lập: {K['thoi_gian_s']} s · Python {K['python']}.", "",
     "SHA-256 module được kiểm: " + ", ".join(f"{k} `{v[:16]}…`" for k, v in K["sha_module"].items()), "",
     "SHA-256 oracle/vector/runner: " + ", ".join(f"{k} `{v[:16]}…`" for k, v in K["sha_oracle"].items()), "",
     "## 2. FAIL của hồi quy – đã phân loại (không sửa test cũ, không sửa expected)", ""]
for t in [x for x in S["ket_qua"] if x["status"] == "FAIL"]:
    L.append(f"- **{t['test_id']}** – lỗi thời do thay đổi có chủ đích của vòng này; test thay thế: xem KD-REG-S3 trong JSON.")
kd_reg = next(x for x in K["ket_qua"] if x["test_id"] == "KD-REG-S3")
for k, v in kd_reg["actual"]["phan_loai"].items():
    L.append(f"  - {k}: {v}")
L += ["", "Bộ 22 test gốc: chạy nguyên trạng dừng ở DUP-01 (tín hiệu mẫu không có emit_seq – thay đổi có chủ đích F2); với shim harness: HD-01 và E2E-01 cũ FAIL – lỗi thời, đã phân loại từ vòng trước.", ""]
nhom = []
for x in K["ket_qua"]:
    if x["nhom"] not in nhom:
        nhom.append(x["nhom"])
L += ["## 3. Chi tiết bộ độc lập", ""]
for n in nhom:
    xs = [x for x in K["ket_qua"] if x["nhom"] == n]
    L += [f"### {n} ({len(xs)})", "", "| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |", "|---|---|---|---|---|"]
    for x in xs:
        a = x["actual"] if isinstance(x["actual"], str) else json.dumps(x["actual"], ensure_ascii=False, default=str)
        a = a.replace("|", "/").replace("\n", " ")
        L.append(f"| {x['test_id']} | {x['status']} | {x['so_assertion']} | {x['muc_tieu'].replace('|', '/')} | {a[:200]}{'…' if len(a) > 200 else ''} |")
    L.append("")
L += ["## 4. Ca lệch đã lưu", "", f"`ca_lech` trong ket_qua_doc_lap.json: " + ", ".join(f"{k}: {len(v)} ca" for k, v in K["ca_lech"].items()), ""]
open(out, "w", encoding="utf-8").write("\n".join(L) + "\n")
print(out)
