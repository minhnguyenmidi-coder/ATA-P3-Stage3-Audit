# -*- coding: utf-8 -*-
"""TOKEN BUDGET GATE – công cụ NGOÀI Pine, chỉ ĐỌC source. Không sửa, không xóa code Pine, không tạo probe/padding.

Làm gì
  1. Phân tích: hàm (dòng, token từ vựng), đồ thị gọi, hàm không được gọi (kèm bằng chứng: dòng định nghĩa, số lần tham chiếu ngoài thân = 0),
     biến khai báo mà không được đọc (ỨNG VIÊN), các lệnh request.security và hàm mà biểu thức của chúng kéo theo (mở rộng), token theo module (mục '// ====').
  2. Ước lượng: nhiều mô hình, hiệu chỉnh trên quan sát compile thật (quan_sat_compile.json), kiểm mô hình nào NHẤT QUÁN với mọi PASS/FAIL đã biết,
     báo khoảng ước lượng và dư địa, mức cảnh báo. Mọi số ước lượng là HYPOTHESIS – TradingView không in token khi compile thành công.
  3. So sánh candidate với baseline: chênh token từ vựng, chênh trong hàm bị request.security nhân bản, hàm mới/xóa.
Dùng: python3 token_budget/cong_token.py --baseline <pine> --candidate <pine> [--out thư_mục]
Mã thoát: 0 = chạy xong (kể cả cảnh báo); 2 = lỗi đầu vào. Cổng KHÔNG thay thế compile thật trên TradingView."""
import argparse, hashlib, json, os, re, sys

GIOI_HAN = 100256
TOK = re.compile(r'"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'|//[^\n]*|[A-Za-z_][\w.]*|\d+\.?\d*(?:[eE][-+]?\d+)?|:=|==|!=|<=|>=|=>|\+=|-=|\*=|/=|\S')
DEF = re.compile(r"^([A-Za-z_]\w*)\s*\((.*)\)\s*=>(.*)$")
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def toks(s):
    return [t for t in TOK.findall(s) if not t.startswith("//")]


def phan_tich(src):
    L = src.split("\n")
    fn = {}
    i = 0
    while i < len(L):
        m = DEF.match(L[i])
        if m:
            name, j = m.group(1), i + 1
            if m.group(3).strip() == "":
                while j < len(L) and (L[j].strip() == "" or L[j][:1] in (" ", "\t")):
                    j += 1
                while j - 1 > i and L[j - 1].strip() == "":
                    j -= 1
            fn.setdefault(name, dict(dong_dau=i + 1, dong_cuoi=j, van_ban="\n".join(L[i:j])))
            i = j
            continue
        i += 1
    for f in fn.values():
        f["token"] = len(toks(f["van_ban"]))
        tk = toks(f["van_ban"])[1:]
        f["goi"] = sorted({t for t in tk if t in fn})
    trong_ham = set()
    for f in fn.values():
        trong_ham.update(range(f["dong_dau"] - 1, f["dong_cuoi"]))
    top = "\n".join(l for k, l in enumerate(L) if k not in trong_ham)
    top_tk = toks(top)
    goi_top = sorted({t for t in top_tk if t in fn})
    # tham chiếu ngoài thân hàm (bằng chứng hàm chết)
    tham_chieu = {n: [] for n in fn}
    for k, l in enumerate(L):
        for t in toks(l):
            if t in fn:
                f = fn[t]
                if not (f["dong_dau"] - 1 <= k < f["dong_cuoi"]):
                    tham_chieu[t].append(k + 1)
    song, todo = set(), list(goi_top)
    while todo:
        n = todo.pop()
        if n in song:
            continue
        song.add(n); todo += fn[n]["goi"]
    chet = sorted(set(fn) - song)
    bang_chung_chet = {n: dict(dinh_nghia_dong=fn[n]["dong_dau"], token=fn[n]["token"], tham_chieu_ngoai_than=tham_chieu[n],
                               chi_duoc_goi_boi_ham_chet=bool(tham_chieu[n])) for n in chet}

    memo = {}

    def size(n, stack=()):
        if n in memo:
            return memo[n]
        if n in stack:
            return fn[n]["token"]
        s = fn[n]["token"] + sum(size(c, stack + (n,)) for c in fn[n]["goi"] for _ in range(toks(fn[n]["van_ban"])[1:].count(c)))
        memo[n] = s
        return s
    sec = []
    for k, l in enumerate(L):
        if "request.security(" in l and not l.lstrip().startswith("//"):
            kt = [t for t in toks(l) if t in fn]
            dong = set()
            for t in kt:
                dong.add(t); todo = list(fn[t]["goi"])
                while todo:
                    x = todo.pop()
                    if x not in dong:
                        dong.add(x); todo += fn[x]["goi"]
            sec.append(dict(dong=k + 1, ham_trong_bieu_thuc=kt, bao_dong=sorted(dong), token_bao_dong=sum(fn[x]["token"] for x in dong)))
    # biến được khai báo nhưng không đọc – ỨNG VIÊN
    decl, trong_type = {}, False
    for k, l in enumerate(L):
        if l.startswith("type "):
            trong_type = True; continue
        if trong_type and (l[:1] in (" ", "\t") or l.strip() == ""):
            continue                                   # trường của UDT – không phải biến
        trong_type = False
        m = re.match(r"^\s*(?:var\s+|varip\s+)?(?:(?:array|map|matrix)<[\w.<>, ]+>\s+|[A-Za-z_][\w.]*\s+)?([A-Za-z_]\w*)\s*=(?!=|>)", l)
        if m and not l.lstrip().startswith("//") and not DEF.match(l):
            decl.setdefault(m.group(1), k + 1)
    doc = {n: 0 for n in decl}
    for k, l in enumerate(L):
        tk = toks(l)
        for idx, t in enumerate(tk):
            if "." in t and t.split(".")[0] in doc:
                doc[t.split(".")[0]] += 1          # truy cập trường/phương thức qua biến = đọc biến
                continue
            if t in doc:
                ghi = idx + 1 < len(tk) and tk[idx + 1] in (":=", "=") and (idx == 0 or tk[idx - 1] in ("var", "varip") or k + 1 == decl[t] or tk[idx + 1] == ":=")
                ghi = ghi or (k + 1 == decl[t] and idx + 1 < len(tk) and tk[idx + 1] == "=")
                if not ghi:
                    doc[t] += 1
    khong_doc = sorted(n for n, c in doc.items() if c == 0 and n not in fn)
    # module theo tiêu đề '// ===='
    mod, ten, start = [], "đầu file", 0
    for k, l in enumerate(L):
        if l.startswith("// ====") and k + 2 < len(L) and L[k + 2].startswith("// ===="):
            mod.append((ten, start, k)); ten, start = L[k + 1].lstrip("/ ").strip()[:70], k
    mod.append((ten, start, len(L)))
    module = [dict(ten=t, dong=f"{a + 1}-{b}", token=len(toks("\n".join(L[a:b])))) for t, a, b in mod if b > a]
    return dict(lex=len(toks(src)), dong=len(L), so_ham=len(fn), ham={n: {k: v for k, v in f.items() if k != "van_ban"} for n, f in fn.items()},
                goi_tu_top=goi_top, ham_khong_goi=chet, bang_chung_ham_chet=bang_chung_chet, bien_khong_doc_ung_vien=khong_doc,
                request_security=sec, module=module, _size=size, _fn=fn, _top=top_tk)


def mo_hinh(pt):
    """Các mô hình token biên dịch (chưa nhân hệ số). Trả dict tên → số."""
    fn, size, top = pt["_fn"], pt["_size"], pt["_top"]
    lex = pt["lex"]
    fs = size("f_struct") if "f_struct" in fn else 0
    n_fs = sum(1 for s in pt["request_security"] if "f_struct" in s["ham_trong_bieu_thuc"])
    full = len(top) + sum(size(c) * top.count(c) for c in set(top) if c in fn)
    once = len(top) + sum(fn[n]["token"] for n in fn if n not in pt["ham_khong_goi"])
    out = dict(lex=lex, once=once, full_inline=full)
    for k in range(0, 8):
        out[f"sec_k{k}"] = lex + k * fs          # f_struct (kèm hàm con) thêm k bản
    out["_n_goi_f_struct_qua_security"] = n_fs
    out["_size_f_struct"] = fs
    return out


def uoc_luong(cand_path, quan_sat):
    """Hiệu chỉnh mỗi mô hình trên điểm FAIL có số thật, kiểm nhất quán với mọi PASS/FAIL, ước lượng candidate."""
    M = {}
    for q in quan_sat:
        M[q["build"]] = mo_hinh(phan_tich(open(os.path.join(G, q["path"]), encoding="utf-8").read()))
    mc = mo_hinh(phan_tich(open(cand_path, encoding="utf-8").read()))
    neo = [q for q in quan_sat if q.get("token_that") is not None]
    if not neo:
        return dict(trang_thai="UNKNOWN", ly_do="không có quan sát có số token thật")
    q0 = neo[0]
    kq = {}
    for k in mc:
        if k.startswith("_"):
            continue
        r = q0["token_that"] / M[q0["build"]][k]
        est = {b: round(M[b][k] * r) for b in M}
        nhat_quan = all((est[q["build"]] <= GIOI_HAN) == (q["ket_qua"] == "PASS") for q in quan_sat if q is not q0)
        kq[k] = dict(he_so=round(r, 6), uoc_luong_quan_sat=est, nhat_quan=nhat_quan, uoc_luong_candidate=round(mc[k] * r), du_dia=GIOI_HAN - round(mc[k] * r))
    nq = {k: v for k, v in kq.items() if v["nhat_quan"]}
    if not nq:
        return dict(trang_thai="UNKNOWN", ly_do="không mô hình nào nhất quán với mọi quan sát", mo_hinh=kq)
    lo = min(v["uoc_luong_candidate"] for v in nq.values()); hi = max(v["uoc_luong_candidate"] for v in nq.values())
    if hi > GIOI_HAN and lo > GIOI_HAN:
        muc = "ĐỎ – mọi mô hình nhất quán dự báo VƯỢT giới hạn"
    elif hi > GIOI_HAN:
        muc = "ĐỎ/VÀNG – một số mô hình nhất quán dự báo VƯỢT"
    elif GIOI_HAN - hi < 0.02 * GIOI_HAN:
        muc = "VÀNG – dư địa ước lượng < 2 % giới hạn"
    else:
        muc = "XANH (ước lượng) – vẫn phải compile thật"
    return dict(trang_thai="ESTIMATE", muc=muc, khoang_uoc_luong=[lo, hi], du_dia_khoang=[GIOI_HAN - hi, GIOI_HAN - lo], mo_hinh=kq,
                mo_hinh_nhat_quan=sorted(nq), so_diem_so_that=len(neo),
                bat_dinh=["Chỉ 1 điểm có số token thật (FAIL 101.360) → hệ số mỗi mô hình khớp đúng 1 điểm; điểm PASS chỉ cho cận trên.",
                          "Nhiều mô hình khác cấu trúc cùng nhất quán → không xác định được mô hình đúng.",
                          "Cách TradingView đếm token (inline hàm, mở rộng request.security, tối ưu) không được công bố."],
                n_goi_f_struct_qua_security=mc["_n_goi_f_struct_qua_security"], size_f_struct=mc["_size_f_struct"])


def so_sanh(pb, pc):
    fb, fc = pb["_fn"], pc["_fn"]
    nhan = set()
    for s in pc["request_security"]:
        nhan.update(s["bao_dong"])
    doi = {n: fc[n]["token"] - fb[n]["token"] for n in set(fb) & set(fc) if fc[n]["token"] != fb[n]["token"]}
    canh = []
    doi_nhan = {n: v for n, v in doi.items() if n in nhan}
    if doi_nhan:
        canh.append(f"Thay đổi trong hàm bị request.security kéo theo (có thể bị nhân bản khi biên dịch): {doi_nhan}")
    moi = sorted(set(fc) - set(fb)); xoa = sorted(set(fb) - set(fc))
    if any(n in nhan for n in moi):
        canh.append(f"Hàm mới nằm trong bao đóng request.security: {[n for n in moi if n in nhan]}")
    return dict(chenh_lex=pc["lex"] - pb["lex"], ham_moi=moi, ham_xoa=xoa, ham_doi_token=doi, ham_trong_bao_dong_security=sorted(nhan), canh_bao=canh)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def chay(baseline, candidate, quan_sat_path=os.path.join(G, "token_budget", "quan_sat_compile.json")):
    qs = json.load(open(quan_sat_path, encoding="utf-8"))
    pb = phan_tich(open(baseline, encoding="utf-8").read()); pc = phan_tich(open(candidate, encoding="utf-8").read())
    sach = lambda p: {k: v for k, v in p.items() if not k.startswith("_")}    # noqa: E731
    return dict(gioi_han=GIOI_HAN, baseline=dict(path=os.path.relpath(baseline, G), sha256=sha(baseline)), candidate=dict(path=os.path.relpath(candidate, G), sha256=sha(candidate)),
                phan_tich_candidate=sach(pc), phan_tich_baseline_tom_tat=dict(lex=pb["lex"], so_ham=pb["so_ham"], ham_khong_goi=pb["ham_khong_goi"]),
                so_sanh=so_sanh(pb, pc), uoc_luong=uoc_luong(candidate, qs), quan_sat=qs,
                su_that=["Giới hạn biên dịch Pine v6: 100.256 token (thông báo lỗi của TradingView).",
                         "0.3.3 FAIL với 101.360 token (số do TradingView in).",
                         "0.3.3a, 0.3.7, 0.3.8, 0.3.9 compile thành công → token thật của mỗi bản ≤ 100.256 (cận trên, không biết dư địa)."])


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", default=os.path.join(G, "src038", "ATA_P3_Build_0.3.8_Candidate_Indicator.pine"))
    ap.add_argument("--candidate", default=os.path.join(G, "src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine"))
    ap.add_argument("--out", default=os.path.join(G, "ket_qua_stage3", "token_gate"))
    a = ap.parse_args(argv)
    for p in (a.baseline, a.candidate):
        if not os.path.exists(p):
            print("không có file", p); return 2
    r = chay(a.baseline, a.candidate)
    os.makedirs(a.out, exist_ok=True)
    json.dump(r, open(os.path.join(a.out, "token_gate.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False)
    u = r["uoc_luong"]
    print("lex", r["phan_tich_candidate"]["lex"], "| hàm", r["phan_tich_candidate"]["so_ham"], "| không gọi", r["phan_tich_candidate"]["ham_khong_goi"])
    print("request.security", [(s["dong"], s["ham_trong_bieu_thuc"]) for s in r["phan_tich_candidate"]["request_security"]])
    print("mức", u.get("muc"), "| khoảng", u.get("khoang_uoc_luong"), "| nhất quán", u.get("mo_hinh_nhat_quan"))
    print("so sánh", {k: v for k, v in r["so_sanh"].items() if k != "ham_trong_bao_dong_security"})
    return 0


if __name__ == "__main__":
    sys.exit(main())
