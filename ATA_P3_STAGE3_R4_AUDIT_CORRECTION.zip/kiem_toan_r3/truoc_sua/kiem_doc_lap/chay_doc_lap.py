# -*- coding: utf-8 -*-
"""BỘ KIỂM ĐỘC LẬP Stage 3 (KD-*). Kỳ vọng lấy từ vector tính tay (vector_vang.py) và oracle viết lại từ đặc tả (oracle.py) – không lấy từ code được kiểm.
Dùng:  python3 kiem_doc_lap/chay_doc_lap.py                 → toàn bộ, ghi ket_qua_stage3/doc_lap/ket_qua_doc_lap.json (+ csv, log)
       python3 kiem_doc_lap/chay_doc_lap.py --nhanh --module-dir <thư mục>   → tập con nhanh trên bản module khác (dùng cho kiểm đột biến)
Mã thoát: 1 nếu có FAIL. BLOCKED / NOT TESTED đếm riêng. Mỗi test ghi số assertion thực sự đã chạy."""
import argparse, copy, csv, datetime as dt, hashlib, inspect, json, math, os, random, re, shutil, subprocess, sys, tempfile, time

KD = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(KD)
ap = argparse.ArgumentParser()
ap.add_argument("--nhanh", action="store_true"); ap.add_argument("--module-dir", default=os.path.join(G, "shadow_eval")); ap.add_argument("--out", default=os.path.join(G, "ket_qua_stage3", "doc_lap"))
A = ap.parse_args()
sys.path.insert(0, A.module_dir); sys.path.insert(1, KD)
import mo_phong_lenh as MP, hop_dong as HD, chi_so as CS, may_trang_thai as MT   # noqa: E402
import oracle as OR, vector_vang as VV   # noqa: E402

SHA38 = "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13"
SHA39 = "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"
KQ, TESTS = [], []
DEM = {"assert": 0}
LECH = {}          # lưu toàn bộ ca lệch (nếu có) để kiểm toán


class Sai(Exception):
    pass


def kt(dk, mo=""):
    DEM["assert"] += 1
    if not dk:
        raise Sai(mo)


def sha_f(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def T(tid, nhom, muc_tieu, loai="FACT", nhanh=False):
    def wrap(fn):
        def run():
            a0, t0 = DEM["assert"], time.time()
            try:
                r = fn()
                st, act = (r if isinstance(r, tuple) and isinstance(r[0], str) else ("PASS", r))
            except Sai as e:
                st, act = "FAIL", f"assertion sai: {e}"
            except Exception as e:      # noqa: BLE001
                st, act = "FAIL", f"NGOẠI LỆ: {e!r}"
            rec = dict(test_id=tid, nhom=nhom, muc_tieu=muc_tieu, phan_loai=loai, status=st, so_assertion=DEM["assert"] - a0, actual=act,
                       test_source=f"kiem_doc_lap/chay_doc_lap.py::{fn.__name__} (dòng {inspect.getsourcelines(fn)[1]})",
                       run_time=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), duration_ms=round((time.time() - t0) * 1000, 1))
            rec["hash"] = hashlib.sha256(json.dumps([tid, st, act], sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:16]
            KQ.append(rec); print(f"[{st:10}] {tid:22} a={rec['so_assertion']:<6} {muc_tieu[:80]}")
        run.nhanh = nhanh; run.tid = tid
        TESTS.append(run)
        return run
    return wrap


def bars(rows):
    return [dict(t=VV.T0 + 300000 * k, o=float(o), h=float(h), l=float(l), c=float(c)) for k, (o, h, l, c) in enumerate(rows)]


def cfg_impl(c):
    return MP.Cfg(entry=c.get("entry", "close"), same_bar=c.get("same_bar", "sl_first"), max_bars=c.get("max_bars", 288), spread=c.get("cost", 0.0))


MAP = dict(note="fill_note", entry_ts="entry_ts_ms", exit_ts="exit_ts_ms", mfe="mfe_r", mae="mae_r", held="bars_held", conflict="same_bar_conflict", gap="gap_exit")


def impl(sig, rows_or_bars, i, c):
    b = rows_or_bars if rows_or_bars and isinstance(rows_or_bars[0], dict) else bars(rows_or_bars)
    r = MP.mo_phong(sig, b, i, cfg_impl(c))
    return {k: r.get(MAP.get(k, k)) for k in ("outcome", "note", "entry_ts", "entry_price", "exit_ts", "exit_price", "r_gross", "r_net", "mfe", "mae", "held", "conflict", "gap", "rr_entry")}


def ora(sig, rows_or_bars, i, c):
    b = rows_or_bars if rows_or_bars and isinstance(rows_or_bars[0], dict) else bars(rows_or_bars)
    return OR.gia_lap(sig, b, i, c.get("entry", "close"), c.get("same_bar", "sl_first"), c.get("max_bars", 288), c.get("cost", 0.0))


def bang(a, b, e=1e-9):
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, (bool, str)) or isinstance(b, (bool, str)):
        return a == b
    return abs(a - b) <= e * max(1.0, abs(a), abs(b))


def so_sanh(kv, got, tag):
    for k, v in kv.items():
        kt(bang(v, got[k]), f"{tag}: {k} kỳ vọng {v}, được {got[k]}")


# ================================================================================ 1. GOLDEN – GIẢ LẬP
for _v in VV.V:
    def _mk(v):
        @T(f"KD-GOLD-{v['id'][2:]}", "Golden giả lập (code được kiểm)", v["mo"], nhanh=True)
        def t_gold():
            g = impl(v["sig"], v["rows"], 0, v["cfg"]); so_sanh(v["kv"], g, "impl"); return {k: g[k] for k in v["kv"]}
        t_gold.__name__ = "t_gold_" + v["id"].replace("-", "_")
    _mk(_v)


@T("KD-ORACLE-GOLD", "Golden giả lập (oracle)", "Oracle độc lập khớp MỌI golden vector (xác nhận oracle trước khi dùng làm chuẩn so sánh)", nhanh=True)
def t_oracle_gold():
    for v in VV.V:
        so_sanh(v["kv"], ora(v["sig"], v["rows"], 0, v["cfg"]), "oracle " + v["id"])
    return f"{len(VV.V)} vector"


def guong_rows(rows, p=4000.0):
    return [(p - o, p - l, p - h, p - c) for (o, h, l, c) in rows]


def guong_sig(s, p=4000.0):
    return dict(dir=-s["dir"] if s["dir"] in (1, -1) else s["dir"], p_ref=p - s["p_ref"], sl=p - s["sl"], tp1=None if s["tp1"] is None else p - s["tp1"])


@T("KD-MIRROR-GOLD", "Đối xứng BUY/SELL", "Mỗi golden BUY → ảnh gương SELL (giá → 4000 − giá): cùng kết cục, ghi chú, R, MFE, MAE, giữ, cờ, rr_entry; giá vào/thoát = 4000 − giá BUY; code và oracle", nhanh=True)
def t_mirror_gold():
    n, bo_qua = 0, []
    for v in VV.V:
        if v["sig"]["dir"] != 1:
            continue
        # Phép gương chỉ là phép đối xứng của miền giá DƯƠNG: nến có giá ≤ 0 (không hợp lệ) có ảnh gương hợp lệ → loại khỏi kiểm gương, ghi rõ
        if any(min(r) <= 0 or 4000 - max(r) <= 0 for r in v["rows"]):
            bo_qua.append(v["id"]); continue
        for f, nm in ((impl, "impl"), (ora, "oracle")):
            a = f(v["sig"], v["rows"], 0, v["cfg"]); b = f(guong_sig(v["sig"]), guong_rows(v["rows"]), 0, v["cfg"])
            for k in ("outcome", "note", "r_gross", "r_net", "mfe", "mae", "held", "conflict", "gap", "rr_entry", "entry_ts", "exit_ts"):
                kt(bang(a[k], b[k]), f"{nm} {v['id']} {k}: BUY {a[k]} / SELL {b[k]}")
            for k in ("entry_price", "exit_price"):
                kt(bang(a[k], None if b[k] is None else 4000.0 - b[k]) if a[k] is not None else b[k] is None, f"{nm} {v['id']} {k}")
            n += 1
    return dict(so_cap=n, so_lech=0, bo_qua_ngoai_mien=bo_qua)


def duong_ngau_nhien(R, n):
    p = 2000.0; rows = [(p, p + 1, p - 1, p)]
    for _ in range(n):
        o = round(p + R.choice((0, 0, 0, R.gauss(0, 3), R.choice((-12, 12)))), 2); c = round(o + R.gauss(0, 2), 2)
        rows.append((o, round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
    b = bars(rows)
    if R.random() < 0.15 and len(b) > 1:                     # khoảng trống thời gian
        k = R.randrange(1, len(b))
        for x in b[k:]:
            x["t"] += 300000 * R.randint(1, 50)
    if R.random() < 0.05:                                    # nến hỏng
        k = R.randrange(0, len(b)); b[k]["h"] = b[k]["l"] - 1
    return b


def ca_ngau_nhien(R):
    b = duong_ngau_nhien(R, R.choice((0, 1, 2, 5, 30, 60)))
    d = R.choice((1, -1)); p = b[0]["c"]
    s = dict(dir=d, p_ref=p, sl=round(p - d * R.choice((R.uniform(0.3, 8), 0.0, -1.0) if R.random() < 0.05 else (R.uniform(0.3, 8),)), 2),
             tp1=(round(p + d * R.uniform(0.3, 15), 2) if R.random() < 0.85 else None))
    c = dict(entry=R.choice(("close", "next_open")), same_bar=R.choice(("sl_first", "tp_first")), max_bars=R.choice((1, 2, 3, 10, 40)), cost=R.choice((0.0, 0.3)))
    return s, b, c


@T("KD-MIRROR-PROP", "Đối xứng BUY/SELL", "Thuộc tính: 6.000 ca ngẫu nhiên (gap, TP1 null, R1/R2, sl/tp_first, max_bars 1…40, chi phí, khoảng trống thời gian, nến hỏng, rủi ro hỏng) – code: BUY vs ảnh gương SELL, MỌI trường; lưu mọi ca lệch")
def t_mirror_prop():
    R = random.Random(20261120); lech = []
    for k in range(6000):
        s, b, c = ca_ngau_nhien(R)
        bg = [dict(t=x["t"], o=4000 - x["o"], h=4000 - x["l"], l=4000 - x["h"], c=4000 - x["c"]) for x in b]
        a, m = impl(s, b, 0, c), impl(guong_sig(s), bg, 0, c)
        for f in ("outcome", "note", "r_gross", "r_net", "mfe", "mae", "held", "conflict", "gap", "rr_entry", "entry_ts", "exit_ts"):
            if not bang(a[f], m[f], 1e-7):
                lech.append(dict(ca=k, truong=f, buy=a[f], sell=m[f], sig=s, cfg=c)); break
    LECH["KD-MIRROR-PROP"] = lech
    kt(len(lech) == 0, f"{len(lech)} ca lệch")
    return dict(so_ca=6000, so_ca_lech=len(lech))


@T("KD-ORACLE-PROP", "Oracle vs code", "Thuộc tính: 8.000 ca ngẫu nhiên – code được kiểm và oracle độc lập cho KẾT QUẢ Y HỆT (kết cục, ghi chú, giá/thời điểm vào-thoát, R gross/net, MFE, MAE, giữ, cờ, rr_entry); lưu mọi ca lệch")
def t_oracle_prop():
    R = random.Random(7_777); lech = []; dem = {}
    for k in range(8000):
        s, b, c = ca_ngau_nhien(R)
        a, o = impl(s, b, 0, c), ora(s, b, 0, c)
        dem[a["outcome"]] = dem.get(a["outcome"], 0) + 1
        for f in a:
            if not bang(a[f], o[f], 1e-9):
                lech.append(dict(ca=k, truong=f, code=a[f], oracle=o[f], sig=s, cfg=c)); break
    LECH["KD-ORACLE-PROP"] = lech
    kt(len(lech) == 0, f"{len(lech)} ca lệch")
    kt(all(dem.get(x, 0) > 0 for x in ("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")), f"phủ kết cục {dem}")
    return dict(so_ca=8000, so_ca_lech=0, phu_ket_cuc=dem)


@T("KD-R1-NOLOOK", "R1/R2 không nhìn trước", "R1: đổi High/Low nến trigger (giữ Close) → kết quả y hệt; R1/R2: thay mọi nến SAU nến thoát bằng giá vô lý → y hệt; R2 không dùng nến trigger ngoài thời điểm (đổi O/H/L) → y hệt (2.000 ca)")
def t_nolook():
    R = random.Random(31); n = 0
    for _ in range(2000):
        s, b, c = ca_ngau_nhien(R)
        if not OR._nen_ok(b[0]):
            continue
        a = impl(s, b, 0, c)
        b2 = copy.deepcopy(b); b2[0]["h"] = max(b2[0]["o"], b2[0]["c"]) + R.uniform(0, 50); b2[0]["l"] = min(b2[0]["o"], b2[0]["c"]) - R.uniform(0, 50)
        if c["entry"] == "next_open":
            b2[0]["o"] = min(max(b2[0]["o"] + R.uniform(-3, 3), b2[0]["l"]), b2[0]["h"])
        kt(impl(s, b2, 0, c) == a, "nến trigger ảnh hưởng kết quả"); n += 1
        if a["exit_ts"] is not None:
            ke = next(i for i, x in enumerate(b) if x["t"] == a["exit_ts"])
            b3 = b[:ke + 1] + [dict(t=x["t"], o=9999.0, h=9999.0, l=1.0, c=5000.0) for x in b[ke + 1:]]
            kt(impl(s, b3, 0, c) == a, "nến sau thoát ảnh hưởng kết quả")
    return f"{n} ca"


@T("KD-ENTRY-RETRO", "R1/R2 giá vào", "Giá vào không đổi hồi tố: R1 entry = P_ref và entry_ts = nến trigger; R2 entry = Open nến kế, entry_ts = nến kế; với mọi lệnh đã vào (4.000 ca)")
def t_entry():
    R = random.Random(41); n = 0
    for _ in range(4000):
        s, b, c = ca_ngau_nhien(R)
        a = impl(s, b, 0, c)
        if a["outcome"] in ("TP1", "SL", "TIMEOUT", "OPEN"):
            if c["entry"] == "close":
                kt(a["entry_price"] == s["p_ref"] and a["entry_ts"] == b[0]["t"], "R1 giá/thời điểm vào")
            else:
                kt(a["entry_price"] == b[1]["o"] and a["entry_ts"] == b[1]["t"], "R2 giá/thời điểm vào")
            n += 1
    return f"{n} lệnh đã vào"

@T("KD-GOLD-EXTRA", "Golden giả lập (code được kiểm)", "Biên chính xác (tính tay): SL = P_ref → INVALID; Open = SL → SL gap R −1; Low = SL → SL; High = TP1 → TP1; MAE nến thoát TP1 có Low dưới giá vào (−0,6); trượt giá 0,25 → chi phí 0,5 → r_net 1,9", nhanh=True)
def t_gold_extra():
    b = lambda rows: bars([VV.TRIG] + rows)      # noqa: E731
    r = MP.mo_phong(dict(VV.BUY, sl=2000.0), b([VV.FLAT]), 0); kt(r["outcome"] == "INVALID" and r["fill_note"] == "INVALID_RISK", "SL = P_ref")
    r = MP.mo_phong(VV.BUY, b([(1995, 1996, 1994, 1995)]), 0); kt(r["outcome"] == "SL" and r["gap_exit"] and bang(r["r_gross"], -1.0), "Open = SL")
    r = MP.mo_phong(VV.BUY, b([(1999, 2001, 1995, 1998)]), 0); kt(r["outcome"] == "SL" and not r["gap_exit"] and bang(r["r_gross"], -1.0), "Low = SL")
    r = MP.mo_phong(VV.BUY, b([(2001, 2010, 1999, 2005)]), 0); kt(r["outcome"] == "TP1" and bang(r["r_gross"], 2.0), "High = TP1")
    r = MP.mo_phong(VV.BUY, b([(2000, 2003, 1999.5, 2002), (2002, 2011, 1997, 2009)]), 0); kt(r["outcome"] == "TP1" and bang(r["mae_r"], -0.6) and bang(r["mfe_r"], 2.0), f"MAE TP1 {r['mae_r']}")
    r = MP.mo_phong(VV.BUY, b([(2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0, MP.Cfg(slippage=0.25)); kt(bang(r["r_net"], 1.9), f"trượt giá {r['r_net']}")
    r = MP.mo_phong(VV.BUY, b([(2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0, MP.Cfg(commission=0.5)); kt(bang(r["r_net"], 1.9), "phí")
    return "7 biên"


@T("KD-PCT", "Bootstrap", "Phân vị đối xứng (tính tay): B = 10 → (0, 9); B = 30 → (0, 29); B = 70 → (1, 68); B = 2000 → (50, 1949)", nhanh=True)
def t_pct():
    for Bn, kv in ((10, (0, 9)), (30, (0, 29)), (70, (1, 68)), (2000, (50, 1949))):
        kt(CS.phan_vi_doi_xung(list(range(Bn))) == kv, f"B={Bn}: {CS.phan_vi_doi_xung(list(range(Bn)))}")
    return "4 giá trị B"


@T("KD-SM-TRADE-NEG", "Máy trạng thái", "Vòng đời lệnh – vi phạm dựng tay: R2 vào TẠI nến trigger, R1 vào sau trigger, NO_FILL tại nến trigger → bị bắt", nhanh=True)
def t_sm_trade_neg():
    t0 = VV.T0; sg = dict(reason=16, trigger_ts_ms=t0)
    base = dict(outcome="TP1", fill_note=None, entry_ts_ms=t0, entry_price=2000.0, exit_ts_ms=t0 + 600000)
    kt(MT.kiem_lenh(base, sg, "next_open") != [], "R2 vào tại trigger lọt")
    kt(MT.kiem_lenh(dict(base, entry_ts_ms=t0 + 300000), sg, "close") != [], "R1 vào sau trigger lọt")
    kt(MT.kiem_lenh(dict(base, outcome="NO_FILL", fill_note="GAP_BEYOND_SL", exit_ts_ms=None), sg, "next_open") != [], "NO_FILL tại trigger lọt")
    kt(MT.kiem_lenh(dict(base, entry_ts_ms=t0 + 300000), sg, "next_open") == [], "R2 hợp lệ bị bác")
    return "4 ca"


# ================================================================================ 2. MÁY TRẠNG THÁI
def EVS(seq, setup="SU5"):
    return [dict(setup_id="x", emit_seq=i, event_type=e, setup=setup) for i, e in enumerate(seq)]


@T("KD-SM-TABLE", "Máy trạng thái", "Bảng chuyển tiếp: 9 chuỗi hợp lệ → 0 lỗi; 10 chuỗi không hợp lệ (CREATED→ARMED, STEP→STEP, CREATED→TRIGGER, sau kết thúc, SKIP ở SU-3, END ở SU-5, không có CREATED, 2 CREATED, ARMED→STEP, TRIGGER→VOID) → bắt hết", nhanh=True)
def t_sm_table():
    ok = [(["CREATED", "VOID"], "SU5"), (["CREATED", "EXPIRED"], "SU3"), (["CREATED", "STEP", "ARMED", "TRIGGER"], "SU5"), (["CREATED", "STEP", "ARMED", "VOID"], "SU3"),
          (["CREATED", "STEP", "ARMED", "EXPIRED"], "SU5"), (["CREATED", "STEP", "SKIP"], "SU5"), (["CREATED", "STEP", "END_NO_EVENT"], "SU3"), (["CREATED", "STEP", "VOID"], "SU5"),
          (["CREATED", "STEP"], "SU3")]
    sai = [(["CREATED", "ARMED", "TRIGGER"], "SU5"), (["CREATED", "STEP", "STEP"], "SU5"), (["CREATED", "TRIGGER"], "SU5"), (["CREATED", "VOID", "STEP"], "SU5"),
           (["CREATED", "STEP", "SKIP"], "SU3"), (["CREATED", "STEP", "END_NO_EVENT"], "SU5"), (["STEP", "ARMED"], "SU5"), (["CREATED", "CREATED"], "SU5"),
           (["CREATED", "STEP", "ARMED", "STEP"], "SU5"), (["CREATED", "STEP", "ARMED", "TRIGGER", "VOID"], "SU3")]
    for q, su in ok:
        kt(MT.kiem_vong_doi(EVS(q, su)) == [], f"hợp lệ bị bác: {q}")
    for q, su in sai:
        kt(MT.kiem_vong_doi(EVS(q, su)) != [], f"không hợp lệ lọt: {q} {su}")
    return dict(hop_le=len(ok), khong_hop_le=len(sai))


@T("KD-SM-ENGINE", "Máy trạng thái", "Đầu ra engine thật (khối Pine nguyên văn qua adapter): 40 seed SYNTH + kịch bản SU-3 định hướng → mọi chuyển tiếp thuộc bảng; thống kê chuyển tiếp quan sát được")
def t_sm_engine():
    import chuan_hoa as CH
    tk = {}; loi = []
    for sd in range(40):
        ev = CH.replay_synth(sd)["events"]; loi += MT.kiem_vong_doi(ev)
        th = {}
        for e in ev:
            th.setdefault(e["setup_id"], []).append(e["event_type"])
        for v in th.values():
            for a, b in zip(["(bắt đầu)"] + v, v):
                tk[f"{a}→{b}"] = tk.get(f"{a}→{b}", 0) + 1
    loi += MT.kiem_vong_doi(CH.replay_su3_co_dinh()["events"])
    kt(not loi, f"{len(loi)} vi phạm: {loi[:3]}")
    kt(all(k.split("→")[1] in MT.CHUYEN.get(k.split("→")[0], set()) for k in tk), "chuyển tiếp ngoài bảng")
    return dict(chuyen_tiep_quan_sat=tk)


@T("KD-SM-TRADE", "Máy trạng thái", "Vòng đời lệnh: mọi đầu ra của code (5.000 ca) thỏa máy trạng thái lệnh; 8 vi phạm dựng tay (vào trước trigger, thoát trước vào, NO_FILL ở R1, OPEN có thoát, TIMEOUT không thoát, đã vào thiếu giá vào, lệnh cho tín hiệu bị bỏ, ghi chú lạ) đều bị bắt")
def t_sm_trade():
    R = random.Random(51); n = 0
    for _ in range(5000):
        s, b, c = ca_ngau_nhien(R)
        r = MP.mo_phong(s, b, 0, cfg_impl(c))
        sg = dict(reason=16, trigger_ts_ms=b[0]["t"])
        kt(MT.kiem_lenh(r, sg, c["entry"]) == [], f"lệnh hợp lệ bị bác {r['outcome']} {r['fill_note']}"); n += 1
    t0 = VV.T0
    base = dict(outcome="TP1", fill_note=None, entry_ts_ms=t0, entry_price=2000.0, exit_ts_ms=t0 + 600000)
    sg = dict(reason=16, trigger_ts_ms=t0)
    sai = [(dict(base, entry_ts_ms=t0 - 300000), "close"), (dict(base, exit_ts_ms=t0 - 300000), "close"), (dict(base, outcome="NO_FILL", fill_note="GAP_BEYOND_SL", exit_ts_ms=None, entry_ts_ms=t0 + 300000), "close"),
           (dict(base, outcome="OPEN"), "close"), (dict(base, outcome="TIMEOUT", exit_ts_ms=None), "close"), (dict(base, entry_price=None), "close"),
           (base, None), (dict(base, outcome="NO_DATA", fill_note="LA"), "close")]
    for tr, rule in sai:
        kt(MT.kiem_lenh(tr, dict(sg, reason=15) if rule is None else sg, rule or "close") != [], f"vi phạm lọt: {tr}")
    return dict(hop_le=n, vi_pham_bat=len(sai))

# ================================================================================ 3. KHỬ TRÙNG / THỨ TỰ
def SG(seq, sym="XAUUSD", su="SU3", d=1, t=5, reason=16):
    # signal_id cố ý NGƯỢC thứ tự emit_seq để phát hiện sắp xếp theo id (F2)
    return dict(signal_id=f"id{999 - seq:03d}", emit_seq=seq, symbol=sym, setup=su, dir=d, trigger_ts_ms=t, reason=reason, dup_key=f"{sym}|{su}|{d}|{t}")


@T("KD-DUP-GOLD", "Khử trùng", "Golden: cùng symbol/setup/chiều/nến → trùng (giữ emit_seq nhỏ); khác chiều / khác setup / khác symbol / khác nến → KHÔNG trùng; tín hiệu bị bỏ (lý do 1) phát trước bản đạt S1 không che bản đạt S1 (F26)", nhanh=True)
def t_dup_gold():
    import pipeline as PL
    a = [SG(3), SG(1), SG(2, d=-1), SG(4, su="SU5"), SG(5, sym="BTCUSD"), SG(6, t=10)]
    g, n = MP.khu_trung(a)
    kt([s["emit_seq"] for s in g] == [1, 2, 4, 5, 6] and n == 1, f"giữ {[s['emit_seq'] for s in g]}, loại {n}")
    g2, n2 = PL.chon_tin_hieu_lenh([SG(1, reason=1), SG(2, reason=16)])
    kt([s["emit_seq"] for s in g2] == [2] and n2 == 0, "F26: bản đạt S1 bị che")
    g3, n3 = PL.chon_tin_hieu_lenh([SG(1, reason=16), SG(2, reason=16), SG(3, reason=15)])
    kt([s["emit_seq"] for s in g3] == [1] and n3 == 1, "hai bản đạt S1 trùng phải giữ bản đầu")
    for bad in ([dict(SG(1), emit_seq=None)], [SG(1), dict(SG(2), emit_seq=1)], [dict(SG(1), emit_seq=True)]):
        try:
            MP.khu_trung(bad); kt(False, "thiếu/trùng/bool emit_seq không bị từ chối")
        except ValueError:
            kt(True)
    return "ok"


@T("KD-DUP-PROP", "Khử trùng", "Thuộc tính: 800 tập ngẫu nhiên (va chạm thời điểm, chéo symbol/setup/chiều) × 5 lần xáo trộn → tập giữ = oracle (min emit_seq mỗi khóa), không phụ thuộc thứ tự đầu vào")
def t_dup_prop():
    R = random.Random(61)
    for _ in range(800):
        n = R.randint(1, 25); seqs = R.sample(range(100), n)
        a = [SG(q, sym=R.choice(("XAUUSD", "BTCUSD")), su=R.choice(("SU3", "SU5")), d=R.choice((1, -1)), t=R.choice((5, 10, 15))) for q in seqs]
        ref = OR.khu_trung(a)
        for _ in range(5):
            R.shuffle(a); g, nb = MP.khu_trung(a)
            kt({s["emit_seq"] for s in g} == ref and nb == len(a) - len(ref), "lệch oracle")
            kt([s["emit_seq"] for s in g] == sorted(s["emit_seq"] for s in g), "đầu ra không theo emit_seq")
    return "800 × 5"


@T("KD-DUP-SEED", "Khử trùng", "Va chạm chéo seed: gộp 2 lượt replay KHÔNG tiền tố → bộ kiểm cấp bảng báo trùng emit_seq/ID; pipeline gộp có tiền tố seed → phễu 'trùng' = số khử trùng thật")
def t_dup_seed():
    import chuan_hoa as CH, pipeline as PL
    a, b = CH.replay_synth(1), CH.replay_synth(2)
    loi = HD.kiem_bang(a["events"] + b["events"], a["signals"] + b["signals"], [])
    kt(any("trùng" in x for x in loi), "gộp seed không bị phát hiện")
    syn = PL.chay_synth("XAUUSD", "SU5", seeds=range(12))
    kt(syn["phieu"]["trung"] == syn["bo_trung"], f"phễu {syn['phieu']['trung']} ≠ {syn['bo_trung']}")
    return dict(loi_gop=loi[:2], trung=syn["bo_trung"], trung_s1=syn["bo_trung_s1"])

# ================================================================================ 4. LỌC DANH MỤC
def TP_(e, x, o="TP1", sym="XAUUSD", su="SU5", seq=0, sid=None):
    return dict(symbol=sym, setup=su, entry_ts_ms=e, exit_ts_ms=x, outcome=o, emit_seq=seq, signal_id=sid or f"{sym}{su}{e}{seq}")


@T("KD-OCC-GOLD", "Lọc danh mục", "Golden: NO_FILL/NO_DATA/INVALID không chiếm; OPEN chiếm tới hết; TP1/SL/TIMEOUT giải phóng sau thoát; vào ĐÚNG thời điểm thoát → bỏ (quy ước bảo thủ); vào sau → giữ; chéo symbol/setup không chặn; cùng thời điểm vào → theo emit_seq rồi signal_id", nhanh=True)
def t_occ_gold():
    ca = [([TP_(1, None, "NO_FILL"), TP_(2, None, "NO_DATA"), TP_(3, None, "INVALID"), TP_(4, 9)], 0),
          ([TP_(1, None, "OPEN"), TP_(5, 9), TP_(5, 9, su="SU3"), TP_(5, 9, sym="BTCUSD")], 1),
          ([TP_(1, 10, "SL"), TP_(11, 20, "TIMEOUT"), TP_(21, 30)], 0), ([TP_(1, 10), TP_(10, 20)], 1), ([TP_(1, 10, "TIMEOUT"), TP_(10, 20)], 1),
          ([TP_(5, 9, seq=2), TP_(5, 9, seq=1)], 1), ([TP_(5, 9, seq=1, sid="b"), TP_(5, 9, seq=1, sid="a")], 1)]
    for tr, kv in ca:
        g, n = MP.khong_chong(tr)
        kt(n == kv, f"bỏ {n} ≠ {kv}"); kt(OR.kiem_danh_muc(tr, g) == [], f"tính chất sai {OR.kiem_danh_muc(tr, g)}")
    g, _ = MP.khong_chong([TP_(5, 9, seq=2), TP_(5, 9, seq=1)]); kt(g[0]["emit_seq"] == 1, "tie emit_seq")
    g, _ = MP.khong_chong([TP_(5, 9, seq=1, sid="b"), TP_(5, 9, seq=1, sid="a")]); kt(g[0]["signal_id"] == "a", "tie signal_id")
    return f"{len(ca)} ca"


@T("KD-OCC-PROP", "Lọc danh mục", "Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ 7 kết cục, va chạm biên, chéo khóa) × 4 lần xáo trộn → thỏa P1–P4 của oracle và đầu ra không phụ thuộc thứ tự")
def t_occ_prop():
    R = random.Random(71)
    for _ in range(1000):
        tr = []
        for j in range(R.randint(1, 20)):
            o = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID")); e = R.randint(0, 30)
            tr.append(TP_(e, (e + R.randint(0, 8)) if o in ("TP1", "SL", "TIMEOUT") else None, o, sym=R.choice(("XAUUSD", "BTCUSD")), su=R.choice(("SU3", "SU5")), seq=R.randint(0, 5), sid=f"id{j}"))
        ref = None
        for _ in range(4):
            R.shuffle(tr); g, n = MP.khong_chong(tr)
            kt(OR.kiem_danh_muc(tr, g) == [], "vi phạm tính chất")
            k = sorted(t["signal_id"] for t in g); ref = ref or k; kt(k == ref, "phụ thuộc thứ tự")
    return "1.000 × 4"

# ================================================================================ 5. HỢP ĐỒNG – ĐỘT BIẾN CÓ PHÁN QUYẾT BIẾT TRƯỚC
def bo_chuan(dir_=1, tp=True):
    """Bộ dữ liệu hợp lệ dựng TAY (độc lập pipeline): một thể hiện CREATED→STEP→ARMED→TRIGGER, một tín hiệu đạt S1, lệnh R1 TP1 (hoặc SL nếu TP null)."""
    t0 = 1767323100000; sid = "aaaa000000000001"
    E = lambda k, et, st, rs, sq: dict(schema_version="1.2", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", tf="5", setup="SU5", mode="SHADOW", setup_id=sid,   # noqa: E731
                                        event_id=HD.hid(sid, et, t0 + 300000 * k, sq), emit_seq=sq, event_type=et, step=st, ts=HD.ts_tu_ms(t0 + 300000 * k), ts_ms=t0 + 300000 * k,
                                        dir=dir_, state={"TRIGGER": 17, "ARMED": 2}.get(et, 0), reason=16 if et == "TRIGGER" else 0, anchor_price=2000.0, ext_price=5.0)
    ev = [E(0, "CREATED", 0, 0, 0), E(1, "STEP", 1, 0, 1), E(2, "ARMED", 2, 0, 2), E(3, "TRIGGER", 2, 16, 3)]
    tt = t0 + 900000; p, sl = 2000.0, 2000.0 - dir_ * 5
    tp1 = 2000.0 + dir_ * 10 if tp else None
    sg = [dict(schema_version="1.2", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", setup="SU5", setup_id=sid, signal_id=HD.hid(sid, tt), emit_seq=3, dir=dir_,
               trigger_ts=HD.ts_tu_ms(tt), trigger_ts_ms=tt, p_ref=p, sl=sl, tp1=tp1, rr=2.0 if tp else None, reason=16, perm_reg=None, perm_vol=None, dup_key=f"XAUUSD|SU5|{dir_}|{tt}")]
    if tp:
        tr = dict(outcome="TP1", exit_price=tp1, r_gross=2.0, r_net=1.9, mfe_r=2.0, mae_r=-0.2, rr_entry=2.0)
    else:
        tr = dict(outcome="SL", exit_price=sl, r_gross=-1.0, r_net=-1.1, mfe_r=0.4, mae_r=-1.0, rr_entry=None)
    trs = [dict(schema_version="1.2", signal_id=sg[0]["signal_id"], symbol="XAUUSD", setup="SU5", emit_seq=3, sim_rule="R-close-sl_first-288", cost_model="C-s0.5-c0.0-sl0.0",
                entry_ts_ms=tt, entry_price=p, risk=5.0, fill_note=None, exit_ts_ms=tt + 600000, bars_held=2, same_bar_conflict=False, gap_exit=False, time_gaps=0, max_gap_ms=0, **tr)]
    return ev, sg, trs


DOT_BIEN = [
    ("xóa trường bắt buộc (EVENTS.reason)", lambda e, s, t: e[0].pop("reason")),
    ("xóa trường bắt buộc (TRADES.outcome)", lambda e, s, t: t[0].pop("outcome")),
    ("thêm trường lạ", lambda e, s, t: s[0].update(la=1)),
    ("sai kiểu (p_ref chuỗi)", lambda e, s, t: s[0].update(p_ref="2000")),
    ("bool giả int (dir = True)", lambda e, s, t: e[1].update(dir=True)),
    ("bool giả int (bars_held = True)", lambda e, s, t: t[0].update(bars_held=True)),
    ("sai timestamp (ts ≠ ts_ms)", lambda e, s, t: e[2].update(ts_ms=e[2]["ts_ms"] + 300000)),
    ("sai timestamp (trigger_ts lệch)", lambda e, s, t: s[0].update(trigger_ts="2026-01-01T00:00:00Z")),
    ("sai ID (signal_id không tái lập)", lambda e, s, t: (s[0].update(signal_id="ffffffffffffffff"), t[0].update(signal_id="ffffffffffffffff"))),
    ("trùng sự kiện", lambda e, s, t: e.append(dict(e[1]))),
    ("trùng lệnh", lambda e, s, t: t.append(dict(t[0]))),
    ("sai thứ tự (emit_seq ngược thời gian)", lambda e, s, t: (e[1].update(emit_seq=2), e[2].update(emit_seq=1))),
    ("sai R (r_gross ≠ giá)", lambda e, s, t: t[0].update(r_gross=2.2, r_net=2.1, mfe_r=2.2)),
    ("sai risk", lambda e, s, t: t[0].update(risk=4.0)),
    ("sai risk (nhất quán nội bộ bản ghi)", lambda e, s, t: t[0].update(risk=4.0, exit_price=t[0]["entry_price"] + (t[0]["exit_price"] - t[0]["entry_price"]) * 0.8,
                                                                       r_gross=2.0, r_net=2.0 - 0.5 / 4.0) if t[0]["outcome"] == "TP1" else t[0].update(risk=4.0, gap_exit=True, exit_price=t[0]["entry_price"] - 6.0 * s[0]["dir"], r_gross=-1.5, r_net=-1.5 - 0.5 / 4.0, mae_r=-1.5)),
    ("sai outcome (SL với R dương)", lambda e, s, t: t[0].update(outcome="SL")),
    ("sai hình học (SL sai phía)", lambda e, s, t: s[0].update(sl=s[0]["p_ref"] + 5 * s[0]["dir"])),
    ("sai vòng đời (CREATED → ARMED)", lambda e, s, t: e.pop(1)),
    ("sai vòng đời (sự kiện sau TRIGGER)", lambda e, s, t: e.append(dict(e[3], event_type="VOID", event_id="z", emit_seq=4, ts_ms=e[3]["ts_ms"] + 300000, ts=HD.ts_tu_ms(e[3]["ts_ms"] + 300000), state=6, reason=6))),
    ("NaN", lambda e, s, t: t[0].update(mfe_r=float("nan"))),
    ("Infinity", lambda e, s, t: s[0].update(sl=float("inf"))),
    ("−Infinity", lambda e, s, t: e[0].update(anchor_price=float("-inf"))),
    ("NO_FILL có R", lambda e, s, t: t[0].update(outcome="NO_FILL", fill_note="GAP_BEYOND_SL")),
    ("OPEN có thoát", lambda e, s, t: t[0].update(outcome="OPEN")),
    ("chi phí không khớp cost_model", lambda e, s, t: t[0].update(r_net=1.95)),
    ("rr_entry sai", lambda e, s, t: t[0].update(rr_entry=1.0)),
    ("lệnh cho tín hiệu bị bỏ (reason 15)", lambda e, s, t: (s[0].update(reason=15), e[3].update(reason=15, state=4))),
    ("ID chéo seed (gộp hai bộ giống hệt)", lambda e, s, t: (e.extend([dict(x) for x in e]), s.extend([dict(x) for x in s]))),
]


@T("KD-HD-MUT", "Hợp đồng dữ liệu", "28 loại đột biến trên bộ hợp lệ dựng tay (BUY và SELL, có/không TP1) – mỗi đột biến vi phạm hợp đồng THEO CẤU TRÚC → bộ kiểm phải bác 100 %", nhanh=True)
def t_hd_mut():
    lot = []; n = 0
    for dir_, tp in ((1, True), (-1, True), (1, False)):
        e0, s0, t0 = bo_chuan(dir_, tp)
        kt(HD.kiem_bang(e0, s0, t0) == [], f"bộ chuẩn bị bác: {HD.kiem_bang(e0, s0, t0)[:2]}")
        for ten, f in DOT_BIEN:
            if not tp and ten in ("sai outcome (SL với R dương)", "rr_entry sai"):
                continue
            e, s, t = copy.deepcopy(e0), copy.deepcopy(s0), copy.deepcopy(t0)
            f(e, s, t); n += 1
            try:
                ok = HD.kiem_bang(e, s, t) != []
            except Exception as ex:      # noqa: BLE001
                ok = False; ten = f"{ten} (NGOẠI LỆ {ex!r})"
            if not ok:
                lot.append((dir_, tp, ten))
            kt(ok, f"đột biến lọt: {ten} dir={dir_} tp={tp}")
    return dict(so_dot_bien=n, lot=lot)


@T("KD-HD-VALID", "Hợp đồng dữ liệu", "Không báo nhầm: 8 bộ hợp lệ (BUY, SELL, TP1 null, R2 NO_FILL, R2 khớp, OPEN, NO_DATA sau khi vào, INVALID) → 0 lỗi", nhanh=True)
def t_hd_valid():
    e, s, t = bo_chuan(1, True); kt(HD.kiem_bang(e, s, t) == [], "BUY")
    e, s, t = bo_chuan(-1, True); kt(HD.kiem_bang(e, s, t) == [], "SELL")
    e, s, t = bo_chuan(1, False); kt(HD.kiem_bang(e, s, t) == [], "TP null")
    tt = s[0]["trigger_ts_ms"]
    nf = dict(t[0], sim_rule="R-next_open-sl_first-288", outcome="NO_FILL", fill_note="GAP_BEYOND_SL", entry_ts_ms=tt + 300000, entry_price=1994.0, risk=None, r_gross=None, r_net=None,
              mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, rr_entry=None)
    e, s, t = bo_chuan(1, False); kt(HD.kiem_bang(e, s, [nf]) == [], f"R2 NO_FILL {HD.kiem_bang(e, s, [nf])[:2]}")
    e, s, t = bo_chuan(1, True)
    r2 = dict(t[0], sim_rule="R-next_open-sl_first-288", entry_ts_ms=tt + 300000, entry_price=2001.0, risk=6.0, exit_price=2010.0, r_gross=1.5, r_net=1.5 - 0.5 / 6, mfe_r=1.5, mae_r=-0.1, rr_entry=1.5)
    kt(HD.kiem_bang(e, s, [r2]) == [], f"R2 khớp {HD.kiem_bang(e, s, [r2])[:2]}")
    op = dict(t[0], outcome="OPEN", exit_ts_ms=None, exit_price=None, r_gross=0.4, r_net=0.3, mfe_r=0.5, mae_r=-0.1)
    kt(HD.kiem_bang(e, s, [op]) == [], f"OPEN {HD.kiem_bang(e, s, [op])[:2]}")
    nd = dict(t[0], outcome="NO_DATA", fill_note="INVALID_BAR_AFTER_FILL", risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, exit_ts_ms=None, exit_price=None, bars_held=0, rr_entry=None)
    kt(HD.kiem_bang(e, s, [nd]) == [], f"NO_DATA sau vào {HD.kiem_bang(e, s, [nd])[:2]}")
    iv = dict(nd, outcome="INVALID", fill_note="INVALID_RISK")
    kt(HD.kiem_bang(e, s, [iv]) == [], f"INVALID {HD.kiem_bang(e, s, [iv])[:2]}")
    return "8 bộ"


@T("KD-JSON", "JSON strict", "Mọi file .json trong các thư mục kết quả/bàn giao parse được ở chế độ strict (không NaN/Infinity/−Infinity); mọi lệnh json.dump trong module Stage 3 mới dùng allow_nan=False; PF không có lỗ → null + trạng thái")
def t_json():
    def cam(x):
        raise ValueError(f"hằng không hợp lệ {x}")
    files = []
    for d in ("ket_qua_stage3", "ket_qua_shadow_eval", "token_budget", "kiem_toan_stage3"):
        for root, _, fs in os.walk(os.path.join(G, d)):
            files += [os.path.join(root, f) for f in fs if f.endswith(".json")]
    # Hiện vật LỊCH SỬ do bản TRƯỚC SỬA sinh ra (bằng chứng F10: profit_factor = Infinity trong CS-01 cũ) – giữ nguyên làm bằng chứng, không sửa
    LICH_SU = {os.path.join(G, "ket_qua_shadow_eval", "ket_qua_truoc_sua.json"), os.path.join(G, "ket_qua_shadow_eval", "ket_qua.json")}
    khong_strict = []
    for p in files:
        try:
            json.loads(open(p, encoding="utf-8").read(), parse_constant=cam)
        except ValueError:
            khong_strict.append(p)
    kt(set(khong_strict) <= LICH_SU, f"file JSON không strict ngoài danh sách lịch sử: {set(khong_strict) - LICH_SU}")
    for p in khong_strict:
        kt("Infinity" in open(p, encoding="utf-8").read(), "hiện vật lịch sử phải chứa đúng lỗi F10 đã biết")
    sites = {}
    for f in ("chuan_hoa.py", "du_lieu.py", "pipeline.py", "kiem_thu_stage3.py", "mo_phong_lenh.py", "hop_dong.py", "chi_so.py", "may_trang_thai.py"):
        src = open(os.path.join(G, "shadow_eval", f), encoding="utf-8").read()
        for m in re.finditer(r"json\.dump\(", src):
            cau = "\n".join(src[m.start():].split("\n")[:3])            # lời gọi có thể xuống dòng: xét 3 dòng
            sites[f"{f}:{src[:m.start()].count(chr(10)) + 1}"] = "allow_nan=False" in cau
    src = open(os.path.join(G, "token_budget", "cong_token.py"), encoding="utf-8").read()
    for m in re.finditer(r"json\.dump\(", src):
        sites[f"cong_token.py:{src[:m.start()].count(chr(10)) + 1}"] = "allow_nan=False" in "\n".join(src[m.start():].split("\n")[:3])
    kt(all(sites.values()), f"dump không strict: {[k for k, v in sites.items() if not v]}")
    h = CS.hieu_qua([dict(symbol="X", setup="S", outcome="TP1", r_net=1.0, mfe_r=1.0, mae_r=0.0, bars_held=1, same_bar_conflict=False, gap_exit=False)] * 3)
    json.dumps({str(k): v for k, v in h.items()}, allow_nan=False)
    kt(h[("X", "S")]["profit_factor"] is None and h[("X", "S")]["pf_trang_thai"] == "KHONG_CO_LENH_THUA", "PF ∞")
    return dict(so_file_json=len(files), khong_strict_lich_su=[os.path.relpath(p, G) for p in khong_strict], lenh_dump=sites)

# ================================================================================ 6. CHỈ SỐ
for _m in VV.M:
    def _mk2(m):
        @T(f"KD-MET-{m['id'][2:]}", "Golden chỉ số", m["mo"], nhanh=True)
        def t_met():
            h = CS.hieu_qua(m["tr"])[("XAUUSD", "SU5")]; o = OR.chi_so(m["tr"])
            for k, v in m["kv"].items():
                kt(bang(v, h[k]), f"code {k}: kỳ vọng {v}, được {h[k]}"); kt(bang(v, o[k]), f"oracle {k}: kỳ vọng {v}, được {o[k]}")
            json.dumps(h, allow_nan=False)
            return {k: h[k] for k in m["kv"]}
        t_met.__name__ = "t_met_" + m["id"].replace("-", "_")
    _mk2(_m)


@T("KD-MET-PROP", "Chỉ số", "Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ kết cục, R = 0 đúng, chi phí âm sau TP1) – code = oracle trên mọi trường chung; tách nhóm (symbol, setup) không rò rỉ")
def t_met_prop():
    R = random.Random(81)
    for _ in range(1000):
        tr = []
        for _ in range(R.randint(0, 30)):
            o = R.choice(("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL", "NO_DATA", "INVALID"))
            r = None if o in ("NO_FILL", "NO_DATA", "INVALID") else R.choice((0.0, -1.0, 2.0, round(R.uniform(-3, 3), 3), -0.05))
            tr.append(dict(VV.TR(o, r), symbol=R.choice(("XAUUSD", "BTCUSD")), setup=R.choice(("SU3", "SU5"))))
        h = CS.hieu_qua(tr)
        for k, v in h.items():
            o = OR.chi_so([t for t in tr if (t["symbol"], t["setup"]) == k])
            for f in o:
                kt(bang(o[f], v[f]), f"{k} {f}: code {v[f]} oracle {o[f]}")
    return "1.000 tập"


@T("KD-BOOT", "Bootstrap", "CI i.i.d. và moving-block: xác định theo seed; i.i.d. không phụ thuộc thứ tự; n < 2 → null; R hằng → suy biến; L = round(n^(1/3)); chuỗi tự tương quan mạnh → CI khối rộng hơn i.i.d.; mọi giá trị hữu hạn")
def t_boot():
    R = random.Random(91)
    x = [round(R.uniform(-1, 2), 3) for _ in range(60)]
    kt(CS.bootstrap_ci(x, 7, ("a",)) == CS.bootstrap_ci(list(reversed(x)), 7, ("a",)), "i.i.d. phụ thuộc thứ tự")
    kt(CS.bootstrap_khoi(x, 7, ("a",)) == CS.bootstrap_khoi(x, 7, ("a",)), "khối không xác định")
    kt(CS.bootstrap_khoi([1.0], 7, ("a",))[1] == "N_NHO_HON_2" and CS.bootstrap_ci([1.0], 7, ("a",))[0] is None, "n<2")
    kt(CS.bootstrap_khoi([0.5] * 10, 7, ("a",))[0] == [0.5, 0.5], "hằng")
    kt(CS.bootstrap_khoi(x, 7, ("a",))[2] == round(60 ** (1 / 3)), "L")
    ac = [2.0] * 30 + [-1.0] * 30                                  # tự tương quan cực mạnh theo thời gian
    ci_i, _ = CS.bootstrap_ci(ac, 7, ("b",)); ci_k, _, _ = CS.bootstrap_khoi(ac, 7, ("b",), L=10)
    kt(ci_k[1] - ci_k[0] > ci_i[1] - ci_i[0], f"khối {ci_k} không rộng hơn iid {ci_i}")
    kt(all(math.isfinite(v) for v in ci_i + ci_k), "không hữu hạn")
    return dict(iid=ci_i, khoi_L10=ci_k, ghi_chu="chỉ kiểm cơ chế – không phải bằng chứng thống kê thị trường")


@T("KD-FUNNEL", "Phễu", "Golden phễu có mẫu số KHÓA: tỷ lệ = tử / mẫu theo MAU_SO; mẫu = 0 → null; đếm NO_FILL / NO_DATA / INVALID / đã vào từ TRADES; SU-3 và SU-5 tách riêng", nhanh=True)
def t_funnel():
    E = lambda et, su="SU3", r=0: dict(symbol="XAUUSD", setup=su, event_type=et, reason=r)     # noqa: E731
    ev = [E("CREATED")] * 4 + [E("ARMED")] * 2 + [E("VOID", r=6), E("EXPIRED", r=7), E("END_NO_EVENT")] + [E("CREATED", "SU5")]
    sg = [dict(symbol="XAUUSD", setup="SU3", reason=r, dup_key=k) for r, k in ((16, "a"), (16, "a"), (15, "b"), (1, "c"))]
    tr = [dict(symbol="XAUUSD", setup="SU3", outcome=o) for o in ("TP1", "NO_FILL", "NO_DATA", "INVALID", "OPEN")]
    f = CS.phieu(ev, sg, tr); a, b = f[("XAUUSD", "SU3")], f[("XAUUSD", "SU5")]
    kv = dict(tao=4, armed=2, trigger=4, s1_dat=2, bo_quyen=1, bo_khac=1, trung=1, lenh_gia_lap=5, khong_khop=1, khong_du_lieu=1, khong_hop_le=1, da_vao=2,
              ty_le_armed=0.5, ty_le_void=0.25, ty_le_het_han=0.25, ty_le_ket_thuc_khong_su_kien=0.25, ty_le_trigger_tren_armed=2.0, ty_le_s1_dat=0.5, ty_le_bo_quyen=0.25,
              ty_le_bo_khac=0.25, ty_le_trung=0.25, ty_le_khong_khop=0.2, ty_le_khong_du_lieu=0.2, ty_le_khong_hop_le=0.2, ty_le_da_vao=0.4)
    for k, v in kv.items():
        kt(bang(v, a[k]), f"{k}: {v} vs {a[k]}")
    kt(b["tao"] == 1 and b["ty_le_armed"] == 0.0 and b["ty_le_trigger_tren_armed"] is None and b["ty_le_s1_dat"] is None, "SU5 / mẫu 0")
    return {k: a[k] for k in kv}

# ================================================================================ 7. BASELINE, HỒI QUY, ĐỘT BIẾN MÃ NGUỒN
@T("KD-BASELINE", "Baseline", "SHA-256 tính TRỰC TIẾP trên source Pine 0.3.8 và 0.3.9 trùng giá trị chuẩn", nhanh=True)
def t_base():
    a = sha_f(os.path.join(G, "src038", "ATA_P3_Build_0.3.8_Candidate_Indicator.pine")); b = sha_f(os.path.join(G, "src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine"))
    kt(a == SHA38 and b == SHA39, f"{a} / {b}")
    return dict(v038=a, v039=b)


LOI_THOI_S3 = {"OT-05": "Nến hỏng SAU khi vào nay ghi INVALID_BAR_AFTER_FILL (tách trạng thái, P0-9) – thay bằng KD-GOLD-R1-BADBAR, KD-ORACLE-PROP",
               "OT-06": "Thời gian lùi/trùng sau khi vào nay ghi NON_MONOTONIC_TIME_AFTER_FILL – thay bằng KD-ORACLE-PROP, KD-SM-TRADE",
               "HD-01": "Fixture dựng tay thiếu sự kiện STEP (CREATED → ARMED) – máy trạng thái 1.2 bác đúng; thay bằng KD-HD-VALID, KD-SM-TABLE"}


@T("KD-REG-S3", "Hồi quy", "Chạy LẠI bộ Stage 3 trước (kiem_thu_stage3.py, 88 test, gồm REG-01 = bộ cũ 22 test, REG-02 = bộ 0.3.9) KHÔNG sửa: mọi FAIL phải là assertion lỗi thời đã phân loại, có test thay thế")
def t_reg():
    if not os.path.exists(os.path.join(G, "shadow_eval", "kiem_thu_stage3.py")):
        return "BLOCKED", "không có bộ Stage 3 trước"
    p = subprocess.run([sys.executable, os.path.join(G, "shadow_eval", "kiem_thu_stage3.py")], capture_output=True, text=True, cwd=G, timeout=1800)
    r = json.load(open(os.path.join(G, "ket_qua_stage3", "ket_qua_kiem_thu.json"), encoding="utf-8"))
    fails = [x["test_id"] for x in r["ket_qua"] if x["status"] == "FAIL"]
    lot = [f for f in fails if f not in LOI_THOI_S3]
    kt(not lot, f"FAIL chưa phân loại: {lot}")
    reg01 = next(x for x in r["ket_qua"] if x["test_id"] == "REG-01"); reg02 = next(x for x in r["ket_qua"] if x["test_id"] == "REG-02")
    return dict(tom_tat=r["tom_tat"], fail=fails, phan_loai={k: LOI_THOI_S3[k] for k in fails}, REG_01=reg01["status"], REG_02=reg02["status"], exit=p.returncode)


DB = [  # (file, đoạn gốc, đoạn đột biến, mô tả)
    ("mo_phong_lenh.py", "if (pr - sl) * d <= 0:", "if (pr - sl) * d < 0:", "biên rủi ro 0"),
    ("mo_phong_lenh.py", "if (entry - sl) * d <= 0:\n            return _khong(base, \"NO_FILL\"", "if (entry - sl) * d < 0:\n            return _khong(base, \"NO_FILL\"", "R2 Open = SL"),
    ("mo_phong_lenh.py", "if tp is not None and (entry - tp) * d >= 0:", "if tp is not None and (entry - tp) * d > 0:", "R2 Open = TP1"),
    ("mo_phong_lenh.py", "if d * (b[\"o\"] - sl) <= 0:", "if d * (b[\"o\"] - sl) < 0:", "gap SL biên"),
    ("mo_phong_lenh.py", "hit_sl = d * (adv - sl) <= 0", "hit_sl = d * (adv - sl) < 0", "chạm SL biên"),
    ("mo_phong_lenh.py", "hit_tp = tp is not None and d * (fav - tp) >= 0", "hit_tp = tp is not None and d * (fav - tp) > 0", "chạm TP biên"),
    ("mo_phong_lenh.py", "if cfg.same_bar == \"sl_first\":", "if cfg.same_bar != \"sl_first\":", "đảo quy tắc cùng nến"),
    ("mo_phong_lenh.py", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), min(mae, R(adv)))", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), mae)", "MAE nến thoát TP1"),
    ("mo_phong_lenh.py", "return ra(\"SL\", k, sl, mfe, min(mae, -1.0))\n        if hit_tp", "return ra(\"SL\", k, sl, max(mfe, R(fav)), min(mae, -1.0))\n        if hit_tp", "MFE nến thoát SL"),
    ("mo_phong_lenh.py", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), min(mae, R(adv)), same_bar_conflict=True)", "return ra(\"TP1\", k, tp, max(mfe, R(tp)), mae, same_bar_conflict=True)", "F3 tái phát"),
    ("mo_phong_lenh.py", "end = min(len(bars), start + cfg.max_bars)", "end = min(len(bars), start + cfg.max_bars + 1)", "max_bars lệch 1"),
    ("mo_phong_lenh.py", "if start + cfg.max_bars > len(bars):", "if start + cfg.max_bars >= len(bars):", "biên OPEN/TIMEOUT"),
    ("mo_phong_lenh.py", "first = (k == start and cfg.entry == \"next_open\")", "first = (k == start)", "R1 bỏ kiểm gap nến đầu"),
    ("mo_phong_lenh.py", "cost = cfg.spread + cfg.commission + 2 * cfg.slippage", "cost = cfg.spread + cfg.commission + cfg.slippage", "chi phí trượt giá 1 lần"),
    ("mo_phong_lenh.py", "        ie, entry, start = i_trig, pr, i_trig + 1", "        ie, entry, start = i_trig, pr, i_trig", "R1 dùng nến trigger (nhìn trước)"),
    ("mo_phong_lenh.py", "if t.get(\"outcome\") in KHONG_VAO:\n            giu.append(t); continue", "if t.get(\"outcome\") == \"NO_DATA\":\n            giu.append(t); continue", "F1 tái phát (NO_FILL chiếm)"),
    ("mo_phong_lenh.py", "if k in mo and t[\"entry_ts_ms\"] <= mo[k]:", "if k in mo and t[\"entry_ts_ms\"] < mo[k]:", "biên vào = thoát"),
    ("mo_phong_lenh.py", "for s in sorted(signals, key=lambda x: x[\"emit_seq\"]):", "for s in sorted(signals, key=lambda x: x[\"signal_id\"]):", "F2 tái phát"),
    ("mo_phong_lenh.py", "x.get(\"emit_seq\", 0), str(x.get(\"signal_id\", \"\"))", "x.get(\"emit_seq\", 0)", "bỏ khóa phụ signal_id"),
    ("chi_so.py", "thang = [r for r in R if r > EPS_R]; thua = [r for r in R if r < -EPS_R]", "thang = [r for r in R if r > EPS_R]; thua = [r for r in R if r <= EPS_R]", "hòa vốn tính là thua"),
    ("chi_so.py", "pf, pfs = None, (\"KHONG_CO_LENH_THUA\" if thang else \"KHONG_CO_LENH_THANG_THUA\")", "pf, pfs = float(\"inf\"), \"OK\"", "F10 tái phát"),
    ("chi_so.py", "win_rate=len(thang) / n if n else None,", "win_rate=len(thang) / (len(thang) + len(thua)) if (thang or thua) else None,", "mẫu số win rate"),
    ("chi_so.py", "dong = [t for t in ts if t[\"outcome\"] in DONG]", "dong = [t for t in ts if t[\"outcome\"] in DONG + (\"OPEN\",)]", "OPEN vào R"),
    ("chi_so.py", "k = (B * int(round(alpha * 1000))) // 2000", "k = (B * int(round(alpha * 1000))) // 1000", "phân vị sai"),
    ("chi_so.py", "o[k][\"trung\"] = sum(1 for x in ds if x is not None) - len({x for x in ds if x is not None})", "o[k][\"trung\"] = 0", "F11 tái phát"),
    ("hop_dong.py", "if t is float and not math.isfinite(v):", "if False:", "F12 tái phát (NaN)"),
    ("hop_dong.py", "if isinstance(ms, int) and not isinstance(ms, bool) and int(t.timestamp() * 1000) != ms:", "if False:", "bỏ ts ↔ ts_ms"),
    ("hop_dong.py", "if t in (int, float) and isinstance(v, bool):", "if False:", "bool giả int"),
    ("hop_dong.py", "if abs(t[\"risk\"] - (t[\"entry_price\"] - s[\"sl\"]) * d) > 1e-6:", "if False:", "bỏ kiểm risk"),
    ("hop_dong.py", "loi += [f\"MÁY TRẠNG THÁI: {x}\" for x in MT.kiem_vong_doi(events)]", "pass", "bỏ máy trạng thái sự kiện"),
    ("may_trang_thai.py", "\"CREATED\": {\"STEP\", \"VOID\", \"EXPIRED\"}", "\"CREATED\": {\"STEP\", \"VOID\", \"EXPIRED\", \"ARMED\"}", "nới CREATED → ARMED"),
    ("may_trang_thai.py", "if rule == \"next_open\" and t[\"entry_ts_ms\"] <= s[\"trigger_ts_ms\"]:", "if False:", "bỏ kiểm R2 vào sau trigger"),
]


@T("KD-MUT-SRC", "Đột biến mã nguồn", "Kiểm đột biến MÃ NGUỒN: 32 đột biến có chủ đích trên các module đã sửa (biên, quy ước nến thoát, F1/F2/F3/F10/F11/F12 tái phát, chi phí, nhìn trước…) – mỗi đột biến chạy tập test nhanh độc lập trong bản sao; đột biến sống sót được liệt kê")
def t_mut_src():
    if A.nhanh:
        return "NOT TESTED", "chế độ nhanh"
    song, chet = [], []
    for f, a, b, mo in DB:
        src = open(os.path.join(A.module_dir, f), encoding="utf-8").read()
        kt(src.count(a) >= 1, f"đoạn gốc không có trong {f}: {mo}")
        tmp = tempfile.mkdtemp(prefix="kd_mut_")
        try:
            for x in os.listdir(A.module_dir):
                if x.endswith(".py"):
                    shutil.copy(os.path.join(A.module_dir, x), tmp)
            open(os.path.join(tmp, f), "w", encoding="utf-8").write(src.replace(a, b, 1))
            p = subprocess.run([sys.executable, os.path.abspath(__file__), "--nhanh", "--module-dir", tmp, "--out", os.path.join(tmp, "out")], capture_output=True, text=True, timeout=600)
            (chet if p.returncode != 0 else song).append(mo)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    kt(not song, f"đột biến sống sót: {song}")
    return dict(tong=len(DB), bi_giet=len(chet), song_sot=song)


def main():
    os.makedirs(A.out, exist_ok=True)
    t0 = time.time()
    for t in TESTS:
        if A.nhanh and not t.nhanh:
            continue
        t()
    if not A.nhanh:
        st = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for tid, mo, ly in (("KD-REAL-XAU-SU3", "Đánh giá SU-3 dữ liệu thật XAUUSD", "Không có OHLCV lịch sử có nguồn (mạng của công cụ tắt) và chưa có replay bối cảnh từ OHLCV"),
                            ("KD-REAL-XAU-SU5", "Đánh giá SU-5 dữ liệu thật XAUUSD", "Như trên"), ("KD-REAL-BTC-SU3", "Đánh giá SU-3 dữ liệu thật BTCUSD", "Như trên"),
                            ("KD-REAL-BTC-SU5", "Đánh giá SU-5 dữ liệu thật BTCUSD", "Như trên"),
                            ("KD-REPLAY-EQ", "Tương đương Python ↔ TradingView", "Không có dữ liệu đối chứng; Data Window chỉ giữ một phần sự kiện SHADOW (B-1)"),
                            ("KD-TV-TOKEN", "Token biên dịch thật 0.3.9", "TradingView không in số token khi compile thành công")):
            KQ.append(dict(test_id=tid, nhom="BLOCKED", muc_tieu=mo, phan_loai="FACT", status="BLOCKED", so_assertion=0, actual=ly, test_source="—", run_time=st, duration_ms=0, hash="-"))
        KQ.append(dict(test_id="KD-REPLAY-FULL", nhom="NOT TESTED", muc_tieu="Replay toàn script từ OHLCV (f_struct, MD-3/4/5, request.security, ta.*)", phan_loai="FACT", status="NOT TESTED",
                       so_assertion=0, actual="Chưa hiện thực – ngoài phạm vi (không xây full Pine interpreter)", test_source="—", run_time=st, duration_ms=0, hash="-"))
    dem = {}
    for x in KQ:
        dem[x["status"]] = dem.get(x["status"], 0) + 1
    tong = dict(tom_tat=dem, so_test=len(KQ), so_assertion=DEM["assert"], che_do="nhanh" if A.nhanh else "day_du", module_dir=A.module_dir,
                thoi_gian_s=round(time.time() - t0, 1), python=sys.version.split()[0], ket_qua=KQ, ca_lech=LECH,
                sha_module={f: sha_f(os.path.join(A.module_dir, f)) for f in ("mo_phong_lenh.py", "hop_dong.py", "chi_so.py", "may_trang_thai.py", "chuan_hoa.py", "pipeline.py") if os.path.exists(os.path.join(A.module_dir, f))},
                sha_oracle={f: sha_f(os.path.join(KD, f)) for f in ("oracle.py", "vector_vang.py", "chay_doc_lap.py")})
    json.dump(tong, open(os.path.join(A.out, "ket_qua_doc_lap.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, allow_nan=False, default=str)
    with open(os.path.join(A.out, "ket_qua_doc_lap.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f); w.writerow(["test_id", "nhom", "status", "so_assertion", "phan_loai", "muc_tieu", "hash"])
        for x in KQ:
            w.writerow([x["test_id"], x["nhom"], x["status"], x["so_assertion"], x["phan_loai"], x["muc_tieu"], x["hash"]])
    print(dem, "assertion:", DEM["assert"], f"{tong['thoi_gian_s']} s")
    sys.exit(1 if dem.get("FAIL") else 0)


if __name__ == "__main__":
    main()
