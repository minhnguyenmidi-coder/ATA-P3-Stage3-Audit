# -*- coding: utf-8 -*-
"""Sinh toàn bộ báo cáo Remediation vòng 3 TỪ KẾT QUẢ CHẠY THỰC (kiem_toan_r3/ket_qua/*.json, log). Không gõ tay số liệu test.
python3 kiem_toan_r3/tao_bao_cao_r3.py → BAN_GIAO_R3/"""
import csv, difflib, hashlib, json, os, sys
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = lambda *p: os.path.join(G, *p)      # noqa: E731
OUT = J("BAN_GIAO_R3"); os.makedirs(OUT, exist_ok=True)
KQ = J("kiem_toan_r3", "ket_qua")
R = json.load(open(os.path.join(KQ, "ket_qua_doc_lap.json"), encoding="utf-8"))
RN = json.load(open(J("kiem_toan_r3", "ket_qua_nhanh", "ket_qua_doc_lap.json"), encoding="utf-8"))
T = {x["test_id"]: x for x in R["ket_qua"]}
MUT = json.load(open(os.path.join(KQ, "bao_cao_dot_bien_nguon.json"), encoding="utf-8"))
HDM = json.load(open(os.path.join(KQ, "bang_dot_bien_hop_dong.json"), encoding="utf-8"))
JS = json.load(open(os.path.join(KQ, "bao_cao_json_strict.json"), encoding="utf-8"))
REG = json.load(open(os.path.join(KQ, "hoi_quy", "ket_qua_kiem_thu.json"), encoding="utf-8"))
REGC = json.load(open(os.path.join(KQ, "hoi_quy", "hoi_quy_bo_cu_tren_module_moi.json"), encoding="utf-8"))
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()      # noqa: E731
w = lambda name, text: open(os.path.join(OUT, name), "w", encoding="utf-8").write(text)      # noqa: E731
js = lambda o, n=None: json.dumps(o, ensure_ascii=False, default=str, allow_nan=False)[:n] if n else json.dumps(o, ensure_ascii=False, default=str, allow_nan=False)   # noqa: E731
st = lambda tid: T[tid]["status"] if tid in T else "KHÔNG CHẠY"      # noqa: E731

SUA = ["shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py", "shadow_eval/chuan_hoa.py", "shadow_eval/pipeline.py",
       "shadow_eval/kiem_thu_stage3.py", "kiem_doc_lap/chay_doc_lap.py", "kiem_doc_lap/vector_vang.py", "kiem_toan_stage3/tao_bao_cao_test_v2.py"]
KHONG_SUA = ["shadow_eval/may_trang_thai.py", "shadow_eval/du_lieu.py", "kiem_doc_lap/oracle.py", "token_budget/cong_token.py", "shadow_eval/kiem_thu_shadow_eval.py",
             "src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine"]
B38, B39 = J("src038", "ATA_P3_Build_0.3.8_Candidate_Indicator.pine"), J("src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine")

# ------------------------------------------------------------------ diff + danh sách file
diff_txt = []
for f in SUA:
    a = J("kiem_toan_r3", "truoc_sua", f)
    if os.path.exists(a):
        diff_txt += list(difflib.unified_diff(open(a, encoding="utf-8").read().splitlines(True), open(J(f), encoding="utf-8").read().splitlines(True), f"a/{f}", f"b/{f}"))
    else:
        diff_txt += [f"--- (mới) {f}\n"]
w("ATA_P3_STAGE3_R3_DIFF.patch", "".join(diff_txt))
R2_MAN = {}
if os.path.exists("/tmp/vr2/ATA_P3_STAGE3_MANIFEST_SHA256.txt"):     # manifest của gói Round 2 đã bàn giao (giải nén ở /tmp/vr2)
    R2_MAN = {l.split("  ./", 1)[1].strip(): l.split("  ", 1)[0] for l in open("/tmp/vr2/ATA_P3_STAGE3_MANIFEST_SHA256.txt", encoding="utf-8") if "  ./" in l}
khong_sua = []
for f in KHONG_SUA:
    a = J("kiem_toan_r3", "truoc_sua", f)
    ok = (sha(a) == sha(J(f))) if os.path.exists(a) else (sha(J(f)) == R2_MAN.get(f) if f in R2_MAN else None)
    khong_sua.append((f, sha(J(f)), "KHỚP bản trước vòng 3" if ok else ("không có bản chụp (không thuộc tập chụp) – không sửa" if ok is None else "ĐÃ ĐỔI")))
w("ATA_P3_STAGE3_R3_FILE_KHONG_SUA.txt", "File không sửa trong vòng 3 (SHA-256 tính trực tiếp):\n" + "".join(f"{h}  {f}  [{k}]\n" for f, h, k in khong_sua))
src_hash = [(f, sha(J(f))) for f in SUA + ["kiem_doc_lap/oracle.py", "shadow_eval/may_trang_thai.py", "shadow_eval/du_lieu.py"]]
w("ATA_P3_STAGE3_R3_SOURCE_HASHES.txt", "".join(f"{h}  {f}\n" for f, h in src_hash))
w("ATA_P3_STAGE3_R3_BASELINE_HASHES.txt", f"{sha(B38)}  src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine\n{sha(B39)}  src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine\n"
  f"Giá trị chuẩn: 79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13 / 2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0\n"
  f"Khớp: {sha(B38) == '79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13' and sha(B39) == '2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0'}\n")

# ------------------------------------------------------------------ ma trận test
with open(os.path.join(OUT, "ATA_P3_STAGE3_R3_TEST_MATRIX.csv"), "w", encoding="utf-8-sig", newline="") as f:
    cw = csv.writer(f); cw.writerow(["Bộ", "test_id", "nhóm", "trạng thái", "số assertion", "mục tiêu", "hash", "nguồn"])
    for x in R["ket_qua"]:
        cw.writerow(["độc lập (đầy đủ)", x["test_id"], x["nhom"], x["status"], x["so_assertion"], x["muc_tieu"], x["hash"], x["test_source"]])
    for x in REG["ket_qua"]:
        cw.writerow(["hồi quy Stage 3 (88)", x["test_id"], x["nhom"], x["status"], "", x["muc_tieu"], x["hash"], x["test_source"]])
    for x in REGC["chay_b_shim"]:
        cw.writerow(["hồi quy bộ gốc (22)", x["test_id"], x.get("nhom", ""), x["result"], "", x.get("mo_ta", ""), "", "shadow_eval/kiem_thu_shadow_eval.py"])

# ------------------------------------------------------------------ ma trận finding
F = [  # id, mức, loại, mô tả, file, hàm/dòng, tái hiện, nguyên nhân, sửa, test, rủi ro còn lại
    ("A-1 (KD-HD-MUT)", "TRUNG BÌNH", "FACT", "Nghi vấn: ngoại lệ được tính là phát hiện đột biến hợp đồng", "kiem_doc_lap/chay_doc_lap.py", "t_hd_mut (bản trước vòng 3)",
     "tai_hien_nghi_van.json NV1-a: cho validator luôn ném ngoại lệ → KD-HD-MUT Round 2 = FAIL ⇒ phần 'exception tính là phát hiện' BỊ BÁC BỎ; NV1-b: validator bác đúng bộ dữ liệu nhưng chỉ trả một thông báo vô nghĩa → KD-HD-MUT Round 2 = PASS ⇒ XÁC NHẬN không kiểm lý do. Sau sửa: VALIDATOR_CRASH / PHAT_HIEN_SAI_LY_DO (FAIL)",
     "Thiếu phân loại chi tiết; không kiểm lý do phát hiện", "Viết lại: 7 lớp kết quả, chỉ PHÁT HIỆN ĐÚNG LÝ DO mới tính; 4 fixture; fixture gốc bất biến", "KD-HD-MUT", "Từ khóa lý do là chuỗi – đổi thông báo lỗi phải cập nhật danh mục"),
    ("F36", "CAO", "FACT", "Bộ kiểm hợp đồng NÉM NGOẠI LỆ (OSError) với ts_ms ngoài miền khi định dạng thông báo; bản ghi không phải object làm crash", "shadow_eval/hop_dong.py", "ts_tu_ms, kiem, kiem_bang",
     "Fuzz 6.000 ca trên bản trước vòng 3: OSError [Errno 75] với ts_ms = 1e20", "Gọi datetime.fromtimestamp không kiểm miền", "MS_MAX + trả chuỗi '<ngoài miền>'; kiểm kiểu bản ghi/bảng", "KD-HD-FUZZ, KD-HD-MUT", "—"),
    ("F37", "TRUNG BÌNH", "FACT", "KD-JSON cũ dùng regex 'json\\.dump\\(' + 3 dòng: BỎ SÓT mọi json.dumps (8 lời gọi không strict)", "kiem_doc_lap/chay_doc_lap.py", "t_json (bản trước vòng 3)",
     "AST tìm thấy 8 lời gọi json.dumps thiếu allow_nan=False (pipeline.py 91/96, kiem_thu_stage3.py 41/646, chay_doc_lap.py 51/470, tao_bao_cao_test_v2.py 20/40); NV2: mẫu nguồn có json.dump 5 dòng (strict) + bí danh 'from json import dump as luu' (không strict) → logic Round 2 báo nhầm cái strict và bỏ sót bí danh; AST mới phân loại đúng cả hai", "Regex không khớp 'dumps', không thấy bí danh, cửa sổ 3 dòng",
     "Quét AST (kể cả bí danh, from-import, **kwargs); sửa cả 8 lời gọi; miễn lịch sử theo file+SHA+vị trí", "KD-JSON", "Chỉ quét file trong PHAM_VI_PY; file ngoài phạm vi liệt kê kèm lý do"),
    ("A-3 (KD-REG-S3)", "CAO", "FACT", "Hồi quy đọc ket_qua_kiem_thu.json không chứng minh là output mới; REG-02 BLOCKED vẫn lọt", "kiem_doc_lap/chay_doc_lap.py", "t_reg (bản trước vòng 3)",
     "NV3: thay bộ Stage 3 bằng script thoát ngay (exit 3, không ghi gì) trong khi file kết quả CŨ còn → runner Round 2 đọc đúng file cũ đó, không kiểm mtime/run_id/exit code; sau sửa: KD-REG-S3 = FAIL 'subprocess không tạo output (exit 3)'", "Kiểm 'FAIL ⊆ whitelist'; đọc output trong cây chung",
     "Bản sao cây sạch, run_id, mtime, exit code, đếm ERROR, FAIL = ĐÚNG tập lỗi thời, REG-01/REG-02 phải PASS, bộ 0.3.9 chạy MỚI trong vòng", "KD-REG-S3", "REG-02 phụ thuộc /tmp/reg039 của lần chạy mới (kiểm mtime)"),
    ("A-4 (KD-MUT-SRC)", "CAO", "FACT", "Đột biến được tính 'bị giết' theo mã thoát của toàn bộ chế độ nhanh, không biết test nào bắt, không có baseline", "kiem_doc_lap/chay_doc_lap.py", "t_mut_src (bản trước vòng 3)",
     "NV4: bản module chèn 'import mo_dun_khong_ton_tai_xyz' (lỗi môi trường) → runner nhanh Round 2 thoát mã 1, mà KD-MUT-SRC Round 2 xếp loại bằng (chet if p.returncode != 0 else song) → tính là KILLED; sau sửa: ENV_ERROR", "Thiếu baseline và ánh xạ", "Baseline sạch bắt buộc; test kỳ vọng khai báo trước; phân loại KILLED_EXPECTED/OTHER/SURVIVED/TEST_ERROR/ENV_ERROR/INVALID; dùng bộ GATE (gồm property test)", "KD-MUT-SRC", "Bộ GATE không gồm hồi quy (quá chậm cho mỗi đột biến)"),
    ("A-5 (MUT-01…05)", "TRUNG BÌNH", "FACT", "Bộ Stage 3 vòng 1: MUT-01…05 tính test ném ngoại lệ là 'bắt được' (FAIL(ngoại lệ))", "shadow_eval/kiem_thu_stage3.py", "_dot_bien",
     "NV5: đọc mã – mọi giá trị ≠ 'PASS', kể cả 'FAIL(ngoại lệ)', được coi là bắt được", "Không phân biệt assertion với ngoại lệ", "KHÔNG sửa test cũ (nguyên tắc I.4–5); THAY bằng KD-MUT-SRC có phân loại", "KD-MUT-SRC", "MUT-01…05 vẫn còn trong bộ cũ với điểm yếu này – không dùng làm bằng chứng"),
    ("F38", "TRUNG BÌNH", "FACT", "Bản sao sạch của KD-REG-S3 loại thư mục _truoc_sua (mẫu '_truoc_sua*') trong khi MUT-01…05 cần nó → 5 test thành ERROR", "kiem_doc_lap/chay_doc_lap.py", "t_reg (copytree ignore)",
     "Lần chạy đầy đủ 19:08 của vòng này: KD-REG-S3 = FAIL 'ERROR [MUT-01…05]' – chính cổng mới phát hiện", "Mẫu bỏ qua quá rộng", "Chỉ bỏ __pycache__", "KD-REG-S3", "—"),
    ("F39", "THẤP", "FACT", "KD-HD-FUZZ kết thúc bằng assertion rỗng kt(True)", "kiem_doc_lap/chay_doc_lap.py", "t_hd_fuzz", "Đọc mã", "Assertion không kiểm gì",
     "Thay bằng kt(bi_bac ≥ 90 % số ca) – bộ kiểm 'im lặng' với dữ liệu hỏng sẽ FAIL", "KD-HD-FUZZ", "—"),
    ("F26", "P0", "FACT", "Khử trùng trước lọc S1 có thể bỏ tín hiệu đạt S1", "shadow_eval/pipeline.py", "chon_tin_hieu_lenh", "KD-F26: mã cũ cho 0 lệnh với [lý do 1, lý do 16]", "Thứ tự thao tác", "Lọc 16 rồi khử trùng (vòng 2)", "KD-F26, KD-DUP-GOLD", "0 ca trên SYNTH; ảnh hưởng dữ liệu thật là HYPOTHESIS"),
    ("F28", "P0", "FACT", "Adapter bỏ STEP khi st đổi cùng nến tạo/kết thúc/ARMED", "shadow_eval/chuan_hoa.py", "BoGhi.buoc, _buoc_trung_gian", "KD-F28-ADAPTER (6/7 kịch bản sai ở bản cũ); KD-F28-SEEDS (vi phạm trước > 0)", "Ghi st cuối nến lúc tạo; không phát STEP trung gian", "Vòng 2", "KD-F28-ADAPTER, KD-F28-SEEDS", "Thứ tự STEP trong nến là quy ước"),
    ("F28b", "CAO", "FACT", "Adapter cũ gán NHIỀU ARMED cho MỘT thể hiện khi có thể hiện trùng khóa IP-21 (thể hiện khác mất ARMED)", "shadow_eval/chuan_hoa.py", "BoGhi.buoc (lọc ứng viên ARMED)",
     "KD-F28-SEEDS seed 27: cũ ARMED×3 cho một thể hiện; mới mỗi thể hiện 1 ARMED; đa tập sự kiện toàn seed giữ nguyên", "info['st'] chỉ cập nhật cuối nến", "Đã được sửa bởi _buoc_trung_gian (cập nhật st ngay khi ghép) – phát hiện ở vòng 3", "KD-F28-SEEDS", "Ghép IP-21 vẫn là quy ước (B-4)"),
    ("F29", "P0", "FACT", "NO_DATA trước/sau khi vào bị gộp ghi chú", "shadow_eval/mo_phong_lenh.py", "mo_phong", "KD-F29: bản cũ INVALID_BAR cho cả hai", "Một ghi chú cho hai trạng thái", "…_AFTER_FILL (vòng 2)", "KD-F29, KD-REPL-OT05, KD-REPL-OT06", "—"),
    ("F35", "TRUNG BÌNH", "FACT", "Phễu không đếm lệnh 'đã vào rồi mất dữ liệu' là đã vào", "shadow_eval/chi_so.py", "phieu", "KD-F29 (phần phễu) trên bản trước vòng 3: da_vao thiếu", "da_vao chỉ xét DONG + OPEN", "Đếm thêm NO_DATA …_AFTER_FILL; trường vao_roi_mat_du_lieu", "KD-F29, KD-FUNNEL-R3", "—"),
    ("F32", "P0", "FACT", "Lọc danh mục phụ thuộc thứ tự khi trùng (entry, emit_seq)", "shadow_eval/mo_phong_lenh.py", "khong_chong", "KD-F32: bản cũ đảo kết quả khi đảo đầu vào", "Thiếu khóa phụ", "Khóa phụ signal_id (vòng 2) + signal_id trùng → ValueError (vòng 3)", "KD-F32, KD-OCC-GOLD, KD-OCC-PROP", "—"),
    ("F37b", "THẤP", "FACT", "Thiếu gross_r trong chỉ số (chỉ có net_r)", "shadow_eval/chi_so.py", "hieu_qua", "Danh mục kiểm của chỉ thị", "Chưa hiện thực", "gross_r (null nếu thiếu r_gross)", "KD-MET-R3", "—"),
    ("T-1", "TRUNG BÌNH", "FACT", "Test lỗi thời phải có thay thế bao phủ ĐỦ (không chỉ trỏ tới test khác)", "kiem_doc_lap/chay_doc_lap.py", "KD-REPL-*", "OT-05/OT-06/HD-01 (Stage 3), HD-01/DUP-01/E2E-01 (gốc)", "Vòng 2 chỉ trỏ tới test liên quan", "Viết test thay thế 1-1 dùng LẠI dữ liệu cũ, chỉ đổi phần thay đổi có chủ đích", "KD-REPL-OT05, KD-REPL-OT06, KD-REPL-HD01S3, KD-REPL-CU-HD01, KD-REPL-CU-DUP01", "E2E-01 gốc thay bằng E2E-01 Stage 3 + RP-03 (không viết lại 1-1)"),
    ("F31", "—", "ASSUMPTION", "R2 không chạy lại S1 theo RR tại giá vào", "shadow_eval/mo_phong_lenh.py", "mo_phong (rr_entry)", "G-R2-G", "Quy ước", "KHÔNG đổi (chỉ thị mục I.15); ghi rr_entry", "KD-GOLD-R2-G", "Chờ quyết định chủ dự án"),
    ("O-1", "—", "HYPOTHESIS", "Oracle độc lập về hiện thực nhưng KHÔNG độc lập về đặc tả", "kiem_doc_lap/oracle.py", "—", "Phân tích ATA_P3_STAGE3_ORACLE_INDEPENDENCE.md", "Cùng tác giả, cùng quy ước", "Bổ sung KD-FIRST (nguyên lý đầu)", "KD-FIRST, KD-ORACLE-GOLD, KD-ORACLE-PROP", "Quy ước chưa được xác nhận độc lập"),
]
with open(os.path.join(OUT, "ATA_P3_STAGE3_R3_FINDINGS_MATRIX.csv"), "w", encoding="utf-8-sig", newline="") as f:
    cw = csv.writer(f)
    cw.writerow(["ID", "Severity", "Phân loại", "Trạng thái (từ test chạy thực)", "Mô tả", "Source file", "Hàm/dòng", "Tái hiện", "Evidence", "Root cause", "Fix", "Test xác nhận", "Residual risk", "SHA-256 file"])
    for fid, sev, pl, mo, fi, ham, th, rc, fx, tests, rr in F:
        ts = [t.strip() for t in tests.replace(",", " ").split() if t.startswith("KD-")]
        sts = [st(t) for t in ts]
        trang = "PASS" if sts and all(s == "PASS" for s in sts) else ("FAIL" if "FAIL" in sts else ("NOT TESTED" if not sts else "/".join(sts)))
        cw.writerow([fid, sev, pl, trang, mo, fi, ham, th, "kiem_toan_r3/ket_qua/ket_qua_doc_lap.json", rc, fx, tests, rr, sha(J(fi)) if os.path.exists(J(fi)) else ""])

# ------------------------------------------------------------------ báo cáo con
def bang_md(rows, hdr):
    return "| " + " | ".join(hdr) + " |\n|" + "---|" * len(hdr) + "\n" + "".join("| " + " | ".join(str(c).replace("|", "/").replace("\n", " ") for c in r) + " |\n" for r in rows)


def tai_hien(tid, ten, them=""):
    x = T[tid]
    return (f"# Tái hiện {ten}\n\nTest: **{tid}** – trạng thái **{x['status']}**, {x['so_assertion']} assertion, {x['duration_ms']} ms, hash `{x['hash']}`.\n\n"
            f"Mục tiêu: {x['muc_tieu']}\n\nNguồn: `{x['test_source']}`\n\nKết quả thực tế (nguyên văn JSON):\n\n```json\n{json.dumps(x['actual'], ensure_ascii=False, indent=1, default=str, allow_nan=False)}\n```\n{them}")


w("ATA_P3_STAGE3_R3_REPRO_F26.md", tai_hien("KD-F26", "F26 – khử trùng trước lọc S1"))
w("ATA_P3_STAGE3_R3_REPRO_F28.md", tai_hien("KD-F28-ADAPTER", "F28 – adapter bỏ STEP (kịch bản cô lập)") + "\n\n" + tai_hien("KD-F28-SEEDS", "F28 / F28b – 60 seed engine thật")
  + "\nEvent trace trước/sau (seed 0–4): `kiem_toan_r3/ket_qua/f28_event_trace_seed0_4.json`; các ca gán lại ARMED (F28b): `kiem_toan_r3/ket_qua/f28b_gan_ARMED_trung_khoa.json`.\n")
w("ATA_P3_STAGE3_R3_REPRO_F29.md", tai_hien("KD-F29", "F29 / F35 – NO_DATA trước/sau khi vào") + "\n\n" + tai_hien("KD-REPL-OT05", "Thay thế OT-05") + "\n\n" + tai_hien("KD-REPL-OT06", "Thay thế OT-06"))
w("ATA_P3_STAGE3_R3_REPRO_F32.md", tai_hien("KD-F32", "F32 – lọc danh mục phụ thuộc thứ tự") + "\n\n" + tai_hien("KD-OCC-PROP", "Tính chất lọc danh mục"))

dem_h = {}
for r in HDM:
    dem_h[r["ket_qua"]] = dem_h.get(r["ket_qua"], 0) + 1
w("ATA_P3_STAGE3_R3_MUTATION_REPORT.md",
  "# Báo cáo kiểm đột biến – vòng 3\n\n## A. Đột biến MÃ NGUỒN (KD-MUT-SRC: " + st("KD-MUT-SRC") + ")\n\n"
  f"Baseline (bản sao KHÔNG đột biến, chế độ gate): `{js(MUT['baseline'])}`\n\nPhân loại: `{js(MUT['phan_loai'])}` trên {len(MUT['dot_bien'])} đột biến khai báo.\n\n"
  + bang_md([(i + 1, x["file"], x["dot_bien"], x["ket_qua"], ", ".join(x["ky_vong"]), ", ".join(x.get("test_bat_bang_assertion", []))[:160], ", ".join(x.get("test_loi_ngoai_le", [])), x.get("sha_dot_bien", ""))
             for i, x in enumerate(MUT["dot_bien"])], ["#", "File", "Đột biến", "Kết quả", "Test kỳ vọng (khai báo trước)", "Test bắt bằng assertion (thực tế)", "Test lỗi ngoại lệ", "SHA bản đột biến"])
  + "\nQuy tắc: chỉ KILLED_EXPECTED (ít nhất một test kỳ vọng FAIL bằng assertion) được tính; ngoại lệ không tính; ≥ 80 % test lỗi ngoại lệ = ENV_ERROR.\n\nLog: `kiem_toan_r3/ket_qua/log_dot_bien_nguon.txt`.\n\n"
  "## B. Đột biến HỢP ĐỒNG DỮ LIỆU (KD-HD-MUT: " + st("KD-HD-MUT") + ")\n\n" + f"Phân loại: `{js(dem_h)}` – {len(HDM)} lần thực thi (29 loại × 4 fixture), 0 bỏ qua.\n\n"
  + bang_md([(r["dot_bien"], r["fixture"], r["ket_qua"], ", ".join(r["ky_vong"]), r["chi_tiet"][:110]) for r in HDM], ["Đột biến", "Fixture", "Kết quả", "Lý do kỳ vọng", "Thông báo bộ kiểm (rút gọn)"])
  + f"\n## C. Độ bền bộ kiểm (KD-HD-FUZZ: {st('KD-HD-FUZZ')})\n\n`{js(T['KD-HD-FUZZ']['actual'])}`\n")

w("ATA_P3_STAGE3_R3_STRICT_JSON_REPORT.md",
  f"# Báo cáo JSON strict – vòng 3 (KD-JSON: {st('KD-JSON')})\n\nPhương pháp: phân tích AST mọi lời gọi `json.dump`/`json.dumps` (kể cả bí danh, from-import, **kwargs) trong phạm vi; quét TOÀN BỘ cây thư mục làm việc tìm *.json; parse strict với định vị từng giá trị không hữu hạn.\n\n"
  "## Lời gọi tuần tự hóa\n\n" + bang_md([(x["file"], x["dong"], x["ham"], x["strict"], x["ly_do"]) for x in JS["sites"]], ["File", "Dòng", "Hàm", "Strict", "Lý do nếu không"])
  + "\n## File .py ngoài phạm vi (kèm lý do)\n\n" + bang_md(list(JS["ngoai_pham_vi"].items()), ["File", "Lý do"])
  + "\n## Miễn lịch sử (đúng file + đúng SHA + đúng vị trí)\n\n" + bang_md([(m["file"], m["sha"], m["vi_tri"], m["loi"], m["ly_do"]) for m in JS["mien_lich_su"]], ["File", "SHA-256", "Vị trí", "Giá trị", "Lý do"])
  + "\n## Tất cả file JSON đã quét\n\n" + bang_md([(x["file"], x["ket_qua"]) for x in JS["file_json"]], ["File", "Kết quả"]))

reg_rows = [(k, v["ly_do"], v["thay_the"], st(v["thay_the"]) if v["thay_the"].startswith("KD-") else "xem E2E-01/RP-03 trong hồi quy") for k, v in T["KD-REG-S3"]["actual"]["lien_ket_loi_thoi_s3"].items()] \
    if isinstance(T["KD-REG-S3"]["actual"], dict) else []
reg_rows_c = [(k, v["ly_do"], v["thay_the"], st(v["thay_the"]) if v["thay_the"].startswith("KD-") else "E2E-01 Stage 3: " + next(x["status"] for x in REG["ket_qua"] if x["test_id"] == "E2E-01"))
              for k, v in T["KD-REG-S3"]["actual"]["lien_ket_loi_thoi_cu"].items()] if isinstance(T["KD-REG-S3"]["actual"], dict) else []
dem_reg = {}
for x in REG["ket_qua"]:
    dem_reg[x["status"]] = dem_reg.get(x["status"], 0) + 1
r039 = json.load(open("/tmp/reg039/ket_qua039/ket_qua_039.json", encoding="utf-8"))["summary"]
w("ATA_P3_STAGE3_R3_REGRESSION_REPORT.md",
  f"# Báo cáo hồi quy – vòng 3 (KD-REG-S3: {st('KD-REG-S3')})\n\nRun: `{js(T['KD-REG-S3']['actual'])[:600]}`\n\n"
  f"Bộ Stage 3 (88 test, KHÔNG sửa assertion) chạy trong bản sao cây sạch: {js(dem_reg)}.\n\nBộ gốc (22 test) qua REG-01: chạy nguyên trạng dừng tại DUP-01; qua shim harness: "
  + js({k: sum(1 for x in REGC['chay_b_shim'] if x['result'] == k) for k in ('PASS', 'FAIL', 'BLOCKED')}) + ".\n\n"
  f"Bộ 0.3.9 chạy MỚI trong vòng này (bản sao /tmp/reg039, bắt đầu epoch {open('/tmp/reg039_batdau.txt').read().strip()}): {js(r039['counts'])}, {r039['seconds']} s – so từng test với lần gốc qua REG-02.\n\n"
  "## Test lỗi thời – lý do và test thay thế 1-1\n\n### Bộ Stage 3 (88)\n\n" + bang_md(reg_rows, ["Test cũ", "Vì sao assertion lỗi thời", "Test thay thế", "Trạng thái thay thế"])
  + "\n### Bộ gốc (22)\n\n" + bang_md(reg_rows_c, ["Test cũ", "Vì sao assertion lỗi thời", "Test thay thế", "Trạng thái thay thế"])
  + "\nKhông có test cũ nào bị bỏ mà không có thay thế. 85/88 test Stage 3 và 20/22 test gốc chạy lại với kết quả không đổi so với lần trước (PASS/BLOCKED/NOT TESTED như cũ).\n\n"
  "Log: `kiem_toan_r3/ket_qua/hoi_quy/stdout_kiem_thu_stage3.log`, `kiem_toan_r3/log/reg039_stdout.txt`.\n")

met_ids = [t for t in T if t.startswith("KD-MET")]
w("ATA_P3_STAGE3_R3_METRICS_REPORT.md", "# Báo cáo chỉ số – vòng 3\n\nKỳ vọng tính tay (vector_vang.M, KD-MET-R3) và oracle (oracle.chi_so) – không dùng code được kiểm để tính kỳ vọng.\n\n"
  + bang_md([(t, T[t]["status"], T[t]["so_assertion"], T[t]["muc_tieu"][:120], js(T[t]["actual"], 160)) for t in met_ids], ["Test", "Trạng thái", "Assertion", "Nội dung", "Thực tế"])
  + "\nĐịnh nghĩa khóa: xem ATA_P3_STAGE3_CORRECTION_REPORT.md vòng 2, mục 3, và docstring chi_so.py (thêm gross_r ở vòng 3).\n")
w("ATA_P3_STAGE3_R3_FUNNEL_REPORT.md", "# Báo cáo phễu – vòng 3\n\nMẫu số khóa trong `chi_so.MAU_SO` (dùng chung dashboard/báo cáo). Vòng 3: lệnh đã vào rồi mất dữ liệu được tính là ĐÃ VÀO (F35) và đếm riêng `vao_roi_mat_du_lieu`.\n\n"
  + bang_md([(t, T[t]["status"], T[t]["so_assertion"], js(T[t]["actual"], 300)) for t in ("KD-FUNNEL", "KD-FUNNEL-R3", "KD-F29") if t in T], ["Test", "Trạng thái", "Assertion", "Thực tế"]))
w("ATA_P3_STAGE3_R3_BOOTSTRAP_REPORT.md", "# Báo cáo bootstrap – vòng 3\n\nPhương pháp: i.i.d. (mốc) và moving-block vòng theo entry_ts (độ nhạy), L = round(n^(1/3)), B = 2.000 mặc định, độ tin cậy 95 %, phân vị đối xứng k = ⌊0,025·B⌋, seed = seed gốc + băm ổn định của (symbol, setup).\n\n"
  "Tổng thể: lệnh ĐÓNG của một (symbol, setup). Giả định i.i.d. KHÔNG được mặc định là phù hợp: lệnh có thể phụ thuộc thời gian, chế độ thị trường, phiên, cụm; moving-block chỉ là độ nhạy cho phụ thuộc thời gian. "
  "Không có dữ liệu thật → không có tuyên bố thống kê nào về thị trường; mọi số liệu dưới đây là kiểm CƠ CHẾ trên dữ liệu tổng hợp.\n\n"
  + bang_md([(t, T[t]["status"], T[t]["so_assertion"], js(T[t]["actual"], 300)) for t in ("KD-PCT", "KD-BOOT", "KD-BOOT-R3") if t in T], ["Test", "Trạng thái", "Assertion", "Thực tế"]))

# ------------------------------------------------------------------ danh sách BLOCKED / NOT TESTED / không chạy / lỗi còn / quyết định
blk = [x for x in R["ket_qua"] if x["status"] == "BLOCKED"] + [dict(test_id="REG:" + x["test_id"], muc_tieu=x["muc_tieu"], actual=x["actual"]) for x in REG["ket_qua"] if x["status"] == "BLOCKED"]
nt = [x for x in R["ket_qua"] if x["status"] == "NOT TESTED"] + [dict(test_id="REG:" + x["test_id"], muc_tieu=x["muc_tieu"], actual=x["actual"]) for x in REG["ket_qua"] if x["status"] == "NOT TESTED"]
w("ATA_P3_STAGE3_R3_BLOCKED.md", "# Danh sách BLOCKED\n\n" + bang_md([(x["test_id"], x["muc_tieu"], str(x["actual"])[:200]) for x in blk], ["Test", "Nội dung", "Lý do / điều kiện mở khóa"])
  + "\nĐiều kiện mở khóa chung: (1) file OHLCV M5 lịch sử có nguồn (TradingView export hoặc MT5 Exness + độ lệch giờ máy chủ); (2) quyết định nguồn sự kiện (replay toàn script hoặc kênh xuất từ TradingView); "
    "(3) dữ liệu đối chứng TradingView cho REPLAY-EQ; (4) token thật chỉ biết khi TradingView báo lỗi kèm số. Proxy mạng chặn nguồn dữ liệu: `ket_qua_stage3/log/thu_mang_du_lieu_that.txt`.\n")
w("ATA_P3_STAGE3_R3_NOT_TESTED.md", "# Danh sách NOT TESTED\n\n" + bang_md([(x["test_id"], x["muc_tieu"], str(x["actual"])[:200]) for x in nt], ["Test", "Nội dung", "Lý do"]))
khong_chay = [x["test_id"] for x in R["ket_qua"] if x["status"] in ("BLOCKED", "NOT TESTED")]
w("ATA_P3_STAGE3_R3_TEST_KHONG_CHAY.md", "# Test không chạy\n\nTrong bộ độc lập đầy đủ, mọi test có thể chạy bằng code đều đã chạy. Không chạy: " + ", ".join(khong_chay)
  + " (BLOCKED/NOT TESTED – xem hai danh sách tương ứng).\n\nChế độ GATE (dùng cho mỗi đột biến) cố ý không gồm KD-REG-S3 và KD-MUT-SRC; chế độ NHANH chỉ gồm test đánh dấu nhanh – đều có log riêng.\n")
w("ATA_P3_STAGE3_R3_LOI_CON_TON_TAI.md", "# Lỗi còn tồn tại / rủi ro còn lại\n\n- Không còn lỗi code nào đã xác nhận mà chưa sửa (theo kết quả chạy thực: bộ độc lập " + js(R["tom_tat"]) + ").\n"
  "- Rủi ro còn lại (không phải lỗi đã xác nhận): oracle không độc lập về đặc tả (O-1); thứ tự STEP trong nến và ghép thể hiện IP-21 là quy ước (B-4, F28b); CI bootstrap không có oracle số học; "
  "quy ước nến thoát MFE/MAE và sl_first chưa được xác nhận bằng dữ liệu tick; bộ GATE không gồm hồi quy.\n- B-1…B-4 (quan sát Pine baseline) giữ nguyên – không sửa Pine.\n")
w("ATA_P3_STAGE3_R3_OWNER_DECISIONS.md", "# Giả định cần chủ dự án quyết định\n\n"
  "1. **F31 – R2 và RR tại giá vào.** Hiện: R2 KHÔNG chạy lại S1, ghi `rr_entry`. Lựa chọn: (a) giữ – R2 là biến thể đo độ nhạy thực thi; (b) R2 bỏ lệnh khi rr_entry < iRRMin (thêm NO_FILL lý do RR) – thay đổi chiến lược. Bằng chứng: G-R2-G (rr_entry 0,875). Không tự đổi.\n"
  "2. **Vào đúng thời điểm thoát của lệnh trước** (lọc danh mục) → hiện bỏ (bảo thủ).\n3. **NO_DATA sau khi vào** không chiếm vị thế trong lọc danh mục (kết quả không xác định) – thay thế: coi như OPEN (chiếm tới hết dữ liệu).\n"
  "4. **sl_first** là quy ước mặc định khi cùng nến chạm SL và TP1.\n5. **Quy ước nến thoát MFE/MAE** (xem docstring mo_phong_lenh.py).\n6. **Nguồn sự kiện cho đánh giá thật** (Q-S3-1) và cung cấp dữ liệu (Q-S3-2), lịch nghỉ Exness (Q-S3-3).\n"
  "7. **Gỡ mã chết / biến không đọc** ở Build sau (Q-S3-5) – hiện chỉ ghi nhận.\n")

# ------------------------------------------------------------------ báo cáo remediation chính
dk = [  # tiêu chí kết thúc (mục XVII) → test
    ("Baseline sạch", ["KD-BASELINE"]), ("Test mới chạy đầy đủ", []), ("Test cũ được xử lý có bằng chứng", ["KD-REG-S3", "KD-REPL-OT05", "KD-REPL-OT06", "KD-REPL-HD01S3", "KD-REPL-CU-HD01", "KD-REPL-CU-DUP01"]),
    ("KD-HD-MUT không tính ngoại lệ là killed", ["KD-HD-MUT", "KD-HD-FUZZ"]), ("KD-JSON strict được xác minh", ["KD-JSON"]), ("KD-REG-S3 không dùng output cũ", ["KD-REG-S3"]),
    ("KD-MUT-SRC có ánh xạ test", ["KD-MUT-SRC"]), ("F26 tái hiện + xác minh", ["KD-F26"]), ("F28 tái hiện + xác minh", ["KD-F28-ADAPTER", "KD-F28-SEEDS"]),
    ("F29 tái hiện + xác minh", ["KD-F29"]), ("F32 tái hiện + xác minh", ["KD-F32"]), ("Oracle độc lập được đánh giá", ["KD-FIRST", "KD-ORACLE-GOLD", "KD-ORACLE-PROP"]),
    ("Chỉ số và phễu được xác minh", met_ids + ["KD-FUNNEL", "KD-FUNNEL-R3"]),
]
rows = []
for ten, ts in dk:
    if not ts:
        ok = R["tom_tat"].get("FAIL", 0) == 0 and R["che_do"] == "day_du"
        rows.append((ten, "ĐẠT" if ok else "CHƯA ĐẠT", f"bộ độc lập đầy đủ: {js(R['tom_tat'])}, {R['so_assertion']} assertion")); continue
    sts = {t: st(t) for t in ts}
    rows.append((ten, "ĐẠT" if all(v == "PASS" for v in sts.values()) else "CHƯA ĐẠT", ", ".join(f"{k}={v}" for k, v in sts.items())))
rows += [("Manifest được tính lại", "xem ATA_P3_STAGE3_R3_MANIFEST_VALIDATION.txt (sinh lúc đóng gói)", "—"), ("Package chạy lại được", "xem log chạy lại từ gói giải nén", "—"),
         ("Điều chưa chứng minh được ghi rõ", "ĐẠT", "BLOCKED.md, NOT_TESTED.md, LOI_CON_TON_TAI.md, ORACLE_INDEPENDENCE.md")]
w("ATA_P3_STAGE3_R3_REMEDIATION_REPORT.md",
  "# ATA P3 · STAGE 3 · INDEPENDENT AUDIT REMEDIATION (vòng 3)\n\nSinh tự động từ kết quả chạy thực của vòng này (`kiem_toan_r3/ket_qua/`). Không dùng output cũ.\n\n"
  f"Baseline Pine (SHA-256 tính trực tiếp): 0.3.8 `{sha(B38)}` · 0.3.9 `{sha(B39)}` – không đổi.\n\n"
  f"## Kết quả chạy\n\n- Bộ độc lập ĐẦY ĐỦ: {js(R['tom_tat'])} · {R['so_test']} test · {R['so_assertion']} assertion · {R['thoi_gian_s']} s\n"
  f"- Bộ độc lập NHANH: {js(RN['tom_tat'])} · {RN['so_assertion']} assertion\n- Hồi quy Stage 3 (88) trong cây sạch: {js(dem_reg)}\n"
  f"- Đột biến mã nguồn: {js(MUT['phan_loai'])} / {len(MUT['dot_bien'])} · baseline {js(MUT['baseline'])}\n- Đột biến hợp đồng: {js(dem_h)} / {len(HDM)}\n"
  f"- JSON strict: {js(T['KD-JSON']['actual'])}\n\n"
  "## Kết luận từng nghi vấn của kiểm toán\n\n"
  "| Nghi vấn | Kết luận sau tái hiện | Hành động |\n|---|---|---|\n"
  "| KD-HD-MUT tính ngoại lệ là phát hiện | NV1-a: **BÁC BỎ** – mã vòng 2 tính ngoại lệ là LỌT (test FAIL). NV1-b: **XÁC NHẬN** điểm yếu khác – không kiểm lý do bị bác (thông báo vô nghĩa vẫn PASS). Fuzz phát hiện lỗi thật F36 (bộ kiểm crash) | 7 lớp kết quả, chỉ PHÁT HIỆN ĐÚNG LÝ DO được tính; 4 fixture; fuzz 20.000 ca; sửa F36 |\n"
  "| KD-JSON regex 3 dòng | NV2: **XÁC NHẬN** – báo nhầm lời gọi strict kéo dài > 3 dòng, bỏ sót bí danh; thêm: bỏ sót hoàn toàn json.dumps (8 lời gọi không strict, F37) | Quét AST; sửa 8 lời gọi; miễn lịch sử theo file+SHA+vị trí |\n"
  "| KD-REG-S3 có thể đọc output cũ | NV3: **XÁC NHẬN** – subprocess hỏng (exit 3, không ghi gì) vẫn để runner vòng 2 đọc file cũ | Cây sạch + run_id + mtime + exit code + FAIL = đúng tập lỗi thời + REG-01/02 phải PASS; chạy lại bộ 0.3.9 mới. Chính cổng mới bắt được lỗi môi trường F38 |\n"
  "| KD-MUT-SRC giết theo mã thoát | NV4: **XÁC NHẬN** – lỗi import được tính là 'killed' | Baseline sạch + ánh xạ test khai báo trước + phân loại; lỗi import → ENV_ERROR |\n"
  "| MUT-01…05 (bộ Stage 3 vòng 1) | NV5: **XÁC NHẬN** – ngoại lệ tính là bắt được | Không sửa test cũ; thay bằng KD-MUT-SRC |\n"
  "| F26 / F28 / F29 / F32 | Tái hiện được trên bản trước sửa; bản hiện tại đúng. Phát hiện thêm F28b (gán nhiều ARMED cho một thể hiện IP-21) và F35 (phễu) | Test tái hiện trước/sau |\n"
  "| Oracle độc lập | Độc lập về hiện thực, KHÔNG độc lập về đặc tả | Báo cáo riêng; thêm KD-FIRST |\n\n"
  "## Tiêu chí kết thúc (mục XVII)\n\n" + bang_md(rows, ["Tiêu chí", "Trạng thái", "Bằng chứng"])
  + "\n## Phạm vi KHÔNG mở rộng (mục XIII)\n\nFull Pine replay, đánh giá thị trường thật, REPLAY-EQ, token thật, compile TradingView: **chưa thực hiện – BLOCKED/NOT TESTED** (xem danh sách). Không thay bằng SYNTH.\n\n"
  "## Tài liệu trong gói\n\nFINDINGS_MATRIX.csv, TEST_MATRIX.csv, REPRO_F26/F28/F29/F32.md, ORACLE_INDEPENDENCE.md, REGRESSION_REPORT.md, MUTATION_REPORT.md, STRICT_JSON_REPORT.md, METRICS/FUNNEL/BOOTSTRAP_REPORT.md, "
  "BASELINE_HASHES.txt, SOURCE_HASHES.txt, MANIFEST_SHA256.txt + MANIFEST_VALIDATION.txt, DIFF.patch, FILE_KHONG_SUA.txt, TEST_KHONG_CHAY.md, BLOCKED.md, NOT_TESTED.md, LOI_CON_TON_TAI.md, OWNER_DECISIONS.md; "
  "log: kiem_toan_r3/log/ (đầy đủ, nhanh, baseline trước sửa, hồi quy 0.3.9), kiem_toan_r3/ket_qua/log_dot_bien_nguon.txt, kiem_toan_r3/ket_qua/hoi_quy/.\n")
import shutil
shutil.copy(J("kiem_toan_r3", "ATA_P3_STAGE3_ORACLE_INDEPENDENCE.md"), os.path.join(OUT, "ATA_P3_STAGE3_ORACLE_INDEPENDENCE.md"))
NV = json.load(open(os.path.join(KQ, "tai_hien_nghi_van.json"), encoding="utf-8"))
w("ATA_P3_STAGE3_R3_TAI_HIEN_NGHI_VAN.md", "# Tái hiện nghi vấn của kiểm toán viên – trước sửa (runner Round 2) và sau sửa (runner mới)\n\n"
  "Script: `kiem_toan_r3/tai_hien_nghi_van.py` (chạy trên cây cô lập có đúng mã gói Round 2 – SHA ở `kiem_toan_r3/log/baseline_truoc_sua_sha_module.txt`). "
  "Kết quả nguyên văn: `kiem_toan_r3/ket_qua/tai_hien_nghi_van.json`.\n\n## Trước sửa (runner Round 2)\n\n"
  + bang_md([(x["nghi_van"], x["ket_luan"], x["mo_ta"], js(x["bang_chung"], 260)) for x in NV["truoc_sua_runner_R2"]], ["Nghi vấn", "Kết luận", "Kịch bản và quan sát", "Bằng chứng"])
  + "\n## Sau sửa (runner mới, cùng kịch bản xấu)\n\n" + bang_md([(x["nghi_van"], "ĐẠT" if x["dat"] else "KHÔNG ĐẠT", js(x["sau_sua"], 300)) for x in NV["sau_sua_runner_moi"]], ["Nghi vấn", "Kết quả", "Phản ứng của runner mới"]))
print("xong", OUT)
