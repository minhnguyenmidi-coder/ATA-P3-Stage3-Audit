# -*- coding: utf-8 -*-
"""Chuyển gói ZIP thành văn bản và tách phần ≤ MAXB byte (để dán vào ChatGPT). python3 tach_txt.py <zip> <tiền_tố_đầu_ra> [MAXB]
Chép nguyên văn mọi file văn bản trừ source Pine và khung kiểm thử Build trước (chỉ ghi SHA); file trùng nội dung chép một lần.
Ưu tiên: báo cáo vòng 3 → kết quả/log vòng 3 → code độc lập → module → phần còn lại."""
import hashlib, os, re, sys, tempfile, zipfile, datetime as dt
Z, PRE = sys.argv[1], sys.argv[2]
MAXB = int(sys.argv[3]) if len(sys.argv) > 3 else 30000
tmp = tempfile.mkdtemp(); zipfile.ZipFile(Z).extractall(tmp)
manp = [os.path.join(r, f) for r, _, fs in os.walk(tmp) for f in fs if f.endswith("MANIFEST_SHA256.txt") and "BAN_GIAO_R3" in r][0]
man = [l.rstrip("\n").split("  ./", 1) for l in open(manp, encoding="utf-8")]
sums = {p: h for h, p in man}; files = [p for h, p in man]
BO = ("src0", "kiem_toan034a/", "kiem_toan035/", "kiem_toan039/", "cong_tien_md6/", "ket_qua039/", "kiem_toan_r3/truoc_sua/")
UU = ["BAN_GIAO_R3/", "kiem_toan_r3/ket_qua/", "kiem_toan_r3/log/", "kiem_toan_r3/", "kiem_doc_lap/", "shadow_eval/", "token_budget/", "BAN_GIAO_STAGE3C/", "kiem_toan_stage3/",
      "ket_qua_stage3/", "ket_qua_shadow_eval/", "BAN_GIAO_STAGE3B/"]
k = lambda f: (next((i for i, p in enumerate(UU) if f.startswith(p)), 99), f)     # noqa: E731
gom, trung, dau = [], {}, {}
for f in sorted((f for f in files if not f.startswith(BO)), key=k):
    if sums[f] in dau:
        trung[f] = dau[sums[f]]; continue
    dau[sums[f]] = f; gom.append(f)
H = "#" * 100
L = ["=" * 100, "ATA P3 · STAGE 3 · INDEPENDENT AUDIT REMEDIATION (vòng 3) – TOÀN BỘ GÓI DẠNG VĂN BẢN", "=" * 100,
     f"Nguồn: {os.path.basename(Z)} – SHA-256 {hashlib.sha256(open(Z, 'rb').read()).hexdigest()}",
     f"Tạo lúc (UTC): {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} · trích bằng code, không sửa nội dung.", "",
     "CHỈ GHI SHA: source Pine (baseline không đổi 0.3.8 79793fcf…, 0.3.9 2184d892…), khung kiểm thử Build trước, bản chụp trước sửa vòng 3 (kiem_toan_r3/truoc_sua – nội dung = vế 'a/' của DIFF.patch).",
     "File trùng nội dung chép một lần.", "", f"MỤC 1 – DANH SÁCH FILE ({len(files)} file trong manifest)"]
for f in files:
    L.append(f"  {sums[f]}  {f}" + ("   [chỉ SHA]" if f.startswith(BO) else (f"   [trùng với {trung[f]}]" if f in trung else "")))
L += ["", f"MỤC 2 – NỘI DUNG NGUYÊN VĂN ({len(gom)} file)"]
for i, f in enumerate(gom, 1):
    try:
        t = open(os.path.join(tmp, f), encoding="utf-8-sig").read()
    except UnicodeDecodeError:
        t = "[nhị phân – bỏ qua]"
    L += ["", H, f"FILE {i}/{len(gom)}: {f}", f"SHA-256: {sums[f]} · {os.path.getsize(os.path.join(tmp, f))} byte", H, t.rstrip("\n")]
L += ["", "=" * 100, "HẾT – TOÀN BỘ GÓI DẠNG VĂN BẢN", "=" * 100]
L = "\n".join(L).split("\n")
# dòng quá dài (JSON 1 dòng) → bẻ cứng để không vượt MAXB
L2 = []
for l in L:
    while len(l.encode()) > MAXB // 3:
        L2.append(l[:MAXB // 6] + "⏎"); l = l[MAXB // 6:]
    L2.append(l)
L = L2
cur, fc = [None] * len(L), None
for i, l in enumerate(L):
    m = re.match(r"FILE \d+/\d+: (\S+)", l)
    if m:
        fc = m.group(1)
    if l.startswith("MỤC 2"):
        fc = None
    cur[i] = fc
cut = set()
for i in range(1, len(L)):
    c = cur[i]
    if (L[i] == H and i + 1 < len(L) and L[i + 1].startswith("FILE ")) or L[i].startswith("MỤC ") or not c:
        cut.add(i)
    elif c.endswith((".json", ".csv", ".txt", ".log", ".md", ".patch")):
        cut.add(i)
    elif L[i - 1].strip() == "" or L[i].startswith(("@T(", "def ", "class ", "    dict(id=", "    (\"")):
        cut.add(i)
cut = sorted(cut); pref = [0]
for l in L:
    pref.append(pref[-1] + len(l.encode()) + 1)
pts = [0]
while pref[len(L)] - pref[pts[-1]] > MAXB:
    cand = [c for c in cut if c > pts[-1] and pref[c] - pref[pts[-1]] <= MAXB]
    pts.append(max(cand) if cand else min(c for c in cut if c > pts[-1]))
pts.append(len(L)); N = len(pts) - 1; mx = 0
for q in range(N):
    a, b = pts[q], pts[q + 1]; seg = L[a:b]
    ds = [re.match(r"FILE \d+/\d+: (\S+)", l).group(1) for l in seg if re.match(r"FILE \d+/\d+: ", l)]
    hdr = ["=" * 100, f"ATA P3 · STAGE 3 · REMEDIATION VÒNG 3 – GÓI DẠNG VĂN BẢN · PHẦN {q + 1}/{N}", "=" * 100]
    if a > 0 and cur[a] and L[a] != H:
        hdr.append(f">>> TIẾP NỘI DUNG FILE: {cur[a]} (từ PHẦN {q}/{N})")
    if q and ds:
        hdr.append("Phần này chứa: " + ", ".join(ds))
    hdr.append("")
    tail = [""]
    if b < len(L) and cur[b - 1] and cur[b] == cur[b - 1] and L[b] != H:
        tail.append(f"<<< FILE {cur[b - 1]} CÒN TIẾP Ở PHẦN {q + 2}/{N}")
    tail += ["=" * 100, f"HẾT PHẦN {q + 1}/{N}" + (f" – đọc tiếp PHẦN {q + 2}/{N}" if q < N - 1 else " – HẾT TOÀN BỘ"), "=" * 100, ""]
    fn = f"{PRE}_{q + 1:02d}_{N}.txt"
    open(fn, "w", encoding="utf-8").write("\n".join(hdr + seg + tail)); mx = max(mx, os.path.getsize(fn))
print("số phần", N, "lớn nhất", mx, "khớp", "\n".join("\n".join(L[pts[q]:pts[q + 1]]) for q in range(N)) == "\n".join(L))
