# ATA P3 · STAGE 3 · R4 – BÁO CÁO SỬA CHỮA VÀ KIỂM THỬ ĐỘC LẬP (vòng 4)

Sinh tự động lúc 2026-11-21T11:58:38Z từ kết quả chạy thật. Báo cáo GỘP mọi mục bắt buộc (mục 12 nhiệm vụ). Quy ước: FACT / ASSUMPTION / PARTIALLY VERIFIED / HYPOTHESIS. Trạng thái không gộp.

## 0. Tóm tắt

- Bộ R4 mới: **{'PASS': 41, 'BLOCKED': 1}**, 174,867 assertion, run_id `fb12b76e-c0db-4226-a62e-391adbe5c630`.
- Hồi quy R3 đầy đủ trên code R4: **{'PASS': 102, 'BLOCKED': 6, 'NOT TESTED': 1}**, 112,562 assertion (R3 gốc: {'PASS': 102, 'BLOCKED': 6, 'NOT TESTED': 1}, 112,562). Test đổi trạng thái so với R3: không có.
- Đột biến R4 (lần chạy cuối): **{'KILLED_EXPECTED': 14}**; lần 1: {'KILLED_EXPECTED': 9, 'SURVIVED': 3, 'WRONG_REASON': 1} (đã xử lý – mục 9).
- Đột biến mã nguồn R3 (KD-MUT-SRC, 42 đột biến) trên code R4: **PASS**.
- Cách ly: **ĐẠT** – file đổi = ['shadow_eval/chi_so.py', 'shadow_eval/hop_dong.py', 'shadow_eval/mo_phong_lenh.py']; file xóa = không; .pyc = 0; Pine khớp = {'src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine': True, 'src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine': True}.
- Bộ Pine 0.3.9 chạy MỚI trong vòng này: {'PASS': 47, 'BLOCKED': 7, 'FAIL': 1, 'NOT TESTED': 1} – trùng R3 (FAIL duy nhất T-01 token gate đã phân loại từ trước; Pine không đổi).

## 1. Kiểm toán trước sửa (baseline)

- FACT: baseline = giải nén `ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION.zip` (SHA-256 `585e7b0e…05ca`); 247/247 file khớp manifest R3; 12/12 SOURCE_HASHES khớp.
- FACT: Pine 0.3.8 `79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13`, 0.3.9 `2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0` – khớp SHA khóa trước VÀ sau sửa.
- Tái hiện lỗi trên bản R3 (bản sao `shadow_eval/_truoc_r4/`, trùng SHA baseline):

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| F01-CU-TAI-HIEN | PASS | 2 | FACT | Tái hiện lỗi F-01 trên bản R3: NO_DATA sau khi vào (INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL) KHÔNG chặn lệnh sau cùng khóa |
| F02-CU-TAI-HIEN | PASS | 0 | FACT | Tái hiện F-02 trên bản R3: hop_dong.kiem với cost_model 'C-s1..2-c0-sl0' NÉM ValueError (validator crash) |
| F03-CU-TAI-HIEN | PASS | 6 | FACT | Tái hiện F-03 trên bản R3: bootstrap_khoi n_boot = 0 → IndexError; L ≥ n → CI suy biến bị ghi 'OK'; L = 0 bị nuốt thành mặc định; bootstrap_ci kiểm n_ |

- File ĐƯỢC PHÉP sửa: `shadow_eval/mo_phong_lenh.py`, `shadow_eval/hop_dong.py`, `shadow_eval/chi_so.py`. File mới: `shadow_eval/_truoc_r4/*` (bản chụp R3 để tái hiện), `kiem_doc_lap/chay_r4.py`, `kiem_doc_lap/oracle_r4.py`, `kiem_toan_r4/*`.
- File BẮT BUỘC không sửa: Pine (src0*), `chuan_hoa.py`, `pipeline.py`, `may_trang_thai.py`, `du_lieu.py`, mọi test cũ (`chay_doc_lap.py`, `kiem_thu_stage3.py`, …), `oracle.py`, `vector_vang.py`, kết quả R3. Kiểm bằng `kiem_cach_ly_r4.py` (mục 11).

## 2. Findings

| ID | Severity | Evidence | File | Line | Trước sửa | Patch | Test | Kết quả | Residual risk |
|---|---|---|---|---|---|---|---|---|---|
| F-01 | CAO | F01-CU-TAI-HIEN: trên bản R3, NO_DATA INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL không chặn TP1 vào sau cùng khóa | `shadow_eval/mo_phong_lenh.py` | 191 (R3) → 195–197 (R4) | NO_DATA (mọi ghi chú) ∈ KHONG_VAO → bỏ qua lọc, không chiếm vị thế | NO_DATA có fill_note ∈ NO_DATA_SAU_VAO được xét như lệnh đã vào: chịu lọc và chiếm vị thế tới ∞ (như OPEN); ca khác không đổi | F01-*, PF-*, OR-DANH-MUC-R4, M01–M05 | {"PASS": 16} | Quy ước '∞' (không biết thời điểm thoát) là bảo thủ; thay quyết định owner R3 #3 theo chỉ thị R4 mục 3 |
| F-02 | CAO | F02-CU-TAI-HIEN: bản R3 ném ValueError với cost_model 'C-s1..2-c0-sl0' (validator crash) | `shadow_eval/hop_dong.py` | 36, 192–194 (R3) → 36–54, 210–216 (R4) | regex [0-9.]+ chấp nhận '1..2', '.', rồi float() ném ngoại lệ; mã 'C-s…' sai cấu trúc bị bỏ qua im lặng | cú pháp số chặt [0-9]+(.[0-9]+)?([eE][+-]?[0-9]+)?; chi_phi_tu_ma() không ném, báo lỗi 'sai cấu trúc' / 'không hữu hạn'; công thức chi phí giữ nguyên | F02-*, M06–M09 | {"PASS": 5} | Mã KHÔNG bắt đầu 'C-s' (ví dụ 'C-0') vẫn là mã tự do theo hợp đồng 1.2 – không kiểm công thức (giữ phạm vi; xem R4-RR-3) |
| F-03 | TRUNG BÌNH | F03-CU-TAI-HIEN: R3 khối n_boot 0 → IndexError; L = n → CI suy biến ghi 'OK'; L = 0 bị nuốt; ci kiểm n_boot sau nhánh suy biến; alpha = 1 → khoảng đảo | `shadow_eval/chi_so.py` | 67–111 (R3) → 67–135 (R4) | kiểm tham số không đồng nhất giữa bootstrap_ci và bootstrap_khoi; không kiểm alpha, R hữu hạn, L | _kiem_tham_so() chung chạy trước mọi nhánh; L ∈ [1, n−1]; phan_vi_doi_xung kiểm alpha, B > 0; phương pháp/seed/CI với đầu vào hợp lệ trùng từng bit R3 (400 + 200 ca) | F03-*, M10–M13 | {"PASS": 6} | Đầu vào sai nay ném ValueError (trước đây có lúc trả kết quả) – bên gọi duy nhất trong engine (hieu_qua) luôn truyền tham số hợp lệ |
| BUG-R4-1 | CAO (tự gây trong R4, đã sửa) | Lượt hồi quy R3 thứ nhất: KD-REG-S3 FAIL vì REG-01 → DUP-02 của bộ gốc 22 FAIL (bản ghi không có 'outcome' bị chiếm vị thế ∞) – r3_day_du_LAN1_REG01_FAIL/ | `shadow_eval/mo_phong_lenh.py` | dòng 'mo[k] = …' của khong_chong | bản nháp R4 rút gọn 'outcome == OPEN' thành 'outcome not in DONG' → bản ghi thiếu outcome đổi hành vi | trả dòng về NGUYÊN VĂN R3 (NO_DATA sau vào vốn có exit null nên vẫn ∞); thêm 1.000 tập 'thiếu outcome' vào PF-KHONG-DOI-CA-DUNG và đột biến M14 | REG-01 (bộ Stage 3 gốc, qua KD-REG-S3), PF-KHONG-DOI-CA-DUNG, M14 | {"PASS": 1} | Không còn – test mới bắt bản lỗi (M14 KILLED_EXPECTED) |
| F-05 | KIỂM CHỨNG | Không sửa (không chứng minh lỗi) | `shadow_eval/chuan_hoa.py` | — | — | không | AD-* | {"PASS": 4, "BLOCKED": 1} | R4-OBS-1: CREATED → END_NO_EVENT cùng nến (adapter sinh, máy trạng thái bác) – 0/200 seed engine; BLOCKED chờ owner |
| F-06 | KIỂM CHỨNG | Không sửa oracle (không chứng minh lỗi); thêm oracle_r4.py cho quy tắc mới | `kiem_doc_lap/oracle.py, vector_vang.py` | — | — | thêm kiem_doc_lap/oracle_r4.py | OR-* | {"PASS": 5} | Oracle độc lập code, KHÔNG độc lập đặc tả |

SHA sau sửa: `shadow_eval/mo_phong_lenh.py` `9f619586f5e3bd0a…`, `shadow_eval/hop_dong.py` `c955c9ba7aaffbd5…`, `shadow_eval/chi_so.py` `a146fb9199f3f18b…`. Diff đầy đủ: `ATA_P3_STAGE3_R4_DIFF.patch`.

## 3. F-01 – Lọc danh mục (portfolio regression)

Quy tắc sau sửa (FACT, kiểm bởi oracle R4 độc lập): lệnh **đã vào** = TP1/SL/TIMEOUT/OPEN + NO_DATA sau khi vào; chiếm vị thế tới exit_ts (TP1/SL/TIMEOUT) hoặc ∞ (OPEN, NO_DATA sau vào); vào khi khóa đang có vị thế (entry ≤ hết) → bỏ; NO_FILL / INVALID / NO_DATA trước khi vào luôn giữ, không chiếm; thứ tự (entry_ts, emit_seq, signal_id).
Thay đổi quyết định: quyết định owner R3 #3 ('NO_DATA sau khi vào không chiếm vị thế') được THAY theo chỉ thị R4 mục 3.

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| F01-CU-TAI-HIEN | PASS | 2 | FACT | Tái hiện lỗi F-01 trên bản R3: NO_DATA sau khi vào (INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL) KHÔNG chặn lệnh sau cùng khóa |
| F01-NODATA-TRUOC | PASS | 8 | FACT | NO_DATA trước khi vào (NO_NEXT_BAR, INVALID_BAR) không chiếm vị thế; TP1 sau đó (kể cả cùng entry_ts) được giữ |
| F01-NODATA-SAU | PASS | 10 | FACT | NO_DATA sau khi vào chiếm vị thế tới ∞: lệnh sau cùng (symbol, setup) bị bỏ ở mọi thời điểm; tự nó được giữ |
| F01-NODATA-SAU-BI-BO | PASS | 6 | FACT | NO_DATA sau khi vào cũng CHỊU lọc: vào khi khóa đang có TP1 mở → bị bỏ, và vì bị bỏ nên không chặn lệnh sau thời điểm thoát của TP1 |
| F01-OPEN | PASS | 7 | FACT | OPEN chặn lệnh tiếp theo cùng khóa (kể cả rất xa), OPEN cuối chuỗi được giữ |
| F01-NOFILL-INVALID | PASS | 20 | FACT | NO_FILL và INVALID (trước khi vào) không chiếm vị thế; lệnh cùng entry_ts hoặc sau đó được xét bình thường |
| F01-DONG-THEO-THOI-GIAN | PASS | 27 | FACT | TP1 / SL / TIMEOUT giải phóng vị thế theo exit_ts_ms: vào trước exit → bỏ; vào ĐÚNG exit → bỏ (bảo thủ); vào sau exit → giữ |
| F01-CUNG-ENTRY | PASS | 12 | FACT | Hai lệnh cùng entry_ts cùng khóa: giữ emit_seq nhỏ hơn; cùng emit_seq → signal_id nhỏ hơn; NO_DATA sau khi vào cùng entry thắng/thua theo cùng khóa th |
| F01-DAO-THU-TU | PASS | 1441 | FACT | Đảo / xáo trộn thứ tự đầu vào không đổi kết quả (mọi hoán vị của 6 lệnh hỗn hợp = 720 hoán vị) |
| F01-TRUNG-ID | PASS | 2 | FACT | signal_id trùng trong một lượt lọc → ValueError có thông điệp (không để thứ tự quyết định), kể cả khi một bản là NO_DATA sau khi vào |
| F01-CHUOI-TOI-THIEU | PASS | 60 | FACT | Chuỗi tối thiểu (mục 3): NO_DATA trước → TP1; NO_DATA sau → chặn; OPEN → chặn; NO_FILL → xét tiếp; SL → xét sau đóng; cùng entry; entry = exit; entry  |
| PF-PROP-R4 | PASS | 20000 | FACT | 2.000 tập ngẫu nhiên (11 kết cục/ghi chú, nhiều symbol/setup, emit_seq TRÙNG, va chạm biên) × 5 xáo trộn: thỏa P0–P4 của oracle R4 (độc lập code) và k |
| PF-KHONG-DOI-CA-DUNG | PASS | 4000 | FACT | Ca đang đúng KHÔNG đổi: 3.000 tập ngẫu nhiên KHÔNG có NO_DATA sau khi vào → kết quả R4 trùng từng phần tử với bản R3; có NO_DATA sau khi vào → R4 = R3 |
| PF-DOC-LAP-DEDUP | PASS | 501 | FACT | Lọc danh mục độc lập với khử trùng: kết quả không đổi khi đổi/bỏ dup_key, khi thêm tín hiệu trùng khóa IP-21 ở bảng SIGNALS; khu_trung không được gọi  |
| PF-MOI-SEED-RIENG | PASS | 4 | FACT | pipeline.chay_synth lọc RIÊNG từng seed: bo_chong_lan = tổng số bỏ khi lọc từng seed; lọc gộp các seed cho số khác (chứng minh việc tách có tác dụng)  |
| PF-EMIT-TRUNG | PASS | 100 | FACT | emit_seq trùng giữa các lệnh cùng entry → phân xử bằng signal_id, tất định qua xáo trộn; entry_ts quyết định trước emit_seq |

Ánh xạ yêu cầu mục 3/6 → test: TP1/SL/TIMEOUT theo exit (F01-DONG-THEO-THOI-GIAN); OPEN (F01-OPEN); NO_FILL/INVALID (F01-NOFILL-INVALID); NO_DATA trước/sau (F01-NODATA-TRUOC/SAU/SAU-BI-BO); trùng signal_id (F01-TRUNG-ID); trùng emit_seq (PF-EMIT-TRUNG, PF-PROP-R4); entry = exit, entry < exit, cùng entry (F01-CHUOI-TOI-THIEU, F01-CUNG-ENTRY); nhiều symbol/setup, OPEN cuối chuỗi, đảo thứ tự (F01-OPEN, F01-DAO-THU-TU, PF-PROP-R4); mỗi seed lọc riêng (PF-MOI-SEED-RIENG); độc lập dedup (PF-DOC-LAP-DEDUP); ca đang đúng không đổi (PF-KHONG-DOI-CA-DUNG).

## 4. F-02 – cost_model

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| F02-CU-TAI-HIEN | PASS | 0 | FACT | Tái hiện F-02 trên bản R3: hop_dong.kiem với cost_model 'C-s1..2-c0-sl0' NÉM ValueError (validator crash) |
| F02-MA-HONG | PASS | 19 | FACT | 19 mã cost_model sai cú pháp/cấu trúc (gồm 6 mã của nhiệm vụ) → lỗi hợp đồng có kiểm soát, KHÔNG ngoại lệ |
| F02-MA-HOP-LE | PASS | 10 | FACT | Mã hợp lệ tiếp tục PASS: 'C-s1-c0-sl0' (r_net khớp chi phí 1), mọi cost_id() do Cfg sinh (0, số nguyên, thập phân, 1e-05, 1e+21), mã tự do 'C-0'/'C-x' |
| F02-CONG-THUC-DONG-BANG | PASS | 2 | FACT | Công thức chi phí đóng băng: r_gross − r_net = (spread + phí + 2×trượt)/risk; sai lệch 1 lần trượt bị bắt đúng lý do |
| F02-FUZZ | PASS | 28981 | FACT | Fuzz 30.000 chuỗi cost_model (bảng chữ 'C-scl0123456789.eE+-NaInfty ' và biến dạng mã hợp lệ) + 5.000 bản ghi TRADES hỏng kiểu: validator không bao gi |

## 5. F-03 – Bootstrap

Khác biệt R3 giữa hai phương pháp (FACT, F03-CU-TAI-HIEN): bootstrap_ci kiểm n_boot ≥ 40 nhưng SAU nhánh suy biến; bootstrap_khoi không kiểm n_boot (0 → IndexError), nuốt L = 0, chấp nhận L ≥ n (CI suy biến ghi 'OK'); cả hai không kiểm alpha (alpha = 1 → khoảng đảo) và R không hữu hạn. Thống nhất: một hàm kiểm chung chạy trước mọi nhánh; L ∈ [1, n−1]. Phương pháp, seed, CI với đầu vào hợp lệ: trùng từng bit R3. CI SYNTH không phải bằng chứng hiệu quả thị trường.

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| F03-CU-TAI-HIEN | PASS | 6 | FACT | Tái hiện F-03 trên bản R3: bootstrap_khoi n_boot = 0 → IndexError; L ≥ n → CI suy biến bị ghi 'OK'; L = 0 bị nuốt thành mặc định; bootstrap_ci kiểm n_ |
| F03-DONG-NHAT | PASS | 82 | FACT | Hai hàm bootstrap cư xử GIỐNG NHAU với đầu vào sai, kiểm TRƯỚC mọi nhánh (n < 2, suy biến): n_boot ∉ int ≥ 40, alpha ∉ (0,1), R có NaN/±Inf/None/bool  |
| F03-L | PASS | 8 | FACT | L của bootstrap khối: 0, âm, bool, float, L = n, L > n → ValueError; L = n − 1 hợp lệ; L = None → mặc định max(1, round(n^(1/3))) |
| F03-BIEN | PASS | 13 | FACT | Biên: n = 1 → N_NHO_HON_2 (cả hai); n = 2 → OK; R suy biến → SUY_BIEN (cả hai); n_boot = 40 tối thiểu chạy; alpha 0,001 → (min, max) của mẫu bootstrap |
| F03-KHONG-DOI-PHUONG-PHAP | PASS | 1000 | FACT | Phương pháp, seed, CI KHÔNG đổi: 400 bộ đầu vào hợp lệ ngẫu nhiên (n 2–80, n_boot 40–2000, alpha 0,01–0,2, L hợp lệ) → bootstrap_ci, bootstrap_khoi, p |
| F03-TAT-DINH | PASS | 61 | FACT | Tất định và thứ tự: cùng đầu vào → cùng CI (10 lần); i.i.d. không phụ thuộc thứ tự R (xáo trộn 50 lần); khối phụ thuộc thứ tự THỜI GIAN theo thiết kế  |

## 6. Adapter – F-05

Phân loại: **FACT** – logic adapter trên driver giả lập (chuỗi sự kiện, emit_seq, ghép theo khóa, không bịa sự kiện) và tính chất trên engine THẬT (60 seed + SU-3 định hướng: 0 vi phạm máy trạng thái, 0 lỗi hợp đồng, mọi SIGNAL có TRIGGER, SKIP chỉ SU-5, 0 sự kiện không ghép được). **ASSUMPTION** – thứ tự các sự kiện SUY RA trong cùng nến (CREATED trước sự kiện evS, STEP trước ARMED/kết thúc, END_NO_EVENT sau), gán IP-21 theo thứ tự tạo. **PARTIALLY VERIFIED** – thứ tự thực thi thật trong nến chưa chứng minh (không có trace engine theo dòng lệnh); không nâng lên VERIFIED bằng SYNTH. Không sửa adapter.

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| AD-KICH-BAN | PASS | 51 | FACT (logic adapter) / ASSUMPTION (thứ tự trong nến) | Adapter CÔ LẬP trên driver giả lập: 12 kịch bản (CREATED/STEP cùng nến, tạo+kết thúc cùng nến, CREATED→STEP→ARMED, STEP→VOID/EXPIRED/SKIP SU-5/END_NO_ |
| AD-TAO-KET-THUC-CUNG-NEN | BLOCKED | 2 | PARTIALLY VERIFIED | Thể hiện tạo và kết thúc KHÔNG kèm sự kiện ngay trong cùng nến (st = 0): adapter sinh CREATED → END_NO_EVENT – máy trạng thái hợp đồng bác chuyển tiếp |
| AD-THU-TU-TAO | PASS | 2 | FACT | Thứ tự tạo: hai thể hiện tạo cùng nến → CREATED theo thứ tự trong mảng sh, setup_id khác nhau (băm gồm thứ tự trong nến) dù trùng khóa IP-21 |
| AD-MAT-GHEP | PASS | 2 | FACT | Sự kiện evS không ghép được thể hiện (khóa không tồn tại) → KHÔNG bịa sự kiện, đếm khong_ghep = 1; IP-21 hai ứng viên giống hệt → đếm mo_ho, gán theo  |
| AD-ENGINE-THAT | PASS | 327 | FACT (engine) / PARTIALLY VERIFIED (thứ tự suy ra) | Engine THẬT (khối Pine nguyên văn qua khung039): 60 seed XAUUSD + kịch bản SU-3 có định hướng: 0 vi phạm máy trạng thái, 0 lỗi hợp đồng bảng, emit_seq |

## 7. Oracle – F-06

- **ORACLE IMPLEMENTATION INDEPENDENT: XÁC MINH (FACT)** – AST: oracle.py, oracle_r4.py, vector_vang.py chỉ import thư viện chuẩn, không open/exec/eval, không tham chiếu module được kiểm; giá trị kỳ vọng vector vàng là hằng viết tay; oracle R4 bắt được bản R3 và bản đột biến (không suy ra từ output code).
- **SPECIFICATION INDEPENDENCE: KHÔNG ĐỘC LẬP** – oracle và code viết từ CÙNG đặc tả (docstring/nhiệm vụ); hiểu sai đặc tả chung sẽ không bị phát hiện (giữ O-1 của R3).

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| OR-DOC-LAP-CODE | PASS | 12 | FACT | Oracle (oracle.py, oracle_r4.py) và vector vàng (vector_vang.py): AST không import module của shadow_eval, không open()/đọc file, không tham chiếu tên |
| OR-VECTOR-VANG-HANG | PASS | 909 | FACT | Golden vector định nghĩa ĐỘC LẬP: mọi giá trị kỳ vọng (kv) trong vector_vang.py là hằng số viết tay (AST literal), không phải lời gọi hàm / biến tính  |
| OR-VECTOR-VANG-SO-CODE | PASS | 229 | FACT | Vector vàng vs code R4: mọi vector của vector_vang.py khớp code được kiểm (giả lập R1/R2, BUY/SELL, gap, SL-first/TP-first, timeout, OPEN, NO_FILL, NO |
| OR-DANH-MUC-R4 | PASS | 2 | FACT | Oracle danh mục R4 độc lập: bắt được bản R3 (không chặn sau NO_DATA sau vào) và bản đột biến 'chạm biên không giao' – tức oracle KHÔNG được suy ra từ  |
| OR-SO-SANH-PHU | PASS | 116911 | FACT | Oracle độc lập vs code R4 trên 8.000 ca ngẫu nhiên + 13 nhóm phủ (R1, R2, BUY, SELL, gap, SL-first xung đột, TP-first xung đột, TIMEOUT, OPEN, NO_FILL |

Phủ nhóm (OR-SO-SANH-PHU): {"R1": 3942, "R2": 4058, "BUY": 3933, "SELL": 4067, "gap": 1432, "SL-first xung đột": 14, "TP-first xung đột": 23, "TIMEOUT": 1418, "OPEN": 1470, "NO_FILL": 638, "NO_DATA trước": 805, "NO_DATA sau": 187, "chi phí": 3067, "INVALID": 309, "chỉ số (300 tập)": 300, "khử trùng (500 tập)": 500}

## 8. Strict JSON và hợp đồng

| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |
|---|---|---|---|---|
| HD-JSON-STRICT | PASS | 9 | FACT | JSON strict: NaN / Infinity / -Infinity bị từ chối khi đọc (parse_constant) và khi ghi (allow_nan=False); bản ghi có float không hữu hạn → lỗi hợp đồn |
| HD-BANG-HONG | PASS | 12 | FACT | Hợp đồng cấp bản ghi/bảng: timestamp ngoài miền, không tròn phút, bool thay int/float, thiếu trường, trường lạ, trùng ID, trùng emit_seq, SIGNAL không |
| HD-NODATA-OPEN-RULE | PASS | 14 | FACT | Hợp đồng TRADES cho NO_DATA trước/sau vào, OPEN, R1, R2, rr_entry: bản ghi do mo_phong sinh đều hợp lệ; NO_DATA sau vào giữ entry_price, R null; OPEN  |

Bộ R3 tương ứng chạy lại trên code R4: KD-HD-MUT = PASS, KD-HD-FUZZ = PASS, KD-HD-VALID = PASS, KD-JSON = PASS.

## 9. Mutation

### 9.1 Đột biến R4 – lần chạy cuối

| ID | File | Mô tả | Test khai báo | Phân loại | Test không PASS |
|---|---|---|---|---|---|
| M01 | mo_phong_lenh.py | F-01 tái phát: NO_DATA sau vào không chiếm vị thế | F01-NODATA-SAU, F01-CHUOI-TOI-THIEU | **KILLED_EXPECTED** | F01-CHUOI-TOI-THIEU, F01-CUNG-ENTRY, F01-DAO-THU-TU, F01-NODATA-SAU, F01-NODATA-SAU-BI-BO, PF-KHONG-DOI-CA-DUNG, PF-PROP-R4 |
| M02 | mo_phong_lenh.py | NO_DATA sau vào chỉ chặn đúng thời điểm vào (hết vị thế sai) | F01-NODATA-SAU, F01-CHUOI-TOI-THIEU | **KILLED_EXPECTED** | F01-CHUOI-TOI-THIEU, F01-DAO-THU-TU, F01-NODATA-SAU, PF-KHONG-DOI-CA-DUNG, PF-PROP-R4 |
| M03 | mo_phong_lenh.py | NO_DATA TRƯỚC khi vào bị coi là đã vào | F01-NODATA-TRUOC | **KILLED_EXPECTED** | F01-CHUOI-TOI-THIEU, F01-DAO-THU-TU, F01-NODATA-TRUOC, PF-KHONG-DOI-CA-DUNG, PF-PROP-R4 |
| M04 | mo_phong_lenh.py | bỏ sót NON_MONOTONIC_TIME_AFTER_FILL | F01-NODATA-SAU | **KILLED_EXPECTED** | F01-DAO-THU-TU, F01-NODATA-SAU, F01-NODATA-SAU-BI-BO, PF-KHONG-DOI-CA-DUNG, PF-PROP-R4 |
| M05 | mo_phong_lenh.py | biên entry = exit không còn bị bỏ | F01-DONG-THEO-THOI-GIAN, F01-CHUOI-TOI-THIEU | **KILLED_EXPECTED** | F01-CHUOI-TOI-THIEU, F01-DONG-THEO-THOI-GIAN, PF-KHONG-DOI-CA-DUNG, PF-PROP-R4 |
| M06 | hop_dong.py | F-02 tái phát: regex lỏng [0-9.]+ | F02-MA-HONG | **KILLED_EXPECTED** | F02-MA-HONG, F02-MA-HOP-LE |
| M07 | hop_dong.py | bỏ kiểm số không hữu hạn trong cost_model | F02-MA-HONG | **KILLED_EXPECTED** | F02-MA-HONG |
| M08 | hop_dong.py | mã 'C-s…' sai cấu trúc bị bỏ qua im lặng | F02-MA-HONG, F02-FUZZ | **KILLED_EXPECTED** | F02-FUZZ, F02-MA-HONG |
| M09 | hop_dong.py | đổi công thức chi phí đóng băng (trượt 1 lần) | F02-MA-HOP-LE, F02-CONG-THUC-DONG-BANG | **KILLED_EXPECTED** | F02-CONG-THUC-DONG-BANG, F02-MA-HOP-LE |
| M10 | chi_so.py | F-03 tái phát: bootstrap_khoi bỏ kiểm tham số chung | F03-DONG-NHAT | **KILLED_EXPECTED** | F03-DONG-NHAT |
| M11 | chi_so.py | cho phép L = n (CI suy biến giả 'OK') | F03-L | **KILLED_EXPECTED** | F03-L |
| M12 | chi_so.py | bỏ kiểm kiểu n_boot (float 40.0 lọt) | F03-DONG-NHAT | **KILLED_EXPECTED** | F03-DONG-NHAT |
| M13 | chi_so.py | đổi seed (mất tất định so với R3) | F03-KHONG-DOI-PHUONG-PHAP | **KILLED_EXPECTED** | F03-KHONG-DOI-PHUONG-PHAP |
| M14 | mo_phong_lenh.py | lỗi hồi quy tự gây ở lượt 1 (bản ghi thiếu outcome chiếm vị thế ∞) – phát hiện bởi REG-01 R3 | PF-KHONG-DOI-CA-DUNG | **KILLED_EXPECTED** | PF-KHONG-DOI-CA-DUNG |

Bản gốc trong lần chạy đột biến: {'PASS': 41, 'BLOCKED': 1}; bất thường ngoài BLOCKED đã biết: không.

### 9.2 Lần chạy 1 (giữ nguyên làm bằng chứng) và xử lý

| ID | Phân loại lần 1 | Xử lý |
|---|---|---|
| M02 | SURVIVED | Đột biến TƯƠNG ĐƯƠNG (hợp đồng buộc NO_DATA có exit_ts_ms = null → ∞ trong cả hai bản) – thay bằng đột biến không tương đương |
| M07 | SURVIVED | Test F02-MA-HONG chỉ đòi chuỗi 'cost_model' → đột biến bỏ kiểm không hữu hạn vẫn bị báo bởi lỗi công thức → SIẾT test đòi đúng lý do |
| M10 | WRONG_REASON | Chuỗi lý do khai báo sai ('ValueError' không có trong thông điệp) – sửa khai báo, test không đổi |
| M12 | SURVIVED | Đột biến TƯƠNG ĐƯƠNG (True/False < 40 luôn bị bác) – thay bằng bỏ kiểm kiểu n_boot |

Lần chạy 2 (sau xử lý lần 1, TRƯỚC khi phát hiện BUG-R4-1): {'KILLED_EXPECTED': 13} – lượt này chạy trên bản nháp có BUG-R4-1; giữ làm bằng chứng, thay bằng lần chạy cuối (thêm M14).

### 9.3 Đột biến mã nguồn R3 (KD-MUT-SRC) trên code R4: PASS – {'baseline': {'rc': 0, 'tom_tat': {'PASS': 100}, 'so_test': 100, 'so_assertion': 112502}, 'tong': 42, 'phan_loai': {'KILLED_EXPECTED': 42}}

## 10. Hồi quy toàn bộ R3

- Bộ độc lập R3 (109 test, KHÔNG sửa, chạy với PYTHONDONTWRITEBYTECODE=1) trên code R4: {'PASS': 102, 'BLOCKED': 6, 'NOT TESTED': 1}; R3 gốc: {'PASS': 102, 'BLOCKED': 6, 'NOT TESTED': 1}.
- Test đổi trạng thái so với R3 gốc: KHÔNG CÓ.
- KD-REG-S3 (bộ Stage 3 88 test + bộ gốc 22 + bộ 0.3.9 chạy mới): PASS – {'run_id': '6ee3d92e-8fa3-4092-9d5a-d778840b252e', 'exit': 1, 'dem': {'PASS': 76, 'FAIL': 3, 'BLOCKED': 6, 'NOT TESTED': 3, 'ERROR': 0}, 'fail': ['HD-01', 'OT-05', 'OT-06'], 'lien_ket_loi_thoi_s3': {'OT-05': {'ly_do': 'Assertion cũ đòi fill_note = INVALID_BAR cho nến hỏng SAU khi đã vào; vòng 2 tách
- Lượt hồi quy 1 (giữ nguyên làm bằng chứng): {'PASS': 101, 'FAIL': 1, 'BLOCKED': 6, 'NOT TESTED': 1} – KD-REG-S3 FAIL do REG-01 (DUP-02) → BUG-R4-1, đã sửa; bảng trên là lượt chạy lại sau sửa.
- Không test cũ nào bị bỏ, đổi nhẹ hơn hay xóa (FILE_KHONG_DOI.txt chứa SHA của mọi file test cũ, trùng baseline).

## 11. Stale output / cách ly

- Cách ly (`kiem_cach_ly_r4.py`, so TOÀN CÂY với baseline R3): file đổi ngoài phép = không; file mới ngoài phép = không; file xóa = không; .pyc/__pycache__ = 0; 245/248 file baseline không đổi; bản chụp _truoc_r4 trùng R3 = {'mo_phong_lenh.py': True, 'hop_dong.py': True, 'may_trang_thai.py': True, 'chi_so.py': True}.
- Sự cố môi trường đã ghi nhận và xử lý: lần chạy hồi quy R3 đầu tiên tạo `__pycache__` (tiến trình con không thừa hưởng cờ -B) → hủy lượt đó, xóa bytecode, chạy lại toàn bộ với PYTHONDONTWRITEBYTECODE=1 (biến môi trường được thừa hưởng). Kết quả báo cáo là của lượt chạy lại.
- Độ mới: mọi kết quả có run_id; trình đột biến kiểm mtime ≥ lúc bắt đầu và module_dir của từng lượt; KD-REG-S3 kiểm run_id, mtime, exit code của bộ Stage 3 và yêu cầu bộ 0.3.9 chạy mới sau mốc bắt đầu (bộ 0.3.9 chạy mới trong vòng này: mốc 1795257514).

## 12. BLOCKED

| Test | Bộ | Lý do |
|---|---|---|
| KD-REAL-XAU-SU3 | R3 | Không có OHLCV lịch sử có nguồn (mạng của công cụ tắt) và chưa có replay bối cảnh từ OHLCV |
| KD-REAL-XAU-SU5 | R3 | Như trên |
| KD-REAL-BTC-SU3 | R3 | Như trên |
| KD-REAL-BTC-SU5 | R3 | Như trên |
| KD-REPLAY-EQ | R3 | Không có dữ liệu đối chứng; Data Window chỉ giữ một phần sự kiện SHADOW (B-1) |
| KD-TV-TOKEN | R3 | TradingView không in số token khi compile thành công |
| AD-TAO-KET-THUC-CUNG-NEN | R4 | Adapter + driver giả lập: CREATED → END_NO_EVENT (máy trạng thái bác). Engine thật: 0 lần trên 200 seed. Chưa chứng minh engine đi được nhánh này → KHÔNG sửa adapter/máy trạng thái (mục 7); ghi R4-OBS-1, cần chủ dự án quyết định quy ước |

## 13. NOT TESTED

| Test | Lý do |
|---|---|
| KD-REPLAY-FULL | Chưa hiện thực – ngoài phạm vi (không xây full Pine interpreter) |

Không có ENV_ERROR / VALIDATOR_CRASH / WRONG_REASON trong lượt chạy cuối của bộ R4 (xem tóm tắt). Không test nào bị bỏ qua mà không báo.

## 14. Rủi ro tồn đọng

- R4-RR-1 (ASSUMPTION): NO_DATA sau khi vào chiếm vị thế tới ∞ – bảo thủ; nếu owner muốn giải phóng tại thời điểm nến hỏng cần thêm trường thời điểm vào hợp đồng.
- R4-RR-2 (FACT): pipeline SYNTH không sinh NO_DATA sau khi vào (PF-MOI-SEED-RIENG đếm 0) → F-01 không đổi số liệu SYNTH hiện có; tác động chỉ xuất hiện với dữ liệu thật có lỗi.
- R4-RR-3 (FACT): mã cost_model không bắt đầu 'C-s' (ví dụ 'C-0') vẫn là mã tự do theo hợp đồng 1.2 – không kiểm công thức chi phí.
- R4-OBS-1 (PARTIALLY VERIFIED): adapter sinh CREATED → END_NO_EVENT khi thể hiện tạo và biến mất không sự kiện trong cùng nến; máy trạng thái bác; 0/200 seed engine – chờ owner.
- Oracle không độc lập đặc tả (O-1). Thứ tự sự kiện suy ra trong nến PARTIALLY VERIFIED. sl_first, MFE/MAE nến thoát chưa kiểm bằng tick.
- Gói D0/D1 (dashboard) ghim SHA engine R3: B2/T3 và kiểm kê trường sẽ báo lệch khi dùng engine R4 – cần cập nhật ghim SAU khi R4 được duyệt (không tự làm trong R4).
- Thị trường thật: KD-REAL-*, KD-REPLAY-EQ, KD-TV-TOKEN vẫn BLOCKED; KD-REPLAY-FULL NOT TESTED. Không tạo dữ liệu thị trường giả.

## 15. Kết luận

| Tiêu chí đóng vòng (mục 13) | Đạt |
|---|---|
| F01 | ĐẠT |
| F02 | ĐẠT |
| F03 | ĐẠT |
| hoi_quy | ĐẠT |
| dot_bien | ĐẠT |
| strict | ĐẠT |
| cach_ly | ĐẠT |
| khong_crash | ĐẠT |

**ĐỀ XUẤT: R4 đủ điều kiện ĐÓNG** theo bằng chứng trong môi trường Claude (chưa phải kiểm toán độc lập). Còn 1 mục BLOCKED mới (R4-OBS-1) cần owner quyết định; các mục thị trường thật giữ BLOCKED. Không tuyên bố CLOSED khi ChatGPT chưa kiểm toán lại.
