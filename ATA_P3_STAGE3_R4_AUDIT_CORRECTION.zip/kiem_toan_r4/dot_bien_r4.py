# -*- coding: utf-8 -*-
"""ĐỘT BIẾN R4 (M02 bản đầu – "dùng exit null" – là đột biến TƯƠNG ĐƯƠNG: hợp đồng buộc NO_DATA có exit_ts_ms = null nên kết quả không thể khác; đã thay bằng đột biến không tương đương; M12 bản đầu – bỏ kiểm bool – cũng tương đương vì True/False < 40, đã thay; M07 sống sót ở lần 1 vì F02-MA-HONG chỉ đòi chuỗi 'cost_model' – test đã siết lý do chính xác)
 – mỗi đột biến chạy TOÀN BỘ bộ chay_r4.py trên BẢN SAO module trong tiến trình riêng (python -B, ATA_GOC = gốc dự án).
Phân loại (không gộp):
  KILLED_EXPECTED   – một test KHAI BÁO TRƯỚC ra FAIL và thông điệp chứa chuỗi lý do kỳ vọng; hoặc (chỉ với đột biến khai báo qua_ly_do) test ra WRONG_REASON
                      vì đột biến đổi lý do lỗi mà test kiểm chính xác
  WRONG_REASON      – test khai báo FAIL/WRONG_REASON nhưng không thỏa điều kiện trên (bắt nhầm lý do)
  VALIDATOR_CRASH   – test khai báo kết thúc vì code được kiểm ném ngoại lệ (không tính là phát hiện hợp lệ)
  KILLED_UNEXPECTED – test khai báo PASS nhưng test KHÁC ra FAIL
  SURVIVED          – mọi test PASS (trừ BLOCKED đã biết)
  ENV_ERROR         – không áp được đột biến (điểm neo không duy nhất) hoặc tiến trình không tạo kết quả / tạo kết quả cũ (run_id, mtime)
python3 -B kiem_toan_r4/dot_bien_r4.py → kiem_toan_r4/ket_qua/dot_bien_r4.json"""
import sys
sys.dont_write_bytecode = True
import json, os, shutil, subprocess, tempfile, time   # noqa: E402
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
OUT = os.path.join(D, "ket_qua"); os.makedirs(OUT, exist_ok=True)
DB = [  # (id, file, neo, thay, mô tả, test khai báo, chuỗi lý do kỳ vọng[, qua_ly_do])
    ("M01", "mo_phong_lenh.py", 'if t.get("outcome") == "NO_DATA" and t.get("fill_note") in NO_DATA_SAU_VAO:\n            pass', 'if False:\n            pass',
     "F-01 tái phát: NO_DATA sau vào không chiếm vị thế", ["F01-NODATA-SAU", "F01-CHUOI-TOI-THIEU"], "oracle R4"),
    ("M02", "mo_phong_lenh.py", 'mo[k] = math.inf if t.get("outcome") == "OPEN" or t.get("exit_ts_ms") is None else t["exit_ts_ms"]',
     'mo[k] = t["entry_ts_ms"] if t.get("outcome") == "NO_DATA" else (math.inf if t.get("outcome") == "OPEN" or t.get("exit_ts_ms") is None else t["exit_ts_ms"])',
     "NO_DATA sau vào chỉ chặn đúng thời điểm vào (hết vị thế sai)", ["F01-NODATA-SAU", "F01-CHUOI-TOI-THIEU"], "oracle R4"),
    ("M03", "mo_phong_lenh.py", 'NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_TIME_AFTER_FILL")', 'NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_TIME_AFTER_FILL", "NO_NEXT_BAR")',
     "NO_DATA TRƯỚC khi vào bị coi là đã vào", ["F01-NODATA-TRUOC"], "oracle R4"),
    ("M04", "mo_phong_lenh.py", 'NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL", "NON_MONOTONIC_TIME_AFTER_FILL")', 'NO_DATA_SAU_VAO = ("INVALID_BAR_AFTER_FILL",)',
     "bỏ sót NON_MONOTONIC_TIME_AFTER_FILL", ["F01-NODATA-SAU"], "oracle R4"),
    ("M05", "mo_phong_lenh.py", 'if k in mo and t["entry_ts_ms"] <= mo[k]:', 'if k in mo and t["entry_ts_ms"] < mo[k]:', "biên entry = exit không còn bị bỏ",
     ["F01-DONG-THEO-THOI-GIAN", "F01-CHUOI-TOI-THIEU"], "oracle R4"),
    ("M06", "hop_dong.py", '_SO = r"([0-9]+(?:\\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)"', '_SO = r"([0-9.]+)"', "F-02 tái phát: regex lỏng [0-9.]+",
     ["F02-MA-HONG"], "sai cấu trúc", True),
    ("M07", "hop_dong.py", 'if not all(math.isfinite(x) for x in v):', 'if False:', "bỏ kiểm số không hữu hạn trong cost_model", ["F02-MA-HONG"], "không hữu hạn", True),
    ("M08", "hop_dong.py", '    if not isinstance(ma, str) or not ma.startswith("C-s"):\n        return None, None\n    m = CHI_PHI.fullmatch(ma)\n    if not m:\n        return None, "cost_model sai cấu trúc/cú pháp số (cần C-s<số>-c<số>-sl<số>)"',
     '    if not isinstance(ma, str) or not ma.startswith("C-s"):\n        return None, None\n    m = CHI_PHI.fullmatch(ma)\n    if not m:\n        return None, None', "mã 'C-s…' sai cấu trúc bị bỏ qua im lặng",
     ["F02-MA-HONG", "F02-FUZZ"], "sai cấu trúc"),
    ("M09", "hop_dong.py", "cp = v[0] + v[1] + 2 * v[2]", "cp = v[0] + v[1] + v[2]", "đổi công thức chi phí đóng băng (trượt 1 lần)", ["F02-MA-HOP-LE", "F02-CONG-THUC-DONG-BANG"], "chi phí"),
    ("M10", "chi_so.py", "    R = list(R_theo_thoi_gian)\n    _kiem_tham_so(R, n_boot, alpha)", "    R = list(R_theo_thoi_gian)", "F-03 tái phát: bootstrap_khoi bỏ kiểm tham số chung",
     ["F03-DONG-NHAT"], "bootstrap_khoi"),
    ("M11", "chi_so.py", "    if L is not None and L > n - 1:", "    if L is not None and L > n:", "cho phép L = n (CI suy biến giả 'OK')", ["F03-L"], "L = 5"),
    ("M12", "chi_so.py", "if not isinstance(n_boot, int) or isinstance(n_boot, bool) or n_boot < N_BOOT_MIN:", "if n_boot < N_BOOT_MIN:",
     "bỏ kiểm kiểu n_boot (float 40.0 lọt)", ["F03-DONG-NHAT"], "n_boot"),
    ("M13", "chi_so.py", "rnd = random.Random(_seed(seed, key))", "rnd = random.Random(_seed(seed + 1, key))", "đổi seed (mất tất định so với R3)", ["F03-KHONG-DOI-PHUONG-PHAP"], "bootstrap_ci đổi"),
]
DB.append(("M14", "mo_phong_lenh.py", 'mo[k] = math.inf if t.get("outcome") == "OPEN" or', 'mo[k] = math.inf if t.get("outcome") not in DONG or',
           "lỗi hồi quy tự gây ở lượt 1 (bản ghi thiếu outcome chiếm vị thế ∞) – phát hiện bởi REG-01 R3", ["PF-KHONG-DOI-CA-DUNG"], "thiếu outcome"))
CHAP_NHAN_BLOCKED = {"AD-TAO-KET-THUC-CUNG-NEN"}


def chay(mut):
    tmp = tempfile.mkdtemp(prefix="r4_mut_"); md = os.path.join(tmp, "m"); os.makedirs(md)
    for f in os.listdir(os.path.join(G, "shadow_eval")):
        if f.endswith(".py"):
            shutil.copy(os.path.join(G, "shadow_eval", f), md)
    if mut:
        _, f, neo, thay = mut[:4]
        src = open(os.path.join(md, f), encoding="utf-8").read()
        if src.count(neo) != 1:
            return None, f"ENV_ERROR: điểm neo xuất hiện {src.count(neo)} lần"
        open(os.path.join(md, f), "w", encoding="utf-8").write(src.replace(neo, thay, 1))
    out = os.path.join(tmp, "out"); t0 = time.time()
    p = subprocess.run([sys.executable, "-B", os.path.join(G, "kiem_doc_lap", "chay_r4.py"), "--module-dir", md, "--out", out], capture_output=True, text=True, timeout=1800,
                       env=dict(os.environ, ATA_GOC=G, PYTHONDONTWRITEBYTECODE="1"), cwd=tmp)
    f = os.path.join(out, "ket_qua_r4.json")
    if not os.path.exists(f) or os.path.getmtime(f) < t0:
        return None, f"ENV_ERROR: không có kết quả mới (exit {p.returncode}) {p.stderr[-300:]}"
    r = json.load(open(f, encoding="utf-8"))
    if r["module_dir"] != md:
        return None, "ENV_ERROR: kết quả của thư mục module khác"
    return dict(r, exit=p.returncode), None


def main():
    goc, loi = chay(None)
    assert goc and not loi, loi
    st_goc = {k["test_id"]: k["status"] for k in goc["ket_qua"]}
    bat_thuong = {k: v for k, v in st_goc.items() if v != "PASS" and k not in CHAP_NHAN_BLOCKED}
    bang = []
    for m in DB:
        mid, f, _, _, mo, khai, ly = m[:7]
        qua_ly_do = len(m) > 7 and m[7]
        r, loi = chay(m)
        if loi:
            bang.append(dict(id=mid, file=f, mo_ta=mo, phan_loai="ENV_ERROR", chi_tiet=loi)); continue
        st = {k["test_id"]: k for k in r["ket_qua"]}
        kb = [st[t] for t in khai if t in st]
        if any(x["status"] == "FAIL" and ly in x["actual"] for x in kb) or (qua_ly_do and any(x["status"] == "WRONG_REASON" and ly in x["actual"] for x in kb)):
            pl = "KILLED_EXPECTED"          # qua_ly_do: đột biến được khai báo là bị bắt qua kiểm LÝ DO chính xác (test ra WRONG_REASON)
        elif any(x["status"] in ("FAIL", "WRONG_REASON") for x in kb):
            pl = "WRONG_REASON"
        elif any(x["status"] == "VALIDATOR_CRASH" for x in kb):
            pl = "VALIDATOR_CRASH"
        elif any(x["status"] not in ("PASS",) and x["test_id"] not in CHAP_NHAN_BLOCKED for x in r["ket_qua"]):
            pl = "KILLED_UNEXPECTED"
        else:
            pl = "SURVIVED"
        khac = sorted(x["test_id"] for x in r["ket_qua"] if x["status"] != "PASS" and x["test_id"] not in CHAP_NHAN_BLOCKED)
        bang.append(dict(id=mid, file=f, mo_ta=mo, test_khai_bao=khai, ly_do_ky_vong=ly, phan_loai=pl,
                         ket_qua_test_khai_bao={x["test_id"]: [x["status"], x["actual"][:200]] for x in kb}, test_khong_pass=khac, run_id=r["run_id"], exit=r["exit"]))
        print(mid, pl, khac)
    dem = {}
    for b in bang:
        dem[b["phan_loai"]] = dem.get(b["phan_loai"], 0) + 1
    json.dump(dict(goc=dict(run_id=goc["run_id"], tom_tat=goc["tom_tat"], bat_thuong=bat_thuong), dem=dem, dot_bien=bang),
              open(os.path.join(OUT, "dot_bien_r4.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("ĐỘT BIẾN R4:", dem, "| bản gốc bất thường:", bat_thuong)
    return 0 if dem == {"KILLED_EXPECTED": len(DB)} and not bat_thuong else 1


if __name__ == "__main__":
    sys.exit(main())
