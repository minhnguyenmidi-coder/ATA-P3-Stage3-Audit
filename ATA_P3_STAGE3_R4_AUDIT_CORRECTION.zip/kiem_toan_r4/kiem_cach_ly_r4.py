# -*- coding: utf-8 -*-
"""CÁCH LY + ĐỘ MỚI R4. python3 -B kiem_toan_r4/kiem_cach_ly_r4.py <thư mục baseline R3 đã giải nén>
So TOÀN BỘ cây làm việc với baseline R3 (giải nén từ ZIP R3, SHA 585e7b0e…): file đổi phải ĐÚNG danh sách được phép; file mới chỉ ở chỗ được phép;
không file nào bị xóa; không __pycache__/.pyc trong cây (mọi lần chạy dùng -B); Pine đúng SHA khóa; kết quả mới hơn lúc bắt đầu, đúng run_id.
Ghi kiem_toan_r4/ket_qua/cach_ly_r4.json."""
import hashlib, json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D); B = os.path.abspath(sys.argv[1])
DUOC_SUA = {"shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py"}
DUOC_THEM = ("shadow_eval/_truoc_r4/", "kiem_doc_lap/chay_r4.py", "kiem_doc_lap/oracle_r4.py", "kiem_toan_r4/")
PINE = {"src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine": "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13",
        "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine": "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"}
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()   # noqa: E731


def cay(goc):
    return {os.path.relpath(os.path.join(r, f), goc): sha(os.path.join(r, f)) for r, _, fs in os.walk(goc) for f in fs}


a, b = cay(B), cay(G)
doi = sorted(k for k in a if k in b and a[k] != b[k]); moi = sorted(k for k in b if k not in a); xoa = sorted(k for k in a if k not in b)
pyc = sorted(k for k in b if "__pycache__" in k or k.endswith(".pyc"))
kq = dict(
    doi_ngoai_phep=[k for k in doi if k not in DUOC_SUA], doi=doi, moi_ngoai_phep=[k for k in moi if not k.startswith(DUOC_THEM)], so_moi=len(moi), xoa=xoa, pyc=pyc,
    pine={p: sha(os.path.join(G, p)) == h for p, h in PINE.items()},
    truoc_r4_khop_r3={f: sha(os.path.join(G, "shadow_eval/_truoc_r4", f)) == a.get("shadow_eval/" + f) for f in os.listdir(os.path.join(G, "shadow_eval/_truoc_r4"))},
    khong_doi=len([k for k in a if k in b and a[k] == b[k]]), tong_baseline=len(a))
kq["dat"] = not kq["doi_ngoai_phep"] and not kq["moi_ngoai_phep"] and not xoa and not pyc and all(kq["pine"].values()) and all(kq["truoc_r4_khop_r3"].values()) \
    and set(doi) == DUOC_SUA
json.dump(kq, open(os.path.join(D, "ket_qua", "cach_ly_r4.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in kq.items() if k != "doi"}, ensure_ascii=False)[:1500]); print("ĐẠT" if kq["dat"] else "KHÔNG ĐẠT")
sys.exit(0 if kq["dat"] else 1)
