# -*- coding: utf-8 -*-
"""SINH BỘ BÀN GIAO R4 từ KẾT QUẢ THẬT (không gõ tay số liệu). python3 -B kiem_toan_r4/tao_ban_giao_r4.py <baseline R3 giải nén>
Đọc: kiem_toan_r4/ket_qua/{ket_qua_r4.json, dot_bien_r4.json, dot_bien_r4_LAN1_truoc_sua_khai_bao.json, cach_ly_r4.json, r3_day_du/ket_qua_doc_lap.json},
     /tmp/reg039 (bộ 0.3.9 chạy mới), baseline R3. Ghi kiem_toan_r4/BAN_GIAO_R4/."""
import csv, datetime as dt, difflib, hashlib, io, json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D); B = os.path.abspath(sys.argv[1])
KQ = os.path.join(D, "ket_qua"); OUT = os.path.join(D, "BAN_GIAO_R4"); os.makedirs(OUT, exist_ok=True)
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()   # noqa: E731
J = lambda p: json.load(open(p, encoding="utf-8"))                  # noqa: E731
r4 = J(os.path.join(KQ, "ket_qua_r4.json")); db = J(os.path.join(KQ, "dot_bien_r4.json")); db1 = J(os.path.join(KQ, "dot_bien_r4_LAN1_truoc_sua_khai_bao.json"))
cl = J(os.path.join(KQ, "cach_ly_r4.json")); r3 = J(os.path.join(KQ, "r3_day_du", "ket_qua_doc_lap.json")); r3g = J(os.path.join(B, "kiem_toan_r3", "ket_qua", "ket_qua_doc_lap.json"))
reg = J(os.path.join(KQ, "reg039_r4_ket_qua_039.json")) if os.path.exists(os.path.join(KQ, "reg039_r4_ket_qua_039.json")) else None
SUA = ["shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py"]
PINE = ["src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine"]
st4 = {k["test_id"]: k for k in r4["ket_qua"]}; st3 = {k["test_id"]: k for k in r3["ket_qua"]}; st3g = {k["test_id"]: k for k in r3g["ket_qua"]}

# ---------------------------------------------------------------- SHA + diff + danh sách file
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_SHA_PINE.txt"), "w").write("".join(f"{sha(os.path.join(G, p))}  {p}\n" for p in PINE))
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_SHA_BASELINE_R3.txt"), "w").write(
    "# Baseline R3 = giải nén ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION.zip (SHA-256 585e7b0e65cb9ea85e9245658c8b6bd0a81159440c7accb289b93b03283d05ca)\n"
    + "".join(f"{sha(os.path.join(B, p))}  {p}\n" for p in SUA + ["shadow_eval/chuan_hoa.py", "shadow_eval/pipeline.py", "shadow_eval/may_trang_thai.py", "shadow_eval/du_lieu.py",
                                                                  "kiem_doc_lap/chay_doc_lap.py", "kiem_doc_lap/oracle.py", "kiem_doc_lap/vector_vang.py"]))
moi = sorted(os.path.relpath(os.path.join(r, f), G) for r, _, fs in os.walk(G) for f in fs
             if os.path.relpath(os.path.join(r, f), G).startswith(("shadow_eval/_truoc_r4/", "kiem_doc_lap/chay_r4.py", "kiem_doc_lap/oracle_r4.py", "kiem_toan_r4/"))
             and "/BAN_GIAO_R4/" not in os.path.join(r, f) and "/ket_qua/" not in os.path.join(r, f))
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_SHA_SAU_SUA.txt"), "w").write("# file SỬA\n" + "".join(f"{sha(os.path.join(G, p))}  {p}\n" for p in SUA)
                                                                     + "# file MỚI (code/test)\n" + "".join(f"{sha(os.path.join(G, p))}  {p}\n" for p in moi))
diff = "".join("".join(difflib.unified_diff(open(os.path.join(B, p), encoding="utf-8").readlines(), open(os.path.join(G, p), encoding="utf-8").readlines(), f"a/{p}", f"b/{p}")) for p in SUA)
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_DIFF.patch"), "w", encoding="utf-8").write(diff)
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_FILE_THAY_DOI.txt"), "w", encoding="utf-8").write(
    "# SỬA (3)\n" + "\n".join(SUA) + "\n# MỚI\n" + "\n".join(moi) + "\n# XÓA\n" + ("\n".join(cl["xoa"]) or "(không)") + "\n")
khong = []
for r, _, fs in os.walk(B):
    for f in fs:
        p = os.path.relpath(os.path.join(r, f), B)
        if p not in SUA and os.path.exists(os.path.join(G, p)) and sha(os.path.join(G, p)) == sha(os.path.join(B, p)):
            khong.append(f"{sha(os.path.join(B, p))}  {p}")
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_FILE_KHONG_DOI.txt"), "w", encoding="utf-8").write(f"# {len(khong)} file trùng SHA baseline R3 (gồm Pine, test cũ, oracle, vector vàng, kết quả R3)\n" + "\n".join(sorted(khong, key=lambda x: x[66:])) + "\n")

# ---------------------------------------------------------------- ma trận test
buf = io.StringIO(); w = csv.writer(buf)
w.writerow(["bo", "test_id", "nhom", "status", "so_assertion", "bang_chung", "muc_tieu", "status_R3_goc", "actual"])
for k in r4["ket_qua"]:
    w.writerow(["R4-moi", k["test_id"], k["nhom"], k["status"], k["so_assertion"], k.get("bang_chung", ""), k["muc_tieu"], "", str(k["actual"])[:300]])
for k in r3["ket_qua"]:
    w.writerow(["R3-cu-tren-R4", k["test_id"], k["nhom"], k["status"], k["so_assertion"], k.get("phan_loai", ""), k["muc_tieu"], st3g.get(k["test_id"], {}).get("status", "MỚI?"), str(k["actual"])[:300]])
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_TEST_MATRIX.csv"), "w", encoding="utf-8").write(buf.getvalue())
lech_r3 = sorted(t for t in set(st3) | set(st3g) if st3.get(t, {}).get("status") != st3g.get(t, {}).get("status"))

# ---------------------------------------------------------------- findings
FIND = [
    dict(id="F-01", sev="CAO", file="shadow_eval/mo_phong_lenh.py", line="191 (R3) → 195–197 (R4)", tests="F01-*, PF-*, OR-DANH-MUC-R4, M01–M05",
         ev="F01-CU-TAI-HIEN: trên bản R3, NO_DATA INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL không chặn TP1 vào sau cùng khóa",
         truoc="NO_DATA (mọi ghi chú) ∈ KHONG_VAO → bỏ qua lọc, không chiếm vị thế",
         patch="NO_DATA có fill_note ∈ NO_DATA_SAU_VAO được xét như lệnh đã vào: chịu lọc và chiếm vị thế tới ∞ (như OPEN); ca khác không đổi",
         du="Quy ước '∞' (không biết thời điểm thoát) là bảo thủ; thay quyết định owner R3 #3 theo chỉ thị R4 mục 3"),
    dict(id="F-02", sev="CAO", file="shadow_eval/hop_dong.py", line="36, 192–194 (R3) → 36–54, 210–216 (R4)", tests="F02-*, M06–M09",
         ev="F02-CU-TAI-HIEN: bản R3 ném ValueError với cost_model 'C-s1..2-c0-sl0' (validator crash)",
         truoc="regex [0-9.]+ chấp nhận '1..2', '.', rồi float() ném ngoại lệ; mã 'C-s…' sai cấu trúc bị bỏ qua im lặng",
         patch="cú pháp số chặt [0-9]+(.[0-9]+)?([eE][+-]?[0-9]+)?; chi_phi_tu_ma() không ném, báo lỗi 'sai cấu trúc' / 'không hữu hạn'; công thức chi phí giữ nguyên",
         du="Mã KHÔNG bắt đầu 'C-s' (ví dụ 'C-0') vẫn là mã tự do theo hợp đồng 1.2 – không kiểm công thức (giữ phạm vi; xem R4-RR-3)"),
    dict(id="F-03", sev="TRUNG BÌNH", file="shadow_eval/chi_so.py", line="67–111 (R3) → 67–135 (R4)", tests="F03-*, M10–M13",
         ev="F03-CU-TAI-HIEN: R3 khối n_boot 0 → IndexError; L = n → CI suy biến ghi 'OK'; L = 0 bị nuốt; ci kiểm n_boot sau nhánh suy biến; alpha = 1 → khoảng đảo",
         truoc="kiểm tham số không đồng nhất giữa bootstrap_ci và bootstrap_khoi; không kiểm alpha, R hữu hạn, L",
         patch="_kiem_tham_so() chung chạy trước mọi nhánh; L ∈ [1, n−1]; phan_vi_doi_xung kiểm alpha, B > 0; phương pháp/seed/CI với đầu vào hợp lệ trùng từng bit R3 (400 + 200 ca)",
         du="Đầu vào sai nay ném ValueError (trước đây có lúc trả kết quả) – bên gọi duy nhất trong engine (hieu_qua) luôn truyền tham số hợp lệ"),
    dict(id="BUG-R4-1", sev="CAO (tự gây trong R4, đã sửa)", file="shadow_eval/mo_phong_lenh.py", line="dòng 'mo[k] = …' của khong_chong", tests="REG-01 (bộ Stage 3 gốc, qua KD-REG-S3), PF-KHONG-DOI-CA-DUNG, M14",
         ev="Lượt hồi quy R3 thứ nhất: KD-REG-S3 FAIL vì REG-01 → DUP-02 của bộ gốc 22 FAIL (bản ghi không có 'outcome' bị chiếm vị thế ∞) – r3_day_du_LAN1_REG01_FAIL/",
         truoc="bản nháp R4 rút gọn 'outcome == OPEN' thành 'outcome not in DONG' → bản ghi thiếu outcome đổi hành vi",
         patch="trả dòng về NGUYÊN VĂN R3 (NO_DATA sau vào vốn có exit null nên vẫn ∞); thêm 1.000 tập 'thiếu outcome' vào PF-KHONG-DOI-CA-DUNG và đột biến M14",
         du="Không còn – test mới bắt bản lỗi (M14 KILLED_EXPECTED)"),
    dict(id="F-05", sev="KIỂM CHỨNG", file="shadow_eval/chuan_hoa.py", line="—", tests="AD-*", ev="Không sửa (không chứng minh lỗi)",
         truoc="—", patch="không", du="R4-OBS-1: CREATED → END_NO_EVENT cùng nến (adapter sinh, máy trạng thái bác) – 0/200 seed engine; BLOCKED chờ owner"),
    dict(id="F-06", sev="KIỂM CHỨNG", file="kiem_doc_lap/oracle.py, vector_vang.py", line="—", tests="OR-*", ev="Không sửa oracle (không chứng minh lỗi); thêm oracle_r4.py cho quy tắc mới",
         truoc="—", patch="thêm kiem_doc_lap/oracle_r4.py", du="Oracle độc lập code, KHÔNG độc lập đặc tả"),
]
buf = io.StringIO(); w = csv.writer(buf)
w.writerow(["id", "severity", "evidence", "file", "line", "truoc_sua", "patch", "test", "ket_qua", "sha_sau_sua", "residual_risk"])
for f in FIND:
    pre = {"F-01": ("F01", "PF"), "F-02": ("F02",), "F-03": ("F03",), "F-05": ("AD",), "F-06": ("OR",), "BUG-R4-1": ("PF-KHONG-DOI",)}[f["id"]]
    ts = [k for k in r4["ket_qua"] if k["test_id"].startswith(pre)]
    kq_ = {}
    for k in ts:
        kq_[k["status"]] = kq_.get(k["status"], 0) + 1
    f["kq"] = kq_
    w.writerow([f["id"], f["sev"], f["ev"], f["file"], f["line"], f["truoc"], f["patch"], f["tests"], json.dumps(kq_, ensure_ascii=False),
                sha(os.path.join(G, f["file"])) if os.path.isfile(os.path.join(G, f["file"])) else "", f["du"]])
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_FINDINGS_MATRIX.csv"), "w", encoding="utf-8").write(buf.getvalue())

# ---------------------------------------------------------------- báo cáo gộp
def bang_test(pre):
    return "\n".join(f"| {k['test_id']} | {k['status']} | {k['so_assertion']} | {k.get('bang_chung', '')} | {k['muc_tieu'][:150]} |" for k in r4["ket_qua"]
                     if (k["test_id"] == pre if pre.endswith("TAI-HIEN") else k["test_id"].startswith(pre)))


H = "| Test | Trạng thái | Assertion | Bằng chứng | Mục tiêu |\n|---|---|---|---|---|\n"
dm = {d_["id"]: d_ for d_ in db["dot_bien"]}
L = []
a = L.append
a("# ATA P3 · STAGE 3 · R4 – BÁO CÁO SỬA CHỮA VÀ KIỂM THỬ ĐỘC LẬP (vòng 4)\n")
a(f"Sinh tự động lúc {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} từ kết quả chạy thật. Báo cáo GỘP mọi mục bắt buộc (mục 12 nhiệm vụ). "
  "Quy ước: FACT / ASSUMPTION / PARTIALLY VERIFIED / HYPOTHESIS. Trạng thái không gộp.\n")
a("## 0. Tóm tắt\n")
a(f"- Bộ R4 mới: **{r4['tom_tat']}**, {r4['so_assertion']:,} assertion, run_id `{r4['run_id']}`.")
a(f"- Hồi quy R3 đầy đủ trên code R4: **{r3['tom_tat']}**, {r3['so_assertion']:,} assertion (R3 gốc: {r3g['tom_tat']}, {r3g['so_assertion']:,}). Test đổi trạng thái so với R3: {lech_r3 or 'không có'}.")
a(f"- Đột biến R4 (lần chạy cuối): **{db['dem']}**; lần 1: {db1['dem']} (đã xử lý – mục 9).")
kd = st3.get("KD-MUT-SRC", {}); a(f"- Đột biến mã nguồn R3 (KD-MUT-SRC, 42 đột biến) trên code R4: **{kd.get('status')}**.")
a(f"- Cách ly: **{'ĐẠT' if cl['dat'] else 'KHÔNG ĐẠT'}** – file đổi = {cl['doi']}; file xóa = {cl['xoa'] or 'không'}; .pyc = {len(cl['pyc'])}; Pine khớp = {cl['pine']}.")
if reg:
    a(f"- Bộ Pine 0.3.9 chạy MỚI trong vòng này: {reg['summary']['counts']} – trùng R3 (FAIL duy nhất T-01 token gate đã phân loại từ trước; Pine không đổi).")
a("")
a("## 1. Kiểm toán trước sửa (baseline)\n")
a("- FACT: baseline = giải nén `ATA_P3_STAGE3_INDEPENDENT_AUDIT_REMEDIATION.zip` (SHA-256 `585e7b0e…05ca`); 247/247 file khớp manifest R3; 12/12 SOURCE_HASHES khớp.")
a(f"- FACT: Pine 0.3.8 `{sha(os.path.join(G, PINE[0]))}`, 0.3.9 `{sha(os.path.join(G, PINE[1]))}` – khớp SHA khóa trước VÀ sau sửa.")
a("- Tái hiện lỗi trên bản R3 (bản sao `shadow_eval/_truoc_r4/`, trùng SHA baseline):\n")
a(H + bang_test("F01-CU-TAI-HIEN") + "\n" + bang_test("F02-CU-TAI-HIEN") + "\n" + bang_test("F03-CU-TAI-HIEN") + "\n")
a("- File ĐƯỢC PHÉP sửa: `shadow_eval/mo_phong_lenh.py`, `shadow_eval/hop_dong.py`, `shadow_eval/chi_so.py`. File mới: `shadow_eval/_truoc_r4/*` (bản chụp R3 để tái hiện), "
  "`kiem_doc_lap/chay_r4.py`, `kiem_doc_lap/oracle_r4.py`, `kiem_toan_r4/*`.")
a("- File BẮT BUỘC không sửa: Pine (src0*), `chuan_hoa.py`, `pipeline.py`, `may_trang_thai.py`, `du_lieu.py`, mọi test cũ (`chay_doc_lap.py`, `kiem_thu_stage3.py`, …), "
  "`oracle.py`, `vector_vang.py`, kết quả R3. Kiểm bằng `kiem_cach_ly_r4.py` (mục 11).\n")
a("## 2. Findings\n")
a("| ID | Severity | Evidence | File | Line | Trước sửa | Patch | Test | Kết quả | Residual risk |\n|---|---|---|---|---|---|---|---|---|---|")
for f in FIND:
    a(f"| {f['id']} | {f['sev']} | {f['ev']} | `{f['file']}` | {f['line']} | {f['truoc']} | {f['patch']} | {f['tests']} | {json.dumps(f['kq'], ensure_ascii=False)} | {f['du']} |")
a("\nSHA sau sửa: " + ", ".join(f"`{p}` `{sha(os.path.join(G, p))[:16]}…`" for p in SUA) + ". Diff đầy đủ: `ATA_P3_STAGE3_R4_DIFF.patch`.\n")
a("## 3. F-01 – Lọc danh mục (portfolio regression)\n")
a("Quy tắc sau sửa (FACT, kiểm bởi oracle R4 độc lập): lệnh **đã vào** = TP1/SL/TIMEOUT/OPEN + NO_DATA sau khi vào; chiếm vị thế tới exit_ts (TP1/SL/TIMEOUT) "
  "hoặc ∞ (OPEN, NO_DATA sau vào); vào khi khóa đang có vị thế (entry ≤ hết) → bỏ; NO_FILL / INVALID / NO_DATA trước khi vào luôn giữ, không chiếm; thứ tự (entry_ts, emit_seq, signal_id).")
a("Thay đổi quyết định: quyết định owner R3 #3 ('NO_DATA sau khi vào không chiếm vị thế') được THAY theo chỉ thị R4 mục 3.\n")
a(H + bang_test("F01-") + "\n" + bang_test("PF-") + "\n")
a("Ánh xạ yêu cầu mục 3/6 → test: TP1/SL/TIMEOUT theo exit (F01-DONG-THEO-THOI-GIAN); OPEN (F01-OPEN); NO_FILL/INVALID (F01-NOFILL-INVALID); NO_DATA trước/sau (F01-NODATA-TRUOC/SAU/SAU-BI-BO); "
  "trùng signal_id (F01-TRUNG-ID); trùng emit_seq (PF-EMIT-TRUNG, PF-PROP-R4); entry = exit, entry < exit, cùng entry (F01-CHUOI-TOI-THIEU, F01-CUNG-ENTRY); nhiều symbol/setup, OPEN cuối chuỗi, đảo thứ tự "
  "(F01-OPEN, F01-DAO-THU-TU, PF-PROP-R4); mỗi seed lọc riêng (PF-MOI-SEED-RIENG); độc lập dedup (PF-DOC-LAP-DEDUP); ca đang đúng không đổi (PF-KHONG-DOI-CA-DUNG).\n")
a("## 4. F-02 – cost_model\n")
a(H + bang_test("F02-") + "\n")
a("## 5. F-03 – Bootstrap\n")
a("Khác biệt R3 giữa hai phương pháp (FACT, F03-CU-TAI-HIEN): bootstrap_ci kiểm n_boot ≥ 40 nhưng SAU nhánh suy biến; bootstrap_khoi không kiểm n_boot (0 → IndexError), nuốt L = 0, "
  "chấp nhận L ≥ n (CI suy biến ghi 'OK'); cả hai không kiểm alpha (alpha = 1 → khoảng đảo) và R không hữu hạn. Thống nhất: một hàm kiểm chung chạy trước mọi nhánh; L ∈ [1, n−1]. "
  "Phương pháp, seed, CI với đầu vào hợp lệ: trùng từng bit R3. CI SYNTH không phải bằng chứng hiệu quả thị trường.\n")
a(H + bang_test("F03-") + "\n")
a("## 6. Adapter – F-05\n")
a("Phân loại: **FACT** – logic adapter trên driver giả lập (chuỗi sự kiện, emit_seq, ghép theo khóa, không bịa sự kiện) và tính chất trên engine THẬT (60 seed + SU-3 định hướng: "
  "0 vi phạm máy trạng thái, 0 lỗi hợp đồng, mọi SIGNAL có TRIGGER, SKIP chỉ SU-5, 0 sự kiện không ghép được). **ASSUMPTION** – thứ tự các sự kiện SUY RA trong cùng nến (CREATED trước sự kiện evS, "
  "STEP trước ARMED/kết thúc, END_NO_EVENT sau), gán IP-21 theo thứ tự tạo. **PARTIALLY VERIFIED** – thứ tự thực thi thật trong nến chưa chứng minh (không có trace engine theo dòng lệnh); "
  "không nâng lên VERIFIED bằng SYNTH. Không sửa adapter.\n")
a(H + bang_test("AD-") + "\n")
a("## 7. Oracle – F-06\n")
a("- **ORACLE IMPLEMENTATION INDEPENDENT: XÁC MINH (FACT)** – AST: oracle.py, oracle_r4.py, vector_vang.py chỉ import thư viện chuẩn, không open/exec/eval, không tham chiếu module được kiểm; "
  "giá trị kỳ vọng vector vàng là hằng viết tay; oracle R4 bắt được bản R3 và bản đột biến (không suy ra từ output code).")
a("- **SPECIFICATION INDEPENDENCE: KHÔNG ĐỘC LẬP** – oracle và code viết từ CÙNG đặc tả (docstring/nhiệm vụ); hiểu sai đặc tả chung sẽ không bị phát hiện (giữ O-1 của R3).\n")
a(H + bang_test("OR-") + "\n")
a("Phủ nhóm (OR-SO-SANH-PHU): " + json.dumps(st4.get("OR-SO-SANH-PHU", {}).get("actual"), ensure_ascii=False) + "\n")
a("## 8. Strict JSON và hợp đồng\n")
a(H + bang_test("HD-") + "\n")
a("Bộ R3 tương ứng chạy lại trên code R4: " + ", ".join(f"{t} = {st3.get(t, {}).get('status')}" for t in ("KD-HD-MUT", "KD-HD-FUZZ", "KD-HD-VALID", "KD-JSON")) + ".\n")
a("## 9. Mutation\n")
a("### 9.1 Đột biến R4 – lần chạy cuối\n")
a("| ID | File | Mô tả | Test khai báo | Phân loại | Test không PASS |\n|---|---|---|---|---|---|")
for d_ in db["dot_bien"]:
    a(f"| {d_['id']} | {d_['file']} | {d_['mo_ta']} | {', '.join(d_.get('test_khai_bao', []))} | **{d_['phan_loai']}** | {', '.join(d_.get('test_khong_pass', []))} |")
a(f"\nBản gốc trong lần chạy đột biến: {db['goc']['tom_tat']}; bất thường ngoài BLOCKED đã biết: {db['goc']['bat_thuong'] or 'không'}.\n")
a("### 9.2 Lần chạy 1 (giữ nguyên làm bằng chứng) và xử lý\n")
a("| ID | Phân loại lần 1 | Xử lý |\n|---|---|---|")
xl = {"M02": "Đột biến TƯƠNG ĐƯƠNG (hợp đồng buộc NO_DATA có exit_ts_ms = null → ∞ trong cả hai bản) – thay bằng đột biến không tương đương",
      "M07": "Test F02-MA-HONG chỉ đòi chuỗi 'cost_model' → đột biến bỏ kiểm không hữu hạn vẫn bị báo bởi lỗi công thức → SIẾT test đòi đúng lý do",
      "M10": "Chuỗi lý do khai báo sai ('ValueError' không có trong thông điệp) – sửa khai báo, test không đổi",
      "M12": "Đột biến TƯƠNG ĐƯƠNG (True/False < 40 luôn bị bác) – thay bằng bỏ kiểm kiểu n_boot"}
for d_ in db1["dot_bien"]:
    if d_["phan_loai"] != "KILLED_EXPECTED":
        a(f"| {d_['id']} | {d_['phan_loai']} | {xl.get(d_['id'], '—')} |")
if os.path.exists(os.path.join(KQ, "dot_bien_r4_LAN2.json")):
    d2 = J(os.path.join(KQ, "dot_bien_r4_LAN2.json"))
    a(f"\nLần chạy 2 (sau xử lý lần 1, TRƯỚC khi phát hiện BUG-R4-1): {d2['dem']} – lượt này chạy trên bản nháp có BUG-R4-1; giữ làm bằng chứng, thay bằng lần chạy cuối (thêm M14).")
a(f"\n### 9.3 Đột biến mã nguồn R3 (KD-MUT-SRC) trên code R4: {kd.get('status')} – {str(kd.get('actual'))[:400]}\n")
a("## 10. Hồi quy toàn bộ R3\n")
a(f"- Bộ độc lập R3 (109 test, KHÔNG sửa, chạy với PYTHONDONTWRITEBYTECODE=1) trên code R4: {r3['tom_tat']}; R3 gốc: {r3g['tom_tat']}.")
a(f"- Test đổi trạng thái so với R3 gốc: {lech_r3 or 'KHÔNG CÓ'}.")
a(f"- KD-REG-S3 (bộ Stage 3 88 test + bộ gốc 22 + bộ 0.3.9 chạy mới): {st3.get('KD-REG-S3', {}).get('status')} – {str(st3.get('KD-REG-S3', {}).get('actual'))[:300]}")
if os.path.exists(os.path.join(KQ, "r3_day_du_LAN1_REG01_FAIL", "ket_qua_doc_lap.json")):
    l1 = J(os.path.join(KQ, "r3_day_du_LAN1_REG01_FAIL", "ket_qua_doc_lap.json"))
    a(f"- Lượt hồi quy 1 (giữ nguyên làm bằng chứng): {l1['tom_tat']} – KD-REG-S3 FAIL do REG-01 (DUP-02) → BUG-R4-1, đã sửa; bảng trên là lượt chạy lại sau sửa.")
a("- Không test cũ nào bị bỏ, đổi nhẹ hơn hay xóa (FILE_KHONG_DOI.txt chứa SHA của mọi file test cũ, trùng baseline).\n")
a("## 11. Stale output / cách ly\n")
a(f"- Cách ly (`kiem_cach_ly_r4.py`, so TOÀN CÂY với baseline R3): file đổi ngoài phép = {cl['doi_ngoai_phep'] or 'không'}; file mới ngoài phép = {cl['moi_ngoai_phep'] or 'không'}; "
  f"file xóa = {cl['xoa'] or 'không'}; .pyc/__pycache__ = {len(cl['pyc'])}; {cl['khong_doi']}/{cl['tong_baseline']} file baseline không đổi; bản chụp _truoc_r4 trùng R3 = {cl['truoc_r4_khop_r3']}.")
a("- Sự cố môi trường đã ghi nhận và xử lý: lần chạy hồi quy R3 đầu tiên tạo `__pycache__` (tiến trình con không thừa hưởng cờ -B) → hủy lượt đó, xóa bytecode, chạy lại toàn bộ với "
  "PYTHONDONTWRITEBYTECODE=1 (biến môi trường được thừa hưởng). Kết quả báo cáo là của lượt chạy lại.")
a(f"- Độ mới: mọi kết quả có run_id; trình đột biến kiểm mtime ≥ lúc bắt đầu và module_dir của từng lượt; KD-REG-S3 kiểm run_id, mtime, exit code của bộ Stage 3 và yêu cầu bộ 0.3.9 chạy mới "
  f"sau mốc bắt đầu (bộ 0.3.9 chạy mới trong vòng này: mốc {open('/tmp/reg039_batdau.txt').read().strip() if os.path.exists('/tmp/reg039_batdau.txt') else '?'}).\n")
a("## 12. BLOCKED\n")
bl = [k for k in r3["ket_qua"] if k["status"] == "BLOCKED"] + [k for k in r4["ket_qua"] if k["status"] == "BLOCKED"]
a("| Test | Bộ | Lý do |\n|---|---|---|")
for k in bl:
    a(f"| {k['test_id']} | {'R4' if k['test_id'] in st4 else 'R3'} | {str(k['actual'])[:300]} |")
a("\n## 13. NOT TESTED\n")
nt = [k for k in r3["ket_qua"] + r4["ket_qua"] if k["status"] == "NOT TESTED"]
a("| Test | Lý do |\n|---|---|")
for k in nt:
    a(f"| {k['test_id']} | {str(k['actual'])[:300]} |")
a("\nKhông có ENV_ERROR / VALIDATOR_CRASH / WRONG_REASON trong lượt chạy cuối của bộ R4 (xem tóm tắt). Không test nào bị bỏ qua mà không báo.\n")
a("## 14. Rủi ro tồn đọng\n")
for x in ["R4-RR-1 (ASSUMPTION): NO_DATA sau khi vào chiếm vị thế tới ∞ – bảo thủ; nếu owner muốn giải phóng tại thời điểm nến hỏng cần thêm trường thời điểm vào hợp đồng.",
          "R4-RR-2 (FACT): pipeline SYNTH không sinh NO_DATA sau khi vào (PF-MOI-SEED-RIENG đếm 0) → F-01 không đổi số liệu SYNTH hiện có; tác động chỉ xuất hiện với dữ liệu thật có lỗi.",
          "R4-RR-3 (FACT): mã cost_model không bắt đầu 'C-s' (ví dụ 'C-0') vẫn là mã tự do theo hợp đồng 1.2 – không kiểm công thức chi phí.",
          "R4-OBS-1 (PARTIALLY VERIFIED): adapter sinh CREATED → END_NO_EVENT khi thể hiện tạo và biến mất không sự kiện trong cùng nến; máy trạng thái bác; 0/200 seed engine – chờ owner.",
          "Oracle không độc lập đặc tả (O-1). Thứ tự sự kiện suy ra trong nến PARTIALLY VERIFIED. sl_first, MFE/MAE nến thoát chưa kiểm bằng tick.",
          "Gói D0/D1 (dashboard) ghim SHA engine R3: B2/T3 và kiểm kê trường sẽ báo lệch khi dùng engine R4 – cần cập nhật ghim SAU khi R4 được duyệt (không tự làm trong R4).",
          "Thị trường thật: KD-REAL-*, KD-REPLAY-EQ, KD-TV-TOKEN vẫn BLOCKED; KD-REPLAY-FULL NOT TESTED. Không tạo dữ liệu thị trường giả."]:
    a(f"- {x}")
a("\n## 15. Kết luận\n")
dk = dict(F01=all(st4[t]["status"] == "PASS" for t in st4 if t.startswith(("F01", "PF"))), F02=all(st4[t]["status"] == "PASS" for t in st4 if t.startswith("F02")),
          F03=all(st4[t]["status"] == "PASS" for t in st4 if t.startswith("F03")), hoi_quy=not lech_r3 and r3["tom_tat"] == r3g["tom_tat"],
          dot_bien=db["dem"] == {"KILLED_EXPECTED": len(db["dot_bien"])} and kd.get("status") == "PASS", strict=all(st4[t]["status"] == "PASS" for t in st4 if t.startswith("HD")),
          cach_ly=cl["dat"], khong_crash=not any(k["status"] in ("ENV_ERROR", "VALIDATOR_CRASH", "WRONG_REASON", "FAIL") for k in r4["ket_qua"] + r3["ket_qua"]))
a("| Tiêu chí đóng vòng (mục 13) | Đạt |\n|---|---|")
for k, v in dk.items():
    a(f"| {k} | {'ĐẠT' if v else 'KHÔNG ĐẠT'} |")
a("")
a(("**ĐỀ XUẤT: R4 đủ điều kiện ĐÓNG** theo bằng chứng trong môi trường Claude (chưa phải kiểm toán độc lập). " if all(dk.values()) else "**CHƯA ĐỦ ĐIỀU KIỆN ĐÓNG** – xem tiêu chí KHÔNG ĐẠT. ")
  + "Còn 1 mục BLOCKED mới (R4-OBS-1) cần owner quyết định; các mục thị trường thật giữ BLOCKED. Không tuyên bố CLOSED khi ChatGPT chưa kiểm toán lại.")
open(os.path.join(OUT, "ATA_P3_STAGE3_R4_BAO_CAO.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
print("đã ghi", OUT, dk)
