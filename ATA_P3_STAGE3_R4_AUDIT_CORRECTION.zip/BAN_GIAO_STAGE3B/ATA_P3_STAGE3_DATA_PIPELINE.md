# ATA P3 · STAGE 3 · ĐƯỜNG ỐNG DỮ LIỆU (E)

Code nằm ở `shadow_eval/du_lieu.py` và `shadow_eval/pipeline.py`. Chạy như sau (từ thư mục gốc gói):

```
python3 shadow_eval/pipeline.py                                    # 4 ô, không có dữ liệu → BLOCKED đúng bước + kiểm đường ống SYNTH
python3 shadow_eval/pipeline.py --du-lieu XAUUSD=xau_m5.csv:TV BTCUSD=btc_m5.csv:MT5:0
```

Với file MT5, tham số thứ ba là `lech_phut` = giờ máy chủ − UTC, tính bằng phút. Bắt buộc phải có tham số này; công cụ không tự đoán múi giờ.

## Các bước

| # | Bước | Làm gì | Trạng thái hiện tại |
|---|---|---|---|
| 1 | Nhập | TV: cột time là Unix giây/ms hoặc ISO có múi giờ. ISO không múi giờ thì từ chối, trừ khi khai báo UTC. MT5: `<DATE> <TIME>` theo giờ máy chủ, cần lech_phut | Chạy được (DL-01, DL-02) |
| 2 | Kiểm OHLCV | Giá hữu hạn > 0; High ≥ max(O, C); Low ≤ min(O, C); thời gian tròn theo khung; thứ tự; trùng giống hệt hoặc mâu thuẫn; khoảng trống; độ phủ; phân bố phiên UTC; dấu hiệu lệch múi giờ | Chạy được (DL-03…06) |
| 3 | Chuẩn hóa | Sắp xếp, bỏ dòng trùng giống hệt. **Không** sửa giá, **không** lấp khoảng trống | Chạy được (DL-07) |
| 4 | Replay engine | Tính bối cảnh từ OHLCV | **BLOCKED** – chưa hiện thực (xem REPLAY_SCOPE) |
| 5 | EVENTS / SIGNALS | Adapter `chuan_hoa.BoGhi` | Chạy trên SYNTH |
| 6 | Khử trùng | emit_seq | Chạy trên SYNTH |
| 7 | Giả lập | `mo_phong_lenh` R1 (mặc định) / R2 | Chạy trên SYNTH |
| 8 | TRADES + hợp đồng | `hop_dong.kiem_bang` | Chạy trên SYNTH |
| 9 | Chỉ số + phễu | `chi_so` theo từng ô | Chạy trên SYNTH |
| 10 | Báo cáo | `ket_qua_stage3/o_<SYMBOL>_<SETUP>/` | Đã sinh 4 ô |

## Phân loại khoảng trống (lịch GIẢ ĐỊNH, chưa xác minh với lịch Exness)

- **XAUUSD**: một khoảng trống được coi là ứng viên nghỉ cuối tuần nếu nằm trong cửa sổ từ thứ Sáu 20:00 UTC tới thứ Hai 01:00 UTC. Khoảng ≤ 75 phút bắt đầu trong 20:00–23:59 UTC là ứng viên nghỉ hằng ngày. Còn lại là THIẾU DỮ LIỆU.
- **BTCUSD** (giao dịch 24/7): mọi khoảng trống là THIẾU DỮ LIỆU. Có thể do broker bảo trì, nhưng không xác minh được.
- Độ phủ = số nến có / số nến kỳ vọng, sau khi đã trừ các khoảng ứng viên nghỉ.

## So sánh với TradingView

Hàm `du_lieu.phat_hien_cot_tv(header)` cho biết những cột nào thật sự có trong file xuất. Hàm này không giả định file có đủ các plot của Data Window. Giới hạn đã biết (B-1):

- sự kiện SHADOW chỉ được điền vào ô còn trống;
- ô không có mã SU riêng;
- ô không có giá của sự kiện SHADOW.

Vì vậy REPLAY-EQ là BLOCKED.

## Bốn ô (G)

Báo cáo từng ô nằm ở `ket_qua_stage3/o_XAUUSD_SU3/`, `o_XAUUSD_SU5/`, `o_BTCUSD_SU3/`, `o_BTCUSD_SU5/`. Mỗi ô có:

- `ATA_P3_STAGE3_SHADOW_<SYMBOL>_<SETUP>.md`
- `bao_cao_o.json` – các bước của dữ liệu thật, hiện đều BLOCKED
- `synth_kiem_duong_ong.json` – chỉ để kiểm cơ chế

Phễu của SU-3 và SU-5 được tính riêng, không gộp.
