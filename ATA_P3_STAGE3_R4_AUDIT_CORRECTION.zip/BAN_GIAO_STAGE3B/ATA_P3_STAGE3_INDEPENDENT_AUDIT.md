# ATA P3 · STAGE 3 · BÁO CÁO KIỂM TOÁN ĐỘC LẬP (A)

Ngày: 2026-11-20 · Người thực hiện: Claude (bên triển khai) · Phạm vi: các module Stage 3 nằm NGOÀI Pine
Baseline Pine (chỉ đọc, không sửa): 0.3.8 `79793fcf…f8cf13`, 0.3.9 `2184d892…87fdb0`. Cả hai SHA được kiểm lại ở đầu và cuối lượt (test BL-01).

## 1. Cách làm

- Đọc lại từng module, không dựa vào kết quả test cũ.
- Mỗi nghi vấn đều được tái hiện bằng code chạy trên **bản trước khi sửa**. Bản này được giữ nguyên trong `shadow_eval/_truoc_sua/`, có SHA lưu ở `SHA256_TRUOC_SUA.txt`. Script tái hiện là `kiem_toan_stage3/bang_chung_truoc_sua.py`, kết quả ở `kiem_toan_stage3/bang_chung_truoc_sua.json`.
- Mỗi lỗi đã sửa có ít nhất một test mới. Có thêm test đột biến (mutation test – thay hàm mới bằng hàm cũ để xem test có bắt được không, MUT-01…05). Cả năm test đột biến đều chứng minh bộ test mới bắt được lỗi cũ.

Module đã kiểm:

- `shadow_eval/`: hop_dong, mo_phong_lenh, chi_so, kiem_thu_shadow_eval, tao_capsule_stage3
- `kiem_toan039/`: kiem_cach_ly, khung039
- `kiem_toan034a/pine_mini.py`
- `token_budget/mo_hinh_token.py`

## 2. Thang mức độ

- **P0 / CAO**: làm sai kết quả đánh giá hoặc thống kê.
- **TRUNG BÌNH**: làm yếu bằng chứng hoặc kiểm tra.
- **THẤP**: chỉ ảnh hưởng tài liệu hoặc độ bền.
- **QUAN SÁT**: không phải lỗi, nhưng là giới hạn cần biết.

## 3. Danh sách finding

Ghi chú: "trước sửa" nghĩa là file trong `shadow_eval/_truoc_sua/`. Dòng code đều tính trên bản trước sửa.

| ID | Mức | File · vị trí (trước sửa) | Bằng chứng (tái hiện) | Ảnh hưởng | Cách sửa | Test |
|---|---|---|---|---|---|---|
| F1 | P0 | mo_phong_lenh.py:105 `khong_chong` | NO_FILL lúc 1, rồi TP1 lúc 100 và SL lúc 300 → chỉ giữ 1, bỏ 2 | Một lệnh không khớp chặn mọi lệnh sau cùng (symbol, setup) mãi mãi, nên biến thể danh mục thiếu lệnh hàng loạt | Chỉ lệnh đã vào mới chiếm vị thế. NO_FILL/NO_DATA/INVALID vẫn giữ trong đầu ra để đếm. OPEN chiếm vị thế tới hết dữ liệu | PF-01…05, MUT-01 |
| F2 | P0 | mo_phong_lenh.py:93 `khu_trung` | Hai tín hiệu cùng dup_key: giữ bản phát ra sau, vì id băm "0000" < "ffff" | Bản bị giữ khi trùng IP-21 là ngẫu nhiên theo băm, không theo thứ tự engine | Thêm `emit_seq` (thứ tự đẩy vào evS) vào hợp đồng 1.1. Khử trùng theo emit_seq. Thiếu hoặc trùng emit_seq thì báo ValueError | DUP-01…04, MUT-02 |
| F3 | CAO | mo_phong_lenh.py:70 (nhánh tp_first) | Nến chạm cả SL và TP1, biến thể tp_first → MAE = 0 | MAE sai trong phân tích độ nhạy, không nhất quán với nhánh SL | Một quy tắc nến thoát áp dụng cho mọi nhánh (xem docstring). tp_first lấy đủ phía bất lợi, nên MAE ≤ −1 | MM-02, MM-03, MUT-03 |
| F4 | P0 | mo_phong_lenh.py:44–50 (R2) | Open nến kế 2015 > TP1 2010 → ra **TP1 với R = −0,25** | Kết cục mâu thuẫn: "chạm TP" mà vẫn lỗ | R2: Open đạt/vượt TP1 → NO_FILL `GAP_BEYOND_TP` | R1R2-03, MUT-03 |
| F5 | CAO | mo_phong_lenh.py:42, 49 | BUY có SL 2001 > P_ref 2000 → NO_FILL với risk = 1,0 (giá trị giả) | Tín hiệu hỏng bị lẫn vào "không khớp"; risk giả có thể lọt vào tính toán | Outcome INVALID, ghi chú INVALID_RISK / INVALID_SIGNAL / TP_WRONG_SIDE. risk, R, MFE, MAE đều để null | R1R2-07, R1R2-08 |
| F6 | TRUNG BÌNH | mo_phong_lenh.py:41–42 | R2 trigger ở nến cuối → NO_FILL | Thiếu dữ liệu bị coi là thị trường không khớp | Outcome NO_DATA `NO_NEXT_BAR` | R1R2-06 |
| F7 | TRUNG BÌNH | mo_phong_lenh.py (vòng lặp nến) | Nến 3 cách nến 2 hơn 10 giờ → không có trường nào báo | Không phân biệt được nến liền mạch với dữ liệu bị thủng | Thêm `time_gaps` và `max_gap_ms`. max_bars đếm theo nến (đã ghi rõ). Việc phân loại nghỉ thị trường hay thiếu dữ liệu nằm ở du_lieu.py | OT-04, DL-04 |
| F8 | CAO | mo_phong_lenh.py (vòng lặp nến) | Nến High 1990 < Low 2010 → ra OPEN, R = 0,2 | Dữ liệu hỏng tạo ra kết quả trông như hợp lệ | Kiểm nến hỏng và thời gian trùng/lùi → NO_DATA `INVALID_BAR` / `NON_MONOTONIC_TIME` | OT-05, OT-06 |
| F9 | TRUNG BÌNH | chi_so.py:52 | B = 10: dưới = 0, trên = 8 (đối xứng phải là 9). Lệch ở B = 30, 50, 70 | CI 95 % lệch khi 0,025·B không nguyên; dễ hỏng do sai số dấu phẩy động | `phan_vi_doi_xung`: k = ⌊α/2·B⌋ tính bằng số nguyên; dưới = s[k], trên = s[B−1−k]. R được sắp xếp trước khi lấy mẫu | CS-03, CS-05 |
| F10 | P0 | chi_so.py:43 | 3 lệnh thắng → PF = inf, `json.dumps(allow_nan=False)` báo lỗi | JSON không hợp lệ, công cụ đọc sau có thể vỡ hoặc hiểu sai | PF = null kèm `pf_trang_thai` (KHONG_CO_LENH_THUA / KHONG_CO_LENH_THANG_THUA) | CS-02, HD-11, MUT-04 |
| F10b | CAO | chi_so.py:40 | R = 0 bị tính là thua; R = 0,0,+1 → PF = inf | Lệch số lệnh thua và PF | Thắng > 0, thua < 0, hòa vốn tách riêng. Thêm `win_rate_khong_hoa`. Tỷ lệ TP1 vẫn tách riêng | CS-01 |
| F11 | TRUNG BÌNH | chi_so.py:13, 19 | 3 tín hiệu cùng dup_key → `trung` = 0 | Phễu báo sai số trùng IP-21 | Đếm trùng theo dup_key cho từng (symbol, setup). Thêm các tỷ lệ phễu | CS-07, MUT-04 |
| F12 | P0 | hop_dong.py:36 `kiem` | TRADE có NaN, inf, bars_held −3, exit trước entry → **0 lỗi** | Dữ liệu hỏng lọt qua bộ kiểm hợp đồng | Kiểm số hữu hạn, miền giá trị, quy tắc riêng theo outcome, nhất quán R/MFE/MAE/chi phí | HD-02, HD-07, HD-08, MUT-05 |
| F13 | CAO | hop_dong.py | trigger_ts lệch 1 ngày so với trigger_ts_ms; BUY có SL nằm trên giá → 0 lỗi | Lệch thời gian và hình học sai không bị phát hiện | Kiểm ts ↔ ts_ms (cả trigger_ts), ms tròn phút, hình học SL/TP theo chiều, rr, dup_key | HD-04, HD-06 |
| F14 | TRUNG BÌNH | hop_dong.py | trigger_ts "2026-13-45T99:99:99Z" → 0 lỗi | Ngày không tồn tại vẫn được chấp nhận | Phân tích lịch thật bằng strptime | HD-04 |
| F15 | P0 | hop_dong.py (thiếu hẳn) | Chỉ có kiểm từng bản ghi | Không phát hiện trùng ID, sai thứ tự, gãy liên kết EVENTS↔SIGNALS↔TRADES | `kiem_bang()`: trùng ID/emit_seq, thứ tự thời gian, vòng đời (CREATED đầu, không có sự kiện sau sự kiện kết thúc), liên kết, R theo chiều tín hiệu, giá thoát SL/TP | HD-09, HD-10 |
| F16 | TRUNG BÌNH | hop_dong.py (schema 1.0) | TRADES bắt buộc risk/R > 0 cả khi không vào lệnh, nên bản cũ phải ghi 0,0 hoặc 1e-12 | Các giá trị 0 giả lẫn vào dữ liệu | Schema 1.1: ngoại lệ rõ cho OPEN / NO_FILL / NO_DATA / INVALID; fill_note bắt buộc khi không vào | HD-01, HD-07 |
| F17 | TRUNG BÌNH | kiem_thu_shadow_eval.py:175 | E2E cũ gán `trigger_ts="2026-01-01T00:00:00Z"` cố định cho mọi tín hiệu | Test E2E cũ PASS trên dữ liệu không nhất quán | Không sửa test cũ. Phân loại assertion là lỗi thời; thay bằng E2E-01, E2E-02, RP-03, RP-04 dùng adapter thật | REG-01 |
| F18 | THẤP | kiem_thu_shadow_eval.py `rec()` | Kết quả thiếu version, thời gian chạy, hash, nguồn test | Khó truy vết | Bộ mới `kiem_thu_stage3.py` ghi đủ metadata cho mỗi test | toàn bộ |
| F19 | THẤP | gói ZIP Stage 3 trước (`SHA256SUMS.txt`) | Có dòng tự tham chiếu `e3b0c442…` (băm của file rỗng) | Kiểm tổng `sha256sum -c` báo FAILED một dòng | Gói mới loại SHA256SUMS khỏi chính nó; capsule ghi rõ | đóng gói (mục I) |
| F20 | CAO (về kết luận) | mo_hinh_token.py:35 | Tên "sec8" và hệ số `7×f_struct` giả định 8 bản f_struct. Thực tế chỉ **4** lệnh request.security gọi f_struct (dòng 1003–1006); 4 lệnh còn lại (1716–1719) chỉ lấy mảng giá | Mô hình 1 tham số khớp được nhiều công thức khác nhau. Các con số 97.519 / 98.069 và dư địa 2.737 / 2.187 **không phải** token thật | Token Gate mới chạy họ mô hình sec_k0…k7 + full_inline + once + lex, báo khoảng và bất định. Không dùng một con số đơn lẻ | TG-02, TG-04 |
| F21 | THẤP | báo cáo Stage 3 trước (tóm tắt) | Từng ghi "lastMssM15 được đọc". grep 0.3.9: chỉ khai báo (dòng 1124) và gán (1133, 2680), không có lần đọc | Nhận định sai trong tài liệu trước | Token Gate liệt kê biến không đọc là **ứng viên**, kèm dòng; không tự xóa | TG-01 |
| F25 | TRUNG BÌNH (code mới của lượt này, tự phát hiện khi rà báo cáo ô) | pipeline.py `chay_synth` (bản đầu của lượt này) | Khi gộp 40 seed (các lượt replay độc lập dùng cùng mốc thời gian SYNTH): (a) dup_key trùng giữa các seed → phễu báo 'trùng' 28, trong khi số bị khử trùng thật là 9; (b) lọc danh mục chạy chung → một lệnh OPEN ở seed trước chặn lệnh ở mọi seed sau (bỏ 17/18, đúng ra là 5) | Số liệu phễu và biến thể danh mục của SYNTH sai | Thêm tiền tố seed vào dup_key; chạy khong_chong riêng từng seed | E2E-01 (phễu 'trùng' = bo_trung; số bỏ do chồng lấn = tổng lọc độc lập từng seed) |
| F22 | QUAN SÁT | pine_mini.py `num_op` | Phép `%` dùng ngữ nghĩa Python. Với số âm có thể khác Pine (−7 % 3: Python = 2) | Không ảnh hưởng hiện tại: không khối SHADOW/S1 nào dùng `%`. 8 chỗ dùng `%` trong 0.3.9 đều với số không âm (dòng 1195–1199, 1378) | Ghi vào phạm vi replay (UNSUPPORTED cho `%` với số âm) | — |
| F23 | QUAN SÁT | kiem_cach_ly.py `PIPE` | Driver dùng chỉ số sổ đơn giản (chS/chE = ứng viên đầu tiên); f_ledger không chạy trong PIPE | Kết quả ô Data Window trong PIPE không đại diện cho sổ thật; khối SHADOW thì không đọc sổ | Ghi rõ PARTIALLY VERIFIED trong REPLAY_SCOPE | RP-02 |
| F24 | QUAN SÁT | khung039.Ip39 | Toán tử lịch sử chỉ có cho open/high/low/close/time; không có request.security, ta.*, lịch sử biến người dùng | Không replay được toàn script từ OHLCV | REPLAY_SCOPE: NOT IMPLEMENTED / UNSUPPORTED | E2E-03 |

## 4. Finding nằm trong Pine baseline (chỉ ghi nhận, KHÔNG sửa)

| ID | File · dòng (0.3.9) | Bằng chứng | Ảnh hưởng | Đề xuất (chủ dự án quyết) |
|---|---|---|---|---|
| B-1 | 3624–3626, 3785, 3857 | Sự kiện SHADOW chỉ được điền vào ô Data Window còn trống sau sự kiện actionable (tối đa 3 ô). Ô không có mã SU-3/SU-5 riêng ("MÃ LOẠI SETUP" chỉ dành cho tín hiệu chính). Ô không có P_ref/SL/TP1 của sự kiện SHADOW | File CSV xuất từ TradingView **không thể** tái lập đầy đủ EVENTS/SIGNALS, nên REPLAY-EQ qua CSV tối đa chỉ là một phần | Đúng với thiết kế K.5. Nếu cần REPLAY-EQ đầy đủ thì phải có kênh xuất riêng (quyết định thuộc chủ dự án, đụng tới token) |
| B-2 | 1795, 1787 | f_srcList (196 token) không được gọi ở đâu. f_srcPush (84 token) chỉ được f_srcList gọi | Mã chết; tốn token biên dịch | Không tự xóa (theo chỉ thị). Ứng viên cho đợt giảm token nếu chủ dự án đồng ý |
| B-3 | 1124/1133/2680 và các biến lastEv*, lastMss*, lotMax (1170), md4Swing (2775), md5LastBix, pslLv, pslRk, pubLv, pubRk | Có ghi nhưng không có lần đọc (17 ứng viên, xem token_gate.json) | Tốn token; không ảnh hưởng logic | Cần xác nhận thủ công trước khi gỡ |
| B-4 | 1870–1889 (type SH) | Các thể hiện SU-3 trùng khóa (IP-21) có cùng (su, d, bm, bs). Sự kiện evS không mang định danh thể hiện | Adapter phải ghép sự kiện theo khóa. 249 lần ghép mơ hồ trên 40 seed SYNTH (các ứng viên giống hệt nhau về khóa và về hệ quả) | IP-21 vẫn mở; khử trùng cấp tín hiệu (dup_key) đã xử lý phía đánh giá |

## 5. Kết luận kiểm toán

- Có **22 finding lỗi**: 21 lỗi trong code, test, gói hoặc mô hình (F1–F20 và F10b), cộng 1 lỗi tài liệu (F21). Trong đó có 6 lỗi P0: F1, F2, F4, F10, F12, F15.
- Có thêm 1 lỗi trong code mới viết ở lượt này (F25). Lỗi này được tự phát hiện khi rà báo cáo ô và đã sửa.
- Có thêm 3 quan sát về công cụ (F22–F24), là giới hạn phạm vi chứ không phải lỗi.
- Tất cả 22 lỗi đã được xử lý trong module ngoài Pine hoặc trong tài liệu và gói. Mỗi lỗi đều có test mới; với các lỗi chính còn có test đột biến chứng minh bộ test bắt được bản cũ.
- Có 4 quan sát về Pine baseline (B-1…B-4). Chỉ ghi nhận, không sửa.
- Không có thay đổi nào với Pine 0.3.8 hoặc 0.3.9.
