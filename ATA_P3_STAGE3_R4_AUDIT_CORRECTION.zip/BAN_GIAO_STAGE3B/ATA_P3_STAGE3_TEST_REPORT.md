# ATA P3 · STAGE 3 · BÁO CÁO KIỂM THỬ (C)

Sinh tự động từ `ket_qua_stage3/ket_qua_kiem_thu.json` (lần chạy này, không dùng kết quả cũ). Python 3.13.18, 48.2 giây.

**Tổng 88 test: PASS 79 · FAIL 0 · BLOCKED 6 · NOT TESTED 3** (đếm riêng từng loại; có FAIL → mã thoát 1).

Baseline sau lượt chạy: 0.3.8 `79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13` · 0.3.9 `2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0`

Phiên bản module (SHA-256, 12 ký tự đầu): hop_dong `be43889860b5`, mo_phong_lenh `7ea5e90c257a`, chi_so `df3f7c262e47`, du_lieu `f192ec6842e8`, chuan_hoa `44db33b96aa4`, pipeline `98c45390cd7e`, cong_token `5cdc750a3d9a`, kiem_thu_stage3 `2520ffc44121`

Lệnh tái lập: `python3 shadow_eval/kiem_thu_stage3.py` (từ thư mục gốc gói). Metadata đầy đủ của từng test (input, expected, actual, evidence, nguồn, version, thời điểm, hash) nằm trong JSON/CSV.

## Giả lập R1/R2 – PASS 10

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| R1R2-01 | PASS | R1 BUY chạm TP1: vào Close nến trigger, thoát TP1, R = 2,0; SELL ảnh gương cho kết quả y hệt | {"outcome": "TP1", "r_gross": 2.0, "mfe_r": 2.0, "mae_r": -0.2, "bars_held": 2} | 0.6 | d459d1d9765be42d |
| R1R2-02 | PASS | R2: Open nến kế VƯỢT SL (và đúng bằng SL) → NO_FILL GAP_BEYOND_SL; risk/R/MFE/MAE/exit = null | [["NO_FILL", "GAP_BEYOND_SL", null], ["NO_FILL", "GAP_BEYOND_SL", null]] | 0.2 | 1b386d540f1c3b58 |
| R1R2-03 | PASS | R2: Open nến kế ĐÃ ĐẠT/VƯỢT TP1 → NO_FILL GAP_BEYOND_TP (bản cũ ra TP1 với R âm – F4) | [["NO_FILL", "GAP_BEYOND_TP"], ["NO_FILL", "GAP_BEYOND_TP"]] | 0.1 | 60aba114b120f8da |
| R1R2-04 | PASS | R2: Open nằm GIỮA P_ref và SL → khớp tại Open, rủi ro = Open − SL (nhỏ hơn), R tính theo rủi ro mới | {"outcome": "TP1", "risk": 2.0, "r_gross": 6.5, "entry_price": 1997.0, "bars_held": 2} | 0.2 | 6a9c76bdd4c69fdc |
| R1R2-05 | PASS | TP1 = null: không bao giờ ra TP1 (R1 và R2); kết thúc SL / TIMEOUT / OPEN | ["SL", "TIMEOUT", "OPEN", 10.0] | 0.2 | ee113b8f4a7caaf4 |
| R1R2-06 | PASS | R2 không có nến kế → NO_DATA NO_NEXT_BAR (thiếu dữ liệu, KHÔNG gộp với NO_FILL – F6) | ["NO_DATA", "NO_NEXT_BAR"] | 0.1 | 8dc3a9e146aefd6b |
| R1R2-07 | PASS | Rủi ro không hợp lệ (SL sai phía, SL = P_ref) → INVALID INVALID_RISK, risk = null (bản cũ: NO_FILL với risk giả – F5) | [["INVALID", "INVALID_RISK"], ["INVALID", "INVALID_RISK"], ["INVALID", "INVALID_RISK"]] | 0.2 | 0aa051261d061867 |
| R1R2-08 | PASS | Tín hiệu hỏng (dir 0, SL NaN, P_ref ∞, TP1 sai phía) → INVALID với lý do; không ngoại lệ | ["INVALID_SIGNAL", "INVALID_SIGNAL", "INVALID_SIGNAL", "TP_WRONG_SIDE"] | 0.1 | 3d4da5db28cedf98 |
| R1R2-09 | PASS | R2: nến vào được đánh giá High/Low sau Open – chạm TP1 ngay nến vào → TP1, giữ 1 nến | {"outcome": "TP1", "bars_held": 1, "r_gross": 1.5} | 0.1 | aca6dba026e880d8 |
| R1R2-10 | PASS | R1: Open nến đầu tiên sau trigger đã vượt SL → thoát tại Open (R < −1), gap_exit; vượt TP1 → thoát tại Open (R > R_TP1) | [["SL", -2.0], ["TP1", 3.0]] | 0.2 | 6b7423fe9b57709a |

## OPEN/TIMEOUT – PASS 6

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| OT-01 | PASS | Biên max_bars: chạm TP1 đúng ở nến thứ max_bars → TP1 (giữ = max_bars); chạm ở nến max_bars+1 → TIMEOUT tại nến max_bars | [["TP1", 5], ["TIMEOUT", 5, 0.1]] | 0.2 | a86f6bd98462bdf2 |
| OT-02 | PASS | Dữ liệu sau trigger có đúng max_bars nến → TIMEOUT; max_bars − 1 nến → OPEN (giữ max_bars − 1, exit = null); max_bars + 1 → TIMEOUT | [["TIMEOUT", 4], ["OPEN", 3], ["TIMEOUT", 4]] | 0.2 | a3eef39817b2b7d7 |
| OT-03 | PASS | Trigger ở nến cuối (R1) → OPEN, giữ 0, R = 0; 1 nến sau với max_bars 1 → TIMEOUT; với max_bars 2 → OPEN | [["OPEN", 0], ["TIMEOUT", 1], ["OPEN", 1]] | 0.2 | e5d08525e3375800 |
| OT-04 | PASS | Thiếu nến (khoảng trống thời gian) KHÁC gap giá: khoảng trống thời gian → đếm time_gaps, max_gap_ms, KHÔNG đổi kết cục; gap giá không có khoảng thời gian → gap_exit, time_gaps 0 | {"lien": ["TP1", 0], "khoang": ["TP1", 1, 36300000], "gap_gia": [true, 0]} | 0.3 | 90094e85b0f7c7ae |
| OT-05 | PASS | Nến hỏng TRONG cửa sổ (High < Low, giá NaN, giá ≤ 0) → NO_DATA INVALID_BAR; nến hỏng SAU nến thoát → không ảnh hưởng (F8) | [["NO_DATA", "NO_DATA", "NO_DATA"], "TP1"] | 2.3 | bfcbfd1bb8ff06f2 |
| OT-06 | PASS | Thời gian trùng hoặc lùi trong cửa sổ → NO_DATA NON_MONOTONIC_TIME | ["NON_MONOTONIC_TIME", "NON_MONOTONIC_TIME"] | 0.2 | a3572b0c061096d6 |

## MFE/MAE – PASS 6

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| MM-01 | PASS | Quy tắc nến thoát bảo thủ: thoát SL → phía có lợi của nến đó không tính, MAE = −1; thoát TP1 → MFE chặn tại TP1, phía bất lợi tính đủ | [[0.6, -1.0], [2.0, -0.6]] | 0.2 | 3582fc8cf25d5e52 |
| MM-02 | PASS | Xung đột cùng nến (chạm cả SL và TP1): sl_first → SL, MFE không lấy nến đó; tp_first → TP1 nhưng MAE ≤ −1 vì giá đã chạm SL (bản cũ MAE = 0 – F3) | {"sl_first": ["SL", 0.0, -1.0], "tp_first": ["TP1", 2.0, -1.2]} | 0.3 | 3184947c2bdcaa43 |
| MM-03 | PASS | Thuộc tính trên 3.000 đường ngẫu nhiên (có gap, TP1 null, R1/R2, sl_first/tp_first, max_bars 1…40, chi phí): mọi bản ghi qua bộ kiểm TRADES; MFE ≥ 0 ≥ MAE; MAE ≤ R ≤ MFE; SL không gap = −1 | {"vi_pham": 0, "mau": []} | 643.7 | 111c65db228eb34e |
| MM-04 | PASS | Đối xứng BUY/SELL: 600 đường và ảnh gương (giá → 4000 − giá), R1 và R2 → cùng kết cục, R, MFE, MAE, thời gian giữ, ghi chú | khác 0 | 99.1 | e8f15210b5afc3a7 |
| MM-05 | PASS | Không nhìn trước: (a) High/Low nến trigger không dùng ở R1; (b) 400 đường: thay mọi nến SAU nến thoát bằng giá vô lý → kết quả y hệt | {"a": "TIMEOUT", "b_khac": 0} | 111.4 | 12bf3c029b4578b4 |
| MM-06 | PASS | Chi phí: r_net = r_gross − (spread + phí + 2×trượt giá)/rủi ro | 1.9 | 0.2 | 92867de5ad73f19b |

## Lọc danh mục – PASS 5

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| PF-01 | PASS | NO_FILL (exit null) KHÔNG chặn khóa (symbol, setup) – bản cũ chặn vĩnh viễn (F1) | {"giu": [[1, "NO_FILL"], [100, "TP1"], [300, "SL"]], "bo": 0} | 0.2 | f5503aec67d2998d |
| PF-02 | PASS | NO_DATA / INVALID không chiếm vị thế, vẫn có mặt trong đầu ra (để đếm) | [["NO_DATA", "INVALID", "TP1"], 0] | 0.1 | 3c2561fd2e1ffee7 |
| PF-03 | PASS | OPEN chiếm vị thế tới hết dữ liệu → chặn mọi lệnh sau cùng khóa, không chặn khóa khác | [[["SU5", 10], ["SU3", 50]], 1] | 0.1 | 45c383ce82ec0685 |
| PF-04 | PASS | Biên thời gian: vào tại đúng thời điểm thoát của lệnh trước (cùng nến) → bỏ (ASSUMPTION bảo thủ); vào sau → giữ | [[1, 11], 1] | 0.1 | 90e2c5d9f137360c |
| PF-05 | PASS | Không chặn chéo SU-3/SU-5 hay XAUUSD/BTCUSD; cùng entry_ts xếp theo emit_seq | [[["BTCUSD", "SU5", 0], ["XAUUSD", "SU3", 0], ["BTCUSD", "SU3", 0], ["XAUUSD", "SU5", 3]], 1] | 0.1 | afa4c05b692e94e7 |

## Khử trùng – PASS 4

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| DUP-01 | PASS | Giữ bản PHÁT RA TRƯỚC theo emit_seq, không theo băm signal_id (F2) | [[[1, "ffff"]], 1] | 0.1 | ae827b18853f1485 |
| DUP-02 | PASS | Thiếu emit_seq hoặc emit_seq trùng → ValueError (không đoán thứ tự) | ["ValueError", "ValueError"] | 0.1 | ef06fb6049906de2 |
| DUP-03 | PASS | Không phụ thuộc thứ tự đầu vào: 200 lần xáo trộn → cùng tập giữ, đầu ra theo emit_seq | 200/200 | 2.8 | 547feb25277ff4ec |
| DUP-04 | PASS | Trên replay thật của khối Pine (SYNTH, 40 seed): với mọi dup_key có > 1 tín hiệu, bản giữ là emit_seq nhỏ nhất; số bị loại = tổng (n−1) | {"nhom_trung": 9, "loai": 9, "sai": 0, "ghi_chu": "SYNTH ngẫu nhiên có thể không sinh trùng – DUP-01…03 kiểm cơ chế"} | 5858.5 | f75b7e73f5d30f78 |

## Hợp đồng dữ liệu – PASS 11

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| HD-01 | PASS | Bộ bản ghi đúng (EVENTS, SIGNALS, TRADES đủ ngoại lệ OPEN/NO_FILL/NO_DATA/INVALID) → 0 lỗi bản ghi và cấp bảng | [] | 3.1 | c82a3c903a5ab7b5 |
| HD-02 | PASS | Mọi trường số thực của 3 bảng: NaN, +∞, −∞ → bị báo 'không hữu hạn' (F12) | {"so_ca": 39, "lot": []} | 0.8 | c2db38895830c67a |
| HD-03 | PASS | Kiểu sai (bool thay int/float, chuỗi thay số, số thay chuỗi), thiếu trường bắt buộc, trường lạ → bị báo; null ở trường tùy chọn → hợp lệ | {"so_loi": [1, 1, 2, 1, 1, 1], "null_tuy_chon": []} | 0.3 | 45e1d0556e892f48 |
| HD-04 | PASS | Thời gian: sai định dạng, ngày không tồn tại, ts ≠ ts_ms, trigger_ts ≠ trigger_ts_ms (F13/F14), ms không tròn phút, ms âm → bị báo | [["ts sai định dạng"], ["ts không phải ngày giờ hợp lệ"], ["ts ≠ ts_ms (2026-01-02T03:05:00Z vs 2026-01-02T03:10:00Z)"], ["trigger_ts ≠ trigger_ts_ms (2026-01-01T00:00:00Z vs 2026-01-02T03:20:00Z)"], ["ts ≠ ts_ms (2026-0… | 0.3 | 7736c39eca6b54a1 |
| HD-05 | PASS | Danh mục và miền: symbol, setup, source, event_type, outcome, mode, dir, state 0…17, reason 0…16, schema_version | [1, 1, 1, 1, 1, 1, 1, 1, 1, 1] | 0.4 | 07139797b30e33cc |
| HD-06 | PASS | Hình học SIGNAL: SL sai phía, TP1 sai phía, rr sai, reason ngoài 16/8/15/14/9/1/2, dup_key không khớp; SELL đúng → hợp lệ | {"loi": ["hình học: SL không nằm phía rủi ro của P_ref", "hình học: TP1 không nằm phía lợi nhuận của P_ref", "rr ≠ /TP1 − P_ref/ / /P_ref − SL/", "reason của SIGNAL ngoài 16/8/15/14/9/1/2", "dup_key không khớp symbol/set… | 0.3 | 1cf413ac23c199de |
| HD-07 | PASS | Ngoại lệ TRADES: NO_FILL có risk ≠ null / thiếu fill_note / bars_held ≠ 0; OPEN có exit; lệnh đóng thiếu exit; lệnh đóng có fill_note → bị báo | [["NO_FILL: risk phải null"], ["NO_FILL: fill_note thiếu/ngoài danh sách"], ["NO_FILL: bars_held phải 0"], ["OPEN: exit phải null"], ["TP1: thiếu exit"], ["TP1: fill_note phải null"]] | 0.2 | c95597e27465a318 |
| HD-08 | PASS | Nhất quán R trong TRADE: R ngoài [MAE, MFE], r_net > r_gross, SL không gap R ≠ −1, /R/×risk ≠ /exit − entry/, exit trước entry, bars_held < 1, MFE < 0, MAE > 0, risk ≤ 0 | [["r_gross ngoài [mae_r, mfe_r]"], ["r_net > r_gross (chi phí âm)"], ["/r_gross/×risk ≠ /exit − entry/"], ["/r_gross/×risk ≠ /exit − entry/"], ["exit_ts_ms < entry_ts_ms"], ["TP1: bars_held < 1"], ["mfe_r < 0"], ["mae_r … | 0.3 | a578edd8716a28e9 |
| HD-09 | PASS | Kiểm cấp bảng (F15): trùng event_id / signal_id / emit_seq, emit_seq ngược thời gian, sự kiện đầu ≠ CREATED, sự kiện sau kết thúc, SIGNAL không có setup, trigger trước CREATED, thiếu sự kiện TRIGGER, TRADE không có SIGNAL, TRADE cho tín hiệu bị bỏ, R1 vào sai nến, risk ≠ (entry − SL)×dir, R sai chiều, SL thoát sai giá, TP1 khi tín hiệu không TP1, signal_id không tái lập | ["EVENTS: trùng event_id", "SIGNALS: trùng signal_id", "EVENTS: trùng emit_seq", "EVENTS: emit_seq 1 có ts_ms nhỏ hơn emit_seq 0", "EVENTS aaaa: sự kiện đầu không phải CREATED", "EVENTS aaaa: có sự kiện sau sự kiện kết t… | 3.2 | 4880215f75a7ad8a |
| HD-10 | PASS | Đột biến ngẫu nhiên trên đầu ra replay thật (SYNTH): 300 lần đổi 1 trường quan trọng (ts_ms, emit_seq, setup_id, dir, sl, p_ref, reason, event_type, risk, r_gross, exit_price) → bộ kiểm bắt được | {"ty_le_bat": 0.9933, "lot": [["E", "emit_seq"], ["E", "emit_seq"]]} | 766.0 | 2b315108cad79fb7 |
| HD-11 | PASS | JSON chuẩn: mọi đầu ra pipeline SYNTH (sự kiện, tín hiệu, lệnh, chỉ số) ghi được với allow_nan=False (không NaN/Infinity) | {"su_kien": 381, "lenh": 9} | 1561.9 | 90cd634edc77e88d |

## Chỉ số – PASS 7

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| CS-01 | PASS | Định nghĩa: thắng r_net > 0, thua < 0, hòa vốn = 0 TÁCH RIÊNG; win_rate = thắng/đóng; win_rate_khong_hoa = thắng/(thắng+thua); tỷ lệ TP1 là tỷ lệ KẾT CỤC (TP1 sau chi phí âm vẫn là TP1) | {"dong": 5, "thang": 2, "thua": 2, "hoa_von": 1, "win_rate": 0.4, "win_rate_khong_hoa": 0.5, "ty_le_tp1": 0.4, "net_r": 1.45, "profit_factor": 2.380952380952381} | 3.3 | 990cbb72c128edc3 |
| CS-02 | PASS | Profit factor biên (F10): không có thua → null + 'KHONG_CO_LENH_THUA'; chỉ hòa vốn → null + 'KHONG_CO_LENH_THANG_THUA'; chỉ thua → 0,0; JSON allow_nan=False ghi được | [[null, "KHONG_CO_LENH_THUA"], [null, "KHONG_CO_LENH_THANG_THUA"], [0.0, "OK"]] | 0.3 | 41feeffa2a81e94e |
| CS-03 | PASS | Phân vị bootstrap đối xứng (F9): với B = 10, 30, 50, 70, 999, 2000 chỉ số trên = B − 1 − chỉ số dưới, dưới = ⌊0,025·B⌋ | {"10": [0, 9], "30": [0, 29], "50": [1, 48], "70": [1, 68], "999": [24, 974], "2000": [50, 1949]} | 0.2 | 80d18cdd4de50aa4 |
| CS-04 | PASS | Biên mẫu: n = 0 (chỉ OPEN) → chỉ số null, CI null; n = 1 → CI null 'N_NHO_HON_2'; mọi R bằng nhau → CI suy biến [r, r]; ngoại lai 1 lệnh +50R → CI chứa expectancy, PF hữu hạn | {"n0": [0, null], "n1": "N_NHO_HON_2", "bang": [1.5, 1.5], "ngoai_lai": [0.7, [-1.0, 4.1], 1.7241379310344827]} | 11.4 | 7108cf1ab98a9e06 |
| CS-05 | PASS | Seed xác định và không phụ thuộc thứ tự: chạy 2 lần → CI y hệt; xáo trộn thứ tự lệnh 20 lần → CI y hệt | {"ci": [0.45015, 1.0637750000000001], "xao_tron_giong": 20} | 360.4 | a5cc6ac851707ea5 |
| CS-06 | PASS | Độ phủ CI bootstrap (kiểm hợp lý, giả định i.i.d.): 120 mẫu n = 60 từ phân phối có kỳ vọng đã biết, B = 400 → tỷ lệ CI chứa kỳ vọng thật trong [0,85; 0,99] | {"do_phu": 0.933} | 542.1 | 0647bdd0d2a27ced |
| CS-07 | PASS | Phễu theo (symbol, setup) riêng: tạo, ARMED, VOID, hết hạn, gap bỏ, kết thúc không sự kiện, trigger, đạt S1, bỏ quyền, bỏ khác, TRÙNG (F11) và các tỷ lệ | {"SU3": {"tao": 2, "armed": 1, "void": 1, "het_han": 1, "gap_bo": 0, "ket_thuc_khong_su_kien": 1, "trigger": 3, "s1_dat": 1, "bo_quyen": 1, "bo_khac": 1, "trung": 2, "ty_le_armed": 0.5, "ty_le_void": 0.5, "ty_le_het_han"… | 0.4 | 2e9b40d4e8297747 |

## Replay – PASS 5

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| RP-01 | PASS | Replay xác định: cùng seed chạy 2 lần (2 tiến trình Python riêng) → băm EVENTS/SIGNALS/nến y hệt (10 seed) | {"giong": 10, "mau": "2d26244c2a69f0da"} | 3220.0 | 8a0cd2b2b929af3a |
| RP-02 | PASS | Adapter KHÔNG can thiệp engine: chạy PIPE có và không có bộ ghi → đầu ra mọi nến (sự kiện, trigger, vùng, ô Data Window) y hệt; số sự kiện evS thô = số sự kiện engine trong EVENTS | {"khac_dau_ra": 0, "lech_so_su_kien": 0} | 4689.9 | 0dce8aa9a4972f8c |
| RP-03 | PASS | EVENTS/SIGNALS do adapter tạo qua bộ kiểm cấp bảng cho 40 seed SYNTH (vòng đời, liên kết, thứ tự, emit_seq) | {"su_kien": 2755, "tin_hieu": 97, "ghep_mo_ho_IP21": 249, "loi": []} | 6418.0 | b6abd63cfd6cc8ed |
| RP-04 | PASS | Kịch bản SU-3 có định hướng (dữ liệu S3-11): vòng đời CREATED → STEP → ARMED → TRIGGER 17/16; SIGNAL P_ref 2005,2, SL 1991,4 (= min(2001,0; 1993 − 0,2×8)); qua hợp đồng; giả lập ra lệnh hợp lệ | {"vong_doi": {"89d5a4292ea83f72": ["CREATED", "STEP", "ARMED", "TRIGGER"], "9f9b4de84b08536a": ["CREATED", "END_NO_EVENT"]}, "tin_hieu": [[2005.2, 1991.4, 2040.0, 16]], "lenh": [["OPEN", 5]], "loi": []} | 73.9 | 14aa1e64a84e5db0 |
| RP-05 | PASS | emit_seq tăng nghiêm ngặt theo thứ tự phát, thời gian không giảm; event_id duy nhất kể cả khi thể hiện trùng khóa (IP-21) | vi phạm 0 | 2980.1 | 55ea00a2d2230a27 |

## Đầu-cuối (SYNTH) – PASS 2

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| E2E-01 | PASS | Ô XAUUSD-SU5 SYNTH: replay khối Pine nguyên văn → EVENTS/SIGNALS → khử trùng emit_seq → giả lập R1 → TRADES → kiểm cấp bảng → chỉ số + phễu; phễu 'trùng' = số bị khử trùng (không phải hiệu quả chiến lược) | {"su_kien": 1462, "tin_hieu": 97, "lenh": 18, "loi": [], "phieu": {"tao": 560, "armed": 197, "trigger": 97, "s1_dat": 18, "trung": 9}, "bo_trung": 9, "bo_chong_lan": 5} | 5965.1 | 5d9ee4fa7053b432 |
| E2E-02 | PASS | Ô SU-3 trên kịch bản có định hướng: chuỗi đầy đủ tới TRADES + chỉ số; ô SU-3 SYNTH ngẫu nhiên được chạy và báo 0 trigger (không bịa) | {"lenh_dinh_huong": [["OPEN", 0.1666666666666639]], "ngau_nhien": {"su_kien": 1293, "tin_hieu": 0}} | 5741.2 | 65d556ea2da33647 |

## Đầu-cuối (thật) – PASS 1

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| E2E-03 | PASS | 4 ô dữ liệu thật khi KHÔNG có file: bước 1–9 đều BLOCKED với lý do; không bước nào PASS giả; bước 4 nêu rõ replay toàn script chưa hiện thực | {"XAUUSD-SU3": ["BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED"], "XAUUSD-SU5": ["BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "… | 0.2 | c45b05d8d545bb8d |

## Đường ống dữ liệu – PASS 9

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| DL-01 | PASS | Nhập TradingView: Unix giây, ISO có múi giờ (+07:00 → đổi về UTC), ISO KHÔNG múi giờ → báo lỗi (không đoán) trừ khi khai báo UTC | {"unix": [1767571200000], "iso_tz": [1767571200000], "khong_tz_loi": 3} | 0.5 | 6dade2d3b6761e82 |
| DL-02 | PASS | Nhập MT5 (tab, <DATE> <TIME>, giờ máy chủ): lech_phut = 120 → trừ 2 giờ về UTC; thiếu lech_phut → từ chối | {"utc": [1767571200000, 1767571500000], "thieu": ["MT5: thiếu lech_phut (giờ máy chủ − UTC) – không đoán múi giờ"]} | 0.5 | c21a470d92b0f130 |
| DL-03 | PASS | Kiểm OHLCV: nến hỏng, lệch khung, trùng mâu thuẫn → FAIL; trùng giống hệt + đảo thứ tự → WARN; dữ liệu sạch → PASS | ["FAIL", "FAIL", "FAIL", "WARN", "PASS"] | 0.7 | 8f35f19c6018efc9 |
| DL-04 | PASS | Phân loại khoảng trống (lịch GIẢ ĐỊNH): XAU nghỉ cuối tuần thứ Sáu 21:00 → Chủ nhật 23:00 UTC = ứng viên nghỉ; XAU nghỉ 1 giờ lúc 21:00 = ứng viên nghỉ hằng ngày; XAU thiếu 30 phút giữa phiên = THIẾU; BTC cuối tuần = THIẾU | ["NGHI_CUOI_TUAN_UNG_VIEN", "NGHI_HANG_NGAY_UNG_VIEN", "THIEU_DU_LIEU", "THIEU_DU_LIEU"] | 0.2 | 973c08f99be91d85 |
| DL-05 | PASS | Độ phủ và phiên: tuần XAU đầy đủ theo lịch giả định → độ phủ 1,0, 0 nến THIẾU; bỏ 10 nến giữa phiên → THIẾU 10, độ phủ giảm đúng; phân bố phiên UTC có đủ 4 nhóm | {"day_du": [1.0, 0, 636], "thieu": [0.992816, 10], "phien": {"A_CHAU": 432, "LONDON": 360, "NEW_YORK": 480, "CUOI_NGAY": 120}} | 6.0 | e054385af53d8b52 |
| DL-06 | PASS | Phát hiện lệch múi giờ: cùng tuần XAU bị dịch +5 giờ (khai nhầm múi giờ) → cảnh báo khoảng nghỉ ≥ 24 giờ không rơi vào cuối tuần UTC | {"dung": [], "lech": ["1 khoảng nghỉ ≥ 24 giờ không rơi vào cuối tuần UTC – nghi lệch múi giờ hoặc thiếu dữ liệu", "636 nến THIEU_DU_LIEU"]} | 7.3 | 0dd93fb029623d61 |
| DL-07 | PASS | Chuẩn hóa: sắp xếp, bỏ dòng trùng giống hệt, KHÔNG sửa giá, KHÔNG lấp khoảng trống | {"so_nen": 12, "khoang": [1767572700000, 1767573300000]} | 0.2 | 4c7583bf4f1f4c65 |
| DL-08 | PASS | Phát hiện cột TradingView: không giả định có đủ plot – file chỉ OHLC → 'KHÔNG'; có đủ ô 1 → 'MỘT PHẦN' kèm giới hạn K.5 (ô đầy làm mất sự kiện SHADOW, thiếu mã SU, thiếu giá) | ["KHÔNG", "MỘT PHẦN (trạng thái/lý do/khóa vùng của sự kiện còn ô)"] | 0.2 | b783def4dc6f69c4 |
| DL-09 | PASS | Chạy ô với file CSV thật về định dạng (dữ liệu tổng hợp ghi ra đĩa): bước 1–3 chạy (PASS/WARN), bước 4–9 BLOCKED – không bịa kết quả | ["PASS", "PASS", "PASS", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED", "BLOCKED"] | 10.2 | 8d313a3340ad16e5 |

## Token Gate – PASS 5

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| TG-01 | PASS | Phân tích 0.3.9: 82 hàm; hàm không gọi f_srcList, f_srcPush kèm bằng chứng (dòng định nghĩa, tham chiếu ngoài thân chỉ từ hàm chết); 8 request.security, 4 lệnh kéo f_struct | {"so_ham": 82, "chet": {"f_srcList": {"dinh_nghia_dong": 1795, "token": 196, "tham_chieu_ngoai_than": [], "chi_duoc_goi_boi_ham_chet": false}, "f_srcPush": {"dinh_nghia_dong": 1787, "token": 84, "tham_chieu_ngoai_than": … | 641.1 | 71895d46fc974199 |
| TG-02 | PASS | Ước lượng: nhiều mô hình, hiệu chỉnh trên điểm FAIL duy nhất có số thật; mô hình 'lex' và 'once' MÂU THUẪN với quan sát; ≥ 2 mô hình nhất quán; trạng thái ESTIMATE kèm khoảng và bất định – không có số 'token thật' | {"muc": "VÀNG – dư địa ước lượng < 2 % giới hạn", "khoang": [95929, 99807], "du_dia": [449, 4327], "nhat_quan": ["full_inline", "sec_k2", "sec_k3", "sec_k4", "sec_k5", "sec_k6", "sec_k7"]} | 0.2 | 6bf026d596dd9d5b |
| TG-03 | PASS | Độ nhạy của cổng (chuỗi trong bộ nhớ, KHÔNG ghi file Pine, KHÔNG dùng để đo trên TradingView): thêm câu lệnh vào f_struct → cảnh báo 'hàm bị request.security kéo theo'; thêm hàm không gọi → nhận diện là hàm chết | {"canh_bao": ["Thay đổi trong hàm bị request.security kéo theo (có thể bị nhân bản khi biên dịch): {'f_struct': 6}"], "chet": ["f_khongGoi", "f_srcList", "f_srcPush"]} | 220.7 | b941cda641f78e8a |
| TG-04 | PASS | Kiểm mô hình cũ (F20): tên 'sec8' giả định 8 bản f_struct nhưng chỉ 4 lệnh request.security gọi f_struct; hệ số 1 tham số khớp được nhiều công thức → khoảng ước lượng rộng (> 3.000 token) | {"n_goi": 4, "do_rong": 3878, "khoang": [95929, 99807]} | 0.1 | 484aceabc870ac0d |
| TG-05 | PASS | Cổng chỉ đọc: SHA 0.3.8 và 0.3.9 không đổi sau khi chạy; CLI trả mã 0 và ghi token_gate.json hợp lệ (allow_nan=False) | {"rc": 0, "sha": ["79793fcf7d55", "2184d8926f6b"]} | 718.6 | 0dc5489c7b689688 |

## Đột biến – PASS 5

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| MUT-01 | PASS | Thay khong_chong bằng bản TRƯỚC SỬA → PF-01 phải FAIL (bộ test bắt được F1) | {"PF-01": "FAIL"} | 1.0 | b2a0b9bffded5278 |
| MUT-02 | PASS | Thay khu_trung bằng bản TRƯỚC SỬA → DUP-01 hoặc DUP-02 phải FAIL (F2) | {"DUP-01": "FAIL", "DUP-02": "FAIL"} | 0.7 | 6e3c76cb98ed2110 |
| MUT-03 | PASS | Thay mo_phong bằng bản TRƯỚC SỬA → R1R2-03 (F4), R1R2-06 (F6), R1R2-07 (F5), OT-05 (F8), MM-02 (F3) đều FAIL | {"R1R2-03": "FAIL(ngoại lệ)", "R1R2-06": "FAIL(ngoại lệ)", "R1R2-07": "FAIL(ngoại lệ)", "OT-05": "FAIL", "MM-02": "FAIL"} | 0.8 | c4eec1c9649d5db7 |
| MUT-04 | PASS | Thay hieu_qua / phieu bằng bản TRƯỚC SỬA → CS-01 (hòa vốn), CS-02 (PF ∞), CS-07 (trùng) FAIL | {"CS-01": "FAIL(ngoại lệ)", "CS-02": "FAIL(ngoại lệ)", "CS-07": "FAIL"} | 7.5 | 5827790df7fe3f77 |
| MUT-05 | PASS | Thay kiem bằng bản TRƯỚC SỬA → HD-02 (NaN/∞) và HD-04 (ts ↔ ts_ms) FAIL | {"HD-02": "FAIL", "HD-04": "FAIL"} | 0.7 | 2c3019edb5960a67 |

## Bảo vệ baseline – PASS 1

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| BL-01 | PASS | Source Pine 0.3.8 và 0.3.9 không đổi (SHA-256) sau toàn bộ lượt chạy | ["79793fcf7d5530d8", "2184d8926f6b7bef"] | 0.5 | e73272cead312336 |

## Hồi quy – PASS 2

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| REG-01 | PASS | Chạy LẠI bộ Stage 3 cũ (shadow_eval/kiem_thu_shadow_eval.py, KHÔNG sửa) trên module mới. (a) chạy nguyên trạng; (b) chạy với shim tương thích emit_seq ở tầng harness để các assertion sau điểm dừng vẫn được thực thi. Mọi FAIL / điểm dừng phải thuộc danh sách lỗi thời đã phân loại, có test thay thế | {"a": {"exit": 1, "test_chay_truoc_khi_dung": 10, "loi": "ValueError: khu_trung: mọi tín hiệu phải có emit_seq (int)"}, "b_shim": {"PASS": 16, "FAIL": 2, "BLOCKED": 4}, "fail_b": ["HD-01", "E2E-01"], "chua_phan_loai": []… | 7520.0 | 407aea06e1340f91 |
| REG-02 | PASS | Chạy LẠI bộ 0.3.9 đầy đủ (kiem_toan039/chay_tat_ca_039.sh) trên BẢN SAO cây thư mục: kết quả trùng lần chạy gốc (47 PASS / 1 FAIL lịch sử T-01 / 7 BLOCKED / 1 NOT TESTED) | {"bo_038_tren_039": {"moi": "{'PASS': 67, 'BLOCKED': 5, 'FAIL': 9, 'NOT TESTED': 1}", "goc": "{'PASS': 67, 'BLOCKED': 5, 'FAIL': 9, 'NOT TESTED': 1}"}, "moi": {"PASS": 47, "BLOCKED": 7, "FAIL": 1, "NOT TESTED": 1}, "goc"… | 2.2 | 66913a44ae9fd63e |

## Thị trường thật – BLOCKED 4

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| REAL-XAU-SU3 | BLOCKED | Đánh giá SU-3 trên dữ liệu thật XAUUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực | 0 | - |
| REAL-XAU-SU5 | BLOCKED | Đánh giá SU-5 trên dữ liệu thật XAUUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực | 0 | - |
| REAL-BTC-SU3 | BLOCKED | Đánh giá SU-3 trên dữ liệu thật BTCUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực | 0 | - |
| REAL-BTC-SU5 | BLOCKED | Đánh giá SU-5 trên dữ liệu thật BTCUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực | 0 | - |

## Tương đương – BLOCKED 1

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| REPLAY-EQ | BLOCKED | Python replay ↔ TradingView | Chưa có dữ liệu đối chứng từ TradingView; Data Window chỉ chứa một phần sự kiện SHADOW (K.5) – không tuyên bố PASS | 0 | - |

## Token – BLOCKED 1

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| TV-TOKEN | BLOCKED | Token biên dịch thật của 0.3.9 | TradingView không in số token khi compile thành công | 0 | - |

## Chưa kiểm – NOT TESTED 3

| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |
|---|---|---|---|---|---|
| REPLAY-FULL | NOT TESTED | Replay toàn script từ OHLCV (f_struct, MD-3, MD-4, MD-5, request.security) | Chưa hiện thực – ngoài phạm vi nhiệm vụ (không tự xây full Pine interpreter) | 0 | - |
| DL-REAL-FILE | NOT TESTED | Nhập file xuất thật từ TradingView / MT5 Exness | Chưa có file thật; định dạng được kiểm bằng file tổng hợp (DL-01, DL-02, DL-09) | 0 | - |
| FUNNEL-REAL | NOT TESTED | Phễu SU-3/SU-5 trên dữ liệu thật | Phụ thuộc REPLAY-FULL và dữ liệu thật | 0 | - |

## Ghi chú phân loại

- BLOCKED và NOT TESTED được đếm riêng, không tính là PASS.
- Test đột biến (MUT-*) PASS nghĩa là: khi thay hàm mới bằng hàm TRƯỚC SỬA, test tương ứng FAIL – chứng minh bộ test bắt được lỗi cũ.
- REG-01: bộ test cũ không bị sửa; assertion lỗi thời được phân loại trong `kiem_thu_stage3.LOI_THOI` kèm test thay thế; kết quả chi tiết ở `ket_qua_stage3/hoi_quy_bo_cu_tren_module_moi.json`.
- REG-02: bộ 0.3.9 chạy trên BẢN SAO cây thư mục (`/tmp/reg039`) vì script tái lập dựng lại 0.3.9 – không chạy trên thư mục baseline. T-01 là FAIL LỊCH SỬ (ước lượng token tuyến tính) đã bị compile thật của 0.3.9 bác bỏ; giữ nguyên, không sửa test.
- Dữ liệu SYNTH chỉ kiểm cơ chế, không phải hiệu quả SU-3/SU-5.
