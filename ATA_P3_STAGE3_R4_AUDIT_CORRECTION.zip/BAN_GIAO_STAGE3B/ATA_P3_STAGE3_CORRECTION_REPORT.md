# ATA P3 · STAGE 3 · BÁO CÁO SỬA LỖI (B)

Mọi sửa đổi đều nằm trong các module Stage 3 ngoài Pine. Không sửa Pine 0.3.8 / 0.3.9, không tạo Build 0.4.0, không sửa logic SU-3/SU-5, không đổi tham số chiến lược.

Bản trước khi sửa được giữ ở `shadow_eval/_truoc_sua/` để đối chiếu và để chạy test đột biến.

## 1. File thay đổi / thêm mới

| File | Loại | Nội dung |
|---|---|---|
| shadow_eval/mo_phong_lenh.py | SỬA (1.1) | F1, F2, F3, F4, F5, F6, F7, F8; quy tắc MFE/MAE thống nhất; outcome NO_DATA/INVALID; fill_note; time_gaps |
| shadow_eval/hop_dong.py | SỬA (schema 1.1) | F12–F16: hữu hạn, ts↔ts_ms, hình học, ngoại lệ theo outcome, nhất quán R/chi phí, `kiem_bang()` cấp bảng; emit_seq |
| shadow_eval/chi_so.py | SỬA (1.1) | F9, F10, F10b, F11; edge case n = 0/1/bằng nhau; seed xác định; CI không phụ thuộc thứ tự; ghi rõ giả định i.i.d. |
| shadow_eval/chuan_hoa.py | MỚI | Adapter engine → hợp đồng (BoGhi), replay_synth, replay_su3_co_dinh |
| shadow_eval/du_lieu.py | MỚI | Nhập TV/MT5, kiểm OHLCV, chuẩn hóa UTC, phân loại khoảng trống, phát hiện cột TV |
| shadow_eval/pipeline.py | MỚI | 4 ô độc lập; dữ liệu thật → BLOCKED đúng bước; SYNTH → chạy đủ chuỗi |
| shadow_eval/kiem_thu_stage3.py | MỚI | 88 test, metadata đầy đủ, test đột biến, hồi quy |
| token_budget/cong_token.py, quan_sat_compile.json | MỚI | Token Budget Gate |
| kiem_toan_stage3/bang_chung_truoc_sua.py (+ .json) | MỚI | Tái hiện từng lỗi trên bản cũ |
| shadow_eval/kiem_thu_shadow_eval.py | **KHÔNG SỬA** | Bộ test cũ được chạy lại để hồi quy (REG-01) |

## 2. Chi tiết từng sửa đổi

Mỗi sửa đổi được ghi theo 6 mục: chỗ lỗi, nguyên nhân, tác động tới đánh giá thật, cách sửa, rủi ro của cách sửa, cách kiểm.

**F1 – Lọc danh mục (khong_chong)**
- Chỗ lỗi: `mo_phong_lenh.khong_chong`.
- Nguyên nhân: `mo[k] = exit_ts_ms` với NO_FILL/OPEN là None, và điều kiện `mo[k] is None` chặn mọi lệnh sau.
- Tác động: biến thể "không chồng lấn" mất hết lệnh sau lần NO_FILL đầu tiên. Số liệu danh mục sai hoàn toàn.
- Cách sửa: chỉ lệnh đã vào (TP1/SL/TIMEOUT/OPEN) mới chiếm vị thế. OPEN chiếm tới hết dữ liệu (∞). NO_FILL/NO_DATA/INVALID giữ lại trong đầu ra để đếm. Khi cùng thời điểm vào, xếp theo emit_seq.
- Rủi ro: quy ước "vào đúng nến thoát của lệnh trước thì bị bỏ" là ASSUMPTION bảo thủ.
- Cách kiểm: PF-01…05, MUT-01.

**F2 – Khử trùng (khu_trung)**
- Nguyên nhân: sắp theo (trigger_ts_ms, signal_id), trong đó signal_id là băm.
- Tác động: khi IP-21 trùng, bản bị giữ là ngẫu nhiên.
- Cách sửa: hợp đồng 1.1 thêm `emit_seq` = thứ tự engine đẩy sự kiện vào evS (theo nến, rồi theo vị trí trong nến). khu_trung sắp theo emit_seq. Thiếu hoặc trùng emit_seq → ValueError, không đoán.
- Rủi ro: dữ liệu cũ (1.0) không có emit_seq sẽ bị từ chối, và đó là chủ ý.
- Cách kiểm: DUP-01…04 (DUP-04 chạy trên replay thật 40 seed: 9 nhóm trùng, giữ đúng emit_seq nhỏ nhất), MUT-02.

**F3 / quy tắc MFE/MAE**
- Nguyên nhân: nhánh tp_first không cập nhật MAE.
- Cách sửa: một quy tắc bảo thủ áp dụng cho mọi nhánh, chi tiết trong docstring:
  - thoát tại Open (gap): chỉ tính giá Open;
  - thoát SL trong nến: bỏ phía có lợi của nến đó, MAE = min(MAE, −1);
  - thoát TP1 trong nến: MFE chặn tại TP1, phía bất lợi tính đủ;
  - xung đột tp_first: phía bất lợi tính đủ;
  - TIMEOUT/OPEN: nến cuối tính đủ.
- Bất biến kiểm được: MAE ≤ R ≤ MFE.
- Cách kiểm: MM-01…06; 3.000 đường ngẫu nhiên với 0 vi phạm.

**F4 / F6 / F5 – Biên R1/R2 và tín hiệu hỏng**
- R2, Open vượt hoặc bằng SL → NO_FILL `GAP_BEYOND_SL`.
- R2, Open đạt hoặc vượt TP1 → NO_FILL `GAP_BEYOND_TP`. Bản cũ ra TP1 với R âm.
- R2, Open nằm giữa P_ref và SL → khớp với rủi ro nhỏ hơn. Ghi nhận, không chỉnh SL.
- R2, không có nến kế → NO_DATA `NO_NEXT_BAR`.
- SL sai phía, SL = P_ref, dir ≠ ±1, giá NaN/∞, TP1 sai phía → INVALID kèm lý do.
- Mọi trường hợp không vào lệnh: risk, R, MFE, MAE, exit đều là null.
- Rủi ro: thêm 2 outcome mới (NO_DATA, INVALID). Bên đọc dữ liệu 1.0 cần cập nhật.
- Cách kiểm: R1R2-01…10.

**F7 / F8 – Dữ liệu trong cửa sổ đánh giá**
- Đếm `time_gaps` và ghi `max_gap_ms`. max_bars đếm theo nến; đã ghi rõ trong docstring.
- Nến hỏng → NO_DATA `INVALID_BAR`.
- Thời gian trùng hoặc lùi → NO_DATA `NON_MONOTONIC_TIME`.
- Gap giá (Open nhảy) và khoảng trống thời gian (thiếu nến) được đo riêng, không lẫn nhau (OT-04).
- Cách kiểm: OT-01…06.

**F9 / F10 / F10b / F11 – Thống kê**

| Nội dung | Định nghĩa mới |
|---|---|
| Thắng / thua / hòa vốn | Thắng: r_net > 1e-9. Thua: r_net < −1e-9. Còn lại là hòa vốn, tách riêng |
| Win rate | win_rate = thắng / số lệnh đóng; thêm win_rate_khong_hoa |
| Tỷ lệ TP1 | Tính riêng theo kết cục TP1, không phải win rate |
| Profit factor | Không có lệnh thua → null + `pf_trang_thai`. Không bao giờ ghi Infinity/NaN; JSON ghi với allow_nan=False |
| Bootstrap | Phân vị đối xứng k = ⌊α/2·B⌋ (số học nguyên). Seed = seed gốc + băm ổn định của nhóm. R được sắp xếp trước khi lấy mẫu |
| Trường hợp biên | n < 2 → CI null; mọi R bằng nhau → CI suy biến |
| Giả định | Ghi rõ i.i.d. (các lệnh độc lập); độ phủ CI kiểm hợp lý ở CS-06 |
| Phễu | Đếm `trung` theo dup_key; thêm tỷ lệ ARMED, trigger/ARMED, S1 đạt |

- Cách kiểm: CS-01…07, MUT-04.

**F12–F16 – Hợp đồng 1.1**
- Mỗi bản ghi được kiểm: kiểu dữ liệu, số hữu hạn, null cho trường tùy chọn, ts ↔ ts_ms, ms tròn phút, danh mục và miền giá trị, hình học SIGNAL, rr, dup_key.
- Riêng TRADES: quy tắc theo outcome, nhất quán R/MFE/MAE, chi phí khớp cost_model.
- Cấp bảng (`kiem_bang`): trùng event_id/signal_id/emit_seq/khóa lệnh, thứ tự thời gian theo emit_seq, vòng đời theo setup_id, liên kết SIGNAL↔TRIGGER, liên kết TRADE↔SIGNAL (S1 đạt, nến vào theo R1/R2, entry/risk/R theo chiều, giá thoát SL/TP1).
- Cách kiểm: bộ riêng HD-01…11, không chỉ dựa vào E2E. HD-02 phủ mọi trường float × NaN/±∞. HD-10: 300 đột biến trên đầu ra replay thật, bắt được 99,3 %; 2 ca lọt là emit_seq của sự kiện cuối bị đẩy lên – không phát hiện được vì thứ tự vẫn hợp lệ.

**F17 / F18 – Test**
- Test cũ không sửa.
- `kiem_thu_stage3.py` ghi đủ metadata cho mỗi test: ID, mục tiêu, input, expected, actual, status, evidence, nguồn (file::hàm, dòng), version (SHA module), thời điểm chạy, thời lượng, hash.

**F19 – Đóng gói**
- SHA256SUMS mới không chứa dòng của chính nó.

**F20 / F21 – Token và tài liệu**
- Dùng Token Gate (báo cáo F) thay cho con số đơn lẻ.
- Đã đính chính nhận định "lastMssM15 được đọc".

**F25 – pipeline SYNTH (code mới của lượt này)**
- Nguyên nhân: khi gộp nhiều seed, (a) dup_key trùng giữa các seed làm phễu báo sai số trùng (28 thay vì 9); (b) lọc danh mục chạy chung nên một lệnh OPEN ở seed trước chặn lệnh ở các seed sau (bỏ 17 thay vì 5).
- Cách sửa: thêm tiền tố seed vào dup_key khi gộp; chạy khong_chong riêng từng seed.
- Cách kiểm: E2E-01 kiểm phễu 'trùng' bằng đúng số bị khử trùng, và số bỏ do chồng lấn bằng tổng lọc độc lập từng seed.

## 3. Hồi quy

- **REG-01 – bộ Stage 3 cũ (không sửa) chạy trên module mới.** Chạy nguyên trạng thì dừng ở DUP-01 cũ, vì tín hiệu không có emit_seq; đây là thay đổi chủ ý của F2. Chạy lại với shim tương thích ở tầng harness (gán emit_seq theo thứ tự trong danh sách; không sửa file test cũ) thì được 16 PASS / 2 FAIL / 4 BLOCKED. Phân loại:
  - 2 FAIL đều là assertion lỗi thời đã phân loại, có test thay thế: HD-01 cũ (schema 1.1) và E2E-01 cũ (fixture trigger_ts sai – F17).
  - SIM-01…10 cũ đều PASS trên bộ giả lập mới, nghĩa là hành vi chính không đổi.
- **REG-02 – bộ 0.3.9 đầy đủ chạy trên bản sao cây thư mục:** xem báo cáo C.

## 4. Không làm (theo chỉ thị)

- Không promote SU-3/SU-5.
- Không đổi permission/trigger/SL/TP/entry/state/dashboard/alert.
- Không tạo probe token.
- Không xóa code Pine.
- Không dùng SYNTH để đánh giá hiệu quả.
- Không tuyên bố REPLAY-EQ PASS.
- Không giả định CSV của TradingView có đủ plot.
