# ATA P3 · STAGE 3 · TOKEN BUDGET GATE (F)

**Token Budget Gate** là công cụ ngoài Pine, file `token_budget/cong_token.py`. "Token biên dịch" là số đơn vị mã mà TradingView đếm sau khi biên dịch; giới hạn của Pine v6 là 100.256.

Cách gate làm việc:

- Chỉ đọc source. Không sửa, không xóa code Pine, không tạo probe hay code padding.
- Kết quả là **ESTIMATE / HYPOTHESIS**, không phải token thật.
- Không có trong roadmap mặc định việc đo bằng probe.

Lệnh chạy: `python3 token_budget/cong_token.py --baseline src038/… --candidate src039/…` → `ket_qua_stage3/token_gate/token_gate.json`

## 1. Sự thật (FACT)

- Giới hạn biên dịch Pine v6 là 100.256 token.
- 0.3.3 FAIL với 101.360 token. Đây là số do TradingView in ra.
- 0.3.3a, 0.3.7, 0.3.8 và 0.3.9 compile thành công. Vì vậy token thật của mỗi bản ≤ 100.256, nhưng **không biết dư địa**. Nguồn của từng quan sát ghi trong `token_budget/quan_sat_compile.json`; riêng 0.3.3a là suy ra.

## 2. Phân tích cấu trúc 0.3.9 (đo được từ source)

| Mục | Giá trị |
|---|---|
| Token từ vựng (tokenizer mới, bỏ comment, nhận diện chuỗi) | 30.181. Báo cáo trước ghi 30.226 với tokenizer cũ; khác nhau do cách tách `+=`, `:=` và comment |
| Số hàm | 82 (0.3.8: 77). Hàm mới: f_zS, f_evS, f_shT, f_shEnd, f_shS1 |
| Hàm không được gọi (kèm bằng chứng) | f_srcList (định nghĩa dòng 1795, 196 token, 0 tham chiếu ngoài thân); f_srcPush (dòng 1787, 84 token, chỉ được hàm chết f_srcList gọi ở dòng 1799) |
| request.security | 8 lệnh. **4 lệnh** (dòng 1003–1006) kéo f_struct + f_tfReq; 4 lệnh (1716–1719) chỉ lấy mảng giá, không kéo hàm |
| Kích thước bao đóng f_struct (inline toàn phần, tính theo số lần gọi) | 7.120 token từ vựng |
| Biến ghi mà không đọc (ỨNG VIÊN, cần xác nhận tay) | lastEvD/H1/H4/M15/New/Txt, lastMssD/H1/H4/M15, lotMax, md4Swing, md5LastBix, pslLv, pslRk, pubLv, pubRk |
| Chênh so với 0.3.8 | +1.853 token từ vựng; không hàm nào trong bao đóng request.security bị đổi; không có cảnh báo nhân bản |

Token theo module (mục `// ====`), sắp theo kích thước:

| Module | Token |
|---|---|
| 11 Pipeline M5 | 8.715 |
| 4 Hàm khung X | 5.317 |
| 11d P0–P8/S1/S2a | 3.814 |
| 11c MD-4 | 3.564 |
| 12 Hiển thị | 1.612 |
| 10 Sổ | 1.147 |
| 2 Inputs | 1.071 |
| 13 Data Window | 1.051 |
| 5 MD-0 | 947 |
| 8 MD-3 | 919 |
| 6 Tham số | 613 |
| 9 S1 | 468 |
| 3 Types | 390 |
| 7 Types biểu đồ | 294 |
| 1 Hằng | 231 |

## 3. Ước lượng nhiều mô hình

Cách hiệu chỉnh: mỗi mô hình có một hệ số, được khớp đúng vào **điểm duy nhất có số thật** (0.3.3 = 101.360). Sau đó kiểm xem mô hình có phân loại đúng mọi bản PASS/FAIL đã biết hay không.

| Mô hình | Hệ số | Với quan sát | Ước lượng 0.3.8 | Ước lượng 0.3.9 | Dư địa 0.3.9 |
|---|---|---|---|---|---|
| lex | 3,3929 | MÂU THUẪN | 96.115 | 102.402 | −2.146 |
| once | 3,3929 | MÂU THUẪN | 95.165 | 101.452 | −1.196 |
| sec_k0 | 3,3929 | MÂU THUẪN | 96.115 | 102.402 | −2.146 |
| sec_k1 | 2,7034 | MÂU THUẪN | 95.831 | 100.841 | −585 |
| sec_k2 | 2,2469 | nhất quán | 95.644 | 99.807 | 449 |
| sec_k3 (4 lệnh gọi f_struct → 3 bản thêm, có cơ sở cấu trúc) | 1,9222 | nhất quán | 95.511 | 99.073 | 1.183 |
| sec_k4 | 1,6795 | nhất quán | 95.411 | 98.523 | 1.733 |
| sec_k5 | 1,4913 | nhất quán | 95.334 | 98.097 | 2.159 |
| sec_k6 | 1,3410 | nhất quán | 95.272 | 97.757 | 2.499 |
| sec_k7 ("sec8" cũ) | 1,2182 | nhất quán | 95.222 | 97.479 | 2.777 |
| full_inline | 1,1874 | nhất quán | 92.344 | 95.929 | 4.327 |

Kết quả của gate cho 0.3.9:

- Trạng thái: **ESTIMATE**.
- Mức: **VÀNG**, vì dư địa ước lượng nhỏ nhất < 2 % giới hạn.
- Khoảng ước lượng: **95.929 – 99.807**, tương ứng dư địa **449 – 4.327**.

## 4. Bất định và cảnh báo

1. Chỉ có 1 điểm có số thật. Các điểm PASS chỉ cho cận trên, nên 7 mô hình khác cấu trúc cùng "nhất quán". Không xác định được mô hình nào đúng.
2. TradingView không công bố cách đếm token: có inline hàm hay không, request.security nhân bản thế nào, có tối ưu gì không.
3. Hai con số 97.519 / 98.069 và dư địa 2.737 / 2.187 trong báo cáo trước **không** phải token thật hay headroom thật. Mô hình "sec8" cũ giả định 8 bản f_struct, trong khi chỉ có 4 lệnh gọi (finding F20).
4. Hệ quả cho các Build sau: thêm khoảng 450 token biên dịch đã **có thể** vượt giới hạn theo mô hình bi quan nhất còn nhất quán (sec_k2). Thay đổi trong f_struct hoặc hàm con của nó bị nhân theo số lệnh gọi; gate sẽ cảnh báo riêng trường hợp này (TG-03).
5. Gate **không thay thế** compile thật. Mỗi Build mới vẫn phải được chủ dự án compile trên TradingView. Có thêm một điểm FAIL kèm số thật sẽ thu hẹp khoảng bất định nhiều nhất.

## 5. Test của gate

TG-01…TG-05 đều PASS: cấu trúc, mô hình, độ nhạy, bằng chứng về F20, và chỉ đọc (SHA baseline giữ nguyên). TV-TOKEN (token thật của 0.3.9) là BLOCKED.
