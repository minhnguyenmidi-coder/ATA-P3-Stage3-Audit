# -*- coding: utf-8 -*-
"""Độ phủ dòng của vùng MD-5 0.3.4a qua toàn bộ kịch bản (trình thông dịch). Liệt kê câu lệnh CHƯA chạy tới."""
import json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import md5_song_song as SS
import pine_mini as PM
cov = set()
orig = SS.May.__init__
def init(self, *a, **k):
    orig(self, *a, **k)
    self.ip.cov = cov
SS.May.__init__ = init
KB = ("lien_tuc", "cum_dong_thoi", "mat_M15", "H1_dung", "H1_cho_L1", "H1_atr_na", "H4_mat", "sat_nguong_khoa", "tong_hop", "khoi_dong_muon", "khoi_dong_tran", "P5_H1", "cum_H1_dung", "bat_kip_day", "bat_kip_hai_phia")
for kb in KB:
    for sd in (1, 2):
        SS.chay(kb, {"mat_M15": 2600, "P5_H1": 2600, "H1_dung": 3200, "cum_H1_dung": 2400}.get(kb, 1500), sd, so_sanh=False, kiem_bb=False)
import vong_doi
vong_doi.main()                 # hợp nhất độ phủ với kiểm thử vòng đời / phát lại (gọi trực tiếp hàm Pine)
lines, base, _ = SS.vung(SS.F34A)
prog = PM.parse_program(lines, base)
allst = set()
def walk(nodes):
    for n in nodes:
        allst.add(n.ln)
        a = n.a
        if n.k == "func": walk(a[2])
        elif n.k == "if":
            for c, b in a[0]: walk(b)
            if a[1]: walk(a[1])
        elif n.k == "for": walk(a[4])
        elif n.k == "while": walk(a[1])
walk(prog)
allst -= {n.ln for n in prog if n.k in ("type", "func")}
chua = sorted(allst - cov)
src = open(SS.F34A, encoding="utf-8").read().split("\n")
r = dict(tong_cau_lenh=len(allst), da_chay=len(allst & cov), ty_le=round(100 * len(allst & cov) / len(allst), 1), chua_chay=[(l, src[l - 1].strip()[:100]) for l in chua])
json.dump(r, open(os.path.join(G, "ket_qua034a_nt", "do_phu_md5.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(r["tong_cau_lenh"], r["da_chay"], r["ty_le"], "%")
for x in r["chua_chay"]: print(x)
