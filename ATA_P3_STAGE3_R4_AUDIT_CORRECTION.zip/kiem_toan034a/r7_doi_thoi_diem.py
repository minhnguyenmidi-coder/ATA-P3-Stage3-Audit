# -*- coding: utf-8 -*-
"""R-7 kiểm DỜI THỜI ĐIỂM: với mỗi biến cục bộ 0.3.3a bị nội tuyến vào StructOut.new/StructX.new ở 0.3.4a,
mọi định danh mà biểu thức đọc KHÔNG được thay đổi giữa dòng khai báo cũ và lệnh trả về (cuối f_struct).
Thay đổi = gán (:=, +=, -=, *=, /=), thao tác ghi array/map lên định danh, hoặc truyền định danh vào hàm người dùng có ghi tham số.
Đồng thời kiểm kiểu trường của StructOut/StructX (chỉ kiểu nguyên thủy → không có bí danh tham chiếu)."""
import re, json, os, sys
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(G, "src033", "ATA_P3_Build_0.3.3a_Candidate_Indicator.pine")
B = os.environ.get("ATA_F034_PATH") or os.path.join(G, "src034a", "ATA_P3_Build_0.3.4a_Candidate_Indicator.pine")
def code(l): return re.sub(r"\s*//.*$", "", l).rstrip()
def split_args(t):
    out, d, cur = [], 0, ""
    for ch in t:
        if ch in "([": d += 1
        if ch in ")]": d -= 1
        if ch == "," and d == 0: out.append(cur.strip()); cur = ""
        else: cur += ch
    out.append(cur.strip()); return out
def chay():
    a = [code(l) for l in open(A, encoding="utf-8").read().split("\n")]
    b = [code(l) for l in open(B, encoding="utf-8").read().split("\n")]
    fa = next(i for i, l in enumerate(a) if l.startswith("f_struct("))
    ra = next(i for i in range(fa, len(a)) if a[i].startswith("    [StructOut.new("))
    m = re.match(r"\s*\[StructOut\.new\((.*)\), StructX\.new\((.*)\)\]$", a[ra])
    old = split_args(m.group(1)) + split_args(m.group(2))
    fb = next(i for i, l in enumerate(b) if l.startswith("f_struct("))
    so = next(i for i in range(fb, len(b)) if b[i].startswith("    StructOut so = StructOut.new("))
    sx = next(i for i in range(fb, len(b)) if b[i].startswith("    StructX sx = StructX.new("))
    new = split_args(re.match(r"\s*StructOut so = StructOut\.new\((.*)\)$", b[so]).group(1)) + split_args(re.match(r"\s*StructX sx = StructX\.new\((.*)\)$", b[sx]).group(1))
    assert len(old) == len(new) == 179, (len(old), len(new))
    body = a[fa:ra]
    # hàm người dùng ghi vào tham số mảng (để bắt ghi gián tiếp)
    ham_ghi = set()
    for i, l in enumerate(a):
        mm = re.match(r"^(f_\w+)\((.*)\) =>", l)
        if mm:
            params = [p.split()[-1] for p in mm.group(2).split(",") if p.strip()]
            j = i + 1
            while j < len(a) and (a[j].startswith(" ") or not a[j].strip()):
                if any(re.search(rf"(array|map)\.(push|set|remove|insert|clear|shift|pop|unshift|sort|reverse|fill|put)\({p}\b", a[j]) for p in params):
                    ham_ghi.add(mm.group(1))
                j += 1
    kq, loi = [], []
    for k, (o, n) in enumerate(zip(old, new)):
        mo = re.match(r"^(\w+)\[1\]$", o)
        if not mo:
            loi.append((k, "đối số cũ không phải tên[1]", o)); continue
        ten = mo.group(1)
        if n == ten:
            kq.append(dict(i=k, ten=ten, kieu="giữ biến")); continue
        # tìm khai báo của ten trong f_struct 0.3.3a
        dk = [i for i, l in enumerate(body) if re.match(rf"^\s+(?:(?:var|varip)\s+)?(?:(?:int|float|bool|string|color)\s+)?{ten}\s*=(?!=)", l)]
        if len(dk) != 1:
            loi.append((k, f"không tìm thấy đúng 1 khai báo ({len(dk)})", ten)); continue
        d = dk[0]
        expr = re.sub(rf"^\s+(?:(?:int|float|bool|string|color)\s+)?{ten}\s*=\s*", "", body[d])
        if expr.strip() != n.strip():
            loi.append((k, "biểu thức nội tuyến khác khai báo", ten, expr, n)); continue
        ids = set(re.findall(r"(?<![\w.])([A-Za-z_]\w*)(?![\w(])", expr)) - {"na", "true", "false", "int", "float", "bool"}
        ids |= set(re.findall(r"\(([A-Za-z_]\w*)\b", expr))
        hams = set(re.findall(r"\b(f_\w+)\(", expr))
        doi = []
        for j in range(d + 1, len(body)):
            l = body[j]
            for x in ids:
                if re.search(rf"(?<![\w.]){x}\s*(:=|\+=|-=|\*=|/=)", l) or re.search(rf"(array|map)\.(push|set|remove|insert|clear|shift|pop|unshift|sort|reverse|fill|put)\({x}\b", l):
                    doi.append((fa + j + 1, x, l.strip()[:80]))
                for h in ham_ghi:
                    if re.search(rf"\b{h}\([^)]*\b{x}\b", l):
                        doi.append((fa + j + 1, x, "qua " + h))
        # biến có var/varip trong khai báo → trạng thái giữ qua nến: không được nội tuyến
        var_decl = bool(re.match(r"^\s+(var|varip)\s", body[d]))
        # vị trí khai báo nằm trong khối điều kiện (thụt lề > 4) → nội tuyến làm đổi điều kiện tính
        trong_khoi = len(body[d]) - len(body[d].lstrip()) > 4
        kq.append(dict(i=k, ten=ten, kieu="nội tuyến", dong_cu=fa + d + 1, bieu_thuc=expr, doc=sorted(ids), ham=sorted(hams), bi_doi_sau_khai_bao=doi, var=var_decl, trong_khoi=trong_khoi))
    # kiểu trường
    def fields(lines, t):
        i = next(i for i, l in enumerate(lines) if l == f"type {t}")
        out = []
        for l in lines[i + 1:]:
            if not l.startswith("    "): break
            if l.strip(): out.append(l.split()[0])
        return out
    kieu = {t: sorted(set(fields(b, t))) for t in ("StructOut", "StructX")}
    nt = [x for x in kq if x["kieu"] == "nội tuyến"]
    xau = [x for x in nt if x["bi_doi_sau_khai_bao"] or x["var"] or x["trong_khoi"] or set(x["ham"]) & ham_ghi]
    return dict(so_doi_so=len(old), giu_bien=len(kq) - len(nt), noi_tuyen=len(nt), loi=loi, nghi_van=xau, kieu_truong=kieu, ham_ghi_tham_so=sorted(ham_ghi), chi_tiet=kq)
if __name__ == "__main__":
    r = chay()
    json.dump(r, open(os.path.join(G, "ket_qua034a_nt", "r7_doi_thoi_diem.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print({k: v for k, v in r.items() if k != "chi_tiet"})
