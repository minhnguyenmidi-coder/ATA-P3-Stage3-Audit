# -*- coding: utf-8 -*-
"""Ma trận kịch bản chạy song song 0.3.3a ↔ 0.3.4a (nguyên văn MD-5, trình thông dịch) + kiểm độ nhạy bằng đột biến.
Chạy: python3 kiem_toan034a/chay_song_song.py [--nhanh]  → ket_qua034a_nt/song_song.json(.jsonl)"""
import json, os, sys, time
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import md5_song_song as SS
OUT = os.path.join(G, "ket_qua034a_nt"); os.makedirs(OUT, exist_ok=True)
KB = ("lien_tuc", "cum_dong_thoi", "mat_M15", "H1_dung", "H1_cho_L1", "H1_atr_na", "H4_mat", "sat_nguong_khoa", "tong_hop")
DOT_BIEN = [
    ("f_mRemove bỏ array.remove(mR)", "    array.remove(mK, i)\n    array.remove(mR, i)", "    array.remove(mK, i)", "cum_dong_thoi"),
    ("MRec.new đảo sd/lv", "MRec.new(sd, lv, rk,", "MRec.new(-sd, lv, rk,", "cum_dong_thoi"),
    ("PHÁ CHỜ ghi sai trạng thái (mrp2)", "mrp2.st := MS_PEND", "mrp2.st := MS_ALIVE", "cum_dong_thoi"),
    ("f_qRemove bỏ cập nhật qHas", "    map.remove(qHas, array.get(qK, i))\n", "", "tong_hop"),
    ("ERec.new đảo L_NEO/E", "ERec.new(bix, sg, array.get(gLv, neo), E,", "ERec.new(bix, sg, E, array.get(gLv, neo),", "cum_dong_thoi"),
    ("cờ EV không ghi (erf)", "erf.fl := true", "erf.fl := false", "tong_hop"),
    ("ev của nguồn SWEEP lệch (mrw)", "mrw.ev := bix", "mrw.ev := bix - 1", "cum_dong_thoi"),
    ("f_qPush bỏ kiểm qHas", "and not map.contains(qHas, k)\n", "\n", "lien_tuc"),
    ("GIẢ ĐỊNH SAO CHÉP thay tham chiếu (mrw = bản sao)", "MRec mrw = array.get(mR, ii)", "MRec mrw = MRec.copy(array.get(mR, ii))", "cum_dong_thoi"),
    ("GIẢ ĐỊNH SAO CHÉP (mrp1 = bản sao)", "MRec mrp1 = array.get(mR, i)", "MRec mrp1 = MRec.copy(array.get(mR, i))", "H1_dung"),
]


def main():
    nhanh = "--nhanh" in sys.argv
    n = 1200 if nhanh else 2000
    seeds = (1,) if nhanh else (1, 2)
    jl = os.path.join(OUT, "song_song.jsonl")
    open(jl, "w").close()
    kq, t0 = [], time.time()
    for ten in KB:
        for sd in seeds:
            r = SS.chay(ten, n, sd)
            r["loai"] = "kich_ban"
            kq.append(r); open(jl, "a").write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
            print(ten, sd, "nến", r["nen_chay"], "sai", r["sai_khac"] is not None, "bb", len(r["loi_bat_bien"]), "lỗi", r["loi_chay"], r["tai_nguyen"], r["dem"], r["thoi_gian_s"], "s", flush=True)
    src = open(SS.F34A, encoding="utf-8").read()
    for ten, cu, moi, kb in DOT_BIEN:
        assert src.count(cu) >= 1, ten
        t = src.replace(cu, moi, 1)
        r = SS.chay(kb, 1200, 1, text_b=t)
        bat = r["sai_khac"] is not None or bool(r["loi_bat_bien"]) or r["loi_chay"] is not None
        r.update(loai="dot_bien", dot_bien=ten, bi_phat_hien=bat)
        kq.append(r); open(jl, "a").write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
        print("ĐỘT BIẾN", ten, "→ phát hiện" if bat else "→ KHÔNG phát hiện", (r["sai_khac"] or {}).get("bien"), r["loi_bat_bien"][:1], r["loi_chay"], flush=True)
    json.dump(dict(n=n, seeds=seeds, ket_qua=kq, tong_thoi_gian_s=round(time.time() - t0)), open(os.path.join(OUT, "song_song.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    kb_ok = all(r["sai_khac"] is None and not r["loi_bat_bien"] and r["loi_chay"] is None for r in kq if r["loai"] == "kich_ban")
    db_ok = all(r["bi_phat_hien"] for r in kq if r["loai"] == "dot_bien")
    print("KỊCH BẢN", "ĐẠT" if kb_ok else "KHÔNG ĐẠT", "· ĐỘT BIẾN", "ĐẠT" if db_ok else "KHÔNG ĐẠT", round(time.time() - t0), "s")
    sys.exit(0 if kb_ok and db_ok else 1)


if __name__ == "__main__":
    main()
