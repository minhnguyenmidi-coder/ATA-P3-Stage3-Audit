# -*- coding: utf-8 -*-
"""Bổ sung ma trận song song: kịch bản khởi động muộn (đường f_mBoot + phát lại có cờ), khởi động tràn bộ chờ, P5 H1 (nguồn muộn → f_replay)."""
import json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import md5_song_song as SS
kq = []
CHI = sys.argv[1:]
for kb, n in (("khoi_dong_muon", 2000), ("khoi_dong_tran", 1500), ("P5_H1", 2500), ("bat_kip_day", 2000)):
    if CHI and kb not in CHI:
        continue
    for sd in (1, 2):
        r = SS.chay(kb, n, sd); r["loai"] = "kich_ban"; kq.append(r)
        print(kb, sd, r["nen_chay"], "sai", r["sai_khac"] is not None, "bb", len(r["loi_bat_bien"]), r["loi_chay"], r["tai_nguyen"], r["dem"], flush=True)
json.dump(dict(ket_qua=kq), open(os.path.join(G, "ket_qua034a_nt", "song_song_bo_sung%s.json" % ("_" + "_".join(CHI) if CHI else "")), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
ok = all(r["sai_khac"] is None and not r["loi_bat_bien"] and r["loi_chay"] is None for r in kq)
print("BỔ SUNG", "ĐẠT" if ok else "KHÔNG ĐẠT"); sys.exit(0 if ok else 1)
