# -*- coding: utf-8 -*-
"""
R-7 – MÔ HÌNH ĐỐI CHỨNG ĐỘC LẬP: lịch sử THEO TỪNG TRƯỜNG (0.3.3a: StructOut.new(x1[1], x2[1], …))
so với lịch sử THEO ĐỐI TƯỢNG (0.3.4a: so = StructOut.new(x1, x2, …) ; so[1]).

Mô hình thực thi Pine (ASSUMPTION, theo tài liệu "Execution model"): mỗi nến khung chạy lại mã; biến không-var tạo mới mỗi lần;
lịch sử [] chỉ chứa giá trị ĐÃ XÁC NHẬN (đóng nến); trong nến realtime mỗi tick chạy lại và bị quay lui (rollback) trừ tick
đóng nến; đối tượng gán theo tham chiếu (FACT – trang Objects). request.security(..., [1] trong hàm, lookahead_on, gaps_off):
nến biểu đồ trong nến khung j nhận giá trị nến khung j − 1 đã xác nhận (ASSUMPTION khớp R2–R4 của mã).

Chạy kiểm: 8 nhóm dữ liệu × nhiều hạt giống × lịch sử + realtime + MTF trễ/khoảng; hai đối chứng âm (đột biến đối tượng sau khi
vào lịch sử; tái sử dụng một đối tượng var) phải bị phát hiện.
"""
import json, os, random, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
NA = None
NF = 12          # số trường mô phỏng (đủ các kiểu int/float/bool, có na)


class Obj:
    __slots__ = ("f",)

    def __init__(self, f):
        self.f = list(f)


def du_lieu(nhom, n, R):
    """Chuỗi giá trị nguyên thủy theo nến khung cho NF trường; mỗi nến có thể có nhiều lần cập nhật trong nến (danh sách)."""
    out = []
    st = [0] * NF
    for j in range(n):
        upd = []
        k = 1 if nhom != "nhieu_cap_nhat" else R.randint(2, 5)
        for _ in range(k):
            row = []
            for q in range(NF):
                if nhom == "tang_giam":
                    v = j * (1 if q % 2 == 0 else -1) + q
                elif nhom == "na":
                    v = NA if R.random() < 0.3 else R.random()
                elif nhom == "thieu_du_lieu":
                    v = NA if (j % 17) in (5, 6, 7) else j + q
                elif nhom == "doi_lien_tiep":
                    v = j % 2 == 0
                elif nhom == "giu_nguyen":
                    v = 42 if q < NF // 2 else True
                elif nhom == "chuyen_doi":
                    if R.random() < 0.1:
                        st[q] = R.randint(0, 6)
                    v = st[q]
                elif nhom == "khoi_tao_ket_thuc":
                    v = NA if j < 5 or j > n - 5 else j
                else:  # nhieu_cap_nhat / ngẫu nhiên
                    v = R.choice([NA, R.random(), R.randint(-5, 5), True, False])
                row.append(v)
            upd.append(row)
        out.append(upd)
    return out


def chay_khung(data, kieu, dot_bien=None, ticks=1):
    """Chạy trên khung lớn. Trả về danh sách giá trị TRẢ VỀ (tuple trường) tại mỗi nến khung (như request.security nhận).
    kieu 'truong': lịch sử từng trường; 'doi_tuong': lịch sử đối tượng. ticks > 1: nến cuối chạy realtime nhiều tick."""
    hist_f = [[] for _ in range(NF)]       # lịch sử đã xác nhận của từng biến cục bộ
    hist_o = []                            # lịch sử đã xác nhận của biến so
    var_obj = Obj([NA] * NF)               # chỉ dùng cho đối chứng âm 'tai_su_dung'
    ra = []
    n = len(data)
    for j, upd in enumerate(data):
        nt = ticks if j == n - 1 else 1
        for t in range(nt):
            # mỗi tick chạy lại toàn bộ thân hàm; nhiều lần cập nhật trong nến → giá trị cuối cùng của các biến cục bộ
            row = upd[-1] if t == nt - 1 else upd[min(t, len(upd) - 1)]
            if kieu == "truong":
                ret = tuple(hist_f[q][-1] if hist_f[q] else NA for q in range(NF))
                ra_j = ret
            else:
                if dot_bien == "tai_su_dung":
                    var_obj.f = list(row)
                    so = var_obj                     # cùng một đối tượng mọi nến (SAI – để đối chứng)
                else:
                    so = Obj(row)                    # StructOut.new(...) mới mỗi lần chạy
                if dot_bien == "sua_sau" and hist_o and j % 7 == 3:
                    hist_o[-1].f[0] = "ĐÃ SỬA"         # mã giữ tham chiếu tới đối tượng nến trước và sửa trường (SAI – để đối chứng)
                prev = hist_o[-1] if hist_o else NA
                ra_j = tuple(prev.f) if prev is not NA else NA
            if t == nt - 1:                           # đóng nến: xác nhận vào lịch sử
                if kieu == "truong":
                    for q in range(NF):
                        hist_f[q].append(row[q])
                else:
                    hist_o.append(so)
            # tick chưa đóng nến: không ghi lịch sử (rollback)
        ra.append(ra_j)
    return ra


def thay_rong(v):
    """R10: đối tượng na → f_empty() (mọi trường na; cờ warm/ready false). 0.3.3a trả đối tượng các trường na."""
    return tuple([NA] * NF) if v is NA else v


def mtf(ra, R, tre=0.0, khoang=0.0, n_chart=None):
    """Ánh xạ nến biểu đồ → giá trị request.security: biểu đồ đi qua các nến khung; nến khung có thể THIẾU (khoảng dữ liệu) hoặc
    TRỄ (biểu đồ vẫn thấy giá trị nến khung trước thêm vài nến). Trả về chuỗi giá trị biểu đồ thấy."""
    out = []
    shown = NA
    for j, v in enumerate(ra):
        if R.random() < khoang:
            continue                               # nến khung không tồn tại trên dữ liệu (gaps_off: giữ giá trị trước)
        lag = R.randint(1, 3) if R.random() < tre else 0
        for _ in range(lag):
            out.append(shown)
        shown = v
        for _ in range(R.randint(1, 4)):
            out.append(shown)
    return out


def main():
    nhom = ["tang_giam", "na", "thieu_du_lieu", "nhieu_cap_nhat", "doi_lien_tiep", "giu_nguyen", "chuyen_doi", "khoi_tao_ket_thuc", "ngau_nhien"]
    kq = []
    for g in nhom:
        for seed in range(1, 6):
            for ticks in (1, 4):
                R = random.Random(seed * 100 + ticks)
                data = du_lieu(g, 300, R)
                a = [thay_rong(x) for x in chay_khung(data, "truong", ticks=ticks)]
                b = [thay_rong(x) for x in chay_khung(data, "doi_tuong", ticks=ticks)]
                R1, R2 = random.Random(seed), random.Random(seed)
                ma = mtf(a, R1, tre=0.2, khoang=0.05)
                mb = mtf(b, R2, tre=0.2, khoang=0.05)
                # kỳ vọng độc lập: giá trị trả về tại nến j = giá trị CUỐI của nến j − 1 (không trộn nến)
                ky_vong = [tuple([NA] * NF)] + [tuple(data[j - 1][-1]) for j in range(1, len(data))]
                sai_ab = sum(1 for x, y in zip(a, b) if x != y)
                sai_kv = sum(1 for x, y in zip(b, ky_vong) if x != y)
                kq.append(dict(nhom=g, seed=seed, ticks=ticks, so_nen=len(data), sai_truong_vs_doi_tuong=sai_ab, sai_vs_ky_vong=sai_kv,
                               sai_mtf=sum(1 for x, y in zip(ma, mb) if x != y), ket_qua="PASS" if sai_ab == sai_kv == 0 and ma == mb else "FAIL"))
    am = []
    for db in ("sua_sau", "tai_su_dung"):
        R = random.Random(7)
        data = du_lieu("ngau_nhien", 300, R)
        a = chay_khung(data, "truong")
        b = chay_khung(data, "doi_tuong", dot_bien=db)
        sai = sum(1 for x, y in zip(a, b) if thay_rong(x) != thay_rong(y))
        am.append(dict(doi_chung=db, so_nen_sai=sai, bi_phat_hien=sai > 0))
    dem = {k: sum(1 for r in kq if r["ket_qua"] == k) for k in ("PASS", "FAIL")}
    out = dict(dem=dem, doi_chung_am=am, ket_qua=kq, ghi_chu=__doc__)
    json.dump(out, open(os.path.join(G, "ket_qua034a_nt", "r7_mo_hinh.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    print(dem, am)
    return dem["FAIL"] == 0 and all(x["bi_phat_hien"] for x in am)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
