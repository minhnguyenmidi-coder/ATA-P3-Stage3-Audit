# -*- coding: utf-8 -*-
"""Dò mã thừa trong một file Pine: định danh khai báo nhưng không bao giờ được đọc, hàm không được gọi, input không dùng,
trường UDT không bao giờ đọc. Chỉ BÁO – không tự sửa. Dùng: python3 do_ma_thua.py <file.pine> <out.json>"""
import re, sys, json
p, out = sys.argv[1], sys.argv[2]
raw = open(p, encoding="utf-8").read().split("\n")
def strip(l):
    o, ins = "", False
    for i, c in enumerate(l):
        if c == '"': ins = not ins
        if not ins and l[i:i + 2] == "//": break
        o += c
    return o
L = [strip(l) for l in raw]
S = "\n".join(re.sub(r'"(?:[^"\\]|\\.)*"', '""', l) for l in L)
decl = {}
for i, l in enumerate(L):
    m = re.match(r"^\s*(?:var\s+|varip\s+)?(?:const\s+)?(?:(?:int|float|bool|string|color|array<[\w ,]+>|map<[\w ,]+>|[A-Z]\w*)\s+)?([A-Za-z_]\w*)\s*=(?!=)", l)
    if m and not l.strip().startswith(("if ", "for ", "while ", "else")):
        decl.setdefault(m.group(1), i + 1)
    for m in re.finditer(r"^\s*\[([\w, ]+)\]\s*=", l):
        for n in m.group(1).split(","):
            decl.setdefault(n.strip(), i + 1)
funcs = {re.match(r"^(\w+)\(", l).group(1): i + 1 for i, l in enumerate(L) if re.match(r"^\w+\(.*\)\s*=>", l)}
khong_doc, khong_goi = [], []
for n, ln in decl.items():
    reads = len(re.findall(rf"(?<![\w.]){re.escape(n)}\b(?!\s*(?:=(?!=)|:=))", S))
    # trừ chính dòng khai báo
    if reads == 0:
        khong_doc.append((n, ln, L[ln - 1].strip()[:90]))
for f, ln in funcs.items():
    if len(re.findall(rf"\b{f}\(", S)) <= 1:
        khong_goi.append((f, ln))
# trường UDT không đọc
types = {}
cur = None
for i, l in enumerate(L):
    m = re.match(r"^type (\w+)", l)
    if m: cur = m.group(1); types[cur] = []; continue
    if cur and l.startswith("    ") and l.strip():
        types[cur].append(l.split()[1])
    elif cur and l.strip() and not l.startswith(" "):
        cur = None
truong = []
for t, fs in types.items():
    for f in fs:
        if not re.search(rf"\.{f}\b(?!\s*:=)", S):
            truong.append((t, f))
r = dict(khong_doc=khong_doc, khong_goi=khong_goi, truong_khong_doc=truong, so_dong=len(raw), byte=len(open(p, "rb").read()))
json.dump(r, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({k: (v if not isinstance(v, list) else v[:40]) for k, v in r.items()}, ensure_ascii=False, indent=0)[:4000])
