# -*- coding: utf-8 -*-
"""
CHẠY SONG SONG NGUYÊN VĂN VÙNG MD-5 (// >>> 0.3.2 DX032 … // <<< 0.3.2 DX032) CỦA 0.3.3a VÀ 0.3.4a
trên trình thông dịch Pine thu gọn (pine_mini.py), cùng đầu vào giả lập, so TOÀN BỘ trạng thái sau MỖI nến
và kiểm bất biến R-5/R-6/R-8/A-08 trên 0.3.4a.

Đây KHÔNG phải TradingView runtime. Đầu vào (StructOut/StructX của request.security, cờ MD-0, mức kỳ, sổ EQ)
được sinh giả lập có hạt giống cố định – khai báo trong GEN.
"""
import json, math, os, random, re, sys, time, copy
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import pine_mini as PM
from pine_mini import NA, PArr, PMap, PObj

F33A = os.path.join(G, "src033", "ATA_P3_Build_0.3.3a_Candidate_Indicator.pine")
F34A = os.environ.get("ATA_F034_PATH") or os.path.join(G, "src034a", "ATA_P3_Build_0.3.4a_Candidate_Indicator.pine")
MF = dict(sd="mSd", l="mL", rk="mRk", dw="mDW", eq="mEQ", per="mPer", a0="mA0", a1="mA1", b0="mB0", b1="mB1", eff="mEff", st="mSt", ev="mEv")
EF = dict(id="eId", sd="eSd", ln="eLn", e="eE", rk="eRk", dw="eDW", eq="eEQ", t="eT", fl="eFl")
M15 = 900000
T0 = 1_700_000_000_000 - (1_700_000_000_000 % (7 * 86400000))


def vung(path, text=None):
    L = (text if text is not None else open(path, encoding="utf-8").read()).split("\n")
    a = next(i for i, l in enumerate(L) if l.startswith("// >>> 0.3.2 DX032"))
    b = next(i for i, l in enumerate(L) if l.startswith("// <<< 0.3.2 DX032"))
    consts = {}
    for l in L:
        m = re.match(r"^const (?:int|float|bool)\s+(\w+)\s*=\s*([-\d.e]+|true|false)\b", l)
        if m:
            v = m.group(2)
            consts[m.group(1)] = (v == "true") if v in ("true", "false") else (float(v) if re.search(r"[.e]", v) else int(v))
    return L[a:b + 1], a + 1, consts


class May:
    """Một bản (0.3.3a hoặc 0.3.4a) chạy trên trình thông dịch."""

    def __init__(self, path, key_cap=None, text=None):
        lines, base, consts = vung(path, text)
        self.ip = PM.Interp()
        prog = PM.parse_program(lines, base)
        self.ip.g.update(consts)
        if key_cap is not None:
            self.ip.g["KEY_CAP"] = key_cap
        self.ip.g.update(tick=0.01, lastMssM15=False)
        for n in ("eqRK", "eqRV", "eqRS", "eqRT", "eqRE", "eqRK0", "eqRH0"):
            self.ip.g[n] = PArr()
        self.rest = self.ip.load(prog)
        self.new = re.search(r"\bvar array<MRec>", "\n".join(lines)) is not None

    def buoc(self, inp, eq):
        g = self.ip.g
        g.update(inp)
        for n, v in eq.items():
            g[n].v[:] = list(v)
        self.ip.bar(self.rest)


def chuan(x):
    if isinstance(x, PArr):
        return [chuan(y) for y in x.v]
    if isinstance(x, PMap):
        return sorted((k, chuan(v)) for k, v in x.d.items())
    if isinstance(x, PObj):
        return (x.t, tuple((k, chuan(v)) for k, v in x.f.items()))
    if isinstance(x, float) and x == int(x) and abs(x) < 1e15:
        return x
    return x


def trang_thai(m):
    """Trạng thái chuẩn hóa: sổ/EV về dạng cột (giống 0.3.3a), mọi biến toàn cục khác giữ nguyên."""
    g = m.ip.g
    st = {}
    if m.new:
        recs = g["mR"].v
        for f, col in MF.items():
            st[col] = [r.f[f] for r in recs]
        recs = g["eR"].v
        for f, col in EF.items():
            st[col] = [r.f[f] for r in recs]
        skip = {"mR", "eR", "qHas"}
    else:
        for col in list(MF.values()) + list(EF.values()):
            st[col] = list(g[col].v)
        skip = set(MF.values()) | set(EF.values())
    for k, v in g.items():
        if k in skip or k in st:
            continue
        st[k] = chuan(v)
    return st


def bat_bien(m, key_cap):
    """Bất biến trên 0.3.4a (danh sách lỗi; rỗng = đạt)."""
    g = m.ip.g
    loi = []
    mK, qK = g["mK"].v, g["qK"].v
    mR, eR, qR = g["mR"].v, g["eR"].v, g["qR"].v
    qHas, mHas, mDead, mFlag = g["qHas"].d, g["mHas"].d, g["mDead"].d, g["mFlag"].d
    if set(qHas) != set(qK):
        loi.append("R8-1 qHas ≠ tập khóa qK")
    if len(set(qK)) != len(qK):
        loi.append("R8-5 khóa trùng trong qK")
    if set(mHas) != set(mK):
        loi.append("R8-2 mHas ≠ tập khóa mK")
    if len(set(mK)) != len(mK):
        loi.append("R5 khóa trùng trong mK")
    if len(mR) != len(mK):
        loi.append("R5 |mR| ≠ |mK|")
    if len(qR) != len(qK):
        loi.append("R8 |qR| ≠ |qK|")
    if any(k in mDead for k in mK) or any(k in mDead for k in qK):
        loi.append("A08 khóa đã kết thúc còn trong sổ/hàng đợi (hồi sinh)")
    if set(mK) & set(qK):
        loi.append("R8 khóa vừa ở sổ vừa ở hàng đợi")
    if not set(mFlag) <= set(mK):
        loi.append("R8-3 mFlag có khóa ngoài sổ")
    if len(mDead) + len(mK) + len(qK) > key_cap:
        loi.append("A08 tổng khóa vượt KEY_CAP")
    ids = [(r.f["id"], r.f["sd"]) for r in eR]
    if len(set(ids)) != len(ids):
        loi.append("R6 EV trùng (id, phía)")
    open_ids = {r.f["id"] for r in eR}
    for k, r in zip(mK, mR):
        if r.f["st"] == g["MS_SWEEP"] and r.f["ev"] not in open_ids:
            loi.append(f"R5/R6 nguồn ĐANG SWEEP trỏ tới EV {r.f['ev']} không còn mở ({k})")
            break
        if r.f["st"] != g["MS_SWEEP"] and r.f["ev"] != -1:
            loi.append("R5 nguồn không SWEEP nhưng ev ≠ -1")
            break
    if len(g["bR"].v) > g["BUF_CAP"]:
        loi.append("A08 bộ đệm > BUF_CAP")
    if len(g["pR"].v) > g["BUF_CAP"]:
        loi.append("A08 bộ chờ > BUF_CAP sau nến")
    return loi


# ------------------------------------------------------------------ dữ liệu giả lập
class GEN:
    """Chuỗi giá bước ngẫu nhiên trên lưới `luoi` (giá), M15 liên tục 24/7; H1 = 4 M15, H4 = 16 M15, ngày = 96, tuần = 672.
    Swing: pivot N=2 trên mỗi khung. EQ: hai pivot cao (thấp) M15 gần nhau ≤ 2 lưới. Sự kiện cấu trúc: ngẫu nhiên (p_sc)."""

    def __init__(self, n, seed, sigma=1.3, luoi=0.01, p_sc=0.04, p_ch=0.02):
        R = random.Random(seed)
        self.n = n
        px = 2000.0
        self.o, self.h, self.l, self.c = [], [], [], []
        for i in range(n + 2):
            op = px
            cl = px + R.gauss(0, sigma)
            hi = max(op, cl) + abs(R.gauss(0, sigma * 0.5))
            lo = min(op, cl) - abs(R.gauss(0, sigma * 0.5))
            q = lambda x: round(round(x / luoi) * luoi, 2)
            op, cl, hi, lo = q(op), q(cl), q(hi), q(lo)
            hi = max(hi, op, cl); lo = min(lo, op, cl)
            self.o.append(op); self.h.append(hi); self.l.append(lo); self.c.append(cl)
            px = cl
        self.scb = [False] * (n + 2); self.scs = [False] * (n + 2); self.ch = [0] * (n + 2)
        for i in range(n + 2):
            r = R.random()
            if r < p_sc:
                self.scb[i] = True
            elif r < 2 * p_sc:
                self.scs[i] = True
            r2 = R.random()
            self.ch[i] = 3 if r2 < p_ch else 4 if r2 < 2 * p_ch else 0
        self.R = R
        self.cache = {}

    def T(self, bx, k=1):
        return T0 + bx * k * M15

    def agg(self, j, k):
        """nến khung k (số M15) chỉ số j: (h, l, c)."""
        key = ("a", j, k)
        r = self.cache.get(key)
        if r is None:
            r = self.cache[key] = self._agg(j, k)
        return r

    def _agg(self, j, k):
        a, b = j * k, j * k + k
        b = min(b, self.n + 2)
        if a >= b:
            return NA, NA, NA
        return max(self.h[a:b]), min(self.l[a:b]), self.c[b - 1]

    def piv(self, j, k, hi):
        """Pivot (N=2) của khung k được XÁC NHẬN khi nến j đóng: pivot ở j-2. Trả về (T, mức) hoặc (na, na)."""
        key = ("p", j, k, hi)
        r = self.cache.get(key)
        if r is None:
            r = self.cache[key] = self._piv(j, k, hi)
        return r

    def _piv(self, j, k, hi):
        p = j - 2
        if p < 2:
            return NA, NA
        vals = [self.agg(q, k)[0 if hi else 1] for q in range(p - 2, p + 3)]
        if any(v is NA for v in vals):
            return NA, NA
        v = vals[2]
        if (hi and v == max(vals) and vals.count(v) == 1) or ((not hi) and v == min(vals) and vals.count(v) == 1):
            return self.T(p, k), v
        return NA, NA

    def ds_piv(self, j, k, hi):
        """10 pivot gần nhất (đến nến j) còn hợp lệ (chưa bị Close vượt): (giá, T, thời điểm xác nhận)."""
        key = ("d", j, k, hi)
        r = self.cache.get(key)
        if r is None:
            r = self.cache[key] = self._ds_piv(j, k, hi)
        return r

    def _ds_piv(self, j, k, hi):
        out = []
        q = j
        cx = None                          # cực trị Close trên [q, j] (duyệt lùi) – tương đương kiểm từng z trong [q, j]
        while q > 3 and len(out) < 10 and q > j - 400:
            c = self.agg(q, k)[2]
            if c is not NA:
                cx = c if cx is None else (max(cx, c) if hi else min(cx, c))
            t, v = self.piv(q, k, hi)
            if t is not NA:
                broken = cx is not None and ((cx > v) if hi else (cx < v))
                if not broken:
                    out.append((v, t, self.T(q, k) + k * M15))
            q -= 1
        return out

    def sx(self, j, k):
        """StructX của nến khung k đã đóng chỉ số j (giá trị [1] nhìn từ nến j+1)."""
        key = ("x", j, k)
        if key in self.cache:
            return self.cache[key]
        f = {}
        h, l, c = self.agg(j, k)
        hp, lp, cp = self.agg(j - 1, k) if j >= 1 else (NA, NA, NA)
        f.update(bix=j, tOpS=self.T(j, k), hiS=h, loS=l, hiP=hp, loP=lp, clsP=cp, tClP=self.T(j - 1, k) + k * M15)
        f["nshT"], f["nshL"] = self.piv(j, k, True)
        f["nslT"], f["nslL"] = self.piv(j, k, False)
        f["nshT1"], f["nshL1"] = self.piv(j - 1, k, True)
        f["nslT1"], f["nslL1"] = self.piv(j - 1, k, False)
        if k == 1:
            f["scBP"], f["scSP"] = (self.scb[j - 1], self.scs[j - 1]) if j >= 1 else (False, False)
        else:
            f["scBP"], f["scSP"] = False, False
        for hi, pre in ((True, "sh"), (False, "sl")):
            ds = self.ds_piv(j, k, hi)
            for i in range(10):
                f[f"{pre}T{i}"] = ds[i][1] if i < len(ds) else NA
                f[f"{pre}C{i}"] = ds[i][2] if i < len(ds) else NA
        o = PObj("StructX", f)
        self.cache[key] = o
        return o

    def so(self, j, k, atr=3.0):
        key = ("s", j, k, atr)
        if key in self.cache:
            return self.cache[key]
        h, l, c = self.agg(j, k)
        f = dict(tClose=self.T(j, k) + k * M15, cls=c, atr=atr, ready=True, warm=True)
        if k == 1:
            f.update(scBuy=self.scb[j], scSell=self.scs[j], ev=self.ch[j])
        else:
            f.update(scBuy=False, scSell=False, ev=0)
        for hi, pre in ((True, "sh"), (False, "sl")):
            ds = self.ds_piv(j, k, hi)
            for i in range(10):
                f[f"{pre}{i}"] = ds[i][0] if i < len(ds) else NA
        o = PObj("StructOut", f)
        self.cache[key] = o
        return o


def kich_ban(ten, n, ma="XAU"):
    """Trả về dict tham số kịch bản. mat_m15: tập nến M15 không có trên biểu đồ; h1_dung: tập nến okH1 = false;
    h1_cho: tập nến pendH1 = true (L-1); h4_mat: tập nến H4 không cập nhật."""
    k = dict(mat_m15=set(), h1_dung=set(), h1_cho=set(), h4_mat=set(), atr_na=set(), h1_bo_qua=set(), key_cap=None, luoi=0.01, p_sc=0.04, sigma=1.3)
    if ma == "BTC":
        k["sigma"] = 3.0
    dai = (1, 2, 6, 12, 48, 191, 192, 193)
    if ten == "lien_tuc":
        pass
    elif ten == "cum_dong_thoi":
        k.update(luoi=0.5, p_sc=0.08, sigma=0.8)
    elif ten == "mat_M15":
        p = 400
        while p < n - 500:
            for d in dai:
                if p + d < n - 50:
                    k["mat_m15"] |= set(range(p, p + d))
                p += d + 250
    elif ten == "H1_dung":
        p = 400
        while p < n - 500:
            for d in dai:
                if p + d < n - 50:
                    k["h1_dung"] |= set(range(p, p + d))
                p += d + 250
    elif ten == "H1_cho_L1":
        p = 400
        for d in dai:
            k["h1_cho"] |= set(range(p, p + d)); p += d + 250
    elif ten == "khoi_dong_muon":
        k["h1_dung"] = set(range(2, 150)) | set(range(900, 1000))
        k["h1_cho"] = set(range(1300, 1304))
    elif ten == "P5_H1":
        # bỏ lỡ đúng một lần cập nhật H1 (4 nến M15 phủ ranh giới H1) trong khi MD-5 vẫn chạy → H1 nhảy 2 → P5 H1 → nguồn muộn → phát lại
        k["h1_bo_qua"] = set(x for p in range(200, n - 50, 13 * 4) for x in range(p, p + 4))
        k["h4_bo_qua"] = set(x for p in range(320, n - 50, 9 * 16) for x in range(p, p + 16))
        k.update(p_sc=0.03)
    elif ten == "cum_H1_dung":
        k.update(luoi=0.5, p_sc=0.10, sigma=0.8)
        p = 300
        while p < n - 300:
            k["h1_dung"] |= set(range(p, p + 150)); p += 400
    elif ten == "bat_kip_day":
        k.update(luoi=0.5, p_sc=0.15, sigma=1.6)
        k["h1_dung"] = set(x for p in range(200, n - 50, 37) for x in range(p, p + 7))
    elif ten == "bat_kip_hai_phia":
        # nến bao (râu dài hai phía, Close giữa thân) nằm TRONG lúc H1 tạm dừng → khi bắt kịp có ứng viên BSL và SSL cùng nến
        k["h1_dung"] = set(x for p in range(300, n - 50, 120) for x in range(p, p + 6))
        k["nen_ngoai"] = set(range(303, n - 50, 120))
    elif ten == "khoi_dong_tran":
        k["h1_dung"] = set(range(2, 400))
    elif ten == "H1_atr_na":
        k["atr_na"] = set(range(500, 560))
    elif ten == "H4_mat":
        k["h4_mat"] = set(range(600, 700)) | set(range(1500, 1520))
    elif ten == "sat_nguong_khoa":
        k.update(key_cap=max(120, n // 25), luoi=0.25)
    elif ten == "tong_hop":
        k["mat_m15"] = set(range(700, 702)) | set(range(1900, 1950))
        k["h1_dung"] = set(range(1000, 1194))
        k["h1_cho"] = set(range(1400, 1406))
        k["h4_mat"] = set(range(2200, 2240))
        k.update(luoi=0.25, key_cap=max(200, n // 15))
    return k


def dau_vao(gen, kb, bx, last):
    """Đầu vào MD-0 cho nến M15 dữ liệu bx (đang có trên biểu đồ). last: trạng thái khung đã thấy."""
    okH1 = bx not in kb["h1_dung"]
    pendH1 = bx in kb["h1_cho"]
    j1 = bx // 4 - 1          # nến H1 đã đóng gần nhất
    j4 = bx // 16 - 1
    atr = NA if bx in kb["atr_na"] else 3.0
    sH1 = gen.so(max(j1, 0), 4, atr); xH1 = gen.sx(max(j1, 0), 4)
    newH1 = okH1 and not pendH1 and j1 >= 0 and last.get("h1") != j1 and bx not in kb["h1_bo_qua"]
    okH4 = j4 >= 0 and bx not in kb["h4_mat"]
    newH4 = okH4 and last.get("h4") != j4 and bx not in kb.get("h4_bo_qua", ())
    if newH1:
        last["h1"] = j1
    if newH4:
        last["h4"] = j4
    d = bx // 96 - 1; w = bx // 672 - 1
    avPD = d >= 0; avPW = w >= 0
    pd = gen.agg(d, 96) if avPD else (NA, NA, NA)
    pw = gen.agg(w, 672) if avPW else (NA, NA, NA)
    inp = dict(runBar=True, newM15=True, okM15=True, okH1=okH1, pendH1=pendH1, okH4=okH4, pendH4=False, newH1=newH1, newH4=newH4,
               sM15=gen.so(bx, 1), xM15=gen.sx(bx, 1), sH1=sH1, xH1=xH1, sH4=gen.so(max(j4, 0), 16), xH4=gen.sx(max(j4, 0), 16),
               time=gen.T(bx) + M15 + 5 * 60000, avPD=avPD, avPW=avPW,
               pdH=pd[0], pdL=pd[1], pdT=gen.T(d, 96) if avPD else NA, pdC=gen.T(d + 1, 96) if avPD else NA,
               pwH=pw[0], pwL=pw[1], pwT=gen.T(w, 672) if avPW else NA, pwC=gen.T(w + 1, 672) if avPW else NA)
    return inp


def so_eq(gen, bx, eq):
    """Sổ EQ giả lập (đầu vào của MD-5, do khối EQ trước đó quản lý): thêm nhóm khi hai pivot M15 gần nhất cùng phía lệch ≤ 2 lưới."""
    for hi, sd in ((True, 1), (False, -1)):
        t, v = gen.piv(bx, 1, hi)
        if t is NA:
            continue
        key = ("ph" if hi else "pl")
        prev = eq.setdefault(key, [])
        for (t0, v0) in prev[-3:]:
            if abs(v - v0) <= 0.021 or (gen.R.random() < 0.02):
                k = ("EQH15|" if hi else "EQL15|") + str(t0) + "|" + str(t)
                if k not in eq["eqRK"]:
                    eq["eqRK"].append(k); eq["eqRV"].append(max(v, v0) if hi else min(v, v0)); eq["eqRS"].append(sd); eq["eqRT"].append(15)
                    eq["eqRE"].append(gen.T(bx) + M15); eq["eqRK0"].append(t0); eq["eqRH0"].append(t)
                    if len(eq["eqRK"]) > 8:
                        for n in ("eqRK", "eqRV", "eqRS", "eqRT", "eqRE", "eqRK0", "eqRH0"):
                            eq[n].pop(0)
                break
        prev.append((t, v))
    return {n: eq[n] for n in ("eqRK", "eqRV", "eqRS", "eqRT", "eqRE", "eqRK0", "eqRH0")}


def chay(ten, n, seed, so_sanh=True, kiem_bb=True, text_a=None, text_b=None, ghi_moc=200, ma="XAU"):
    kb = kich_ban(ten, n, ma)
    gen = GEN(n, seed, sigma=kb["sigma"], luoi=kb["luoi"], p_sc=kb["p_sc"])
    for b_ in kb.get("nen_ngoai", ()):
        gen.h[b_] = round(gen.c[b_] + 40, 2); gen.l[b_] = round(gen.c[b_] - 40, 2)
    cap = kb["key_cap"]
    A = May(F33A, cap, text_a) if so_sanh else None
    B = May(F34A, cap, text_b)
    capv = B.ip.g["KEY_CAP"]
    last = {}
    eq = {n_: [] for n_ in ("eqRK", "eqRV", "eqRS", "eqRT", "eqRE", "eqRK0", "eqRH0")}
    sai, loi_bb, loi_chay = None, [], None
    do = dict(max_mK=0, max_qK=0, max_mDead=0, max_eR=0, max_bR=0, max_pR=0, max_tong=0, max_mFlag=0)
    dem = dict(nen=0, ev_tao=0, ev_ket_thuc_cung_nen_max=0, dong_bo_lai=0, bat_kip=0, so_day=0, nguon_ket_thuc_cung_nen_max=0)
    moc = []
    ts = []
    t0 = time.time()
    for bx in range(2, n):
        if bx in kb["mat_m15"]:
            continue
        inp = dau_vao(gen, kb, bx, last)
        eqv = so_eq(gen, bx, eq)
        g = B.ip.g
        ev0 = g.get("evTotal", 0); kt0 = g.get("evConf", 0) + g.get("evBroke", 0) + g.get("evExp", 0); dead0 = len(g["mDead"].d) if "mDead" in g else 0
        dsn0 = g.get("md5DesyncN", 0)
        a = time.perf_counter_ns()
        try:
            B.buoc(inp, eqv)
        except PM.PineErr as e:
            loi_chay = f"0.3.4a nến {bx}: {e}"
            break
        ts.append(time.perf_counter_ns() - a)
        if A is not None:
            try:
                A.buoc(inp, eqv)
            except PM.PineErr as e:
                loi_chay = f"0.3.3a nến {bx}: {e}"
                break
        dem["nen"] += 1
        dem["ev_tao"] = g["evTotal"]
        dem["ev_ket_thuc_cung_nen_max"] = max(dem["ev_ket_thuc_cung_nen_max"], g["evConf"] + g["evBroke"] + g["evExp"] - kt0)
        dem["nguon_ket_thuc_cung_nen_max"] = max(dem["nguon_ket_thuc_cung_nen_max"], len(g["mDead"].d) - dead0)
        dem["dong_bo_lai"] = g["md5DesyncN"]; dem["bat_kip"] = g["md5Cnt"].v[7]; dem["so_day"] = g["md5Cnt"].v[0]
        tong = len(g["mDead"].d) + len(g["mK"].v) + len(g["qK"].v)
        for k_, v_ in (("max_mK", len(g["mK"].v)), ("max_qK", len(g["qK"].v)), ("max_mDead", len(g["mDead"].d)), ("max_eR", len(g["eR"].v)),
                       ("max_bR", len(g["bR"].v)), ("max_pR", len(g["pR"].v)), ("max_tong", tong), ("max_mFlag", len(g["mFlag"].d))):
            do[k_] = max(do[k_], v_)
        if ghi_moc and bx % ghi_moc == 0:
            moc.append((bx, len(g["mDead"].d), len(g["mK"].v), len(g["qK"].v)))
        if kiem_bb:
            lb = bat_bien(B, capv)
            if lb and len(loi_bb) < 20:
                loi_bb.append((bx, lb))
        if A is not None and sai is None:
            sa, sb = trang_thai(A), trang_thai(B)
            ks = sorted(set(sa) | set(sb))
            khac = [k_ for k_ in ks if sa.get(k_, "<thiếu>") != sb.get(k_, "<thiếu>")]
            if khac:
                sai = dict(nen=bx, bien=khac[:10], vi_du={k_: (str(sa.get(k_))[:300], str(sb.get(k_))[:300]) for k_ in khac[:3]})
                break
    ts.sort()
    q = (lambda p: round(ts[min(len(ts) - 1, int(p * len(ts)))] / 1e3, 1)) if ts else (lambda p: None)
    return dict(kich_ban=ten, n=n, seed=seed, key_cap=capv, so_sanh=so_sanh, nen_chay=dem["nen"], sai_khac=sai, loi_bat_bien=loi_bb, loi_chay=loi_chay,
                tai_nguyen=do, dem=dem, moc=moc, thoi_gian_s=round(time.time() - t0, 1),
                us_moi_nen_034a=dict(trung_vi=q(0.5), p95=q(0.95), p99=q(0.99), max=round(ts[-1] / 1e3, 1) if ts else None))


if __name__ == "__main__":
    r = chay(sys.argv[1] if len(sys.argv) > 1 else "lien_tuc", int(sys.argv[2]) if len(sys.argv) > 2 else 800, int(sys.argv[3]) if len(sys.argv) > 3 else 1)
    print(json.dumps({k: v for k, v in r.items() if k != "moc"}, ensure_ascii=False, indent=1, default=str))
