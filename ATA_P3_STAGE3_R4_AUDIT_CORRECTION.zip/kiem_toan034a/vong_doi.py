# -*- coding: utf-8 -*-
"""
KIỂM THỬ VÒNG ĐỜI (R-5/R-6/R-8) – gọi TRỰC TIẾP các hàm Pine nguyên văn (f_qPush, f_qRemove, f_mAddSt, f_mEnd, f_mRemove,
f_evEnd, f_evFlag, f_slot) của 0.3.3a và 0.3.4a trên trình thông dịch, cùng chuỗi thao tác; sau mỗi thao tác so trạng thái
chuẩn hóa hai bản, kiểm bất biến 0.3.4a và kết quả mong đợi. Mỗi bản ghi lưu: đầu vào, trạng thái trước, thao tác,
trạng thái sau, mong đợi, thực tế.
"""
import json, os, random, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import pine_mini as PM
import md5_song_song as SS
from pine_mini import NA


def moi(path, cap=None):
    m = SS.May(path, cap)
    for st in m.rest:
        if st.k == "decl" and st.a[2]:
            m.ip.run(st, [])
    m.ip.g.update(sOp=0, bix=0)
    return m


def pine(m, code):
    """Chạy đoạn Pine (một hoặc vài dòng) trên máy m."""
    prog = PM.parse_program(code.split("\n"))
    out = None
    for st in prog:
        out = m.ip.run(st, [])
    return out


def ev_push(m, id_, sd, ln, e, fl=False):
    if m.new:
        pine(m, f"array.push(eR, ERec.new({id_}, {sd}, {ln}, {e}, 1, false, false, 0, {'true' if fl else 'false'}))")
    else:
        for arr, v in (("eId", id_), ("eSd", sd), ("eLn", ln), ("eE", e), ("eRk", 1), ("eDW", "false"), ("eEQ", "false"), ("eT", 0), ("eFl", "true" if fl else "false")):
            pine(m, f"array.push({arr}, {v})")


def tom_tat(m):
    g = m.ip.g
    s = SS.trang_thai(m)
    return dict(mK=list(g["mK"].v), mSt=s["mSt"], mEv=s["mEv"], qK=list(g["qK"].v), mDead=sorted(g["mDead"].d), eId=s["eId"], eFl=s["eFl"],
                qHas=sorted(g["qHas"].d) if m.new else None, cnt0=g["md5Cnt"].v[0])


KQ = []


def buoc(ten, A, B, code, mong=None, cap=None):
    truoc = tom_tat(B)
    loi = []
    try:
        ra = pine(A, code)
    except PM.PineErr as e:
        ra = f"LỖI {e}"
    try:
        rb = pine(B, code)
    except PM.PineErr as e:
        rb = f"LỖI {e}"
    sau = tom_tat(B)
    sa, sb = SS.trang_thai(A), SS.trang_thai(B)
    khac = [k for k in sorted(set(sa) | set(sb)) if sa.get(k) != sb.get(k)]
    if khac:
        loi.append(f"hai bản khác: {khac[:5]}")
    dung_tra_ve = code.strip().startswith(("f_slot(", "f_endAt(", "f_replay(", "f_sameOrigin("))
    if not dung_tra_ve:
        pass                                   # hàm thủ tục: giá trị trả về không được nơi gọi dùng (kiểm tĩnh RET-01)
    elif isinstance(ra, str) and isinstance(rb, str) and ra.startswith("LỖI") and rb.startswith("LỖI"):
        pass                                   # cả hai bản đều dừng vì lỗi chỉ số (thông điệp có thể khác lệnh gây lỗi)
    elif str(SS.chuan(ra)) != str(SS.chuan(rb)):
        loi.append(f"giá trị trả về khác: {ra} / {rb}")
    bb = SS.bat_bien(B, B.ip.g["KEY_CAP"])
    bb = [x for x in bb if not x.startswith("R5/R6 nguồn ĐANG SWEEP")]   # kiểm thử đơn vị không dựng EV cho mọi nguồn SWEEP
    loi += bb
    if mong is not None:
        ok, mt = mong(sau, str(rb))
        mt = str(mt)
        if not ok:
            loi.append("sai mong đợi: " + mt)
    KQ.append(dict(test=ten, thao_tac=code, trang_thai_truoc=truoc, trang_thai_sau=sau, tra_ve=str(rb),
                   mong_doi=(mong.__doc__ or "") if mong else "hai bản giống nhau + bất biến", ket_qua="PASS" if not loi else "FAIL", loi=loi))
    return not loi


def m_(doc):
    def deco(f):
        f.__doc__ = doc
        return f
    return deco


def qp(k, eff=100, sd=1, lv=10.0):
    return f'f_qPush("{k}", {sd}, {lv}, 1, false, false, false, 5, 6, na, na, {eff})'


def main():
    F33A, F34A = SS.F33A, SS.F34A
    # ---- hàng đợi
    A, B = moi(F33A), moi(F34A)
    buoc("Q01 hàng đợi rỗng: f_slot", A, B, "f_slot()", m_("trả về true")(lambda s, r: (r == "True", r)))
    buoc("Q02 thêm một khóa", A, B, qp("SH15|1"), m_("qK = [SH15|1], qHas = {SH15|1}")(lambda s, r: (s["qK"] == ["SH15|1"] and s["qHas"] == ["SH15|1"], str(s["qK"]))))
    for i in range(2, 7):
        buoc(f"Q03 thêm nhiều khóa #{i}", A, B, qp(f"SH15|{i}"))
    buoc("Q04 thêm khóa trùng (đang ở hàng đợi)", A, B, qp("SH15|3"), m_("|qK| không đổi = 6")(lambda s, r: (len(s["qK"]) == 6, str(len(s["qK"])))))
    buoc("Q05 thêm khóa thiếu mức (na)", A, B, 'f_qPush("SH15|99", 1, na, 1, false, false, false, 5, 6, na, na, 100)', m_("bị bỏ qua")(lambda s, r: ("SH15|99" not in s["qK"], "")))
    buoc("Q06 xóa đầu", A, B, "f_qRemove(0)", m_("SH15|1 ra khỏi qK và qHas")(lambda s, r: ("SH15|1" not in s["qK"] and "SH15|1" not in s["qHas"], "")))
    buoc("Q07 xóa giữa", A, B, "f_qRemove(2)", m_("SH15|4 ra; thứ tự còn lại giữ nguyên")(lambda s, r: (s["qK"] == ["SH15|2", "SH15|3", "SH15|5", "SH15|6"], str(s["qK"]))))
    buoc("Q08 xóa cuối", A, B, "f_qRemove(3)", m_("qK = [2,3,5]")(lambda s, r: (s["qK"] == ["SH15|2", "SH15|3", "SH15|5"], str(s["qK"]))))
    buoc("Q09 xóa liên tiếp nhiều (giảm dần như mã gốc)", A, B, "f_qRemove(2)\nf_qRemove(1)\nf_qRemove(0)", m_("rỗng")(lambda s, r: (s["qK"] == [] and s["qHas"] == [], str(s["qK"]))))
    buoc("Q10 xóa khóa không tồn tại (chỉ số ngoài phạm vi) – Pine báo lỗi runtime; mã gốc không bao giờ gọi như vậy (xem kiểm tĩnh)", A, B, "f_qRemove(0)",
         m_("cả hai báo lỗi chỉ số, trạng thái không đổi")(lambda s, r: (str(r).startswith("LỖI") and s["qK"] == [], str(r))))
    buoc("Q11 thêm rồi xóa cùng nến, thêm lại khóa đó", A, B, qp("SH15|7") + "\nf_qRemove(0)\n" + qp("SH15|7"),
         m_("khóa vào lại được (chưa kết thúc) – qK = [SH15|7]")(lambda s, r: (s["qK"] == ["SH15|7"], str(s["qK"]))))
    buoc("Q12 khóa đã kết thúc không được nhận lại", A, B, 'map.put(mDead, "SH15|8", true)\n' + qp("SH15|8"),
         m_("không vào hàng đợi")(lambda s, r: ("SH15|8" not in s["qK"], "")))
    # ---- sổ nguồn
    for i in range(5):
        buoc(f"M01 thêm nguồn vào sổ #{i}", A, B, f'f_mAddSt("K{i}", 1, {10 + i}.0, 1, false, false, false, {i}, {i + 1}, na, na, 0, MS_ALIVE, -1)')
    buoc("M02 kết thúc nguồn đầu (f_mEnd)", A, B, "f_mEnd(0)", m_("K0 → mDead; sổ K1..K4")(lambda s, r: ("K0" in s["mDead"] and s["mK"] == ["K1", "K2", "K3", "K4"], str(s["mK"]))))
    buoc("M03 kết thúc nguồn giữa", A, B, "f_mEnd(1)", m_("K2 ra; K1,K3,K4 còn đúng thứ tự, đúng bản ghi")(lambda s, r: (s["mK"] == ["K1", "K3", "K4"], str(s["mK"]))))
    buoc("M04 kết thúc nguồn cuối", A, B, "f_mEnd(2)", m_("K4 ra")(lambda s, r: (s["mK"] == ["K1", "K3"], str(s["mK"]))))
    buoc("M05 gỡ không kết thúc (f_mRemove – kỳ hết hiệu lực)", A, B, "f_mRemove(0)", m_("K1 ra, KHÔNG vào mDead")(lambda s, r: ("K1" not in s["mDead"] and s["mK"] == ["K3"], "")))
    for i in range(5, 11):
        buoc(f"M06 thêm #{i}", A, B, f'f_mAddSt("K{i}", {1 if i % 2 else -1}, {10 + i}.0, 1, false, false, false, {i}, {i + 1}, na, na, 0, MS_SWEEP, 777)')
    ev_push(A, 777, 1, 15.0, 16.0); ev_push(B, 777, 1, 15.0, 16.0)
    ev_push(A, 778, -1, 9.0, 8.0); ev_push(B, 778, -1, 9.0, 8.0)
    buoc("E01 gắn cờ EV theo (id, phía) – qua biến tạm erf (0.3.4a)", A, B, "f_evFlag(778, -1)", m_("eFl = [false, true]")(lambda s, r: (s["eFl"] == [False, True], str(s["eFl"]))))
    buoc("E02 gắn cờ sai phía không có tác dụng", A, B, "f_evFlag(777, -1)", m_("eFl không đổi")(lambda s, r: (s["eFl"] == [False, True], str(s["eFl"]))))
    buoc("E03 nhiều nguồn kết thúc đồng thời khi EV 777 kết thúc (f_evEnd)", A, B, "f_evEnd(0, 50)",
         m_("mọi nguồn SWEEP(777) → mDead; EV 777 rời eR; K3 (ALIVE) còn")(lambda s, r: (s["mK"] == ["K3"] and all(f"K{i}" in s["mDead"] for i in range(5, 11)) and s["eId"] == [778], str(s["mK"]) + str(s["eId"]))))
    ev_push(A, 779, 1, 1.0, 2.0); ev_push(B, 779, 1, 1.0, 2.0)
    ev_push(A, 780, 1, 1.0, 2.0, True); ev_push(B, 780, 1, 1.0, 2.0, True)
    buoc("E04 nhiều EV kết thúc đồng thời (giảm dần như Bước 5)", A, B, "f_evEnd(2, 51)\nf_evEnd(1, 51)\nf_evEnd(0, 51)", m_("eR rỗng; xId ghi 3 EV")(lambda s, r: (s["eId"] == [], str(s["eId"]))))
    buoc("E05 sửa trạng thái nguồn qua biến tạm (mrp – 0.3.4a)", A, B,
         ("MRec mrp = array.get(mR, 0)\nmrp.st := MS_PEND" if False else "f_mAddSt(\"K20\", 1, 1.0, 1, false, false, false, 1, 2, na, na, 0, MS_ALIVE, -1)"))
    # Pine nguyên văn từng bản cho lệnh đặt PHÁ CHỜ (khác cú pháp, cùng ý nghĩa)
    pine(A, "if true\n    array.set(mSt, 1, MS_PEND)")
    pine(B, "if true\n    MRec mrp2 = array.get(mR, 1)\n    mrp2.st := MS_PEND")
    buoc("E06 đặt PHÁ CHỜ: 0.3.3a array.set(mSt) ≡ 0.3.4a biến tạm + gán trường (tham chiếu)", A, B, "f_slot()",
         m_("mSt của K20 = MS_PEND ở cả hai bản")(lambda s, r: (s["mSt"][1] == 1, str(s["mSt"]))))

    # ---- phát lại G.3 (f_replay) trên bộ đệm dựng sẵn – đi qua mọi nhánh, gồm nhập EV (f_evFlag cùng phía) và gắn cờ EV phía kia
    def dung_bo_dem(m, bars):
        pine(m, "array.clear(bR)\narray.clear(xId)\narray.clear(xAt)")
        for (bx, t, h, l, c, sb, ss, ub, us, eb, es, ne) in bars:
            pine(m, f"array.push(bR, BufRec.new({bx}, {t}, {h}, {l}, {c}, {h}, {l}, {str(sb).lower()}, {str(ss).lower()}, {str(ub).lower()}, {str(us).lower()}, {eb}, {es}, {str(ne).lower()}))")
    T = lambda b: 1_000_000 + b * 900000
    ca = [
        # (tên, bộ đệm, (sd, L, eff, curBix), EV cần có sẵn [(id, sd)], mong đợi mã)
        ("RP1 nhập EV cùng phía (UV1, có EV BSL ở nến) → ĐANG SWEEP + gắn cờ EV", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, True, False, 11, -1, False)], (1, 10.0, T(10), 12), [(11, 1)], 2),
        ("RP2 phía kia có ứng viên (loại trừ hai phía), EV phía kia tồn tại → gắn cờ EV phía kia, nguồn CÒN", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 7, 9.5, False, False, False, True, -1, 11, False)], (1, 10.0, T(10), 12), [(11, -1)], 0),
        ("RP3 không có EV ở nến ứng viên → EV BỊ BỎ LỠ (mã 4)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, False, False, -1, -1, False)], (1, 10.0, T(10), 12), [], 4),
        ("RP4 nến bắt kịp (ne) → KẾT THÚC (mã 3)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, False, False, -1, -1, True)], (1, 10.0, T(10), 12), [], 3),
        ("RP5 Close vượt → PHÁ CHỜ (mã 1)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 10.5, False, False, False, False, -1, -1, False)], (1, 10.0, T(10), 12), [], 1),
        ("RP6 bộ đệm không liền tới nến hiện tại → KHÔNG ĐỦ LỊCH SỬ (mã 5)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False)], (1, 10.0, T(10), 13), [], 5),
        ("RP8 nhập EV rồi EV kết thúc ở nến sau trong bộ đệm → KẾT THÚC (mã 3)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, True, False, 11, -1, False), (12, T(12), 9.8, 9, 9.2, False, False, False, False, -1, -1, False), (13, T(13), 9.8, 9, 9.2, False, False, False, False, -1, -1, False)], (1, 10.0, T(10), 14), [(11, 1)], 3),
        ("RP8b nhập EV, EV còn mở qua các nến sau → ĐANG SWEEP (mã 2)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, True, False, 11, -1, False), (12, T(12), 9.8, 9, 9.2, False, False, False, False, -1, -1, False)], (1, 10.0, T(10), 13), [(11, 1)], 2),
        ("RP9 EV bỏ lỡ rồi có sự kiện cấu trúc ngược phía → KẾT THÚC (mã 3)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, False, False, -1, -1, False), (12, T(12), 9.8, 9, 9.2, False, True, False, False, -1, -1, False)], (1, 10.0, T(10), 13), [], 3),
        ("RP9b EV bỏ lỡ, các nến sau không kết thúc → EV BỎ LỠ (mã 4)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, False, False, -1, -1, False), (12, T(12), 9.8, 9, 9.2, False, False, False, False, -1, -1, False)], (1, 10.0, T(10), 13), [], 4),
        ("RP7 EV nhập đã kết thúc trong bộ đệm → KẾT THÚC (mã 3)", [(10, T(10), 9, 8, 8.5, False, False, False, False, -1, -1, False), (11, T(11), 12, 9, 9.5, False, False, True, False, 11, -1, False)], (1, 10.0, T(10), 12), [(11, 1)], 3),
    ]
    for ten, bars, (sd, L, eff, cur), evs, ma in ca:
        A, B = moi(F33A), moi(F34A)
        for m in (A, B):
            dung_bo_dem(m, bars)
            for (i_, s_) in evs:
                ev_push(m, i_, s_, L, 13.0)
            if ten.startswith("RP7"):
                pine(m, "array.push(xId, 11)\narray.push(xAt, 11)")
            if ten.startswith("RP8 "):
                pine(m, "array.push(xId, 11)\narray.push(xAt, 12)")
        kq_ok = buoc(ten, A, B, f"f_replay({sd}, {L}, {eff}, {cur})", m_(f"mã {ma}; cờ EV đúng như mô tả")(
            lambda s, r, ma=ma, evs=evs, ten=ten: (r.startswith(f"({ma},") and (not evs or ten.startswith(("RP7", "RP8")) or s["eFl"] == [True]), r + " eFl=" + str(s["eFl"]))))
    # ---- gần đầy / đầy
    A, B = moi(F33A, 6), moi(F34A, 6)
    pine(A, 'map.put(mDead, "D0", true)\nmap.put(mDead, "D1", true)'); pine(B, 'map.put(mDead, "D0", true)\nmap.put(mDead, "D1", true)')
    buoc("C01 gần đầy: |mDead| = 2, thêm 2 khóa hàng đợi (tổng 4 < 6)", A, B, qp("Q1") + "\n" + qp("Q2"), m_("qK = [Q1, Q2]")(lambda s, r: (s["qK"] == ["Q1", "Q2"], str(s["qK"]))))
    buoc("C02 thêm khóa thứ 5 (tổng 5 < 6)", A, B, qp("Q3"), m_("nhận")(lambda s, r: ("Q3" in s["qK"], "")))
    buoc("C03 đầy: thêm khóa khi tổng = 5 → nhận (5 < 6), tổng 6", A, B, qp("Q4"), m_("nhận; tổng = 6")(lambda s, r: ("Q4" in s["qK"], "")))
    buoc("C04 đầy: tổng = 6 → từ chối, đếm SỔ ĐẦY", A, B, qp("Q5"), m_("không nhận; md5Cnt[0] = 1")(lambda s, r: ("Q5" not in s["qK"] and s["cnt0"] == 1, str(s["cnt0"]))))
    buoc("C05 chuyển khóa hàng đợi → mDead không làm tăng tổng", A, B, 'map.put(mDead, array.get(qK, 0), true)\nf_qRemove(0)',
         m_("tổng vẫn 6, Q1 trong mDead")(lambda s, r: ("Q1" in s["mDead"] and len(s["mDead"]) + len(s["qK"]) == 6, "")))
    buoc("C06 sổ đầy không xóa FIFO/tuổi: khóa cũ trong mDead còn nguyên", A, B, qp("Q6"), m_("D0, D1 còn; Q6 bị từ chối")(lambda s, r: ("D0" in s["mDead"] and "D1" in s["mDead"] and "Q6" not in s["qK"], "")))
    # ---- ngẫu nhiên có hạt giống: chuỗi thao tác qPush/qRemove/mAddSt/mEnd/mRemove
    for seed in range(1, 6):
        R = random.Random(seed)
        A, B = moi(F33A, 40), moi(F34A, 40)
        ok_all = True
        for step in range(400):
            g = B.ip.g
            nq, nm = len(g["qK"].v), len(g["mK"].v)
            r = R.random()
            if r < 0.35:
                code = qp(f"R{R.randrange(60)}")
            elif r < 0.5 and nq:
                code = f"f_qRemove({R.randrange(nq)})"
            elif r < 0.62 and nq:
                i = R.randrange(nq)
                code = f'string kk = array.get(qK, {i})\nf_qRemove({i})\nif not map.contains(mHas, kk) and not map.contains(mDead, kk)\n    f_mAddSt(kk, 1, 1.0, 1, false, false, false, 1, 2, na, na, 0, MS_ALIVE, -1)'
            elif r < 0.8 and nm:
                code = f"f_mEnd({R.randrange(nm)})"
            elif r < 0.85 and nm:
                code = f"f_mRemove({R.randrange(nm)})"
            elif nq:
                code = f"map.put(mDead, array.get(qK, 0), true)\nf_qRemove(0)"
            else:
                code = qp(f"R{R.randrange(60)}")
            ok_all &= buoc(f"N{seed:02d}-{step:03d} ngẫu nhiên", A, B, code)
    dem = {k: sum(1 for x in KQ if x["ket_qua"] == k) for k in ("PASS", "FAIL")}
    out = os.path.join(G, "ket_qua034a_nt", "vong_doi.json")
    json.dump(dict(dem=dem, ket_qua=KQ), open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    print(dem, [ (x["test"], x["loi"]) for x in KQ if x["ket_qua"] == "FAIL"][:5])
    return dem


if __name__ == "__main__":
    d = main()
    sys.exit(1 if d["FAIL"] else 0)
