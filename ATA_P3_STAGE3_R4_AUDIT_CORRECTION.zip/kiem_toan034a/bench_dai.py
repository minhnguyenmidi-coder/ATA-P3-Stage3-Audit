# -*- coding: utf-8 -*-
"""Mô hình chi phí (Python bám Pine – kiem_toan034/bench_034.py, KHÔNG phải Pine/Profiler): lịch sử dài 60k/150k nến M15 với
mất M15 đủ độ dài 1, 2, 6, 12, 48, 191, 192, 193 (lặp lại), XAU/BTC giả lập. Ghi ket_qua034a_nt/bench_dai.json"""
import json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, os.path.join(G, "kiem_toan034"))
import bench_034 as B
kq = []
for ma, vol in (("XAU-giả lập", 1.3), ("BTC-giả lập", 3.0)):
    for n in (60000, 150000):
        r = B.chay(n, 21, vol, "mat_M15_du_do_dai"); r["ma"] = ma; kq.append(r)
        print(ma, n, r["thoi_gian_mo_hinh_s"], "s", r["tai_nguyen"], r["dem"], r["mDead_moi_nen_m15"], r["micro_s_moi_nen"], flush=True)
json.dump(dict(ket_qua=kq), open(os.path.join(G, "ket_qua034a_nt", "bench_dai.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
