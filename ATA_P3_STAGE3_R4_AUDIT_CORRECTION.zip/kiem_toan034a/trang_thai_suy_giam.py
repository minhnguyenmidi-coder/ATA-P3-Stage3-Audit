# -*- coding: utf-8 -*-
"""Trạng thái suy giảm/phục hồi trên nguyên văn MD-5 0.3.4a (trình thông dịch). Ghi md5Status mỗi nến và kiểm:
 S1 khoảng mất ≥ 2 nến M15 → đồng bộ lại (md5DesyncN tăng) và trạng thái 1 SUY GIẢM ngay sau đó;
 S2 sau khoảng mất, SUY GIẢM tự hết trong ≤ BUF_CAP nến M15 nếu không còn khóa/EV mang cờ và không có khoảng mới;
 S3 H1 dừng 191/192 nến: bộ chờ KHÔNG tràn (bắt kịp đủ, không đồng bộ lại vì tràn); 193 nến: tràn → trạng thái 5 rồi đồng bộ lại;
 S4 H1 chờ (L-1): trạng thái 6 trong lúc chờ; MD-5 không chạy (md5OK = false);
 S5 sổ đầy: md5Cnt[0] > 0 → trạng thái 3 SỔ KHÓA ĐẦY (giữ nguyên theo thiết kế A-08b – không tự xóa khóa)."""
import json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import md5_song_song as SS
from pine_mini import NA


def theo_doi(ten, n, h1_dung=None, mat=None, h1_cho=None, cap=None):
    kb = SS.kich_ban("lien_tuc", n)
    if h1_dung: kb["h1_dung"] = h1_dung
    if mat: kb["mat_m15"] = mat
    if h1_cho: kb["h1_cho"] = h1_cho
    if cap: kb["key_cap"] = cap; kb["luoi"] = 0.25
    gen = SS.GEN(n, 5, sigma=kb["sigma"], luoi=kb["luoi"], p_sc=kb["p_sc"])
    B = SS.May(SS.F34A, kb["key_cap"])
    last, eq = {}, {k: [] for k in ("eqRK", "eqRV", "eqRS", "eqRT", "eqRE", "eqRK0", "eqRH0")}
    tl = []
    for bx in range(2, n):
        if bx in kb["mat_m15"]:
            continue
        inp = SS.dau_vao(gen, kb, bx, last)
        B.buoc(inp, SS.so_eq(gen, bx, eq))
        g = B.ip.g
        tl.append(dict(bx=bx, st=g["md5Status"], ok=g["md5OK"], dsn=g["md5DesyncN"], pR=len(g["pR"].v), pOver=g["pOver"], cnt3=g["md5Cnt"].v[3], cnt0=g["md5Cnt"].v[0], flag=len(g["mFlag"].d)))
    return tl


def main():
    kq = []
    # S1/S2: mất 2, 6, 48 nến M15
    for d in (1, 2, 6, 48):
        tl = theo_doi(f"mat{d}", 1600, mat=set(range(600, 600 + d)))
        sau = [x for x in tl if x["bx"] >= 600 + d]
        dsn = sau[0]["dsn"]
        suy = sau[0]["st"]
        het = next((x["bx"] for x in sau if x["st"] == 0), None)
        if d == 1:
            ok = dsn == 0                                                   # P5: mất đúng 1 nến → không đồng bộ lại
            mt = "mất 1 nến: P5, không đồng bộ lại"
        else:
            ok = dsn == 1 and suy == 1 and het is not None and het - (600 + d) <= 192 + 2
            mt = f"mất {d} nến: đồng bộ lại 1 lần, SUY GIẢM rồi hết sau {None if het is None else het - (600 + d)} nến (≤ 194)"
        kq.append(dict(test=f"S1/S2 mất {d} nến M15", mong_doi=mt, thuc_te=dict(dong_bo_lai=dsn, trang_thai_ngay_sau=suy, het_suy_giam_tai=het), ket_qua="PASS" if ok else "FAIL"))
    # S3: H1 dừng 191 / 192 / 193
    for d in (191, 192, 193):
        tl = theo_doi(f"h1_{d}", 1400, h1_dung=set(range(500, 500 + d)))
        trong = [x for x in tl if 500 <= x["bx"] < 500 + d]
        sau = [x for x in tl if x["bx"] >= 500 + d]
        maxp = max(x["pR"] for x in trong)
        co5 = any(x["st"] == 5 for x in trong)
        co2 = all(x["st"] in (2, 5) for x in trong)
        dsn = sau[0]["dsn"]
        if d <= 192:
            ok = maxp == d and not co5 and dsn == 0 and co2 and sau[0]["ok"]
            mt = f"bộ chờ đạt {d} ≤ 192, không tràn, bắt kịp, không đồng bộ lại; trạng thái 2 trong lúc dừng"
        else:
            ok = co5 and dsn == 1 and co2 and maxp <= 192
            mt = "nến thứ 193 làm tràn → bỏ toàn bộ bộ chờ, trạng thái 5, đồng bộ lại 1 lần khi H1 về"
        kq.append(dict(test=f"S3 H1 dừng {d} nến", mong_doi=mt, thuc_te=dict(max_bo_cho=maxp, co_trang_thai_5=co5, dong_bo_lai=dsn, trang_thai_trong_luc_dung=sorted({x['st'] for x in trong})), ket_qua="PASS" if ok else "FAIL"))
    # S4: H1 chờ (L-1) 6 nến
    tl = theo_doi("cho", 900, h1_cho=set(range(500, 506)))
    trong = [x for x in tl if 500 <= x["bx"] < 506]
    ok = all(x["st"] == 6 and not x["ok"] for x in trong) and tl[-1]["dsn"] == 0
    kq.append(dict(test="S4 H1 chờ (L-1) 6 nến", mong_doi="trạng thái 6, MD-5 không chạy, không đồng bộ lại (bắt kịp)", thuc_te=sorted({(x['st'], x['ok']) for x in trong}), ket_qua="PASS" if ok else "FAIL"))
    # S5: sổ đầy
    tl = theo_doi("day", 2500, cap=150)
    lan_dau = next((x["bx"] for x in tl if x["cnt0"] > 0), None)
    sau = [x for x in tl if lan_dau and x["bx"] >= lan_dau and x["ok"]]
    ok = lan_dau is not None and all(x["st"] == 3 for x in sau)
    kq.append(dict(test="S5 sổ khóa đầy (KEY_CAP thu nhỏ 150)", mong_doi="từ lần từ chối đầu: trạng thái 3 khi MD-5 chạy; không tự xóa khóa", thuc_te=dict(lan_tu_choi_dau=lan_dau, trang_thai=sorted({x['st'] for x in sau})), ket_qua="PASS" if ok else "FAIL"))
    dem = {k: sum(1 for r in kq if r["ket_qua"] == k) for k in ("PASS", "FAIL")}
    json.dump(dict(dem=dem, ket_qua=kq, ghi_chu=__doc__), open(os.path.join(G, "ket_qua034a_nt", "trang_thai_suy_giam.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    for r in kq: print(r["ket_qua"], r["test"], r["thuc_te"])
    return dem


if __name__ == "__main__":
    sys.exit(1 if main()["FAIL"] else 0)
