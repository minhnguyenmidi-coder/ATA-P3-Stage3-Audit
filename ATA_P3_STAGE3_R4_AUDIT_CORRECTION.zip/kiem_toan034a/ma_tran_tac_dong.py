# -*- coding: utf-8 -*-
"""Ma trận tác động (tĩnh, tự động): mỗi mục của script → đầu vào đọc từ khung lớn (StructOut/StructX – R-7), đầu ra MD-5 đọc vào,
định danh R-5/R-6/R-8 (mR, MRec, eR, ERec, qHas) có xuất hiện không. Dùng: python3 ma_tran_tac_dong.py <file> <out.json>"""
import re, sys, json
p, out = sys.argv[1], sys.argv[2]
L = [re.sub(r'"(?:[^"\\]|\\.)*"', '""', re.sub(r"\s*//.*$", "", l)) for l in open(p, encoding="utf-8").read().split("\n")]
raw = open(p, encoding="utf-8").read().split("\n")
sec = [(i, raw[i][3:].strip()) for i in range(len(raw)) if re.match(r"^// \d+[a-z]?\. ", raw[i])]
a = next(i for i, l in enumerate(raw) if l.startswith("// >>> 0.3.2 DX032")); b = next(i for i, l in enumerate(raw) if l.startswith("// <<< 0.3.2 DX032"))
# tách vùng MD-5 thành mục riêng
bounds = []
for k, (i, n) in enumerate(sec):
    j = sec[k + 1][0] if k + 1 < len(sec) else len(raw)
    if i < a < j:
        bounds += [(i, a, n), (a, b + 1, "11b. MD-5 (sổ nguồn, hàng đợi, EV, bộ đệm – vùng DX032)"), (b + 1, j, n + " (phần sau MD-5)")]
    else:
        bounds.append((i, j, n))
md5_out = sorted({m.group(1) for l in L[a:b + 1] for m in [re.match(r"^var\s+(?:[\w<>, ]+\s+)?(\w+)\s*=", l)] if m})
md5_out += ["md5CanRun"]
R56 = ["mR", "MRec", "eR", "ERec", "qHas"]
STRUCT = ["sM15", "xM15", "sH1", "xH1", "sH4", "xH4", "sD", "xD"]
rows = []
for i, j, n in bounds:
    txt = "\n".join(L[i:j])
    def doc(names):
        return [x for x in names if re.search(rf"(?<![\w.]){x}\b", txt)]
    rows.append(dict(muc=n, dong=f"{i + 1}–{j}", doc_struct_R7=doc(STRUCT), doc_md5=[x for x in doc(md5_out) if not (i <= a < j and n.startswith("11b"))] if not n.startswith("11b") else ["(chính vùng MD-5)"],
                     dinh_danh_R5_R6_R8=doc(R56)))
json.dump(dict(md5_dau_ra=md5_out, muc=rows), open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for r in rows:
    print(r["dong"], r["muc"][:55], "| R7:", len(r["doc_struct_R7"]), "| MD5 out:", r["doc_md5"][:8], "| R5/6/8:", r["dinh_danh_R5_R6_R8"])
