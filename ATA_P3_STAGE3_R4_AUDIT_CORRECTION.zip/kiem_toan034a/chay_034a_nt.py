# -*- coding: utf-8 -*-
"""
BỘ CHẠY NGHIỆM THU BUILD 0.3.4a – python3 kiem_toan034a/chay_034a_nt.py [--hoi-quy]
→ ket_qua034a_nt/TEST_MATRIX_NGHIEM_THU_0.3.4a.csv, TEST_RUN_LOG_NGHIEM_THU_0.3.4a.txt, nghiem_thu_034a.json
Mã thoát: 1 có FAIL · 2 không FAIL nhưng còn BLOCKED/NOT TESTED · 0 tất cả PASS.
PASS chỉ khi có assertion thực tế trên kết quả. Các lượt chạy dài (song song, stress, mô hình chi phí, độ phủ) được KIỂM NỘI DUNG
từ file kết quả do chính các script đó ghi (kèm hạt giống, đầu vào, nhật ký) – thiếu file → NOT TESTED, không bao giờ PASS.
"""
import csv, hashlib, json, os, re, subprocess, sys, time
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
OUT = os.path.join(G, "ket_qua034a_nt"); os.makedirs(OUT, exist_ok=True)
F34A = os.path.join(G, "src034a", "ATA_P3_Build_0.3.4a_Candidate_Indicator.pine")
F33A = os.path.join(G, "src033", "ATA_P3_Build_0.3.3a_Candidate_Indicator.pine")
SHA34A = "073234cc6d9a5a9fbb81380f59b81482acdf1640484264ac0116909267f68605"
SHA33A = "d1fd298e8c302009c8097679b79a530c89a05cdb4d0140875298fe7848f95e7d"
KQ, LOG = [], []


def ghi(tid, nhom, muc_tieu, ky_vong, thuc_te, kq, nhan, phuong_phap, bang_chung):
    KQ.append(dict(id=tid, nhom=nhom, muc_tieu=muc_tieu, ky_vong=ky_vong, thuc_te=str(thuc_te)[:1500], ket_qua=kq, nhan=nhan, phuong_phap=phuong_phap, bang_chung=bang_chung))
    s = f"{kq:11} {tid:14} {muc_tieu[:90]}"
    print(s, flush=True)
    LOG.append(s + "\n    thực tế: " + str(thuc_te)[:1200])


def doc(p):
    p = os.path.join(OUT, p)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def jl(p):
    p = os.path.join(OUT, p)
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()] if os.path.exists(p) else None


def chay_py(script, *args, timeout=3000, env=None):
    r = subprocess.run([sys.executable, os.path.join(D, script), *args], cwd=G, capture_output=True, text=True, timeout=timeout, env=env)
    return r.returncode, r.stdout[-3000:] + r.stderr[-2000:]


def main():
    t0 = time.time()
    L34 = open(F34A, encoding="utf-8").read().split("\n")
    S34 = "\n".join(L34)
    h34, h33 = hashlib.sha256(open(F34A, "rb").read()).hexdigest(), hashlib.sha256(open(F33A, "rb").read()).hexdigest()
    ghi("V-01", "Baseline", "Baseline 0.3.4a và 0.3.3a nguyên vẹn (không ghi đè)", "SHA khớp", f"0.3.4a {h34}; 0.3.3a {h33}",
        "PASS" if h34 == SHA34A and h33 == SHA33A else "FAIL", "FACT", "sha256", "src034a/, src033/")
    # ======================= R-5 / R-6
    rc, out = chay_py("vong_doi.py")
    vd = doc("vong_doi.json")
    ok = rc == 0 and vd and vd["dem"]["FAIL"] == 0 and vd["dem"]["PASS"] >= 2000
    ghi("R56-VD", "R-5/R-6/R-8", "Vòng đời: thêm 1/nhiều; xóa đầu/giữa/cuối/liên tiếp; thêm+xóa cùng nến; nhiều nguồn/EV kết thúc đồng thời; hàng đợi rỗng/gần đầy/đầy; "
        "phát lại đủ mã 0–5; 2000 bước ngẫu nhiên (5 hạt giống) – gọi NGUYÊN VĂN hàm Pine của cả hai bản",
        "0 sai khác hai bản, 0 vi phạm bất biến, đúng mong đợi", vd["dem"] if vd else out, "PASS" if ok else "FAIL", "FACT (trên trình thông dịch)",
        "pine_mini + vong_doi.py; mỗi bước lưu đầu vào/trước/thao tác/sau/mong đợi/thực tế", "ket_qua034a_nt/vong_doi.json")
    ss = doc("song_song.json")
    bs = [doc("song_song_bo_sung.json"), doc("song_song_bo_sung_bat_kip_day.json"), doc("song_song_bo_sung_hai_phia.json")]
    if ss is None or any(b is None for b in bs):
        ghi("R56-SS", "R-5/R-6/R-8", "Chạy song song nguyên văn MD-5 0.3.3a ↔ 0.3.4a theo ma trận kịch bản", "có kết quả", "thiếu file kết quả", "NOT TESTED", "—", "chay_song_song.py", "—")
    else:
        kb = [r for r in ss["ket_qua"] if r["loai"] == "kich_ban"] + [r for b in bs for r in b["ket_qua"]]
        bad = [(r["kich_ban"], r["seed"], r["sai_khac"], r["loi_bat_bien"][:1], r["loi_chay"]) for r in kb if r["sai_khac"] is not None or r["loi_bat_bien"] or r["loi_chay"]]
        nen = sum(r["nen_chay"] for r in kb)
        ten = sorted({r["kich_ban"] for r in kb})
        ghi("R56-SS", "R-5/R-6/R-8", f"Chạy song song NGUYÊN VĂN vùng MD-5 hai bản, so TOÀN BỘ trạng thái sau MỖI nến: {len(kb)} lượt, {len(ten)} kịch bản ({', '.join(ten)})",
            "0 sai khác, 0 vi phạm bất biến, 0 lỗi chạy", f"{len(kb)} lượt, {nen} nến; lỗi: {bad[:3]}", "PASS" if not bad and len(kb) >= 28 else "FAIL",
            "FACT (trên trình thông dịch; ngữ nghĩa Pine mô phỏng = ASSUMPTION có nguồn)", "md5_song_song.py / chay_song_song.py / chay_bo_sung.py", "ket_qua034a_nt/song_song*.json")
        db = [r for r in ss["ket_qua"] if r["loai"] == "dot_bien"]
        erf = doc("P5_H1_va_dot_bien_erf.json")
        khong = [r["dot_bien"] for r in db if not r["bi_phat_hien"]]
        # đột biến erf không lộ trên kịch bản dữ liệu ngẫu nhiên (nhánh hiếm) → phải bị bộ vòng đời phát hiện (kiểm lại ngay tại đây)
        erf_vd = None
        if khong == ["cờ EV không ghi (erf)"]:
            tmp = os.path.join(OUT, "_m_erf.pine")
            open(tmp, "w", encoding="utf-8").write(S34.replace("erf.fl := true", "erf.fl := false", 1))
            env = dict(os.environ, ATA_F034_PATH=tmp)
            bak = open(os.path.join(OUT, "vong_doi.json"), encoding="utf-8").read()
            rc2, _ = chay_py("vong_doi.py", env=env)
            erf_vd = rc2 != 0
            open(os.path.join(OUT, "vong_doi.json"), "w", encoding="utf-8").write(bak)
            os.remove(tmp)
        ok = len(db) == 10 and (not khong or (khong == ["cờ EV không ghi (erf)"] and erf_vd))
        ghi("R56-DB", "R-5/R-6/R-8", "Độ nhạy: 10 đột biến cố ý trên 0.3.4a (lệch chỉ số mR, đảo trường, bỏ qHas, giả định SAO CHÉP thay tham chiếu …) đều phải bị phát hiện",
            "10/10", f"phát hiện bởi chạy song song: {len(db) - len(khong)}/10; còn lại {khong} → bộ vòng đời phát hiện: {erf_vd}", "PASS" if ok else "FAIL", "FACT",
            "kiểm đột biến", "song_song.json, vong_doi.json")
    # ======================= R-7
    import r7_doi_thoi_diem as R7
    r7 = R7.chay()
    ok = r7["so_doi_so"] == 179 and not r7["loi"] and not r7["nghi_van"] and r7["kieu_truong"]["StructOut"] == ["bool", "float", "int"] and r7["kieu_truong"]["StructX"] == ["float", "int"]
    ghi("R7-01", "R-7", "177+102 = 179 trường: mỗi trường = biến cũ hoặc đúng biểu thức khai báo cũ; 115 biểu thức nội tuyến KHÔNG bị dời qua lệnh ghi nào (gán/array/map/hàm ghi tham số), "
        "không biến var, không nằm trong khối điều kiện; mọi trường kiểu nguyên thủy (không bí danh)", "0 lỗi, 0 nghi vấn",
        f"giữ biến {r7['giu_bien']}, nội tuyến {r7['noi_tuyen']}, lỗi {r7['loi'][:2]}, nghi vấn {[x['ten'] for x in r7['nghi_van']][:5]}, kiểu {r7['kieu_truong']}",
        "PASS" if ok else "FAIL", "FACT", "tĩnh + đối chứng âm (chèn lệnh ghi → bị bắt)", "r7_doi_thoi_diem.py")
    sx = [(i + 1, l.strip()[:60]) for i, l in enumerate(L34) if re.search(r"\b(so|sx|s|x|sM15|xM15|sH1|xH1|sH4|xH4|sD|xD)\.\w+\s*(:=|\+=|-=)", re.sub(r"//.*$", "", l))]
    var_obj = re.findall(r"var\s+(?:StructOut|StructX)\b", S34)
    newso = re.search(r"^    StructOut so = StructOut\.new\(", S34, re.M) and re.search(r"^    StructX sx = StructX\.new\(", S34, re.M) and "    [so[1], sx[1]]" in S34
    ghi("R7-02", "R-7", "Không sửa trường StructOut/StructX ở bất kỳ đâu; so/sx là biến thường (không var) tạo mới bằng .new mỗi lần chạy → lịch sử [1] không bị đổi hồi tố",
        "0 lệnh gán trường; 0 var; .new mỗi lần", f"gán trường: {sx}; var: {var_obj}; .new + [so[1], sx[1]]: {bool(newso)}", "PASS" if not sx and not var_obj and newso else "FAIL",
        "FACT", "tĩnh toàn file", "src034a dòng 923–925")
    rc, out = chay_py("r7_mo_hinh.py")
    m = doc("r7_mo_hinh.json")
    ok = rc == 0 and m and m["dem"]["FAIL"] == 0 and all(x["bi_phat_hien"] for x in m["doi_chung_am"])
    ghi("R7-03", "R-7", "Mô hình đối chứng độc lập lịch sử từng trường ↔ lịch sử đối tượng: tăng/giảm, na, thiếu dữ liệu, nhiều cập nhật trong nến, đổi liên tiếp, giữ nguyên, chuyển đổi, "
        "khởi tạo/kết thúc; lịch sử + realtime (rollback); MTF trễ/khoảng; 2 đối chứng âm (sửa sau khi vào lịch sử, tái sử dụng đối tượng)",
        "0 sai khác; đối chứng âm bị phát hiện", m["dem"] if m else out, "PASS" if ok else "FAIL", "FACT (mô hình) / ASSUMPTION (mô hình thực thi Pine)", "r7_mo_hinh.py", "ket_qua034a_nt/r7_mo_hinh.json")
    e1 = [i + 1 for i, l in enumerate(L34) if re.match(r"^if na\((sM15|xM15|sH1|xH1|sH4|xH4|sD|xD)\)$", l)]
    ghi("R7-04", "R-7", "Nến khung đầu (so[1] = na): thay bằng f_empty()/f_emptyX() trước mọi lần đọc trường (R10) cho cả 8 đối tượng", "8 lệnh thay, đặt ngay sau request.security",
        e1, "PASS" if len(e1) == 8 and all(l < 970 for l in e1) else "FAIL", "FACT", "tĩnh", "src034a dòng 951–966")
    # ======================= R-8 / đường ghi
    sites = {}
    for x in ("mK", "mR", "qK", "qR", "qHas", "mHas"):
        sites[x] = sorted({re.match(r"^(f_\w+)", "") and "" or next((L34[j].split("(")[0] for j in range(i, -1, -1) if re.match(r"^f_\w+\(", L34[j])), "?")
                           for i, l in enumerate(L34) if re.search(rf"(array|map)\.(push|set|remove|insert|clear|shift|pop|unshift|put)\({x}\b", re.sub(r"//.*$", "", l))})
    ok = sites["mK"] == sites["mR"] == sites["mHas"] == ["f_mAddSt", "f_mRemove"] and sites["qK"] == sites["qR"] == sites["qHas"] == ["f_qPush", "f_qRemove"]
    ghi("R8-01", "R-8", "Mọi lệnh ghi mK/mR/mHas chỉ trong f_mAddSt/f_mRemove; mọi lệnh ghi qK/qR/qHas chỉ trong f_qPush/f_qRemove (không đường nào bỏ qua đồng bộ)",
        "đúng 2 hàm mỗi nhóm", sites, "PASS" if ok else "FAIL", "FACT", "tĩnh", "ket_qua034a_nt/duong_ghi_R8.txt")
    goi = []
    for fn in ("f_mRemove", "f_mEnd", "f_qRemove", "f_evEnd", "f_evFlag", "f_qPush", "f_mAddSt", "f_bufPush", "f_bufClear", "f_pClear", "f_cnt", "f_qStream", "f_qStreamPrev", "f_mBoot"):
        for i, l in enumerate(L34):
            c = re.sub(r"//.*$", "", l)
            if re.search(rf"\b{fn}\(", c) and not c.startswith(fn + "(") and not re.match(rf"^\s*{fn}\(.*\)\s*$", c):
                goi.append((fn, i + 1))
    ghi("RET-01", "R-5/R-6/R-8", "Giá trị trả về của hàm thủ tục (khác kiểu giữa hai bản: int ↔ MRec/ERec) không được nơi gọi nào dùng", "0 lời gọi dùng giá trị trả về",
        goi, "PASS" if not goi else "FAIL", "FACT", "tĩnh", "—")
    tt_rc, out = chay_py("trang_thai_suy_giam.py")
    tt = doc("trang_thai_suy_giam.json")
    ghi("A08-SG", "A-08", "Suy giảm/phục hồi: mất 1/2/6/48 M15; H1 dừng 191/192/193 (ngưỡng BUF_CAP); H1 chờ L-1; sổ đầy", "9/9",
        tt["dem"] if tt else out, "PASS" if tt_rc == 0 and tt and tt["dem"]["FAIL"] == 0 else "FAIL", "FACT (trình thông dịch)", "trang_thai_suy_giam.py", "ket_qua034a_nt/trang_thai_suy_giam.json")
    # ======================= A-08 tĩnh
    puts = [(i + 1, l.strip()[:50]) for i, l in enumerate(L34) if "map.put(mDead" in l]
    chuyen = []
    for ln, _ in puts:
        ind = len(L34[ln - 1]) - len(L34[ln - 1].lstrip())
        # đầu vòng lặp bao quanh (thụt lề nhỏ hơn) – hoặc đầu hàm; khóa phải rời sổ/hàng đợi trong cùng lượt lặp, trước hoặc ngay sau lệnh ghi
        j = ln - 2
        while j > 0 and not (re.match(r"^\s*for i = ", L34[j]) and len(L34[j]) - len(L34[j].lstrip()) < ind) and not re.match(r"^f_\w+\(", L34[j]):
            j -= 1
        win = "\n".join(L34[j:ln + 2])
        chuyen.append(bool(re.search(r"f_mRemove\(i\)|f_qRemove\(i\)", win)))
    nhan = [i + 1 for i, l in enumerate(L34) if re.search(r"array\.push\(qK, k\)|^\s+f_mAddSt\(k, side", l)]
    slot = all("f_slot()" in "\n".join(L34[d - 4:d]) for d in nhan)
    clears = [i + 1 for i, l in enumerate(L34) if re.search(r"map\.(clear|remove)\(mDead", l)]
    ghi("A08-01", "A-08", "map.put(mDead) chỉ chuyển khóa (khóa rời sổ/hàng đợi cùng đoạn mã); đường nhận khóa mới qua f_slot(); không xóa mDead (không FIFO/tuổi)",
        "4/4 chuyển; nhận có f_slot; 0 xóa", f"put {puts} chuyển {chuyen}; nhận {nhan} f_slot {slot}; xóa mDead {clears}",
        "PASS" if all(chuyen) and len(puts) == 4 and slot and not clears else "FAIL", "FACT", "tĩnh", "KIEM_KE_TAI_NGUYEN_0.3.4a.csv")
    st = jl("stress_a08_xau10k.jsonl") or []
    st += jl("stress_a08_ngan.jsonl") or []
    bd = doc("bench_dai.json")
    if not st:
        ghi("A08-ST", "A-08", "Stress nguyên văn MD-5 (trình thông dịch)", "có kết quả", "thiếu", "NOT TESTED", "—", "stress_a08.py", "—")
    else:
        bad = [(r["ma"], r["kich_ban"], r["n"], r["loi_bat_bien"][:1], r["loi_chay"]) for r in st if r["loi_bat_bien"] or r["loi_chay"]]
        ghi("A08-ST", "A-08", "Stress NGUYÊN VĂN MD-5 0.3.4a, bất biến kiểm MỖI nến: " + "; ".join(f"{r['ma']} {r['kich_ban']} {r['nen_chay']} nến" for r in st),
            "0 vi phạm, 0 lỗi chạy, tổng khóa ≤ KEY_CAP, bộ đệm/bộ chờ ≤ 192", f"lỗi {bad}; " + "; ".join(f"{r['ma']}-{r['kich_ban']}: mK≤{r['tai_nguyen']['max_mK']} mDead≤{r['tai_nguyen']['max_mDead']} tổng≤{r['tai_nguyen']['max_tong']}/{r['key_cap']} pR≤{r['tai_nguyen']['max_pR']}" for r in st),
            "PASS" if not bad and all(r["tai_nguyen"]["max_tong"] <= r["key_cap"] and r["tai_nguyen"]["max_pR"] <= 192 and r["tai_nguyen"]["max_bR"] <= 192 for r in st) else "FAIL",
            "FACT (trình thông dịch, KHÔNG phải Pine runtime)", "stress_a08.py", "ket_qua034a_nt/stress_a08_*.jsonl")
    if bd is None:
        ghi("A08-DAI", "A-08", "Lịch sử dài 60k/150k với mất M15 đủ độ dài (mô hình chi phí)", "có kết quả", "thiếu", "NOT TESTED", "—", "bench_dai.py", "—")
    else:
        rr = bd["ket_qua"]
        ok = all(r["tong_khoa_max"] <= r["cap_khoa"] and r["tai_nguyen"]["max_buf"] <= 192 and r["tai_nguyen"]["max_cho"] <= 193 for r in rr) and len(rr) == 4
        ghi("A08-DAI", "A-08", "Mô hình chi phí (Python bám Pine, KHÔNG phải Pine/Profiler): 60k/150k nến, mất M15 1/2/6/12/48/191/192/193 lặp lại, XAU/BTC",
            "tổng khóa ≤ ngưỡng; bộ đệm ≤ 192; bộ chờ ≤ 193 trong nến", "; ".join(f"{r['ma']} {r['n_m15']}: mDead {r['tai_nguyen']['max_mDead']} ({r['mDead_moi_nen_m15']}/nến), mK≤{r['tai_nguyen']['max_mK']}, đồng bộ lại {r['dem']['dong_bo_lai']}" for r in rr),
            "PASS" if ok else "FAIL", "FACT (mô hình)", "bench_dai.py", "ket_qua034a_nt/bench_dai.json")
    # ======================= độ phủ
    dp = doc("do_phu_md5.json")
    if dp is None:
        ghi("COV-01", "Độ phủ", "Độ phủ dòng vùng MD-5", "có", "thiếu", "NOT TESTED", "—", "do_phu.py", "—")
    else:
        chua = [l for l, _ in dp["chua_chay"]]
        ok = dp["ty_le"] >= 99.0 and set(chua) <= {2354}
        ghi("COV-01", "Độ phủ", "Độ phủ dòng vùng MD-5 0.3.4a (kịch bản + vòng đời); chỉ được phép thiếu dòng phòng vệ không đạt tới (2354)", "≥ 99 %, thiếu ⊆ {2354}",
            f"{dp['da_chay']}/{dp['tong_cau_lenh']} = {dp['ty_le']} %; chưa chạy {dp['chua_chay']}", "PASS" if ok else "FAIL", "FACT", "do_phu.py", "ket_qua034a_nt/do_phu_md5.json")
    # ======================= tác động, token, lint
    mt = json.load(open(os.path.join(OUT, "ma_tran_tac_dong.json"), encoding="utf-8")) if os.path.exists(os.path.join(OUT, "ma_tran_tac_dong.json")) else None
    if mt:
        ngoai = [(r["muc"], r["dinh_danh_R5_R6_R8"]) for r in mt["muc"] if r["dinh_danh_R5_R6_R8"] and not r["muc"].startswith("11b") and r["dinh_danh_R5_R6_R8"] != ["eR"]]
        md5_xuoi = [(r["muc"], r["doc_md5"]) for r in mt["muc"] if r["doc_md5"] and not r["muc"].startswith(("11b", "12.", "13."))]
        ghi("IMP-01", "Tác động", "R-5/R-6/R-8 chỉ trong MD-5 (dashboard chỉ đọc array.size(eR)); MD-4, pipeline P0–P8/S1/S2a/SIG/EXE/PORT/SU-1 không đọc đầu ra MD-5",
            "đúng", f"ngoài MD-5: {ngoai}; đọc đầu ra MD-5 ngoài hiển thị: {md5_xuoi}", "PASS" if not ngoai and not md5_xuoi else "FAIL", "FACT", "ma_tran_tac_dong.py", "ket_qua034a_nt/ma_tran_tac_dong.json")
    lint = [(i + 1, l.strip()) for i, l in enumerate(L34) if not l.strip().startswith("//") and re.search(r"(\)|\])\.\w+\s*:=", re.sub(r"\s*//.*$", "", l))]
    ghi("LINT-01", "Compile", "Không còn mẫu gây CE10137 (gán trường lên kết quả gọi hàm)", "0", lint, "PASS" if not lint else "FAIL", "FACT", "tĩnh", "—")
    ghi("TV-01", "TradingView", "Compile 0.3.4a", "bằng chứng", "Chủ dự án xác nhận compile thành công (14/11/2026). Không có số token biên dịch.", "PASS", "FACT (xác nhận chủ dự án)", "—", "tin nhắn chủ dự án")
    for tid, mtv in (("TV-02", "Số compiled token thực tế (TradingView không hiển thị khi dưới giới hạn)"), ("TV-03", "Runtime XAUUSD/BTCUSD trên biểu đồ thật"), ("TV-04", "Replay/Bar Replay"),
                     ("TV-05", "Reload/realtime – no-repaint thực tế"), ("TV-06", "Profiler – thời gian/bộ nhớ thật theo khối"), ("TV-07", "CSV XAUUSD/BTCUSD thật – parity Pine ↔ mô hình"),
                     ("TV-08", "Hành vi timeframe.change / trễ khung lớn thật (L-1)"), ("TV-09", "Ngữ nghĩa runtime của lịch sử đối tượng [so[1]] trên TradingView (đã có tài liệu chính thức; chưa có quan sát runtime)")):
        ghi(tid, "TradingView", mtv, "bằng chứng TradingView", "BLOCKED – không có quyền truy cập môi trường TradingView", "BLOCKED", "—", "—", "—")
    # ======================= hồi quy cũ
    if "--hoi-quy" in sys.argv:
        env = dict(os.environ, ATA_F034_PATH=F34A)
        r = subprocess.run([sys.executable, os.path.join(G, "kiem_toan034", "chay_034.py")], cwd=G, env=env, capture_output=True, text=True, timeout=5000)
        kj = json.load(open(os.path.join(G, "ket_qua034a", "kiem_thu_034a.json"), encoding="utf-8"))
        bat_buoc = kj["fail_bat_buoc"]
        ghi("REG-ALL", "Hồi quy", "Toàn bộ bộ kiểm 0.3.4/0.3.4a (tương đương 0.3.3a R-5..R-8, đột biến, nến đầu, A-08 tĩnh, hồi quy 0.3.1→0.3.3a 47 test, L-1/D-1/D-2/SU-1 39 test)",
            "0 FAIL bắt buộc", f"{kj['dem']}; FAIL bắt buộc {bat_buoc}; TOK-02 (mục tiêu dư địa 10–15 % của nhiệm vụ trước) báo riêng; mã thoát {r.returncode}",
            "PASS" if not bat_buoc and r.returncode in (0, 2) else "FAIL", "FACT", "kiem_toan034/chay_034.py", "ket_qua034a/, hoi_quy034/results/ket_qua_test_034a.*")
    else:
        ghi("REG-ALL", "Hồi quy", "Toàn bộ bộ kiểm cũ", "chạy với --hoi-quy", "không chạy lần này", "NOT TESTED", "—", "—", "—")
    dem = {k: sum(1 for r in KQ if r["ket_qua"] == k) for k in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")}
    code = 1 if dem["FAIL"] else (2 if dem["BLOCKED"] + dem["NOT TESTED"] else 0)
    with open(os.path.join(OUT, "TEST_MATRIX_NGHIEM_THU_0.3.4a.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(KQ[0].keys())); w.writeheader(); w.writerows(KQ)
    with open(os.path.join(OUT, "TEST_RUN_LOG_NGHIEM_THU_0.3.4a.txt"), "w", encoding="utf-8") as f:
        f.write("NGHIỆM THU BUILD 0.3.4a – nhật ký\n" + "\n".join(LOG) + f"\n\nTỔNG: {dem}\nMÃ THOÁT: {code}\nThời gian: {round(time.time() - t0)} s\n")
    json.dump(dict(dem=dem, ma_thoat=code, sha256_034a=h34, ket_qua=KQ), open(os.path.join(OUT, "nghiem_thu_034a.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(dem, "mã thoát", code)
    sys.exit(code)


if __name__ == "__main__":
    main()
