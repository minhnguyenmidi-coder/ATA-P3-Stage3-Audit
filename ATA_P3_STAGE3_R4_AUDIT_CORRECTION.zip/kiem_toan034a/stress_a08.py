# -*- coding: utf-8 -*-
"""STRESS A-08 trên NGUYÊN VĂN mã MD-5 của 0.3.4a (trình thông dịch Pine thu gọn – KHÔNG phải TradingView runtime/Profiler).
Bất biến kiểm MỖI nến. Dữ liệu giả lập XAU (σ 1,3) / BTC (σ 3,0), hạt giống cố định. Chạy: python3 stress_a08.py [ngan|dai]"""
import json, os, sys, time
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import md5_song_song as SS
OUT = os.path.join(G, "ket_qua034a_nt")
che_do = sys.argv[1] if len(sys.argv) > 1 else "ngan"
if che_do == "ngan":
    # XAU lien_tuc 10000 đã chạy riêng (stress_a08_xau10k.jsonl)
    VIEC = [("BTC", "lien_tuc", 10000), ("XAU", "mat_M15", 6000), ("BTC", "H1_dung", 6000), ("XAU", "sat_nguong_khoa", 6000), ("BTC", "tong_hop", 6000)]
else:
    VIEC = [("XAU", "lien_tuc", 60000), ("XAU", "mat_M15", 150000)]
jl = os.path.join(OUT, f"stress_a08_{che_do}.jsonl"); open(jl, "w").close()
for ma, kb, n in VIEC:
    r = SS.chay(kb, n, 21, so_sanh=False, ghi_moc=1000, ma=ma)
    r["ma"] = ma
    moc = r["moc"]
    if len(moc) >= 4:
        (x1, y1, *_), (x2, y2, *_) = moc[len(moc) // 4], moc[-1]
        r["mDead_moi_nen"] = round((y2 - y1) / max(1, x2 - x1), 4)
    open(jl, "a").write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
    print(ma, kb, n, "nến", r["nen_chay"], "bb", len(r["loi_bat_bien"]), "lỗi", r["loi_chay"], r["tai_nguyen"], r["dem"], r.get("mDead_moi_nen"), r["us_moi_nen_034a"], r["thoi_gian_s"], "s", flush=True)
