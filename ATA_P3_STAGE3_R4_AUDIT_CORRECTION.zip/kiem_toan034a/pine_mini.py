# -*- coding: utf-8 -*-
"""
TRÌNH THÔNG DỊCH PINE THU GỌN (chỉ phần cú pháp mà vùng MD-5 dùng) – dùng để CHẠY NGUYÊN VĂN mã nguồn Pine
của 0.3.3a và 0.3.4a trên cùng đầu vào và so trạng thái. KHÔNG phải TradingView runtime.

Ngữ nghĩa Pine v6 được mô phỏng (nguồn: tài liệu TradingView, xem báo cáo):
  * đối tượng (UDT), array, map gán theo THAM CHIẾU (FACT – trang Objects: "objects are assigned by reference")
  * and/or đánh giá lười (FACT – migration v6)
  * for: điều kiện dừng đánh giá lại trước MỖI vòng (FACT – migration v6); chiều lặp xác định từ giá trị đầu (ASSUMPTION)
  * bool không bao giờ na (FACT – migration v6); trường bool mặc định false; trường khác mặc định na
  * na lan truyền qua số học; so sánh với na → false (ASSUMPTION theo hành vi Pine đã biết)
  * thứ tự ưu tiên: [] > unary(+,-,not) > * / % > + - > < <= > >= > == != > and > or > ?: (FACT – trang Operators)
  * truy cập trường của đối tượng na, chỉ số mảng ngoài phạm vi → LỖI (dừng chạy, để phát hiện lỗi chỉ số)
  * biến var khởi tạo một lần; khai báo không var chạy lại mỗi lần thực thi
"""
import re

NA = None


class PineErr(Exception):
    pass


class Brk(Exception):
    pass


class Cont(Exception):
    pass


class PArr:
    __slots__ = ("v",)

    def __init__(self, v=None):
        self.v = [] if v is None else v


class PMap:
    __slots__ = ("d",)

    def __init__(self):
        self.d = {}


class PObj:
    __slots__ = ("t", "f")

    def __init__(self, t, f):
        self.t = t
        self.f = f


# ------------------------------------------------------------------ tokenizer
TOK = re.compile(r'\s*(?:(?P<num>\d+\.\d*(?:e[+-]?\d+)?|\d+e[+-]?\d+|\d+)|(?P<str>"(?:[^"\\]|\\.)*")|(?P<id>[A-Za-z_]\w*)|(?P<op>:=|\+=|-=|\*=|/=|==|!=|<=|>=|=>|[-+*/%<>=?:()\[\],.]))')


def tokens(s):
    out, i = [], 0
    s = s.rstrip()
    while i < len(s):
        m = TOK.match(s, i)
        if not m or m.end() == i:
            if s[i:].strip() == "":
                break
            raise PineErr("không tách được token: " + s[i:i + 30])
        i = m.end()
        k = m.lastgroup
        out.append((k, m.group(k)))
    return out


# ------------------------------------------------------------------ expression parser (Pratt)
PREC = {"or": 1, "and": 2, "==": 3, "!=": 3, "<": 4, "<=": 4, ">": 4, ">=": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6}


class P:
    def __init__(self, toks):
        self.t = toks
        self.i = 0

    def peek(self, k=0):
        j = self.i + k
        return self.t[j] if j < len(self.t) else (None, None)

    def eat(self, v=None):
        tk = self.peek()
        if v is not None and tk[1] != v:
            raise PineErr(f"mong '{v}', gặp {tk} trong {self.t}")
        self.i += 1
        return tk

    def expr(self):
        c = self.binop(1)
        if self.peek()[1] == "?":
            self.eat("?")
            a = self.expr()
            self.eat(":")
            b = self.expr()
            return ("tern", c, a, b)
        return c

    def binop(self, minp):
        left = self.unary()
        while True:
            op = self.peek()[1]
            if op in PREC and PREC[op] >= minp and self.peek()[0] in ("op", "id"):
                self.eat()
                right = self.binop(PREC[op] + 1)
                left = ("bin", op, left, right)
            else:
                return left

    def unary(self):
        tk = self.peek()
        if tk[1] == "not":
            self.eat()
            return ("not", self.unary())
        if tk[1] == "-" and tk[0] == "op":
            self.eat()
            return ("neg", self.unary())
        if tk[1] == "+" and tk[0] == "op":
            self.eat()
            return self.unary()
        return self.postfix(self.atom())

    def atom(self):
        k, v = self.eat()
        if k == "num":
            return ("lit", float(v) if ("." in v or "e" in v) else int(v))
        if k == "str":
            return ("lit", bytes(v[1:-1], "utf-8").decode("unicode_escape") if "\\" in v else v[1:-1])
        if v == "(":
            e = self.expr()
            self.eat(")")
            return e
        if v == "[":
            items = [self.expr()]
            while self.peek()[1] == ",":
                self.eat()
                items.append(self.expr())
            self.eat("]")
            return ("tuple", items)
        if k == "id":
            if v in ("true", "false"):
                return ("lit", v == "true")
            if v == "na" and self.peek()[1] != "(":
                return ("lit", NA)
            name = v
            while self.peek()[1] == "." and self.peek(1)[0] == "id":
                self.eat(".")
                name += "." + self.eat()[1]
            if self.peek()[1] == "<" and name.endswith(".new"):      # array.new<int>( / map.new<string, bool>(
                depth = 0
                while True:
                    t = self.eat()[1]
                    if t == "<":
                        depth += 1
                    elif t == ">":
                        depth -= 1
                        if depth == 0:
                            break
            return ("name", name)
        raise PineErr(f"atom lạ {k} {v}")

    def postfix(self, e):
        while True:
            v = self.peek()[1]
            if v == "(":
                self.eat()
                args, kw = [], {}
                if self.peek()[1] != ")":
                    while True:
                        if self.peek()[0] == "id" and self.peek(1)[1] == "=":
                            n = self.eat()[1]
                            self.eat("=")
                            kw[n] = self.expr()
                        else:
                            args.append(self.expr())
                        if self.peek()[1] == ",":
                            self.eat()
                            continue
                        break
                self.eat(")")
                e = ("call", e, args, kw)
            elif v == "." and self.peek(1)[0] == "id":
                self.eat()
                e = ("field", e, self.eat()[1])
            elif v == "[":
                self.eat()
                ix = self.expr()
                self.eat("]")
                e = ("hist", e, ix)
            else:
                return e


def parse_expr(toks):
    p = P(toks)
    e = p.expr()
    if p.i != len(toks):
        raise PineErr(f"thừa token {toks[p.i:]}")
    return e


# ------------------------------------------------------------------ statement parser
TYPEKW = {"int", "float", "bool", "string", "color", "label", "line", "box", "table"}


def strip_comment(l):
    out, ins = "", False
    for i, c in enumerate(l):
        if c == '"':
            ins = not ins
        if not ins and l[i:i + 2] == "//":
            break
        out += c
    return out.rstrip()


def logical_lines(src_lines, base_line=1):
    """(số dòng, thụt lề, nội dung) – gộp dòng tiếp nối (thụt lề không chia hết cho 4)."""
    out = []
    for n, raw in enumerate(src_lines):
        l = strip_comment(raw)
        if not l.strip():
            continue
        ind = len(l) - len(l.lstrip())
        if ind % 4 != 0 and out:
            out[-1] = (out[-1][0], out[-1][1], out[-1][2] + " " + l.strip())
            continue
        out.append((base_line + n, ind // 4, l.strip()))
    return out


class Node:
    __slots__ = ("k", "a", "ln")

    def __init__(self, k, a, ln):
        self.k = k
        self.a = a
        self.ln = ln


def parse_block(lines, i, lvl):
    out = []
    while i < len(lines) and lines[i][1] >= lvl:
        ln, ind, s = lines[i]
        if ind > lvl:
            raise PineErr(f"thụt lề lạ dòng {ln}: {s}")
        node, i = parse_stmt(lines, i, lvl)
        if node is not None:
            out.append(node)
    return out, i


def parse_type_tokens(tk, j):
    """Bỏ qua một khai báo kiểu ở vị trí j: int | array<int> | map<string, bool> | TênUDT. Trả về j mới."""
    if tk[j][0] != "id":
        return None
    j += 1
    if j < len(tk) and tk[j][1] == "<":
        d = 0
        while j < len(tk):
            if tk[j][1] == "<":
                d += 1
            elif tk[j][1] == ">":
                d -= 1
                if d == 0:
                    j += 1
                    break
            j += 1
    return j


def parse_stmt(lines, i, lvl):
    ln, ind, s = lines[i]
    tk = tokens(s)
    # type
    if s.startswith("type "):
        name = s.split()[1]
        fields = []
        i += 1
        while i < len(lines) and lines[i][1] > lvl:
            ft = tokens(lines[i][2])
            j = parse_type_tokens(ft, 0)
            fname = ft[j][1]
            ftype = lines[i][2].split()[0]
            dflt = parse_expr(ft[j + 2:]) if j + 1 < len(ft) and ft[j + 1][1] == "=" else None
            fields.append((fname, ftype, dflt))
            i += 1
        return Node("type", (name, fields), ln), i
    # function def
    m = re.match(r"^(\w+)\((.*)\)\s*=>\s*(.*)$", s)
    if m and lvl == 0 and not s.startswith(("if ", "for ", "while ")):
        params = []
        for p in m.group(2).split(","):
            p = p.strip()
            if p:
                params.append(p.split()[-1])
        if m.group(3):
            body = [Node("expr", parse_expr(tokens(m.group(3))), ln)]
            return Node("func", (m.group(1), params, body), ln), i + 1
        body, j = parse_block(lines, i + 1, lvl + 1)
        return Node("func", (m.group(1), params, body), ln), j
    kw = tk[0][1]
    if kw == "if":
        cond = parse_expr(tk[1:])
        body, j = parse_block(lines, i + 1, lvl + 1)
        branches = [(cond, body)]
        els = None
        while j < len(lines) and lines[j][1] == lvl and (lines[j][2] == "else" or lines[j][2].startswith("else if ")):
            if lines[j][2] == "else":
                els, j = parse_block(lines, j + 1, lvl + 1)
                break
            c2 = parse_expr(tokens(lines[j][2])[2:])
            b2, j = parse_block(lines, j + 1, lvl + 1)
            branches.append((c2, b2))
        return Node("if", (branches, els), ln), j
    if kw == "for" and tk[2] == ("id", "in"):
        # 0.3.5: for x in arr (lặp trên bản chụp kích thước đầu vòng; đặc tả Pine: không sửa mảng trong vòng)
        body, j = parse_block(lines, i + 1, lvl + 1)
        return Node("forin", (tk[1][1], parse_expr(tk[3:]), body), ln), j
    if kw == "for":
        # for v = a to b [by s]
        var = tk[1][1]
        assert tk[2][1] == "="
        rest = tk[3:]
        k_to = next(q for q, t in enumerate(rest) if t == ("id", "to"))
        a = parse_expr(rest[:k_to])
        rest2 = rest[k_to + 1:]
        k_by = next((q for q, t in enumerate(rest2) if t == ("id", "by")), None)
        b = parse_expr(rest2[:k_by] if k_by is not None else rest2)
        st = parse_expr(rest2[k_by + 1:]) if k_by is not None else None
        body, j = parse_block(lines, i + 1, lvl + 1)
        return Node("for", (var, a, b, st, body), ln), j
    if kw == "while":
        cond = parse_expr(tk[1:])
        body, j = parse_block(lines, i + 1, lvl + 1)
        return Node("while", (cond, body), ln), j
    if s == "break":
        return Node("break", None, ln), i + 1
    if s == "continue":
        return Node("continue", None, ln), i + 1
    # tuple declaration [a, b] = expr
    if tk[0][1] == "[":
        k_eq = next((q for q, t in enumerate(tk) if t[1] == "="), None)
        if k_eq is None:
            return Node("expr", parse_expr(tk), ln), i + 1
        names = [t[1] for t in tk[1:k_eq - 1] if t[0] == "id"]
        if tk[k_eq + 1:] and tk[k_eq + 1][1] != "=":
            return Node("tdecl", (names, parse_expr(tk[k_eq + 1:])), ln), i + 1
        return Node("expr", parse_expr(tk), ln), i + 1
    # declarations
    j = 0
    isvar = False
    if tk[0][1] in ("var", "varip"):
        isvar = True
        j = 1
    if tk[j][1] == "const":
        j += 1
    # [type] name = expr
    jt = parse_type_tokens(tk, j)
    if jt is not None and jt + 1 < len(tk) and tk[jt][0] == "id" and tk[jt + 1][1] == "=":
        return Node("decl", (tk[jt][1], parse_expr(tk[jt + 2:]), isvar), ln), i + 1
    if tk[j][0] == "id" and len(tk) > j + 1 and tk[j + 1][1] == "=" and "." not in tk[j][1]:
        return Node("decl", (tk[j][1], parse_expr(tk[j + 2:]), isvar), ln), i + 1
    # assignment (name or field)
    for q, t in enumerate(tk):
        if t[1] in (":=", "+=", "-=", "*=", "/=") and t[0] == "op":
            lhs = parse_expr(tk[:q])
            return Node("assign", (lhs, t[1], parse_expr(tk[q + 1:])), ln), i + 1
    return Node("expr", parse_expr(tk), ln), i + 1


def parse_program(src_lines, base_line=1):
    lines = logical_lines(src_lines, base_line)
    body, j = parse_block(lines, 0, 0)
    assert j == len(lines)
    return body


# ------------------------------------------------------------------ interpreter
def num_op(op, x, y):
    if x is NA or y is NA:
        return NA
    if op == "+":
        return x + y
    if op == "-":
        return x - y
    if op == "*":
        return x * y
    if op == "/":
        if isinstance(x, int) and isinstance(y, int) and not isinstance(x, bool):
            return x / y if x % y else x // y
        return x / y
    if op == "%":
        return x % y


def cmp_op(op, x, y):
    if x is NA or y is NA:
        return False
    return {"<": x < y, "<=": x <= y, ">": x > y, ">=": x >= y}[op]


def tostr(x, fmt=None):
    if x is NA:
        return "NaN"
    if isinstance(x, bool):
        return "true" if x else "false"
    if isinstance(x, int):
        return str(x)
    if isinstance(x, float):
        if fmt is not None:
            return f"{x:.2f}"
        if x == int(x) and abs(x) < 1e15:
            return str(int(x))
        return repr(round(x, 10))
    return str(x)


def _aget(a):
    v = a[0].v; i = a[1]
    if i is NA or i < 0 or i >= len(v):
        raise PineErr(f"array.get chỉ số {i} ngoài [0,{len(v)})")
    return v[i]


FAST = {
    "array.get": _aget,
    "array.size": lambda a: len(a[0].v),
    "na": lambda a: a[0] is NA,
    "map.contains": lambda a: a[1] in a[0].d,
    "math.abs": lambda a: NA if a[0] is NA else abs(a[0]),
}


class Interp:
    def __init__(self):
        self.g = {}             # biến toàn cục
        self.varinit = set()    # biến var đã khởi tạo
        self.funcs = {}
        self.types = {}
        self.steps = 0
        self.cov = None         # tập dòng đã thực thi (bật khi đo độ phủ)

    # ---------------- builtins
    def call_builtin(self, name, args, kw):
        if name == "array.new":
            n = args[0] if args else 0
            v = args[1] if len(args) > 1 else NA
            return PArr([v] * n)
        if name == "array.from":
            return PArr(list(args))
        if name.startswith("array."):
            a = args[0]
            if a is NA or not isinstance(a, PArr):
                raise PineErr(f"{name} trên mảng na")
            op = name[6:]
            v = a.v
            if op == "size":
                return len(v)
            if op == "get":
                i = args[1]
                if i is NA or i < 0 or i >= len(v):
                    raise PineErr(f"array.get chỉ số {i} ngoài [0,{len(v)})")
                return v[i]
            if op == "set":
                i = args[1]
                if i is NA or i < 0 or i >= len(v):
                    raise PineErr(f"array.set chỉ số {i} ngoài [0,{len(v)})")
                v[i] = args[2]
                return NA
            if op == "push":
                v.append(args[1])
                return NA
            if op == "remove":
                i = args[1]
                if i is NA or i < 0 or i >= len(v):
                    raise PineErr(f"array.remove chỉ số {i} ngoài [0,{len(v)})")
                return v.pop(i)
            if op == "shift":
                if not v:
                    raise PineErr("array.shift mảng rỗng")
                return v.pop(0)
            if op == "clear":
                v.clear()
                return NA
            if op == "concat":          # 0.3.5b: nối id2 vào id1 (sửa tại chỗ), trả id1
                v.extend(args[1].v)
                return a
            if op == "includes":
                return args[1] in v
            if op == "sort_indices":
                asc = (args[1] if len(args) > 1 else "asc") == "asc"
                idx = list(range(len(v)))
                key = [(x is NA, x if x is not NA else 0) for x in v]
                idx.sort(key=lambda q: key[q], reverse=not asc)
                return PArr(idx)
            raise PineErr("array." + op + " chưa hỗ trợ")
        if name == "map.new":
            return PMap()
        if name.startswith("map."):
            m = args[0]
            op = name[4:]
            if op == "put":
                m.d[args[1]] = args[2]
                return NA
            if op == "remove":
                return m.d.pop(args[1], NA)
            if op == "contains":
                return args[1] in m.d
            if op == "size":
                return len(m.d)
            if op == "get":
                return m.d.get(args[1], NA)
            if op == "clear":
                m.d.clear()
                return NA
            raise PineErr("map." + op)
        if name == "na":
            return args[0] is NA
        if name == "nz":
            return (args[1] if len(args) > 1 else 0) if args[0] is NA else args[0]
        if name == "int":
            return NA if args[0] is NA else int(args[0])
        if name == "float":
            return NA if args[0] is NA else float(args[0])
        if name == "math.abs":
            return NA if args[0] is NA else abs(args[0])
        if name == "math.floor":
            import math as _m
            return NA if args[0] is NA else int(_m.floor(args[0]))
        if name == "math.max":
            return NA if any(x is NA for x in args) else max(args)
        if name == "math.min":
            return NA if any(x is NA for x in args) else min(args)
        if name == "str.tostring":
            return tostr(args[0], args[1] if len(args) > 1 else None)
        if name == "str.startswith":
            return args[0].startswith(args[1])
        raise PineErr("hàm chưa hỗ trợ: " + name)

    # ---------------- expressions
    def ev(self, e, sc):
        k = e[0]
        if k == "name":
            n = e[1]
            for d in reversed(sc):
                if n in d:
                    return d[n]
            g = self.g
            if n in g:
                return g[n]
            return self.ev_name_slow(e, sc)
        if k == "lit":
            return e[1]
        if k == "call":
            fn = e[1]
            args = [self.ev(a, sc) for a in e[2]]
            if fn[0] == "name":
                n = fn[1]
                f = FAST.get(n)
                if f is not None and not e[3]:
                    return f(args)
        return self.ev_slow(e, sc)

    def ev_name_slow(self, e, sc):
        return self.ev_slow(e, sc)

    def ev_slow(self, e, sc):
        k = e[0]
        if k == "lit":
            return e[1]
        if k == "name":
            n = e[1]
            for d in sc:
                if n in d:
                    return d[n]
            if n in self.g:
                return self.g[n]
            if "." in n:
                head, *rest = n.split(".")
                base = None
                for d in sc:
                    if head in d:
                        base = ("v", d[head])
                if base is None and head in self.g:
                    base = ("v", self.g[head])
                if base is not None:
                    o = base[1]
                    for f in rest:
                        if o is NA:
                            raise PineErr(f"truy cập trường .{f} của đối tượng na ({n})")
                        if not isinstance(o, PObj):
                            raise PineErr(f"truy cập trường .{f} trên giá trị không phải đối tượng ({n})")
                        o = o.f.get(f, NA)
                    return o
            if n == "format.mintick":
                return "mintick"
            if n == "order.ascending":
                return "asc"
            if n == "order.descending":
                return "desc"
            raise PineErr("tên chưa định nghĩa: " + n)
        if k == "bin":
            op = e[1]
            if op == "and":
                return bool(self.ev(e[2], sc)) and bool(self.ev(e[3], sc))
            if op == "or":
                return bool(self.ev(e[2], sc)) or bool(self.ev(e[3], sc))
            x = self.ev(e[2], sc)
            y = self.ev(e[3], sc)
            if op == "==":
                return False if (x is NA or y is NA) else x == y
            if op == "!=":
                return False if (x is NA or y is NA) else x != y   # ASSUMPTION: na != x → false (không gặp trong MD-5 với na)
            if op in ("<", "<=", ">", ">="):
                return cmp_op(op, x, y)
            if op == "+" and (isinstance(x, str) or isinstance(y, str)):
                return ("NaN" if x is NA else x) + ("NaN" if y is NA else y)
            return num_op(op, x, y)
        if k == "not":
            return not bool(self.ev(e[1], sc))
        if k == "neg":
            x = self.ev(e[1], sc)
            return NA if x is NA else -x
        if k == "tern":
            return self.ev(e[2], sc) if bool(self.ev(e[1], sc)) else self.ev(e[3], sc)
        if k == "field":
            o = self.ev(e[1], sc)
            if o is NA:
                raise PineErr(f"truy cập trường .{e[2]} của đối tượng na")
            if not isinstance(o, PObj):
                raise PineErr(f"truy cập trường .{e[2]} trên giá trị không phải đối tượng: {o!r}")
            if e[2] not in o.f:
                return NA      # trường không cung cấp trong dữ liệu giả lập → na
            return o.f[e[2]]
        if k == "tuple":
            return tuple(self.ev(x, sc) for x in e[1])
        if k == "call":
            fn = e[1]
            args = [self.ev(a, sc) for a in e[2]]
            kw = {n: self.ev(v, sc) for n, v in e[3].items()}
            if fn[0] == "name":
                n = fn[1]
                if n in self.funcs:
                    return self.call_user(n, args)
                if n.endswith(".new") and n[:-4] in self.types:
                    return self.new_obj(n[:-4], args, kw)
                if n.endswith(".copy") and n[:-5] in self.types:      # bản sao nông (chỉ dùng cho đột biến kiểm độ nhạy)
                    return PObj(args[0].t, dict(args[0].f))
                return self.call_builtin(n, args, kw)
            raise PineErr("gọi hàm dạng lạ")
        if k == "hist":
            raise PineErr("toán tử lịch sử [] không hỗ trợ trong vùng MD-5")
        raise PineErr("biểu thức lạ " + k)

    def new_obj(self, t, args, kw):
        flds = self.types[t]
        f = {}
        for q, (fn, ft, dflt) in enumerate(flds):
            if q < len(args):
                v = args[q]
            elif fn in kw:
                v = kw[fn]
            elif dflt is not None:
                v = self.ev(dflt, [])
            else:
                v = NA
            if ft == "bool" and v is NA:
                v = False
            f[fn] = v
        return PObj(t, f)

    def call_user(self, n, args):
        params, body = self.funcs[n]
        sc = [dict(zip(params, args))]
        return self.run_block(body, sc, ret=True)

    # ---------------- statements
    def run_block(self, body, sc, ret=False):
        last = NA
        sc = sc + [{}] if not ret else sc
        for st in body:
            last = self.run(st, sc)
        return last

    def assign_name(self, n, v, sc):
        for d in reversed(sc):
            if n in d:
                d[n] = v
                return
        if n in self.g:
            self.g[n] = v
            return
        raise PineErr("gán vào tên chưa khai báo: " + n)

    def run(self, st, sc):
        k = st.k
        if self.cov is not None:
            self.cov.add(st.ln)
        if k == "expr":
            return self.ev(st.a, sc)
        if k == "decl":
            n, e, isvar = st.a
            if isvar:
                if not sc:
                    if n not in self.varinit:
                        self.g[n] = self.ev(e, sc)
                        self.varinit.add(n)
                    return NA
                raise PineErr("var trong khối chưa hỗ trợ")
            v = self.ev(e, sc)
            if sc:
                sc[-1][n] = v
            else:
                self.g[n] = v
            return v
        if k == "tdecl":
            names, e = st.a
            v = self.ev(e, sc)
            tgt = sc[-1] if sc else self.g
            for n, x in zip(names, v):
                tgt[n] = x
            return NA
        if k == "assign":
            lhs, op, e = st.a
            v = self.ev(e, sc)
            if lhs[0] == "name" and "." in lhs[1]:
                head, f = lhs[1].rsplit(".", 1)
                lhs = ("field", ("name", head), f)
            if lhs[0] == "name":
                if op != ":=":
                    v = num_op(op[0], self.ev(lhs, sc), v)
                self.assign_name(lhs[1], v, sc)
                return v
            if lhs[0] == "field":
                if lhs[1][0] != "name":
                    raise PineErr(f"CE10137: gán trường lên biểu thức không phải biến (dòng {st.ln})")
                o = self.ev(lhs[1], sc)
                if o is NA:
                    raise PineErr("gán trường của đối tượng na")
                if op != ":=":
                    v = num_op(op[0], o.f.get(lhs[2], NA), v)
                o.f[lhs[2]] = v
                return v
            raise PineErr("vế trái lạ")
        if k == "if":
            branches, els = st.a
            for c, b in branches:
                if bool(self.ev(c, sc)):
                    self.run_block(b, sc)
                    return NA
            if els is not None:
                self.run_block(els, sc)
            return NA
        if k == "for":
            var, a, b, stp, body = st.a
            i = self.ev(a, sc)
            end = self.ev(b, sc)
            if i is NA or end is NA:
                return NA
            step = abs(self.ev(stp, sc)) if stp is not None else 1
            dirn = 1 if i <= end else -1
            guard = 0
            while True:
                end = self.ev(b, sc)          # v6: đánh giá lại điều kiện dừng trước mỗi vòng
                if end is NA or (dirn == 1 and i > end) or (dirn == -1 and i < end):
                    break
                inner = sc + [{var: i}]
                try:
                    for s2 in body:
                        self.run(s2, inner)
                except Cont:
                    pass
                except Brk:
                    break
                i += dirn * step
                guard += 1
                if guard > 10_000_000:
                    raise PineErr("vòng for không dừng")
            return NA
        if k == "forin":
            var, ae, body = st.a
            a = self.ev(ae, sc)
            if a is NA or not isinstance(a, PArr):
                raise PineErr("for…in trên mảng na")
            for x in list(a.v):
                inner = sc + [{var: x}]
                try:
                    for s2 in body:
                        self.run(s2, inner)
                except Cont:
                    pass
                except Brk:
                    break
            return NA
        if k == "while":
            cond, body = st.a
            g = 0
            while bool(self.ev(cond, sc)):
                inner = sc + [{}]
                try:
                    for s2 in body:
                        self.run(s2, inner)
                except Cont:
                    pass
                except Brk:
                    break
                g += 1
                if g > 1_000_000:
                    raise PineErr("while không dừng")
            return NA
        if k == "break":
            raise Brk()
        if k == "continue":
            raise Cont()
        if k == "type":
            self.types[st.a[0]] = st.a[1]
            return NA
        if k == "func":
            self.funcs[st.a[0]] = (st.a[1], st.a[2])
            return NA
        raise PineErr("lệnh lạ " + k)

    def load(self, prog):
        """Đăng ký type/func; trả về danh sách lệnh cấp cao còn lại (chạy mỗi nến)."""
        rest = []
        for st in prog:
            if st.k in ("type", "func"):
                self.run(st, [])
            else:
                rest.append(st)
        return rest

    def bar(self, rest):
        for st in rest:
            self.run(st, [])
