# -*- coding: utf-8 -*-
"""Chỉ số đánh giá – tính RIÊNG cho từng (symbol, setup); không gộp SU-3/SU-5, không gộp XAUUSD/BTCUSD.
Phễu (funnel) từ EVENTS/SIGNALS; hiệu quả từ TRADES đã ĐÓNG (TP1, SL, TIMEOUT). OPEN/NO_FILL chỉ đếm, không vào R."""
import math, random

N_TOI_THIEU = 30      # ASSUMPTION: dưới mức này chỉ báo số liệu, không đưa nhận định


def phieu(events, signals):
    o = {}
    for e in events:
        k = (e["symbol"], e["setup"])
        r = o.setdefault(k, dict(tao=0, armed=0, void=0, het_han=0, gap_bo=0, ket_thuc_khong_su_kien=0, trigger=0, s1_dat=0, bo_quyen=0, bo_khac=0, trung=0))
        et = e["event_type"]
        r["tao"] += et == "CREATED"; r["armed"] += et == "ARMED"; r["void"] += et == "VOID"; r["het_han"] += et == "EXPIRED"
        r["gap_bo"] += et == "SKIP" and e["reason"] == 4; r["ket_thuc_khong_su_kien"] += et == "END_NO_EVENT"
    for s in signals:
        k = (s["symbol"], s["setup"])
        r = o.setdefault(k, dict(tao=0, armed=0, void=0, het_han=0, gap_bo=0, ket_thuc_khong_su_kien=0, trigger=0, s1_dat=0, bo_quyen=0, bo_khac=0, trung=0))
        r["trigger"] += 1
        r["s1_dat"] += s["reason"] == 16
        r["bo_quyen"] += s["reason"] == 15
        r["bo_khac"] += s["reason"] not in (15, 16)
    for k, r in o.items():
        r["ty_le_void"] = r["void"] / r["tao"] if r["tao"] else None
        r["ty_le_het_han"] = r["het_han"] / r["tao"] if r["tao"] else None
        r["ty_le_bo_quyen"] = r["bo_quyen"] / r["trigger"] if r["trigger"] else None
    return o


def hieu_qua(trades, seed=7, n_boot=2000):
    o = {}
    nhom = {}
    for t in trades:
        nhom.setdefault((t["symbol"], t["setup"]), []).append(t)
    for k, ts in nhom.items():
        dong = [t for t in ts if t["outcome"] in ("TP1", "SL", "TIMEOUT")]
        R = [t["r_net"] for t in dong]
        n = len(R)
        thang = [r for r in R if r > 0]; thua = [r for r in R if r <= 0]
        r_ = dict(so_lenh=len(ts), dong=n, mo=sum(t["outcome"] == "OPEN" for t in ts), khong_khop=sum(t["outcome"] == "NO_FILL" for t in ts),
                  win_rate=len(thang) / n if n else None, net_r=sum(R) if n else 0.0, avg_r=sum(R) / n if n else None, expectancy=sum(R) / n if n else None,
                  profit_factor=(sum(thang) / -sum(thua)) if thua and sum(thua) < 0 else (math.inf if thang else None),
                  ty_le_tp1=sum(t["outcome"] == "TP1" for t in dong) / n if n else None, ty_le_sl=sum(t["outcome"] == "SL" for t in dong) / n if n else None,
                  ty_le_timeout=sum(t["outcome"] == "TIMEOUT" for t in dong) / n if n else None,
                  mfe_tb=sum(t["mfe_r"] for t in dong) / n if n else None, mae_tb=sum(t["mae_r"] for t in dong) / n if n else None,
                  giu_tb_nen=sum(t["bars_held"] for t in dong) / n if n else None, xung_dot_cung_nen=sum(t["same_bar_conflict"] for t in dong),
                  du_mau=n >= N_TOI_THIEU)
        if n >= 2:
            rnd = random.Random(seed)
            bs = sorted(sum(rnd.choice(R) for _ in range(n)) / n for _ in range(n_boot))
            r_["expectancy_ci95"] = (bs[int(0.025 * n_boot)], bs[int(0.975 * n_boot) - 1])
        o[k] = r_
    return o
