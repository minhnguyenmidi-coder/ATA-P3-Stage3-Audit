# -*- coding: utf-8 -*-
"""Bộ kiểm thử lõi Shadow Evaluation (ngoài Pine). python3 shadow_eval/kiem_thu_shadow_eval.py → ket_qua_shadow_eval/ket_qua.json
Không đọc/ghi Pine. Dữ liệu dùng ở đây là GIẢ LẬP (SYNTH) – không phải đánh giá hiệu quả SU-3/SU-5."""
import hashlib, json, math, os, random, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import hop_dong as HD        # noqa: E402
import mo_phong_lenh as MP   # noqa: E402
import chi_so as CS          # noqa: E402

OUT = os.path.join(G, "ket_qua_shadow_eval"); os.makedirs(OUT, exist_ok=True)
KQ = []


def rec(tid, nhom, mo, inp, kv, tt, ok, ev="shadow_eval/kiem_thu_shadow_eval.py", res=None):
    r = res or ("PASS" if ok else "FAIL")
    KQ.append(dict(test_id=tid, nhom=nhom, mo_ta=mo, input=inp, expected=kv, actual=tt, result=r, evidence=ev))
    print(f"[{r:10}] {tid} – {mo[:110]}")


def B(rows, t0=0):
    return [dict(t=t0 + 300000 * i, o=o, h=h, l=l, c=c) for i, (o, h, l, c) in enumerate(rows)]


def mirror(bars, p=4000.0):
    return [dict(t=b["t"], o=p - b["o"], h=p - b["l"], l=p - b["h"], c=p - b["c"]) for b in bars]


def gan(a, b, e=1e-9):
    return a is not None and b is not None and abs(a - b) < e


def main():
    # ------------------------------------------------------------------ giả lập lệnh
    sig = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
    bars = B([(1999, 2001, 1998, 2000), (2000, 2004, 1999, 2003), (2003, 2011, 2002, 2009)])
    r = MP.mo_phong(sig, bars, 0)
    rec("SIM-01", "Giả lập", "BUY chạm TP1: thoát tại TP1, R = (TP1 − E)/rủi ro = 2,0; MFE = 2,0; MAE = −0,2", "E 2000, SL 1995, TP1 2010", "TP1, R 2,0, MAE −0,2",
        dict(outcome=r["outcome"], r=r["r_gross"], mfe=r["mfe_r"], mae=r["mae_r"], giu=r["bars_held"]), r["outcome"] == "TP1" and gan(r["r_gross"], 2.0) and gan(r["mfe_r"], 2.0) and gan(r["mae_r"], -0.2) and r["bars_held"] == 2)
    r = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000), (2000, 2003, 1996, 1997), (1997, 1998, 1994, 1995)]), 0)
    rec("SIM-02", "Giả lập", "BUY chạm SL: R = −1, MAE ≤ −1, MFE = 0,6", "nến 2 Low 1994", "SL, −1", dict(o=r["outcome"], r=r["r_gross"], mfe=r["mfe_r"], mae=r["mae_r"]),
        r["outcome"] == "SL" and gan(r["r_gross"], -1.0) and r["mae_r"] <= -1.0 and gan(r["mfe_r"], 0.6))
    bb = B([(1999, 2001, 1998, 2000), (2000, 2012, 1994, 2001)])
    r1 = MP.mo_phong(sig, bb, 0); r2 = MP.mo_phong(sig, bb, 0, MP.Cfg(same_bar="tp_first"))
    rec("SIM-03", "Giả lập", "Một nến chạm cả SL và TP1: quy tắc chính 'SL trước' → −1, đánh dấu xung đột; biến thể độ nhạy 'TP trước' → +2", "High 2012, Low 1994", "SL/−1 và TP1/+2, cờ xung đột",
        dict(chinh=(r1["outcome"], r1["r_gross"], r1["same_bar_conflict"]), nhay=(r2["outcome"], r2["r_gross"])), r1["outcome"] == "SL" and gan(r1["r_gross"], -1) and r1["same_bar_conflict"] and r2["outcome"] == "TP1" and gan(r2["r_gross"], 2))
    r = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000), (1990, 1992, 1988, 1991)]), 0)
    r2 = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000), (2015, 2016, 2014, 2015)]), 0)
    rec("SIM-04", "Giả lập", "Gap: Open vượt SL → thoát tại Open (R = −2,0 < −1); Open vượt TP1 → thoát tại Open (R = +3,0)", "Open 1990 / 2015", "SL −2,0 gap; TP1 +3,0 gap",
        dict(sl=(r["outcome"], r["r_gross"], r["gap_exit"]), tp=(r2["outcome"], r2["r_gross"], r2["gap_exit"])), r["outcome"] == "SL" and gan(r["r_gross"], -2.0) and r["gap_exit"] and r2["outcome"] == "TP1" and gan(r2["r_gross"], 3.0))
    R = random.Random(1); sai = []
    for k in range(500):
        p = 2000.0; rows = [(p, p + 1, p - 1, p)]
        for _ in range(60):
            o = p; c = round(p + R.gauss(0, 2), 2); rows.append((o, round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
        bs = B(rows)
        s = dict(dir=1, p_ref=2000.0, sl=round(2000 - R.uniform(2, 8), 2), tp1=round(2000 + R.uniform(2, 15), 2))
        sm = dict(dir=-1, p_ref=4000 - 2000.0, sl=4000 - s["sl"], tp1=4000 - s["tp1"])
        a, b = MP.mo_phong(s, bs, 0, MP.Cfg(max_bars=40)), MP.mo_phong(sm, mirror(bs), 0, MP.Cfg(max_bars=40))
        if not (a["outcome"] == b["outcome"] and gan(a["r_gross"], b["r_gross"], 1e-7) and gan(a["mfe_r"], b["mfe_r"], 1e-7) and gan(a["mae_r"], b["mae_r"], 1e-7) and a["bars_held"] == b["bars_held"]):
            sai.append(k)
    rec("SIM-05", "Giả lập", "Đối xứng BUY/SELL: 500 đường giá ngẫu nhiên và ảnh gương của chúng (giá → 4000 − giá) cho cùng kết cục, R, MFE, MAE, thời gian giữ", "500 cặp", "0 khác", f"khác {len(sai)}", not sai)
    r = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000)] + [(2000, 2002, 1998, 2001)] * 5), 0, MP.Cfg(max_bars=3))
    r2 = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000)] + [(2000, 2002, 1998, 2001)] * 2), 0, MP.Cfg(max_bars=3))
    rec("SIM-06", "Giả lập", "Hết thời gian giữ (max_bars) → TIMEOUT thoát tại Close nến cuối (R = 0,2); hết dữ liệu trước max_bars → OPEN (không vào thống kê đóng lệnh)", "max_bars 3", "TIMEOUT 0,2; OPEN",
        dict(t=(r["outcome"], r["r_gross"], r["bars_held"]), o=r2["outcome"]), r["outcome"] == "TIMEOUT" and gan(r["r_gross"], 0.2) and r["bars_held"] == 3 and r2["outcome"] == "OPEN")
    r = MP.mo_phong(sig, B([(1999, 2020, 1990, 2000), (2000, 2001, 1999, 2000)] + [(2000, 2001, 1999, 2000)] * 3), 0, MP.Cfg(max_bars=4))
    sai = []
    for k in range(300):
        p = 2000.0; rows = [(p, p + 1, p - 1, p)]
        for _ in range(80):
            o = p; c = round(p + R.gauss(0, 2), 2); rows.append((o, round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
        bs = B(rows); s = dict(dir=R.choice((1, -1)), p_ref=2000.0); s["sl"] = 2000 - s["dir"] * R.uniform(2, 6); s["tp1"] = 2000 + s["dir"] * R.uniform(3, 12)
        a = MP.mo_phong(s, bs, 0, MP.Cfg(max_bars=60))
        if a["outcome"] in ("TP1", "SL", "TIMEOUT"):
            ke = next(i for i, b in enumerate(bs) if b["t"] == a["exit_ts_ms"])
            bs2 = bs[:ke + 1] + [dict(t=b["t"], o=9999.0, h=9999.0, l=1.0, c=5000.0) for b in bs[ke + 1:]]
            b2 = MP.mo_phong(s, bs2, 0, MP.Cfg(max_bars=60))
            if b2 != a:
                sai.append(k)
    rec("SIM-07", "Không nhìn trước", "Không nhìn trước: (a) High/Low của chính nến trigger không được dùng (High 2020 ≥ TP1 ở nến trigger → không tính); (b) 300 đường ngẫu nhiên: thay mọi nến SAU nến thoát bằng giá vô lý → kết quả không đổi",
        "nến trigger chạm TP1; 300 đường", "(a) TIMEOUT; (b) 0 khác", dict(a=r["outcome"], b_khac=len(sai)), r["outcome"] == "TIMEOUT" and not sai)
    r = MP.mo_phong(sig, bars, 0, MP.Cfg(spread=0.3, commission=0.1, slippage=0.05))
    rec("SIM-08", "Giả lập", "Chi phí: r_net = r_gross − (spread + phí + 2×trượt giá)/rủi ro = 2,0 − 0,5/5 = 1,9", "spread 0,3, phí 0,1, trượt 0,05", "1,9", r["r_net"], gan(r["r_net"], 1.9))
    r = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000), (1994, 1996, 1990, 1995), (1995, 2011, 1994, 2010)]), 0, MP.Cfg(entry="next_open"))
    r2 = MP.mo_phong(sig, B([(1999, 2001, 1998, 2000), (2001, 2004, 1999, 2003), (2003, 2011, 2002, 2009)]), 0, MP.Cfg(entry="next_open"))
    rec("SIM-09", "Giả lập", "Biến thể R2 (vào ở Open nến kế): Open đã vượt SL → NO_FILL; Open 2001 → rủi ro 6, TP1 → R = 9/6 = 1,5", "Open 1994 / 2001", "NO_FILL; TP1 1,5",
        dict(a=r["outcome"], b=(r2["outcome"], r2["r_gross"], r2["risk"])), r["outcome"] == "NO_FILL" and r2["outcome"] == "TP1" and gan(r2["r_gross"], 1.5))
    sai = []
    for k in range(2000):
        p = 2000.0; rows = [(p, p + 1, p - 1, p)]
        for _ in range(50):
            o = p + R.choice((0, 0, 0, R.gauss(0, 3))); c = round(o + R.gauss(0, 2), 2); rows.append((round(o, 2), round(max(o, c) + abs(R.gauss(0, 1)), 2), round(min(o, c) - abs(R.gauss(0, 1)), 2), c)); p = c
        bs = B(rows); d = R.choice((1, -1)); s = dict(dir=d, p_ref=2000.0, sl=2000 - d * R.uniform(1, 6), tp1=2000 + d * R.uniform(1, 12) if R.random() < 0.9 else None)
        a = MP.mo_phong(s, bs, 0, MP.Cfg(max_bars=R.choice((5, 20, 40)), same_bar=R.choice(("sl_first", "tp_first"))))
        ok = a["mfe_r"] >= 0 and a["mae_r"] <= 0 and a["mae_r"] - 1e-9 <= a["r_gross"] <= a["mfe_r"] + 1e-9 and a["risk"] > 0
        if a["outcome"] == "SL" and not a["gap_exit"]:
            ok = ok and gan(a["r_gross"], -1.0)
        if a["outcome"] == "TP1" and not a["gap_exit"]:
            ok = ok and gan(a["r_gross"], (s["tp1"] - 2000.0) * d / a["risk"])
        if s["tp1"] is None:
            ok = ok and a["outcome"] != "TP1"
        if not ok:
            sai.append((k, a["outcome"]))
    rec("SIM-10", "Nhất quán R/MFE/MAE", "2.000 đường ngẫu nhiên (có gap, có TP1 = na, đủ biến thể): MFE ≥ 0, MAE ≤ 0, MAE ≤ R ≤ MFE; SL không gap → R = −1; TP1 không gap → R đúng công thức; TP1 = na không bao giờ ra TP1",
        "2000 đường", "0 vi phạm", f"vi phạm {len(sai)} {sai[:3]}", not sai)
    # ------------------------------------------------------------------ khử trùng / chồng lấn
    sg = [dict(signal_id=f"s{i}", trigger_ts_ms=t, dup_key=k) for i, (t, k) in enumerate([(1, "a"), (1, "a"), (2, "b"), (1, "c"), (3, "a")])]
    g, n = MP.khu_trung(sg)
    rec("DUP-01", "Trùng / chồng lấn", "Khử trùng theo dup_key (symbol, setup, chiều, nến trigger) – IP-21: giữ tín hiệu đầu tiên, loại bản trùng", "5 tín hiệu, 2 trùng khóa 'a'", "giữ 3 khóa, loại 2", ([x["signal_id"] for x in g], n),
        n == 2 and sorted({x["dup_key"] for x in g}) == ["a", "b", "c"])
    tr = [dict(symbol="XAUUSD", setup="SU5", entry_ts_ms=1, exit_ts_ms=10), dict(symbol="XAUUSD", setup="SU5", entry_ts_ms=5, exit_ts_ms=12), dict(symbol="XAUUSD", setup="SU3", entry_ts_ms=5, exit_ts_ms=9),
          dict(symbol="BTCUSD", setup="SU5", entry_ts_ms=5, exit_ts_ms=8), dict(symbol="XAUUSD", setup="SU5", entry_ts_ms=11, exit_ts_ms=20)]
    g, n = MP.khong_chong(tr)
    rec("DUP-02", "Trùng / chồng lấn", "Biến thể danh mục không chồng lấn: mỗi (symbol, setup) chỉ 1 lệnh mở; không chặn chéo giữa SU-3/SU-5 hay XAUUSD/BTCUSD", "5 lệnh", "bỏ đúng 1 (XAU SU5 vào lúc 5)",
        ([(x["symbol"], x["setup"], x["entry_ts_ms"]) for x in g], n), n == 1 and ("XAUUSD", "SU5", 5) not in [(x["symbol"], x["setup"], x["entry_ts_ms"]) for x in g])
    # ------------------------------------------------------------------ hợp đồng dữ liệu
    e = dict(schema_version="1.0", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", tf="5", setup="SU5", mode="SHADOW", setup_id=HD.hid("XAUUSD", "SU5", 1, 123), event_id=HD.hid("x", "ARMED", 123),
             event_type="ARMED", ts="2026-01-02T03:05:00Z", ts_ms=1767323100000, dir=1, state=2, reason=0, anchor_price=2000.0, ext_price=5.0)
    bad = dict(e, symbol="EURUSD", ts="2026-01-02 03:05", dir=0, extra=1); del bad["reason"]
    t_ok = dict(schema_version="1.0", signal_id="s", sim_rule="R-close-sl_first-288", cost_model="C-0", entry_ts_ms=1, entry_price=2000.0, risk=5.0, outcome="TP1", exit_ts_ms=2, exit_price=2010.0,
                r_gross=2.0, r_net=1.9, mfe_r=2.0, mae_r=-0.2, bars_held=2, same_bar_conflict=False, gap_exit=False)
    t_bad = dict(t_ok, risk=0.0, mfe_r=-0.1, mae_r=0.3, outcome="WIN")
    l1, l2, l3, l4 = HD.kiem(e, HD.EVENTS), HD.kiem(bad, HD.EVENTS), HD.kiem(t_ok, HD.TRADES), HD.kiem(t_bad, HD.TRADES)
    rec("HD-01", "Hợp đồng dữ liệu", "Bộ kiểm hợp đồng: bản ghi đúng → 0 lỗi; bản ghi sai (symbol lạ, ts sai định dạng, dir = 0, thiếu reason, trường lạ; risk ≤ 0, MFE < 0, MAE > 0, outcome lạ) → báo đủ lỗi",
        "4 bản ghi", "0 / ≥5 / 0 / 4 lỗi", dict(event_dung=l1, event_sai=l2, trade_dung=l3, trade_sai=l4), not l1 and len(l2) >= 5 and not l3 and len(l4) == 4)
    rec("HD-02", "Hợp đồng dữ liệu", "ID xác định: cùng đầu vào → cùng setup_id/event_id/signal_id; khác đầu vào → khác", "băm SHA-1 16 ký tự", "ổn định",
        (HD.hid("XAUUSD", "SU3", 1, 5), HD.hid("XAUUSD", "SU3", 1, 5), HD.hid("XAUUSD", "SU3", -1, 5)), HD.hid("XAUUSD", "SU3", 1, 5) == HD.hid("XAUUSD", "SU3", 1, 5) != HD.hid("XAUUSD", "SU3", -1, 5))
    # ------------------------------------------------------------------ chỉ số
    T = lambda sym, su, o, r: dict(symbol=sym, setup=su, outcome=o, r_net=r, mfe_r=max(r, 0.0) + 0.1, mae_r=min(r, 0.0) - 0.1, bars_held=10, same_bar_conflict=False)  # noqa: E731
    trs = [T("XAUUSD", "SU5", "TP1", 2.0), T("XAUUSD", "SU5", "SL", -1.0), T("XAUUSD", "SU5", "SL", -1.0), T("XAUUSD", "SU5", "TIMEOUT", 0.5), T("XAUUSD", "SU5", "OPEN", 3.0),
           T("BTCUSD", "SU5", "TP1", 1.5), T("XAUUSD", "SU3", "SL", -1.0)]
    h = CS.hieu_qua(trs)
    x = h[("XAUUSD", "SU5")]
    ok = set(h) == {("XAUUSD", "SU5"), ("BTCUSD", "SU5"), ("XAUUSD", "SU3")} and x["dong"] == 4 and x["mo"] == 1 and gan(x["win_rate"], 0.5) and gan(x["net_r"], 0.5) and gan(x["expectancy"], 0.125) and gan(x["profit_factor"], 1.25) and gan(x["ty_le_tp1"], 0.25) and not x["du_mau"]
    ok = ok and x["expectancy_ci95"][0] <= x["expectancy"] <= x["expectancy_ci95"][1]
    rec("CS-01", "Chỉ số", "Chỉ số tách riêng (symbol, setup); chỉ lệnh ĐÓNG vào R (OPEN chỉ đếm): XAU-SU5 → 4 lệnh đóng, win 50 %, Net R 0,5, expectancy 0,125, PF 2,5/2,0 = 1,25, TP1 25 %; dưới 30 lệnh → du_mau = sai; CI 95 % bootstrap chứa expectancy",
        "7 lệnh, 3 nhóm", "như mô tả", {f"{k[0]}-{k[1]}": {kk: v for kk, v in vv.items() if kk in ("dong", "mo", "win_rate", "net_r", "expectancy", "profit_factor", "ty_le_tp1", "du_mau", "expectancy_ci95")} for k, vv in h.items()}, ok)
    evs = [dict(symbol="XAUUSD", setup="SU3", event_type=et, reason=rs) for et, rs in (("CREATED", 0), ("CREATED", 0), ("ARMED", 0), ("VOID", 6), ("EXPIRED", 7), ("END_NO_EVENT", 0))]
    sgs = [dict(symbol="XAUUSD", setup="SU3", reason=r_) for r_ in (16, 15, 8)]
    f = CS.phieu(evs, sgs)[("XAUUSD", "SU3")]
    rec("CS-02", "Chỉ số", "Phễu: tạo → ARMED → trigger → đạt S1 / bỏ do quyền (15) / bỏ khác; tỷ lệ VOID, hết hạn, bỏ do quyền", "6 sự kiện, 3 tín hiệu", "tạo 2, void 0,5, hết hạn 0,5, bỏ quyền 1/3",
        f, f["tao"] == 2 and gan(f["ty_le_void"], 0.5) and gan(f["ty_le_het_han"], 0.5) and gan(f["ty_le_bo_quyen"], 1 / 3) and f["s1_dat"] == 1 and f["ket_thuc_khong_su_kien"] == 1)
    # ------------------------------------------------------------------ đầu-cuối trên khối Pine nguyên văn (pine_mini) + dữ liệu GIẢ LẬP
    try:
        sys.path.insert(0, os.path.join(G, "kiem_toan039"))
        import kiem_cach_ly as CL
        from khung039 import S39, zone
        rr = random.Random(9); n_sig = n_trade = 0; loi = []
        for seed in range(40):
            r2 = random.Random(seed)
            pp = CL.PIPE(S39, True); pp.ctx(r2.choice((1, 2, 3, 4)))
            p = 2000.0
            for _ in range(2):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(2, 8), 1)
                pp.g["zones"].v.append(zone(pp.ip, 60, d, b0 - 2, b0 + 2, bm=pp.T // 60000 - 600, pos=1))
            for _ in range(3):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(1, 6), 1)
                pp.g["zones"].v.append(zone(pp.ip, 15, d, b0 - 1, b0 + 1, bm=pp.T // 60000 + r2.choice((15, 30, 60)), bs=r2.randint(0, 99), pos=1))
            cl = sorted(round(p + r2.uniform(-8, 8), 1) for _ in range(3))
            pp.g.update(cLo=CL.PArr([x_ - 0.4 for x_ in cl]), cHi=CL.PArr([x_ + 0.4 for x_ in cl]), cRank=CL.PArr([r2.randint(1, 5) for _ in cl]))
            bars, sigs = [], []
            for j in range(120):
                o = p; c = round(p + r2.gauss(0, 1.8), 1); h_ = round(max(o, c) + abs(r2.gauss(0, 0.7)), 1); l_ = round(min(o, c) - abs(r2.gauss(0, 0.7)), 1)
                m15 = j % 3 == 0
                bb = dict(o=o, h=h_, l=l_, c=c, m15=m15, ev=r2.choice((0, 0, 1, 2, 3, 4)) if m15 else 0, ref=round(p + r2.uniform(-3, 3), 1),
                          h1=(c, r2.choice((0, 3, 4)), r2.random() < 0.6) if (m15 and j % 12 == 0) else None, pend=False)
                t_ = pp.T
                pp.bar(bb)
                bars.append(dict(t=t_, o=o, h=h_, l=l_, c=c))
                for ev in pp.g["evS"].v:
                    if ev.f["trig"]:
                        su = "SU%d" % ev.f["su"]; sid = HD.hid("XAUUSD", su, ev.f["dir"], ev.f["bosMin"], ev.f["baseMin"])
                        s_ = dict(schema_version="1.0", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", setup=su, setup_id=sid, signal_id=HD.hid(sid, t_), dir=ev.f["dir"],
                                  trigger_ts="2026-01-01T00:00:00Z", trigger_ts_ms=t_, p_ref=float(ev.f["pRef"]), sl=float(ev.f["sl"]),
                                  tp1=None if ev.f["tp1"] is None or ev.f["tp1"] is CL.NA else float(ev.f["tp1"]), rr=None, reason=ev.f["reason"], perm_reg=None, perm_vol=None,
                                  dup_key=f"XAUUSD|{su}|{ev.f['dir']}|{t_}")
                        loi += HD.kiem(s_, HD.SIGNALS)
                        sigs.append((s_, j))
                p = c
            for s_, j in sigs:
                n_sig += 1
                if s_["reason"] != 16:
                    continue
                tr_ = MP.mo_phong(s_, bars, j, MP.Cfg(max_bars=60))
                tr_.update(schema_version="1.0", signal_id=s_["signal_id"], sim_rule=MP.Cfg().rule_id(), cost_model=MP.Cfg().cost_id())
                loi += HD.kiem(tr_, HD.TRADES); n_trade += 1
        rec("E2E-01", "Đầu-cuối (SYNTH)", "Chuỗi đầu-cuối: khối Pine SHADOW nguyên văn (pine_mini, 40 kịch bản giả lập × 120 nến) → bản ghi SIGNALS → giả lập lệnh → bản ghi TRADES; mọi bản ghi qua bộ kiểm hợp đồng",
            "40 kịch bản SYNTH", "có tín hiệu, có lệnh; 0 lỗi hợp đồng", dict(tin_hieu=n_sig, lenh=n_trade, loi=loi[:5]), n_sig > 0 and n_trade > 0 and not loi,
            ev="shadow_eval/kiem_thu_shadow_eval.py + kiem_toan039/kiem_cach_ly.py::PIPE")
    except Exception as ex:      # noqa: BLE001
        rec("E2E-01", "Đầu-cuối (SYNTH)", "Chuỗi đầu-cuối", "—", "—", repr(ex), False)
    # ------------------------------------------------------------------ baseline không bị đụng
    def sha(p):
        return hashlib.sha256(open(os.path.join(G, p), "rb").read()).hexdigest()
    s8 = sha("src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine"); s9 = sha("src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine")
    rec("BL-01", "Bảo vệ baseline", "Source 0.3.8 và 0.3.9 không đổi (lượt này không sửa Pine; bộ đánh giá chỉ đọc)", "SHA", "79793fcf… / 2184d892…", (s8[:16], s9[:16]),
        s8 == "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13" and s9 == "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0")
    # ------------------------------------------------------------------ chưa làm được
    for tid, mo, ly in (("REAL-SU3", "Đánh giá SU-3 trên dữ liệu thật XAUUSD/BTCUSD", "Chưa có dữ liệu OHLCV lịch sử trong môi trường; mạng của công cụ đang tắt"),
                        ("REAL-SU5", "Đánh giá SU-5 trên dữ liệu thật XAUUSD/BTCUSD", "Như trên"),
                        ("REPLAY-EQ", "Tương đương Python replay ↔ TradingView", "Chưa có replay toàn script và chưa có dữ liệu đối chứng từ TradingView"),
                        ("TV-TOKEN", "Token biên dịch thật của 0.3.9", "TradingView không in số token khi compile thành công")):
        rec(tid, "Chưa thực hiện", mo, "—", "—", ly, False, res="BLOCKED")
    dem = {}
    for x in KQ:
        dem[x["result"]] = dem.get(x["result"], 0) + 1
    json.dump(dict(tom_tat=dem, ket_qua=KQ), open(os.path.join(OUT, "ket_qua.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    print(dem)
    sys.exit(1 if dem.get("FAIL") else 0)


if __name__ == "__main__":
    main()
