# -*- coding: utf-8 -*-
"""Đối chiếu các mô hình token với 5 lần compile đã biết (0.3.3 FAIL 101.360; 0.3.3a, 0.3.7, 0.3.8, 0.3.9 PASS). Chỉ là HYPOTHESIS – không phải token biên dịch thật."""
import re,sys,json
sys.path.insert(0,'kiem_toan035'); import khung as K
def toks(s): return re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\S', "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n")))
def model(S):
    L=S.split("\n"); fn={}; body_lines=set()
    for m in re.finditer(r'^(f_\w+)\(', S, re.M):
        name=m.group(1)
        if name in fn: continue
        Lb,b=K.khoi(S,name); fn[name]="\n".join(Lb)
        st=b-1 if b>0 else 0
    # remove function bodies from top-level text
    top=S
    for n,bd in fn.items(): top=top.replace(bd,"",1)
    T=toks(top); FT={n:toks(b) for n,b in fn.items()}
    calls=lambda tk:[t for t in tk if t in fn]
    memo={}
    def size(n,stack=()):
        if n in memo: return memo[n]
        if n in stack: return len(FT[n])
        s=len(FT[n])+sum(size(c,stack+(n,)) for c in calls(FT[n][1:]))
        memo[n]=s; return s
    full=len(T)+sum(size(c) for c in calls(T))
    called=set(calls(T)); 
    # closure of called
    ch=set(); todo=list(called)
    while todo:
        n=todo.pop()
        if n in ch: continue
        ch.add(n); todo+= calls(FT[n][1:])
    once=len(T)+sum(len(FT[n]) for n in ch)        # mỗi hàm được gọi tính 1 lần, hàm không gọi = 0
    lex=len(toks(S))
    fs=size('f_struct')
    sec=lex+7*fs                                       # chỉ nhân f_struct (kèm hàm con) theo 8 lệnh request.security
    return dict(lex=lex, khong_goi=sorted(set(fn)-ch), once=once, sec8=sec, full_inline=full)
import os
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
R={}
for v,p in (('0.3.3','src033/ATA_P3_Build_0.3.3_Candidate_Indicator.pine'),('0.3.3a','src033/ATA_P3_Build_0.3.3a_Candidate_Indicator.pine'),('0.3.7','src037/ATA_P3_Build_0.3.7_Candidate_Indicator.pine'),('0.3.8','src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine'),('0.3.9','src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine')):
    R[v]=model(open(p,encoding='utf-8').read())
OBS={'0.3.3':'FAIL (101.360)','0.3.3a':'PASS','0.3.7':'PASS','0.3.8':'PASS','0.3.9':'PASS'}
for k in ('lex','once','sec8','full_inline'):
    r=101360/R['0.3.3'][k]
    est={v:round(R[v][k]*r) for v in R}
    ok=all((est[v]<=100256)==(OBS[v]!='FAIL (101.360)') for v in R if v!='0.3.3')
    print(k, 'ty_le', round(r,4), est, 'NHẤT QUÁN' if ok else 'MÂU THUẪN', ' du_dia_039', 100256-est['0.3.9'])
print({v:R[v]['khong_goi'] for v in R})
json.dump(R,open('token_budget/mo_hinh_token.json','w'),ensure_ascii=False,indent=1)
