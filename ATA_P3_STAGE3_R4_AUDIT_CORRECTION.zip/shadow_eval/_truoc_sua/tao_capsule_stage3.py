# -*- coding: utf-8 -*-
"""Chuyển gói ATA_P3_Stage3_ShadowEval.zip (đã giải nén) thành các phần văn bản thuần, trích xuất bằng code – không sửa nội dung.
python3 tao_capsule_stage3.py <thư mục kt> <thư mục ra>"""
import hashlib, json, os, sys

ROOT, OUTD = sys.argv[1], sys.argv[2]
os.makedirs(OUTD, exist_ok=True)
J = lambda p: os.path.join(ROOT, p)  # noqa: E731
rd = lambda p: open(J(p), encoding="utf-8").read()  # noqa: E731
sha = lambda p: hashlib.sha256(open(J(p), "rb").read()).hexdigest()  # noqa: E731
LIM = 24000
files = sorted(os.path.relpath(os.path.join(d, f), ROOT) for d, _, fs in os.walk(ROOT) for f in fs)
sums = {l.split("  ", 1)[1].strip().lstrip("./"): l.split("  ", 1)[0] for l in rd("SHA256SUMS.txt").splitlines() if "  " in l}
SEC = []

# 1. mục lục + toàn vẹn
rows = ["| File | Byte | SHA-256 | Khớp SHA256SUMS |", "|---|---|---|---|"]
for f in files:
    ok = "tự tham chiếu (bỏ qua)" if f == "SHA256SUMS.txt" else ("✓" if sums.get(f) == sha(f) else "✗")
    rows.append(f"| {f} | {os.path.getsize(J(f))} | {sha(f)} | {ok} |")
SEC.append(("MỤC LỤC GÓI VÀ KIỂM TOÀN VẸN", "Gói: ATA_P3_Stage3_ShadowEval.zip, thư mục gốc kt/.\n"
            "Ghi chú: dòng của chính SHA256SUMS.txt trong file đó được tính trước khi file ghi xong nên không khớp – mọi file khác khớp.\n"
            "Thứ tự các phần: báo cáo → kết quả test → mô hình token → mã nguồn Python.\n\n" + "\n".join(rows)))

# 2. báo cáo nguyên văn (chia theo mục '## ')
bc = rd("shadow_eval/BAO_CAO_STAGE3_SHADOW_EVAL_TOKEN_BUDGET.md")
SEC.append(("BÁO CÁO (nguyên văn shadow_eval/BAO_CAO_STAGE3_SHADOW_EVAL_TOKEN_BUDGET.md)", bc))

# 3. kết quả test – bảng + chi tiết
kq = json.load(open(J("ket_qua_shadow_eval/ket_qua.json"), encoding="utf-8"))
t = [f"Nguồn: ket_qua_shadow_eval/ket_qua.json · tóm tắt {json.dumps(kq['tom_tat'], ensure_ascii=False)}", "", "| ID | Nhóm | Kết quả | Nội dung |", "|---|---|---|---|"]
for x in kq["ket_qua"]:
    t.append(f"| {x['test_id']} | {x['nhom']} | {x['result']} | {x['mo_ta'].replace('|', '/')} |")
t.append("\nCHI TIẾT TỪNG TEST (input / kỳ vọng / thực tế / bằng chứng – nguyên văn JSON):")
for x in kq["ket_qua"]:
    t.append(f"\n[{x['test_id']}] {x['result']}\n  Input: {json.dumps(x['input'], ensure_ascii=False, default=str)}\n  Kỳ vọng: {json.dumps(x['expected'], ensure_ascii=False, default=str)}\n"
             f"  Thực tế: {json.dumps(x['actual'], ensure_ascii=False, default=str)}\n  Bằng chứng: {x['evidence']}")
SEC.append(("KẾT QUẢ TEST", "\n".join(t)))

# 4. mô hình token
SEC.append(("MÔ HÌNH TOKEN (token_budget/) – HYPOTHESIS, không phải token biên dịch thật",
            "token_budget/ket_qua_mo_hinh.txt:\n" + rd("token_budget/ket_qua_mo_hinh.txt") + "\ntoken_budget/mo_hinh_token.json:\n" + rd("token_budget/mo_hinh_token.json")))

# 5. mã nguồn
for f in ("shadow_eval/hop_dong.py", "shadow_eval/mo_phong_lenh.py", "shadow_eval/chi_so.py", "shadow_eval/kiem_thu_shadow_eval.py", "token_budget/mo_hinh_token.py"):
    SEC.append((f"MÃ NGUỒN {f} (SHA {sha(f)[:16]}…, nguyên văn)", "```python\n" + rd(f) + "```"))


def tach(title, body):
    """Chia phần dài theo ranh giới mục '## ' (báo cáo), dòng trống giữa hàm (mã) – không cắt giữa bảng/khối mã."""
    if len(body) <= LIM:
        return [(title, body)]
    is_code = body.startswith("```")
    inner = body[len("```python\n"):-3] if is_code else body
    lines = inner.split("\n")
    out, cur, n = [], [], 0
    for i, ln in enumerate(lines):
        biên = (ln.startswith("## ") if not is_code else (ln.startswith("def ") or ln.startswith("class ") or (ln.startswith("    # ----") and len(ln) > 40)))
        in_table = cur and cur[-1].startswith("|")
        if biên and n > LIM * 0.55 and not in_table:
            out.append(cur); cur, n = [], 0
        cur.append(ln); n += len(ln) + 1
    out.append(cur)
    res = []
    for k, c in enumerate(out, 1):
        txt = "\n".join(c)
        res.append((f"{title} – đoạn {k}/{len(out)}", ("```python\n" + txt + "\n```") if is_code else txt))
    return res


chunks = [c for s in SEC for c in tach(*s)]
parts, cur = [], []
for title, body in chunks:
    ch = f"=== {title} ===\n{body}\n"
    if cur and sum(len(x) for x in cur) + len(ch) > LIM:
        parts.append(cur); cur = []
    cur.append(ch)
parts.append(cur)
N = len(parts)
for i, p in enumerate(parts, 1):
    hdr = (f"ATA P3 STAGE 3 – SHADOW EVALUATION & TOKEN BUDGET – PART {i}/{N}\n"
           "Trích xuất tự động bằng shadow_eval/tao_capsule_stage3.py từ ATA_P3_Stage3_ShadowEval.zip – không sửa nội dung.\n"
           "Baseline chỉ đọc: 0.3.8 SHA 79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13 · 0.3.9 SHA 2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0\n"
           + "-" * 100 + "\n")
    open(os.path.join(OUTD, f"STAGE3_PART_{i:02d}_of_{N:02d}.txt"), "w", encoding="utf-8").write(hdr + "\n".join(p) + f"\n--- HẾT PART {i}/{N} ---\n")
print(N, [sum(len(x) for x in p) for p in parts])
