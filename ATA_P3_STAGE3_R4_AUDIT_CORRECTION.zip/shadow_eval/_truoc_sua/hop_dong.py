# -*- coding: utf-8 -*-
"""DATA CONTRACT – Shadow Evaluation ATA P3 (schema 1.0). Ngoài Pine; dùng chung cho Dashboard / Chart / Data & Performance / Regression / Final Acceptance.
Ba bảng (JSONL hoặc CSV, UTF-8): EVENTS (vòng đời), SIGNALS (trigger + S1), TRADES (kết quả giả lập). Thời gian: chuỗi ISO-8601 UTC 'YYYY-MM-DDTHH:MM:SSZ'
(thời điểm MỞ nến) + số nguyên ms Unix. Mã trạng thái/lý do giữ nguyên mã của engine (2 CHỜ, 4 BỎ QUA, 5 HẾT HẠN, 6 VÔ HIỆU, 8 BẤT BIẾN, 17 SHADOW; lý do 0…16)."""
import hashlib, re

SCHEMA_VERSION = "1.0"
TS = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
SYMBOLS = ("XAUUSD", "BTCUSD")
SETUPS = ("SU3", "SU5")
SOURCES = ("PY_REPLAY", "TV_EXPORT", "SYNTH")
EVENT_TYPES = ("CREATED", "STEP", "ARMED", "TRIGGER", "VOID", "EXPIRED", "SKIP", "END_NO_EVENT")
OUTCOMES = ("TP1", "SL", "TIMEOUT", "OPEN", "NO_FILL")

# (tên, kiểu, bắt buộc, mô tả)
EVENTS = [("schema_version", str, True, "phiên bản hợp đồng"), ("engine_version", str, True, "ví dụ 0.3.9"), ("source", str, True, "PY_REPLAY / TV_EXPORT / SYNTH"),
          ("symbol", str, True, "XAUUSD / BTCUSD"), ("tf", str, True, "khung chạy engine, ví dụ 5"), ("setup", str, True, "SU3 / SU5"), ("mode", str, True, "SHADOW"),
          ("setup_id", str, True, "băm xác định của (symbol, setup, dir, anchor_ts, khóa neo)"), ("event_id", str, True, "băm (setup_id, event_type, ts_ms)"),
          ("event_type", str, True, "CREATED/STEP/ARMED/TRIGGER/VOID/EXPIRED/SKIP/END_NO_EVENT"), ("step", int, False, "bước J.2/J.4 đạt được (1…5)"),
          ("ts", str, True, "thời điểm mở nến M5 xử lý sự kiện (UTC)"), ("ts_ms", int, True, "như trên, ms"), ("dir", int, True, "+1 BUY / −1 SELL"),
          ("state", int, True, "mã trạng thái engine"), ("reason", int, True, "mã lý do engine"), ("anchor_price", float, False, "SU-3 MỐC / SU-5 Lv"), ("ext_price", float, False, "SU-3 ĐÁY/ĐỈNH FINAL / SU-5 A")]
SIGNALS = [("schema_version", str, True, ""), ("engine_version", str, True, ""), ("source", str, True, ""), ("symbol", str, True, ""), ("setup", str, True, ""),
           ("setup_id", str, True, ""), ("signal_id", str, True, "băm (setup_id, trigger_ts_ms)"), ("dir", int, True, ""), ("trigger_ts", str, True, "nến trigger (UTC, mở nến)"),
           ("trigger_ts_ms", int, True, ""), ("p_ref", float, True, "Close nến trigger"), ("sl", float, True, ""), ("tp1", float, False, "na → null"), ("rr", float, False, ""),
           ("reason", int, True, "16 = đạt S1; 8/15/14/9/1/2 = bị bỏ"), ("perm_reg", int, False, "REG H4 tại trigger"), ("perm_vol", int, False, "lớp VOL tại trigger"), ("dup_key", str, True, "(symbol, setup, dir, trigger_ts_ms) – khử trùng IP-21")]
TRADES = [("schema_version", str, True, ""), ("signal_id", str, True, ""), ("sim_rule", str, True, "mã bộ quy tắc giả lập, ví dụ R1-close-slfirst"), ("cost_model", str, True, "mã chi phí"),
          ("entry_ts_ms", int, True, ""), ("entry_price", float, True, ""), ("risk", float, True, "|entry − SL| > 0"), ("outcome", str, True, "TP1/SL/TIMEOUT/OPEN/NO_FILL"),
          ("exit_ts_ms", int, False, ""), ("exit_price", float, False, ""), ("r_gross", float, True, ""), ("r_net", float, True, "sau chi phí"), ("mfe_r", float, True, "≥ 0"),
          ("mae_r", float, True, "≤ 0"), ("bars_held", int, True, "số nến M5 từ sau nến vào tới nến thoát"), ("same_bar_conflict", bool, True, "nến chạm cả SL và TP1"), ("gap_exit", bool, True, "thoát ở Open do gap")]


def hid(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:16]


def kiem(rec, schema):
    """Trả danh sách lỗi (rỗng = hợp lệ)."""
    loi = []
    ten = {n for n, _, _, _ in schema}
    for n, t, bb, _ in schema:
        if n not in rec or rec[n] is None:
            if bb:
                loi.append(f"thiếu {n}")
            continue
        v = rec[n]
        if t is float and isinstance(v, int) and not isinstance(v, bool):
            v = float(v)
        if t is int and isinstance(v, bool):
            loi.append(f"{n}: bool thay int"); continue
        if not isinstance(v, t):
            loi.append(f"{n}: kiểu {type(v).__name__} ≠ {t.__name__}")
    for n in rec:
        if n not in ten:
            loi.append(f"trường lạ {n}")
    if "ts" in rec and rec.get("ts") is not None and not TS.match(str(rec["ts"])):
        loi.append("ts sai định dạng")
    if rec.get("symbol") is not None and rec["symbol"] not in SYMBOLS:
        loi.append("symbol ngoài danh sách")
    if rec.get("setup") is not None and rec["setup"] not in SETUPS:
        loi.append("setup ngoài danh sách")
    if rec.get("source") is not None and rec["source"] not in SOURCES:
        loi.append("source ngoài danh sách")
    if rec.get("event_type") is not None and rec["event_type"] not in EVENT_TYPES:
        loi.append("event_type ngoài danh sách")
    if rec.get("outcome") is not None and rec["outcome"] not in OUTCOMES:
        loi.append("outcome ngoài danh sách")
    if rec.get("dir") is not None and rec["dir"] not in (1, -1):
        loi.append("dir phải ±1")
    if schema is TRADES:
        if rec.get("risk") is not None and not rec["risk"] > 0:
            loi.append("risk ≤ 0")
        if rec.get("mfe_r") is not None and rec["mfe_r"] < 0:
            loi.append("mfe_r < 0")
        if rec.get("mae_r") is not None and rec["mae_r"] > 0:
            loi.append("mae_r > 0")
    return loi
