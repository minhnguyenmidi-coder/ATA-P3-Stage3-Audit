# -*- coding: utf-8 -*-
"""Bộ GIẢ LẬP LỆNH thống nhất cho tín hiệu SHADOW (SU-3, SU-5). Ngoài Pine. Mọi quy tắc là ASSUMPTION có tham số, ghi vào trường sim_rule.

Quy tắc mặc định R1 (bảo thủ):
  • Vào lệnh tại P_ref = Close nến trigger (đúng P_ref của S1 engine). Biến thể R2: Open nến kế tiếp (gap được tính).
  • Chỉ đánh giá từ nến SAU nến vào (không dùng High/Low của nến trigger – tránh nhìn trước trong nến).
  • BUY: chạm SL khi Low ≤ SL; chạm TP1 khi High ≥ TP1. SELL đối xứng.
  • Gap: Open đã vượt SL → thoát tại Open (xấu hơn SL); Open đã vượt TP1 → thoát tại Open.
  • Một nến chạm cả SL và TP1 → coi SL trước (bảo thủ), đánh dấu same_bar_conflict.
  • Chưa chạm sau max_bars nến → TIMEOUT, thoát tại Close nến cuối. Hết dữ liệu trước max_bars → OPEN (không tính vào thống kê đóng lệnh).
  • R = (giá thoát − giá vào)×dir / rủi ro, rủi ro = |giá vào − SL|. Chi phí (spread + phí + trượt giá, đơn vị giá) trừ vào R: r_net = r_gross − cost/risk.
  • MFE/MAE (đơn vị R), MFE ≥ 0, MAE ≤ 0, đo trên các nến từ sau nến vào tới nến thoát. Nến thoát: thoát TP1 → MFE chặn tại TP1, phía bất lợi tính đủ;
    thoát SL → phía có lợi của nến đó không tính, MAE ≤ −1 (bảo thủ vì không biết thứ tự giá trong nến M5)."""
from dataclasses import dataclass


@dataclass
class Cfg:
    entry: str = "close"          # "close" (R1) | "next_open" (R2)
    same_bar: str = "sl_first"    # "sl_first" | "tp_first" (chỉ để đo độ nhạy, không dùng làm kết quả chính)
    max_bars: int = 288           # 288 nến M5 = 24 giờ (ASSUMPTION)
    spread: float = 0.0           # đơn vị giá (ASSUMPTION theo symbol/broker)
    commission: float = 0.0       # đơn vị giá cho 1 lượt khứ hồi
    slippage: float = 0.0         # đơn vị giá mỗi lần khớp (vào + ra)

    def rule_id(self):
        return f"R-{self.entry}-{self.same_bar}-{self.max_bars}"

    def cost_id(self):
        return f"C-s{self.spread}-c{self.commission}-sl{self.slippage}"


def mo_phong(sig, bars, i_trig, cfg=Cfg()):
    """sig: dict(dir, sl, tp1, p_ref). bars: list dict(t, o, h, l, c) nến M5 đã đóng. i_trig: chỉ số nến trigger.
    Trả dict theo hợp đồng TRADES (thiếu signal_id/schema – bên gọi bổ sung)."""
    d, sl, tp = sig["dir"], sig["sl"], sig.get("tp1")
    if cfg.entry == "close":
        ie, entry = i_trig, sig["p_ref"]
        start = i_trig + 1
    else:
        if i_trig + 1 >= len(bars):
            return dict(outcome="NO_FILL", entry_ts_ms=bars[i_trig]["t"], entry_price=sig["p_ref"], risk=abs(sig["p_ref"] - sl) or 1e-12, r_gross=0.0, r_net=0.0,
                        mfe_r=0.0, mae_r=0.0, bars_held=0, same_bar_conflict=False, gap_exit=False, exit_ts_ms=None, exit_price=None)
        ie, entry = i_trig + 1, bars[i_trig + 1]["o"]
        start = i_trig + 1
    risk = (entry - sl) * d
    base = dict(entry_ts_ms=bars[ie]["t"], entry_price=entry, same_bar_conflict=False, gap_exit=False)
    if risk <= 0:                                   # giá vào đã vượt SL (chỉ xảy ra với next_open gap) → không khớp
        return dict(base, outcome="NO_FILL", risk=abs(risk) or 1e-12, r_gross=0.0, r_net=0.0, mfe_r=0.0, mae_r=0.0, bars_held=0, exit_ts_ms=None, exit_price=None)
    cost = cfg.spread + cfg.commission + 2 * cfg.slippage
    mfe = mae = 0.0
    for k in range(start, min(len(bars), start + cfg.max_bars)):
        b = bars[k]
        first = (k == start and cfg.entry == "next_open")          # nến vào ở R2: Open là giá vào, không phải gap thoát
        if not first:
            if d * (b["o"] - sl) <= 0:
                return dict(base, outcome="SL", exit_ts_ms=b["t"], exit_price=b["o"], risk=risk, r_gross=(b["o"] - entry) * d / risk, r_net=(b["o"] - entry) * d / risk - cost / risk,
                            mfe_r=mfe, mae_r=min(mae, (b["o"] - entry) * d / risk), bars_held=k - start + 1, gap_exit=True)
            if tp is not None and d * (b["o"] - tp) >= 0:
                return dict(base, outcome="TP1", exit_ts_ms=b["t"], exit_price=b["o"], risk=risk, r_gross=(b["o"] - entry) * d / risk, r_net=(b["o"] - entry) * d / risk - cost / risk,
                            mfe_r=max(mfe, (b["o"] - entry) * d / risk), mae_r=mae, bars_held=k - start + 1, gap_exit=True)
        fav = (b["h"] if d == 1 else b["l"]); adv = (b["l"] if d == 1 else b["h"])
        hit_sl = d * (adv - sl) <= 0
        hit_tp = tp is not None and d * (fav - tp) >= 0
        if hit_sl and hit_tp:
            if cfg.same_bar == "sl_first":
                return dict(base, outcome="SL", exit_ts_ms=b["t"], exit_price=sl, risk=risk, r_gross=-1.0, r_net=-1.0 - cost / risk, mfe_r=mfe, mae_r=min(mae, -1.0),
                            bars_held=k - start + 1, same_bar_conflict=True)
            rt = (tp - entry) * d / risk
            return dict(base, outcome="TP1", exit_ts_ms=b["t"], exit_price=tp, risk=risk, r_gross=rt, r_net=rt - cost / risk, mfe_r=max(mfe, rt), mae_r=mae,
                        bars_held=k - start + 1, same_bar_conflict=True)
        if hit_sl:          # nến thoát SL: phía có lợi của nến này không tính (không biết thứ tự trong nến) – bảo thủ
            return dict(base, outcome="SL", exit_ts_ms=b["t"], exit_price=sl, risk=risk, r_gross=-1.0, r_net=-1.0 - cost / risk, mfe_r=mfe, mae_r=min(mae, -1.0), bars_held=k - start + 1)
        if hit_tp:          # nến thoát TP1: MFE chặn tại mức TP1; phía bất lợi của nến vẫn tính (bảo thủ)
            rt = (tp - entry) * d / risk
            return dict(base, outcome="TP1", exit_ts_ms=b["t"], exit_price=tp, risk=risk, r_gross=rt, r_net=rt - cost / risk, mfe_r=max(mfe, rt),
                        mae_r=min(mae, (adv - entry) * d / risk), bars_held=k - start + 1)
        mfe = max(mfe, (fav - entry) * d / risk)
        mae = min(mae, (adv - entry) * d / risk)
    n = min(len(bars), start + cfg.max_bars) - start
    if start + cfg.max_bars > len(bars):
        last = bars[-1]
        return dict(base, outcome="OPEN", exit_ts_ms=None, exit_price=None, risk=risk, r_gross=(last["c"] - entry) * d / risk, r_net=(last["c"] - entry) * d / risk - cost / risk,
                    mfe_r=mfe, mae_r=mae, bars_held=n)
    last = bars[start + cfg.max_bars - 1]
    rr = (last["c"] - entry) * d / risk
    return dict(base, outcome="TIMEOUT", exit_ts_ms=last["t"], exit_price=last["c"], risk=risk, r_gross=rr, r_net=rr - cost / risk, mfe_r=mfe, mae_r=mae, bars_held=n)


def khu_trung(signals):
    """IP-21: nhiều thể hiện SU-3 có thể trigger cùng nến, cùng chiều → giữ 1 tín hiệu theo dup_key (signal-level). Trả (giữ, số bị loại)."""
    seen, giu = set(), []
    for s in sorted(signals, key=lambda x: (x["trigger_ts_ms"], x["signal_id"])):
        if s["dup_key"] in seen:
            continue
        seen.add(s["dup_key"]); giu.append(s)
    return giu, len(signals) - len(giu)


def khong_chong(trades):
    """Biến thể danh mục: mỗi (symbol, setup) chỉ 1 lệnh mở tại một thời điểm – lệnh vào khi lệnh trước chưa thoát bị bỏ. Trả (giữ, số bị bỏ)."""
    giu, bo, mo = [], 0, {}
    for t in sorted(trades, key=lambda x: x["entry_ts_ms"]):
        k = (t["symbol"], t["setup"])
        if k in mo and (mo[k] is None or t["entry_ts_ms"] <= mo[k]):
            bo += 1; continue
        giu.append(t); mo[k] = t.get("exit_ts_ms")
    return giu, bo
