# ATA P3 – Stage 3: Shadow Evaluation & Token Budget Architecture

**Phạm vi lượt này:**
- Không sửa Pine. Source 0.3.8 và 0.3.9 giữ nguyên SHA (test BL-01).
- Không tạo Build 0.4.0. Không kết luận SU-3/SU-5 có hiệu quả hay không, vì chưa có dữ liệu thật.

**Đã làm:**
- Thiết kế kiến trúc đánh giá SHADOW nằm hoàn toàn ngoài Pine.
- Dựng và kiểm thử phần lõi bằng Python: bộ giả lập lệnh, hợp đồng dữ liệu, chỉ số đánh giá, chuỗi đầu-cuối trên dữ liệu giả lập. Kết quả **18 PASS / 0 FAIL / 4 BLOCKED**.
- Lập lại mô hình token sau dữ kiện mới: 0.3.9 compile được.

---

## 1. Shadow Evaluation Architecture

```
OHLCV M5 lịch sử (XAUUSD, BTCUSD – nguồn Exness)
      │
      ▼
[L1] Replay chạy từ chính source Pine 0.3.9 (pine_mini mở rộng)
      → EVENTS (vòng đời SU-3/SU-5), SIGNALS (trigger + S1)
      │                                    ▲
      │                    [V] Đối chiếu với TradingView (CSV Data Window)
      ▼
[L2] Giả lập lệnh (shadow_eval/mo_phong_lenh.py) → TRADES
      ▼
[L3] Chỉ số (shadow_eval/chi_so.py), tách riêng (symbol × setup)
      ▼
Bảng theo hợp đồng dữ liệu (shadow_eval/hop_dong.py)
      → nguồn chung cho Dashboard / Chart / Data & Performance / Regression / Final Acceptance
```

**Nguyên tắc:**
- Toàn bộ thu thập và phân tích nằm ngoài Pine; không thêm byte nào vào Pine.
- Engine SHADOW không được viết lại bằng tay. L1 chạy **chính** mã Pine bằng trình thông dịch, nên không có phiên bản logic thứ hai để lệch.
- Mỗi kết quả mang `source` (PY_REPLAY / TV_EXPORT / SYNTH) và `engine_version`. Dữ liệu giả lập không bao giờ được trộn vào thống kê thật.

## 2. Phương án thu thập dữ liệu

| Dữ liệu | Cách lấy | Ghi chú |
|---|---|---|
| OHLCV M5 | **Cần nguồn** – chưa có trong môi trường; mạng của công cụ đang tắt | Phương án bên dưới |
| OHLCV M1 (tùy chọn) | Như trên | Chỉ để xử lý nến M5 chạm cả SL và TP1 |
| Thời điểm tạo, chiều, mức neo, ARMED, trigger, ET (= P_ref), SL, TP1, trạng thái, lý do VOID/hết hạn, quyền | **Tái tạo bằng L1** | Không cần thêm vào Pine |
| Kết quả lệnh, R, MFE, MAE (lời/lỗ lớn nhất trong lệnh, đơn vị R), thời gian giữ | **Tính bằng L2** | Không cần thêm vào Pine |
| Regime/VOL H4 tại trigger | L1 (MD-6) | Dùng để phân nhóm thị trường khách quan |

**Nguồn OHLCV – chủ dự án chọn:**

| PA | Cách lấy | Ưu / nhược |
|---|---|---|
| D1 (khuyến nghị) | Xuất CSV "Export chart data" của EXNESS:XAUUSD và EXNESS:BTCUSD khung 5 phút **có gắn 0.3.9**, trên TradingView bản web/desktop | Một lần xuất cho cả hai việc: OHLCV đúng nguồn, và giá trị Data Window để đối chiếu replay (mục 3.4). Chưa xác minh: TradingView có xuất các plot chỉ-Data-Window không, và mỗi lần xuất được bao nhiêu nến (UNKNOWN) |
| D2 | Xuất lịch sử từ MT5 bản desktop (Exness) | Đúng nguồn broker, nhưng không có dữ liệu đối chứng TradingView. Không làm được trên iPad |
| D3 | Bật quyền mạng cho công cụ để lấy dữ liệu công khai (GitHub) | Không phải nguồn Exness, có thể lệch giá/phiên (ASSUMPTION rủi ro) |

**Cỡ mẫu (ASSUMPTION):**
- Cần ít nhất 30 lệnh đóng cho mỗi (symbol × setup) mới được nhận định; khoảng 100 lệnh mới đủ để ra quyết định.
- Tần suất SU-3/SU-5 trên dữ liệu thật chưa biết, nên số nến cần là UNKNOWN. Sẽ xác định sau đợt replay đầu tiên.

## 3. Phương án Python replay

### 3.1 Cơ sở đã có (FACT)

- `pine_mini` đã chạy **nguyên văn** các khối Pine: SU-1 P1…S1, SU-4, S2a, ARMED, toàn bộ khối SHADOW, MD-4, MD-5, `f_ledger`.
- Bằng chứng: bộ test 0.3.9; chuỗi đầu-cuối E2E-01 ở lượt này ra 97 tín hiệu, 18 lệnh giả lập, 0 lỗi hợp đồng.
- Kiểm vi sai 0.3.8 ↔ 0.3.9 đã chạy 14.400 nến.

### 3.2 Phần còn thiếu để replay **toàn script** (đo bằng quét mã 0.3.9)

| Hạng mục | Việc cần làm |
|---|---|
| `request.security` (8 lệnh) | Mô phỏng: dựng nến 15/60/240/D/W/M/12M từ M5; chạy `f_struct` trong ngữ cảnh riêng của từng khung; áp ngữ nghĩa `[1]` + `lookahead_on` (giá trị nến khung lớn đã đóng xuất hiện ở nến M5 đầu tiên sau thời điểm đóng) |
| Hàm chuỗi | `ta.atr`, `ta.sma`, `ta.change`, `math.sum`, `timeframe.change`, `timeframe.in_seconds`, `hour`, `math.ceil/round/round_to_mintick`, `map.*`, `input.*` (lấy giá trị mặc định) |
| Toán tử lịch sử `x[n]` | Áp cho mọi biến chuỗi (khoảng 77 biểu thức). Hiện chỉ có cho high/low/open/close/time |
| Vẽ | `table.*`, `label.*`, `box.*`: chỉ cần stub (không ảnh hưởng logic) |

### 3.3 Chỗ không thể chứng minh tương đương nếu chỉ dùng Python

1. **Dữ liệu khung lớn:** TradingView dựng nến H4/D/W từ dữ liệu khung lớn của chính nó, không gộp từ M5. Ranh giới phiên của XAU (giờ đóng cửa ngày, mở tuần) có thể khác.
2. **Điểm bắt đầu lịch sử:** trạng thái `var` phụ thuộc đường đi. Replay phải bắt đầu đúng nến đầu tiên TradingView nạp, nếu không giai đoạn khởi động sẽ khác.
3. **Thứ tự thực thi** trong một nến: replay đi theo đúng thứ tự B.2.2 của source, nên rủi ro thấp.
4. **Nến chưa đóng:** replay chỉ chạy trên nến đã đóng (`runBar` vốn chỉ chạy khi `barstate.isconfirmed`). LIVE trên dashboard không được đánh giá (chỉ hiển thị).
5. **Lookahead/repaint:** `[1]` + `lookahead_on` phải mô phỏng chính xác. Sai một nến là lệch toàn bộ.
6. **Số học dấu phẩy động, `mintick`, dữ liệu thiếu hoặc gap cuối tuần.**

### 3.4 Đối chiếu và kiểm chứng (bắt buộc trước khi dùng kết quả)

- **V1:** so từng nến 56 giá trị Data Window giữa replay và CSV xuất từ TradingView (phương án D1), sau giai đoạn khởi động.
- **Tiêu chí:**
  - 100 % trùng ở mã MD-6 (REG + 10×VOL) và mã actionable;
  - ô sự kiện SHADOW (trạng thái 17) trùng tại các nến có ô trống.
- **Giới hạn:** ô Data Window chỉ hiện sự kiện SHADOW khi còn ô trống (IP-28), nên đây là đối chiếu **một phần** cho SHADOW.
- Nếu V1 không đạt: replay chỉ được dùng làm "ước lượng" (`source = PY_REPLAY`, cờ chưa xác minh), không dùng để kết luận.

### 3.5 Khuyến nghị

Chọn L1 (replay chạy từ source) làm đường chính. Không viết lại engine bằng Python độc lập, vì có nguy cơ lệch logic. Mô hình độc lập chỉ dùng để kiểm chéo từng phần.

## 4. Phương án đánh giá SU-3

**Phạm vi thật của SU-3 trong 0.3.9 (FACT):**
- Chỉ có nhánh **vùng H1** của bước 1. Nhánh cụm MD-4 bị chặn (IP-19), nên kết quả **không đại diện cho toàn bộ J.2**.
- Không có hạng A/B.

**Phễu theo từng symbol:** tạo → MSS H1 → chọn vùng M15 → chạm vùng (ARMED) → trigger → kết quả S1. Các nhánh kết thúc được đếm riêng:
- vô hiệu trước bước 2;
- không có vùng mới (IP-20);
- hết hạn ở bước 2, bước 4 hoặc sau ARMED;
- P4 vô hiệu (5); vùng bị gỡ (6);
- S1 bỏ với lý do 8/15/14/9/1/2.

**Khử trùng (IP-21):** một nến M15 nằm trong vùng H1 có thể sinh nhiều thể hiện. Thống kê lệnh dùng **1 tín hiệu cho mỗi** (symbol, setup, chiều, nến trigger). Số bản trùng được báo riêng.

**Kết quả lệnh:** chỉ tính tín hiệu đạt S1 (lý do 16), theo quy tắc R1 ở mục 6.

**Phân nhóm thị trường khách quan:** REG H4 tại trigger (theo đúng quyền ĐẢO CHIỀU: DOWNTREND, hoặc TRANSITION có LAST_CHOCH), lớp VOL, phiên giờ.

**Đối chứng "bị chặn quyền" (lý do 15):** tính kết quả giả định, đặt trong bảng riêng có nhãn *phản thực tế*. Không bao giờ gộp vào kết quả SU-3.

## 5. Phương án đánh giá SU-5

**Phễu:** BOS M15 → rời mức → retest (ARMED, hoặc gap → bỏ lý do 4) → trigger → S1. Các nhánh kết thúc: vô hiệu neo, vô hiệu setup (P4), hết hạn trước/sau retest, mức Lv bị chặn theo J.4.3.

**Phân nhóm:**
- Lv lấy từ REF hay từ cụm MD-4;
- hạng cụm;
- REG H4 (lớp THUẬN);
- VOL.

**Không có hạng** (IP-23). Lệnh, khử trùng và đối chứng lý do 15 xử lý như SU-3.

**Cả hai setup:** báo cáo riêng từng ô (XAUUSD-SU3, XAUUSD-SU5, BTCUSD-SU3, BTCUSD-SU5). Không có con số gộp.

## 6. Quy tắc giả lập lệnh (tất cả là ASSUMPTION, có tham số; mã quy tắc ghi vào mỗi lệnh)

| Mục | Quy tắc chính R1 | Biến thể độ nhạy |
|---|---|---|
| Giá vào | P_ref = Close nến trigger (đúng P_ref của S1) | R2: Open nến kế tiếp; nếu Open đã vượt SL thì NO_FILL |
| Nến bắt đầu đánh giá | Nến **sau** nến vào (High/Low của nến trigger không dùng) | — |
| SL / TP | SL và TP1 của S1. Hiện engine SHADOW chỉ cho TP1 | — |
| Gap | Open vượt SL → thoát tại Open (R < −1); Open vượt TP1 → thoát tại Open | — |
| Một nến chạm cả SL và TP1 | Coi chạm SL trước (bảo thủ), gắn cờ xung đột | Chạm TP trước, chỉ để đo độ nhạy. Nếu có M1 thì phân xử bằng M1 |
| Spread / phí / trượt giá | Tham số đơn vị giá theo symbol, trừ vào R: r_net = r_gross − chi phí / rủi ro | Chạy 0 và mức thực tế Exness (UNKNOWN – cần chủ dự án cho số) |
| MFE / MAE | Đo từ nến sau nến vào tới nến thoát. Nến thoát TP1: MFE dừng tại TP1. Nến thoát SL: bỏ phía có lợi của nến đó | — |
| Thời gian giữ tối đa | 288 nến M5 (24 giờ) → TIMEOUT, thoát tại Close | 96 / 576 nến |
| Hết dữ liệu | OPEN: chỉ đếm, không vào R | — |
| Setup đồng thời | Mức tín hiệu: đánh giá độc lập sau khử trùng | Mức danh mục: mỗi (symbol, setup) chỉ 1 lệnh mở; không chặn chéo giữa setup hay symbol |
| Tín hiệu hết hạn, VOID, bị bỏ ở S1 | Không có lệnh; chỉ vào phễu | — |

**Công thức chỉ số** (`chi_so.py`, chỉ tính trên lệnh đóng TP1/SL/TIMEOUT):

| Chỉ số | Công thức |
|---|---|
| Win rate | Số lệnh R > 0 ÷ số lệnh đóng |
| Net R | Tổng r_net |
| Average R = Expectancy | Net R ÷ số lệnh đóng |
| Profit Factor | Tổng R dương ÷ \|Tổng R âm\| |
| Tỷ lệ TP1 / SL / TIMEOUT | Số lệnh theo kết cục ÷ số lệnh đóng |
| MFE, MAE, thời gian giữ | Trung bình trên lệnh đóng |
| Khoảng tin cậy 95 % của expectancy | Bootstrap |
| Phễu | Tỷ lệ VOID, hết hạn, bỏ do quyền, bản trùng |
| Cờ `du_mau` | Đúng khi có ≥ 30 lệnh đóng |

**Không tối ưu tham số trong giai đoạn này.** Nếu sau này tối ưu, phải:
- tách in-sample / out-of-sample theo thời gian;
- chạy walk-forward;
- giữ nguyên bộ kết quả của tham số gốc để đối chiếu.

## 7. Data contract (schema 1.0 – `shadow_eval/hop_dong.py`)

**Ba bảng:**

| Bảng | Nội dung |
|---|---|
| EVENTS | Vòng đời |
| SIGNALS | Trigger + S1 |
| TRADES | Kết quả giả lập |

**Quy ước chung:**
- File JSONL hoặc CSV, UTF-8.
- Thời gian: chuỗi ISO-8601 UTC (thời điểm **mở** nến) kèm số ms Unix.
- Mã trạng thái/lý do giữ nguyên mã của engine.

**Trường khóa:**

| Nhóm | Trường |
|---|---|
| Danh tính | schema_version, engine_version, source, symbol, tf, setup, mode |
| ID xác định (băm SHA-1, 16 ký tự) | setup_id, event_id, signal_id; dup_key = (symbol, setup, chiều, nến trigger) |
| Sự kiện | event_type (CREATED/STEP/ARMED/TRIGGER/VOID/EXPIRED/SKIP/END_NO_EVENT), step, ts, ts_ms, dir, state, reason, anchor_price, ext_price |
| Tín hiệu | trigger_ts(_ms), p_ref, sl, tp1 (null nếu na), rr, reason, perm_reg, perm_vol |
| Lệnh | sim_rule, cost_model, entry/exit (ts_ms, price), risk, outcome (TP1/SL/TIMEOUT/OPEN/NO_FILL), r_gross, r_net, mfe_r, mae_r, bars_held, same_bar_conflict, gap_exit |

**Phục vụ các giai đoạn sau:**
- **Dashboard:** dùng EVENTS/SIGNALS.
- **Chart Visualization:** ts + giá.
- **Data & Performance:** TRADES + chỉ số.
- **Regression:** so file giữa các phiên bản theo ID.
- **Final Acceptance:** source + engine_version + sim_rule.

Bộ kiểm hợp đồng `kiem()` đã có test (HD-01, HD-02).

## 8. Bộ kiểm thử

**Đã có, đã chạy** (`shadow_eval/kiem_thu_shadow_eval.py` → `ket_qua_shadow_eval/ket_qua.json`):

| ID | Nội dung | Kết quả |
|---|---|---|
| SIM-01 | BUY chạm TP1: R = 2,0, MFE = 2,0, MAE = −0,2 | PASS (lần đầu FAIL do quy ước MFE ở nến thoát; đã chốt quy ước bảo thủ) |
| SIM-02 | BUY chạm SL: R = −1 | PASS |
| SIM-03 | Một nến chạm cả SL và TP1 (SL trước; biến thể TP trước) | PASS |
| SIM-04 | Gap qua SL / qua TP1 → thoát tại Open | PASS |
| SIM-05 | Đối xứng BUY/SELL: 500 cặp đường giá gương | PASS |
| SIM-06 | TIMEOUT / OPEN | PASS |
| SIM-07 | Không nhìn trước: không dùng nến trigger; 300 đường thay dữ liệu sau nến thoát → không đổi | PASS |
| SIM-08 | Chi phí trừ vào R | PASS |
| SIM-09 | Biến thể vào lệnh ở Open nến kế (NO_FILL khi gap qua SL) | PASS |
| SIM-10 | Nhất quán R/MFE/MAE trên 2.000 đường ngẫu nhiên | PASS |
| DUP-01, DUP-02 | Khử trùng IP-21; danh mục không chồng lấn | PASS |
| HD-01, HD-02 | Kiểm hợp đồng; ID xác định | PASS |
| CS-01, CS-02 | Chỉ số tách nhóm; phễu | PASS |
| E2E-01 | Khối Pine SHADOW nguyên văn → SIGNALS → TRADES (dữ liệu **giả lập**): 97 tín hiệu, 18 lệnh, 0 lỗi hợp đồng | PASS |
| BL-01 | SHA 0.3.8/0.3.9 không đổi | PASS |

**Dự kiến (cần replay L1 và dữ liệu thật):**
- Vòng đời SU-3/SU-5 theo replay khớp với các test nguồn đã có (S3-*, S5-*).
- Đối xứng BUY/SELL của replay.
- Hết hạn, vô hiệu, quyền tại trigger.
- Dữ liệu thiếu và nến chưa đóng (replay bỏ nến chưa đóng).
- Replay không nhìn trước: cắt dữ liệu tại nến t, kết quả đến t không đổi.
- Actionable không bị ảnh hưởng (đã có I-04/I-06 của 0.3.9).
- V1: đối chiếu replay với TradingView.

## 9. Token Budget Roadmap

### 9.1 FACT

| Bản | Token từ vựng | Kết quả compile |
|---|---|---|
| 0.3.3 | 29.909 | **FAIL** CE10117, TradingView báo 101.360 token |
| 0.3.3a | 28.902 | PASS (suy từ việc chủ dự án gặp lỗi runtime RE10139, tức là đã compile được) |
| 0.3.7 | 29.368 | PASS |
| 0.3.8 | 28.369 | PASS |
| **0.3.9** | **30.226** | **PASS** (chủ dự án xác nhận) |
| Giới hạn | — | 100.256 |

- 0.3.9 có **nhiều** token từ vựng hơn 0.3.3 nhưng vẫn compile được. Vì vậy mô hình tuyến tính "token từ vựng × 3,3889" đã dùng ở báo cáo 0.3.9 là **sai**. Kết luận BLOCKED về token ở báo cáo 0.3.9 bị bác bỏ.
- Số token biên dịch thật của 0.3.9: **UNKNOWN**, chỉ biết ≤ 100.256. TradingView không in số token khi compile thành công.

### 9.2 HYPOTHESIS

Script: `token_budget/mo_hinh_token.py`, kết quả trong `token_budget/ket_qua_mo_hinh.txt`.

Hàm `f_struct` (kèm các hàm con) được gọi bởi 8 lệnh `request.security`. Ở 0.3.3 nó dài 5.239 + 642 token, từ 0.3.5f còn 4.517 + 909. Mô hình nào tính `f_struct` **lặp theo từng lệnh gọi** thì giải thích được cả 5 kết quả compile:

| Mô hình | Nhất quán với 5 lần compile? | Ước lượng 0.3.9 | Dư địa ước lượng |
|---|---|---|---|
| Tuyến tính theo token từ vựng | **Mâu thuẫn** (dự báo 0.3.9 FAIL) | 102.434 | −2.178 |
| f_struct × 8 lệnh request.security | Nhất quán | 97.519 | +2.737 |
| Mở rộng mọi lời gọi hàm (inline toàn bộ) | Nhất quán | 98.069 | +2.187 |

**Hệ quả thiết kế (HYPOTHESIS, cần kiểm):**
- Mã thêm vào `f_struct` hoặc các hàm nó gọi tốn khoảng ×8.
- Hàm được gọi ở nhiều nơi tốn theo số lần gọi.
- Hàm không được gọi (`f_srcList`, `f_srcPush`) có thể không tốn token biên dịch.

Hai mô hình nhất quán chỉ dựa trên **1 điểm đo số** và 4 ràng buộc đúng/sai, nên độ bất định lớn.

### 9.3 ASSUMPTION để lập ngân sách

- Lấy dư địa nhỏ hơn: khoảng 2.190 token biên dịch, tương đương khoảng 1.850 token từ vựng nếu là mã cấp cao nhất, chạy một chỗ.
- Giữ lại 40 % làm dự phòng cho độ bất định.
- Còn khoảng **1.100 token từ vựng** để phân bổ.

### 9.4 Phân bổ (ESTIMATE, đơn vị token từ vựng cấp cao nhất)

| Giai đoạn | Ngân sách Pine | Ghi chú |
|---|---|---|
| Shadow Evaluation | **0** | Toàn bộ nằm ngoài Pine |
| Dashboard | ≤ 400 | UNKNOWN cho tới khi có yêu cầu cụ thể theo UI Design Master; ưu tiên tái dùng bảng `tb` hiện có |
| Chart Visualization | ≤ 400 | Không đặt mã vẽ trong `f_struct` hay hàm gọi nhiều nơi |
| Data & Performance | **0** | Dùng hợp đồng dữ liệu bên ngoài |
| Final Acceptance | **0** | |
| Sửa lỗi / regression | ≥ 300 | |
| Dự phòng bất định | ~ 750 | Không được dùng khi chưa đo |

**Nguồn có thể thu hồi** (chưa làm; cần chủ dự án duyệt):
- 7 biến `lastEv*` không được đọc: khoảng 75 token, chắc chắn có tác dụng.
- Hàm không được gọi `f_srcList`/`f_srcPush`: có thể **không** có tác dụng nếu giả thuyết inline đúng.

### 9.5 Token Gate (bắt buộc trước mọi đề xuất thêm mã Pine)

1. Ghi rõ module cần thêm, module có thể tái dùng, và mã chết có thể gỡ (phải có bằng chứng không được đọc hay gọi).
2. Chạy `mo_hinh_token.py` cho bản đề xuất: ghi mức tăng theo 3 mô hình và vị trí mã (cấp cao nhất, trong hàm gọi nhiều lần, hay trong `f_struct`).
3. Tính ngân sách còn lại cho các giai đoạn sau. Nếu vượt 60 % dư địa ước lượng thì phải có phép đo (mục 9.6) trước khi triển khai.
4. Bắt buộc nêu phương án ngoài Pine trước.
5. Không cắt tính năng hay logic actionable để giảm token.

### 9.6 Đo dư địa thật (đề xuất, chủ dự án quyết)

- Tạo 3–4 bản **thăm dò**: 0.3.9 cộng thêm một khối đệm N token ở cấp cao nhất (N = 1.000, 2.000, 3.000; không ảnh hưởng logic).
- Chủ dự án dán thử từng bản. Bản đầu tiên báo CE10117 sẽ cho số token thật, đồng thời khoanh vùng dư địa.
- Đây là bước chỉ TradingView làm được.

## 10. Rủi ro và giới hạn

1. Chưa có dữ liệu thật, nên chưa có bất kỳ kết quả hiệu quả nào (BLOCKED).
2. Replay toàn script chưa dựng. Sau khi dựng, phải qua V1 mới được tin.
3. SU-3 trong 0.3.9 chỉ có nhánh vùng H1 (IP-19). Kết quả không đại diện cho J.2 đầy đủ.
4. IP-21: số thể hiện SU-3 trùng làm phễu phình to. Thống kê lệnh đã khử trùng.
5. Nến M5 chạm cả SL và TP1: nếu không có M1, quy tắc "SL trước" làm kết quả thiên thấp (bảo thủ).
6. Chi phí Exness thật (spread theo giờ, swap) chưa có số. Swap qua đêm chưa mô hình hóa.
7. Ước lượng token chỉ là giả thuyết. Dư địa thật UNKNOWN.
8. Rủi ro overfitting nếu sau này tối ưu tham số.

## 11. FACT / ASSUMPTION / HYPOTHESIS / RECOMMENDATION

**FACT:**
- 0.3.9 compile được; mô hình token tuyến tính bị bác bỏ.
- SHA 0.3.8/0.3.9 không đổi.
- Bộ lõi 18 PASS (gồm E2E-01 trên khối Pine nguyên văn, dữ liệu giả lập).
- Chưa có OHLCV thật trong môi trường.

**ASSUMPTION:** quy tắc giả lập R1; max_bars 288; ngưỡng mẫu 30/100; dự phòng token 40 %; dữ liệu khung lớn trong replay được dựng từ M5.

**HYPOTHESIS:** chi phí token theo số lần gọi hàm (f_struct × 8); dư địa khoảng 2,2–2,7 nghìn token biên dịch.

**RECOMMENDATION:**
- Nguồn dữ liệu D1.
- Replay L1 + đối chiếu V1.
- Đo dư địa token (mục 9.6) trước giai đoạn Dashboard.
- Không chuyển SHADOW sang ACTIONABLE trước khi đủ mẫu và qua out-of-sample.

## 12. PASS / FAIL / BLOCKED / NOT TESTED

| Kết quả | Số lượng | Test |
|---|---|---|
| PASS | 18 | SIM-01…10, DUP-01/02, HD-01/02, CS-01/02, E2E-01, BL-01 |
| FAIL | 0 | — |
| BLOCKED | 4 | REAL-SU3, REAL-SU5 (chưa có dữ liệu thật); REPLAY-EQ (chưa có replay toàn script và dữ liệu đối chứng); TV-TOKEN (TradingView không in số token khi compile thành công) |
| NOT TESTED | 7 | Các test replay dự kiến ở mục 8 |

## 13. File cần tạo (giai đoạn kế tiếp)

| File | Nội dung |
|---|---|
| `replay/pine_full.py` | Mở rộng pine_mini cho toàn script: `request.security`, `ta.*`, toán tử lịch sử, `var` |
| `replay/nap_du_lieu.py` | Đọc CSV OHLCV, kiểm nến thiếu/gap, chuẩn hóa UTC |
| `replay/chay_replay.py` | Replay → EVENTS/SIGNALS theo hợp đồng |
| `replay/doi_chieu_tv.py` | V1: so với CSV TradingView |
| `shadow_eval/bao_cao.py` | Xuất bảng (symbol × setup) và phễu |
| Bộ test replay | Theo mục 8 |

**Đã tạo ở lượt này:** `shadow_eval/{hop_dong, mo_phong_lenh, chi_so, kiem_thu_shadow_eval}.py`, `token_budget/mo_hinh_token.py`.

## 14. File dùng từ baseline

- Source: `src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine` (SHA `2184d892…fdb0`), chỉ đọc.
- Trình thông dịch và driver: `kiem_toan034a/pine_mini.py`, `kiem_toan035/khung.py`, `kiem_toan039/khung039.py`, `kiem_toan039/kiem_cach_ly.py`.
- Test nguồn SU-3/SU-5 để đối chiếu replay: `kiem_toan039/kiem_su3_su5.py`.
- Đặc tả: `cong_tien_md6/ho_so/…P2-1_5_1_Final_Consolidated.txt` (J.0–J.5, K.5, B.2.2, I.3/I.5).

## 15. Kế hoạch thực thi

| Bước | Việc | Ai làm | Cần Pine? |
|---|---|---|---|
| 1 | Chủ dự án chọn nguồn dữ liệu (D1/D2/D3), cung cấp chi phí Exness, quyết định có đo dư địa token (mục 9.6) hay không | Chủ dự án | Không |
| 2 | Dựng `pine_full` (replay toàn script), có test đơn vị cho từng builtin mới | Claude | Không |
| 3 | Kiểm replay tái tạo đúng các test nguồn SU-3/SU-5 và I-06 đã có | Claude | Không |
| 4 | Nạp OHLCV thật, chạy replay, đối chiếu V1 với TradingView; báo mức khớp | Claude | Không |
| 5 | Giả lập lệnh R1 + biến thể độ nhạy; báo cáo riêng 4 ô (symbol × setup) kèm phễu, khoảng tin cậy, cờ đủ mẫu | Claude | Không |
| 6 | Kiểm toán độc lập (capsule như vòng 0.3.9) | Kiểm toán | Không |
| 7 | Chỉ khi cần cho Dashboard: qua Token Gate (mục 9.5) và đo dư địa | Claude + chủ dự án | Đề xuất riêng, chưa triển khai |
