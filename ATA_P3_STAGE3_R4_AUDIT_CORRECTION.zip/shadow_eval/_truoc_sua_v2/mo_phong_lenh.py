# -*- coding: utf-8 -*-
"""Bộ GIẢ LẬP LỆNH thống nhất cho tín hiệu SHADOW (SU-3, SU-5). Ngoài Pine. Phiên bản 1.1 (Stage 3 – Audit Correction).
Mọi quy tắc là ASSUMPTION có tham số; mã quy tắc ghi vào trường sim_rule. Không tối ưu tham số chiến lược.

KẾT CỤC (outcome)
  TP1 / SL / TIMEOUT : lệnh ĐÓNG – vào thống kê R.
  OPEN               : đã vào, hết dữ liệu trước khi đóng – chỉ đếm; chiếm vị thế tới hết dữ liệu (lọc danh mục).
  NO_FILL            : không vào được do thị trường (R2: Open nến kế đã vượt SL hoặc đã vượt TP1) – chỉ đếm, không chiếm vị thế.
  NO_DATA            : không đánh giá được do DỮ LIỆU (R2 không có nến kế; gặp nến hỏng) – chỉ đếm, không chiếm vị thế.
  INVALID            : tín hiệu hỏng (chiều ≠ ±1, giá không hữu hạn, SL sai phía → rủi ro ≤ 0) – chỉ đếm.
  Với NO_FILL / NO_DATA / INVALID: risk, r_gross, r_net, mfe_r, mae_r = null; lý do ở fill_note.

QUY TẮC
  • R1 (mặc định): vào tại P_ref = Close nến trigger; đánh giá từ nến SAU nến trigger.
    R2 (biến thể): vào tại Open nến kế; Open vượt SL (hoặc = SL) → NO_FILL GAP_BEYOND_SL; Open đạt/vượt TP1 → NO_FILL GAP_BEYOND_TP;
    Open nằm giữa P_ref và SL → khớp, rủi ro nhỏ hơn (ghi nhận, không điều chỉnh SL). Ở R2 nến vào được đánh giá High/Low (sau Open).
  • BUY: chạm SL khi Low ≤ SL; chạm TP1 khi High ≥ TP1. SELL đối xứng. TP1 = null → chỉ SL / TIMEOUT / OPEN.
  • Gap: Open của một nến sau nến vào đã vượt SL → thoát tại Open (xấu hơn SL); đã vượt TP1 → thoát tại Open.
  • Nến chạm cả SL và TP1 → mặc định SL trước (bảo thủ), cờ same_bar_conflict; tp_first chỉ để đo độ nhạy.
  • max_bars ĐẾM THEO NẾN có trong dữ liệu (không theo đồng hồ). Chưa chạm sau đúng max_bars nến → TIMEOUT tại Close nến thứ max_bars.
    Hết dữ liệu trước max_bars → OPEN. Khoảng trống thời gian giữa hai nến liên tiếp > bar_ms được ĐẾM (time_gaps) và
    ghi khoảng lớn nhất (max_gap_ms) – bộ giả lập không phân biệt nghỉ thị trường với thiếu dữ liệu; việc đó thuộc bộ kiểm dữ liệu (du_lieu.py).
  • Nến hỏng (giá không hữu hạn, ≤ 0, High < max(Open, Close), Low > min(Open, Close)) trong cửa sổ đánh giá → dừng, NO_DATA INVALID_BAR.
  • R = (giá thoát − giá vào)×dir / rủi ro, rủi ro = (giá vào − SL)×dir > 0. Chi phí (spread + phí + 2×trượt giá) trừ vào R.
  • MFE/MAE (đơn vị R), MFE ≥ 0, MAE ≤ 0, trên các nến đánh giá tới nến thoát. QUY TẮC NẾN THOÁT (bảo thủ, mọi nhánh):
      – thoát tại Open (gap): chỉ tính giá Open của nến đó;
      – thoát SL trong nến (kể cả xung đột sl_first): phía có lợi của nến đó KHÔNG tính; MAE = min(MAE, −1);
      – thoát TP1 trong nến: MFE chặn tại TP1; phía bất lợi của nến đó TÍNH ĐỦ;
      – xung đột tp_first: MFE chặn tại TP1; phía bất lợi tính đủ (đã chạm SL → MAE ≤ −1);
      – TIMEOUT / OPEN: nến cuối tính đủ.
    Hệ quả kiểm được: MAE ≤ r_gross ≤ MFE trên mọi nhánh."""
import math
from dataclasses import dataclass

PHIEN_BAN = "1.1"
DONG = ("TP1", "SL", "TIMEOUT")
KHONG_VAO = ("NO_FILL", "NO_DATA", "INVALID")


@dataclass
class Cfg:
    entry: str = "close"          # "close" (R1) | "next_open" (R2)
    same_bar: str = "sl_first"    # "sl_first" | "tp_first"
    max_bars: int = 288           # 288 nến M5 = 24 giờ giao dịch liên tục (ASSUMPTION)
    spread: float = 0.0           # đơn vị giá
    commission: float = 0.0       # đơn vị giá, khứ hồi
    slippage: float = 0.0         # đơn vị giá mỗi lần khớp
    bar_ms: int = 300000          # độ dài nến (M5) để đếm khoảng trống thời gian

    def rule_id(self):
        return f"R-{self.entry}-{self.same_bar}-{self.max_bars}"

    def cost_id(self):
        return f"C-s{self.spread}-c{self.commission}-sl{self.slippage}"


def _f(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def nen_hong(b):
    """None nếu nến hợp lệ, ngược lại chuỗi lý do."""
    try:
        o, h, l, c, t = b["o"], b["h"], b["l"], b["c"], b["t"]
    except (KeyError, TypeError):
        return "thiếu trường"
    if not all(_f(v) for v in (o, h, l, c)) or not isinstance(t, int):
        return "giá/thời gian không hữu hạn"
    if min(o, h, l, c) <= 0:
        return "giá ≤ 0"
    if h < max(o, c) or l > min(o, c):
        return "High/Low mâu thuẫn Open/Close"
    return None


def _khong(base, outcome, note):
    return dict(base, outcome=outcome, fill_note=note, risk=None, r_gross=None, r_net=None, mfe_r=None, mae_r=None, bars_held=0,
                exit_ts_ms=None, exit_price=None, time_gaps=0, max_gap_ms=0)


def mo_phong(sig, bars, i_trig, cfg=Cfg()):
    """sig: dict(dir, sl, tp1, p_ref). bars: list dict(t, o, h, l, c) nến M5 đã đóng, tăng dần theo t. i_trig: chỉ số nến trigger.
    Trả dict theo hợp đồng TRADES 1.1 (thiếu signal_id/schema – bên gọi bổ sung)."""
    d, sl, tp, pr = sig.get("dir"), sig.get("sl"), sig.get("tp1"), sig.get("p_ref")
    t_trig = bars[i_trig]["t"] if 0 <= i_trig < len(bars) and isinstance(bars[i_trig], dict) else None
    base = dict(entry_ts_ms=t_trig, entry_price=None, same_bar_conflict=False, gap_exit=False)
    if d not in (1, -1) or not _f(sl) or not _f(pr) or (tp is not None and not _f(tp)) or t_trig is None:
        return _khong(base, "INVALID", "INVALID_SIGNAL")
    if (pr - sl) * d <= 0:
        return _khong(dict(base, entry_price=pr), "INVALID", "INVALID_RISK")
    if tp is not None and (tp - pr) * d <= 0:
        return _khong(dict(base, entry_price=pr), "INVALID", "TP_WRONG_SIDE")
    if nen_hong(bars[i_trig]):
        return _khong(base, "NO_DATA", "INVALID_BAR")
    if cfg.entry == "close":
        ie, entry, start = i_trig, pr, i_trig + 1
    else:
        if i_trig + 1 >= len(bars):
            return _khong(base, "NO_DATA", "NO_NEXT_BAR")
        if nen_hong(bars[i_trig + 1]):
            return _khong(base, "NO_DATA", "INVALID_BAR")
        ie, entry, start = i_trig + 1, bars[i_trig + 1]["o"], i_trig + 1
        base.update(entry_ts_ms=bars[ie]["t"], entry_price=entry)
        if (entry - sl) * d <= 0:
            return _khong(base, "NO_FILL", "GAP_BEYOND_SL")
        if tp is not None and (entry - tp) * d >= 0:
            return _khong(base, "NO_FILL", "GAP_BEYOND_TP")
    base.update(entry_ts_ms=bars[ie]["t"], entry_price=entry)
    risk = (entry - sl) * d
    cost = cfg.spread + cfg.commission + 2 * cfg.slippage
    R = lambda px: (px - entry) * d / risk           # noqa: E731
    mfe = mae = 0.0
    gaps, gmax, t_prev = 0, 0, bars[ie]["t"]

    def ra(outcome, k, px, mfe_, mae_, **kw):
        rg = R(px)
        return dict(base, outcome=outcome, fill_note=None, exit_ts_ms=bars[k]["t"], exit_price=px, risk=risk, r_gross=rg, r_net=rg - cost / risk,
                    mfe_r=max(0.0, mfe_), mae_r=min(0.0, mae_), bars_held=k - start + 1, time_gaps=gaps, max_gap_ms=gmax, **kw)

    end = min(len(bars), start + cfg.max_bars)
    for k in range(start, end):
        b = bars[k]
        why = nen_hong(b)
        if why or (k > ie and b["t"] <= t_prev):
            return dict(_khong(base, "NO_DATA", "INVALID_BAR" if why else "NON_MONOTONIC_TIME"), time_gaps=gaps, max_gap_ms=gmax)
        if k > ie and b["t"] - t_prev > cfg.bar_ms:
            gaps += 1; gmax = max(gmax, b["t"] - t_prev)
        t_prev = b["t"]
        first = (k == start and cfg.entry == "next_open")           # R2: Open nến vào là giá vào
        if not first:
            if d * (b["o"] - sl) <= 0:
                return ra("SL", k, b["o"], mfe, min(mae, R(b["o"])), gap_exit=True)
            if tp is not None and d * (b["o"] - tp) >= 0:
                return ra("TP1", k, b["o"], max(mfe, R(b["o"])), mae, gap_exit=True)
        fav = b["h"] if d == 1 else b["l"]
        adv = b["l"] if d == 1 else b["h"]
        hit_sl = d * (adv - sl) <= 0
        hit_tp = tp is not None and d * (fav - tp) >= 0
        if hit_sl and hit_tp:
            if cfg.same_bar == "sl_first":
                return ra("SL", k, sl, mfe, min(mae, -1.0), same_bar_conflict=True)
            return ra("TP1", k, tp, max(mfe, R(tp)), min(mae, R(adv)), same_bar_conflict=True)
        if hit_sl:
            return ra("SL", k, sl, mfe, min(mae, -1.0))
        if hit_tp:
            return ra("TP1", k, tp, max(mfe, R(tp)), min(mae, R(adv)))
        mfe = max(mfe, R(fav))
        mae = min(mae, R(adv))
    n = end - start
    if start + cfg.max_bars > len(bars):
        last_c = bars[end - 1]["c"] if n > 0 else (entry if cfg.entry == "close" else bars[ie]["c"])
        rg = R(last_c)
        return dict(base, outcome="OPEN", fill_note=None, exit_ts_ms=None, exit_price=None, risk=risk, r_gross=rg, r_net=rg - cost / risk,
                    mfe_r=mfe, mae_r=mae, bars_held=n, time_gaps=gaps, max_gap_ms=gmax)
    k = start + cfg.max_bars - 1
    return ra("TIMEOUT", k, bars[k]["c"], mfe, mae)


def khu_trung(signals):
    """IP-21: nhiều thể hiện có thể trigger cùng nến, cùng chiều → giữ 1 tín hiệu mỗi dup_key: bản PHÁT RA TRƯỚC theo emit_seq
    (thứ tự engine đẩy sự kiện vào evS, tăng dần theo nến rồi theo vị trí trong nến). Thiếu emit_seq → ValueError (không đoán thứ tự).
    Trả (giữ, số bị loại). Thứ tự đầu ra = thứ tự phát ra."""
    if any(not isinstance(s.get("emit_seq"), int) or isinstance(s.get("emit_seq"), bool) for s in signals):
        raise ValueError("khu_trung: mọi tín hiệu phải có emit_seq (int)")
    seq = [s["emit_seq"] for s in signals]
    if len(set(seq)) != len(seq):
        raise ValueError("khu_trung: emit_seq bị trùng")
    seen, giu = set(), []
    for s in sorted(signals, key=lambda x: x["emit_seq"]):
        if s["dup_key"] in seen:
            continue
        seen.add(s["dup_key"]); giu.append(s)
    return giu, len(signals) - len(giu)


def khong_chong(trades):
    """Biến thể danh mục: mỗi (symbol, setup) chỉ 1 lệnh ĐANG MỞ tại một thời điểm.
    • Chỉ lệnh ĐÃ VÀO (TP1/SL/TIMEOUT/OPEN) chiếm vị thế. NO_FILL/NO_DATA/INVALID không chiếm, được giữ nguyên trong đầu ra để thống kê đếm.
    • OPEN chiếm vị thế tới hết dữ liệu (chặn mọi lệnh sau cùng khóa).
    • Lệnh vào tại thời điểm ≤ thời điểm thoát của lệnh đang mở (cùng nến) bị bỏ – ASSUMPTION bảo thủ vì không biết thứ tự trong nến.
    • Thứ tự xét: (entry_ts_ms, emit_seq nếu có). Trả (giữ, số bị bỏ)."""
    giu, bo, mo = [], 0, {}
    for t in sorted(trades, key=lambda x: (x["entry_ts_ms"] if x.get("entry_ts_ms") is not None else -1, x.get("emit_seq", 0))):
        if t.get("outcome") in KHONG_VAO:
            giu.append(t); continue
        k = (t["symbol"], t["setup"])
        if k in mo and t["entry_ts_ms"] <= mo[k]:
            bo += 1; continue
        giu.append(t)
        mo[k] = math.inf if t.get("outcome") == "OPEN" or t.get("exit_ts_ms") is None else t["exit_ts_ms"]
    return giu, bo
