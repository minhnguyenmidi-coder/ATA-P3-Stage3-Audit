# -*- coding: utf-8 -*-
"""PIPELINE Shadow Evaluation theo 4 Ô ĐỘC LẬP: XAUUSD-SU3, XAUUSD-SU5, BTCUSD-SU3, BTCUSD-SU5. Ngoài Pine.

Các bước: 1 nhập · 2 kiểm OHLCV · 3 chuẩn hóa · 4 replay engine (tính bối cảnh từ OHLCV) · 5 EVENTS/SIGNALS · 6 khử trùng (emit_seq) ·
7 giả lập lệnh · 8 TRADES + kiểm hợp đồng cấp bảng · 9 chỉ số + phễu · 10 báo cáo.
• Dữ liệu THẬT: bước 1–3 chạy được khi có file; bước 4 BLOCKED vì replay toàn script (f_struct, MD-3 dựng vùng, MD-4 cụm, MD-5 pool,
  request.security, ta.*) CHƯA ĐƯỢC HIỆN THỰC trong Python (xem ATA_P3_STAGE3_REPLAY_SCOPE.md) → bước 5–10 BLOCKED. Không bịa kết quả.
• SYNTH: chạy đủ bước 4–10 trên khối Pine SHADOW nguyên văn với bối cảnh tiêm ngẫu nhiên – chỉ để KIỂM ĐƯỜNG ỐNG, không phải hiệu quả.
Dùng: python3 shadow_eval/pipeline.py [--du-lieu XAUUSD=path.csv:TV ...] → ket_qua_stage3/o_*/"""
import argparse, json, os, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import hop_dong as HD, mo_phong_lenh as MP, chi_so as CS, du_lieu as DL   # noqa: E402

O_LIST = [("XAUUSD", "SU3"), ("XAUUSD", "SU5"), ("BTCUSD", "SU3"), ("BTCUSD", "SU5")]
LY_DO_REPLAY = ("Replay toàn script từ OHLCV chưa hiện thực: f_struct (gọi qua 4 lệnh request.security M15/H1/H4/D), 4 lệnh request.security lấy giá kỳ D/W/M/12M, "
                "MD-3 dựng vùng, MD-4 cụm, MD-5 pool, ta.* "
                "chưa có trong Python – chỉ các khối SHADOW/S1/ARMED chạy nguyên văn với bối cảnh tiêm sẵn")


def _jd(o, p):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(o, f, ensure_ascii=False, indent=1, allow_nan=False, default=str)


def chay_synth(symbol, setup, seeds=range(40), cfg=MP.Cfg(max_bars=60)):
    """Chạy đủ chuỗi trên SYNTH cho một ô. Trả dict kết quả (events, signals, trades, loi_hop_dong, chi_so, phieu)."""
    import chuan_hoa as CH
    E, S, T, loi, bo_trung = [], [], [], [], 0
    for sd in seeds:
        r = CH.replay_synth(sd, symbol=symbol)
        ev = [e for e in r["events"] if e["setup"] == setup]
        sg = [s for s in r["signals"] if s["setup"] == setup]
        loi += [f"seed {sd}: {x}" for x in HD.kiem_bang(r["events"], r["signals"], [])]
        giu, n = MP.khu_trung(sg); bo_trung += n
        tr = []
        for s in giu:
            if s["reason"] != 16:
                continue
            t = MP.mo_phong(s, r["bars"], r["idx"][s["trigger_ts_ms"]], cfg)
            t.update(schema_version=HD.SCHEMA_VERSION, signal_id=s["signal_id"], symbol=symbol, setup=setup, emit_seq=s["emit_seq"], sim_rule=cfg.rule_id(), cost_model=cfg.cost_id())
            tr.append(t)
        loi += [f"seed {sd}: {x}" for x in HD.kiem_bang(ev, sg, tr)]
        # mỗi seed là một lượt replay riêng → emit_seq chỉ duy nhất trong seed; gắn tiền tố seed khi gộp
        E += [dict(e, _seed=sd) for e in ev]; S += [dict(s, _seed=sd, dup_key=f"seed{sd}|{s['dup_key']}") for s in sg]; T += [dict(t, _seed=sd) for t in tr]
    T_chon, n_chong = [], 0
    for sd in sorted({t["_seed"] for t in T}):              # mỗi seed là một lượt replay độc lập → lọc danh mục riêng từng lượt (F25)
        g_, n_ = MP.khong_chong([t for t in T if t["_seed"] == sd]); T_chon += g_; n_chong += n_
    return dict(events=E, signals=S, trades=T, loi_hop_dong=loi, bo_trung=bo_trung, bo_chong_lan=n_chong,
                chi_so=CS.hieu_qua(T).get((symbol, setup)), chi_so_khong_chong=CS.hieu_qua(T_chon).get((symbol, setup)),
                phieu=CS.phieu(E, S).get((symbol, setup)))


def chay_o(symbol, setup, du_lieu=None, out_dir=None):
    """Một ô với dữ liệu THẬT. du_lieu = (đường dẫn, định dạng, lech_phut) hoặc None."""
    bc = dict(o=f"{symbol}-{setup}", buoc=[], ket_luan=None)
    add = lambda n, st, ct: bc["buoc"].append(dict(buoc=n, trang_thai=st, chi_tiet=ct))      # noqa: E731
    if not du_lieu or not os.path.exists(du_lieu[0]):
        add("1 nhập", "BLOCKED", "không có file OHLCV lịch sử trong môi trường (mạng tắt; chưa được cung cấp)")
        kq = None
    else:
        bars, loi = DL.nhap(open(du_lieu[0], encoding="utf-8").read(), du_lieu[1], du_lieu[2] if len(du_lieu) > 2 else None)
        add("1 nhập", "PASS" if bars and not loi else ("WARN" if bars else "FAIL"), dict(so_nen=len(bars), loi=loi[:10]))
        kq = DL.kiem_ohlcv(bars, symbol) if bars else None
        if kq:
            add("2 kiểm OHLCV", kq["trang_thai"], {k: kq[k] for k in ("so_dong", "do_phu", "nen_thieu", "nen_nghi_ung_vien", "loi", "canh_bao", "phien")})
            if kq["trang_thai"] != "FAIL":
                nb = DL.chuan_hoa(bars)
                add("3 chuẩn hóa", "PASS", dict(so_nen=len(nb)))
    for n in ("1 nhập", "2 kiểm OHLCV", "3 chuẩn hóa"):
        if not any(b["buoc"] == n for b in bc["buoc"]):
            add(n, "BLOCKED", "phụ thuộc bước trước")
    add("4 replay engine", "BLOCKED", LY_DO_REPLAY)
    for n in ("5 EVENTS/SIGNALS", "6 khử trùng", "7 giả lập lệnh", "8 TRADES + kiểm hợp đồng", "9 chỉ số + phễu"):
        add(n, "BLOCKED", "phụ thuộc bước 4")
    bc["ket_luan"] = "BLOCKED – chưa đánh giá hiệu quả thị trường thật"
    if out_dir:
        os.makedirs(out_dir, exist_ok=True); _jd(bc, os.path.join(out_dir, "bao_cao_o.json"))
    return bc


def bao_cao_o_md(bc, syn):
    L = [f"# Báo cáo Shadow – ô {bc['o']}", "", f"**Kết luận thị trường thật:** {bc['ket_luan']}", "", "| Bước | Trạng thái | Chi tiết |", "|---|---|---|"]
    for b in bc["buoc"]:
        L.append(f"| {b['buoc']} | {b['trang_thai']} | {json.dumps(b['chi_tiet'], ensure_ascii=False) if not isinstance(b['chi_tiet'], str) else b['chi_tiet']} |")
    L += ["", "## Kiểm đường ống trên SYNTH (KHÔNG phải hiệu quả chiến lược)", "",
          "Bối cảnh vùng/cụm/sự kiện cấu trúc được tiêm ngẫu nhiên, giá là bước ngẫu nhiên. Số liệu dưới đây chỉ chứng minh chuỗi chạy đúng hợp đồng.", ""]
    L.append(f"- Sự kiện: {len(syn['events'])}; tín hiệu: {len(syn['signals'])}; lệnh giả lập: {len(syn['trades'])}; loại trùng (IP-21): {syn['bo_trung']}; "
             f"bỏ do chồng lấn (biến thể danh mục): {syn['bo_chong_lan']}; lỗi hợp đồng: {len(syn['loi_hop_dong'])}")
    L.append(f"- Phễu: `{json.dumps(syn['phieu'], ensure_ascii=False)}`")
    if syn["chi_so"]:
        L.append(f"- Chỉ số (SYNTH): dong={syn['chi_so']['dong']}, mo={syn['chi_so']['mo']}, khong_khop={syn['chi_so']['khong_khop']} – không diễn giải")
    else:
        L.append("- Chỉ số: không có lệnh (SYNTH không sinh trigger cho setup này)")
    return "\n".join(L) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--du-lieu", nargs="*", default=[], help="SYMBOL=path:TV hoặc SYMBOL=path:MT5:lech_phut")
    ap.add_argument("--out", default=os.path.join(G, "ket_qua_stage3"))
    a = ap.parse_args(argv)
    dl = {}
    for x in a.du_lieu:
        sym, rest = x.split("=", 1); p = rest.split(":")
        dl[sym] = (p[0], p[1], int(p[2]) if len(p) > 2 else None)
    tong = {}
    for sym, su in O_LIST:
        od = os.path.join(a.out, f"o_{sym}_{su}")
        bc = chay_o(sym, su, dl.get(sym), od)
        syn = chay_synth(sym, su)
        _jd(dict(phieu=syn["phieu"], chi_so=syn["chi_so"], chi_so_khong_chong=syn["chi_so_khong_chong"], loi_hop_dong=syn["loi_hop_dong"][:50],
                 so_su_kien=len(syn["events"]), so_tin_hieu=len(syn["signals"]), so_lenh=len(syn["trades"]), bo_trung=syn["bo_trung"]), os.path.join(od, "synth_kiem_duong_ong.json"))
        open(os.path.join(od, f"ATA_P3_STAGE3_SHADOW_{sym}_{su}.md"), "w", encoding="utf-8").write(bao_cao_o_md(bc, syn))
        tong[f"{sym}-{su}"] = dict(thi_truong_that=bc["ket_luan"], synth_loi_hop_dong=len(syn["loi_hop_dong"]), synth_lenh=len(syn["trades"]))
        print(sym, su, tong[f"{sym}-{su}"])
    _jd(tong, os.path.join(a.out, "tong_hop_4_o.json"))
    return tong


if __name__ == "__main__":
    main()
