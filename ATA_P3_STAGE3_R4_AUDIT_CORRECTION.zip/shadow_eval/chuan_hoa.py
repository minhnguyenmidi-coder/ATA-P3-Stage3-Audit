# -*- coding: utf-8 -*-
"""ADAPTER engine → hợp đồng 1.1 (EVENTS / SIGNALS) cho replay SHADOW. Ngoài Pine; chỉ ĐỌC trạng thái sau mỗi nến.

Nguồn sự kiện
  • Sự kiện engine THẬT (mảng evS do khối Pine nguyên văn đẩy vào): ARMED (trạng thái 2), SKIP (4), EXPIRED (5), VOID (6), TRIGGER (có trig).
    emit_seq của chúng = thứ tự đẩy vào evS trong nến → CHÍNH XÁC.
  • Sự kiện SUY RA từ so sánh mảng sh trước/sau nến (engine không phát): CREATED (thể hiện mới), STEP (st đổi, không phải sang 2),
    END_NO_EVENT (thể hiện biến mất không kèm sự kiện – IP-20). Thứ tự trong nến của nhóm này là QUY ƯỚC: CREATED trước mọi sự kiện evS
    (thể hiện được tạo ở khối tiền-kích hoạt, chạy trước khối M5), STEP và END_NO_EVENT sau → PARTIALLY VERIFIED (xem REPLAY_SCOPE).
  • Ghép sự kiện evS với thể hiện theo (su, dir, bosMin, baseMin) với giá trị trường của thể hiện tại cuối nến. Trùng khóa (IP-21) →
    gán theo thứ tự tạo, đánh dấu 'mo_ho' trong thống kê adapter.

setup_id = hid(symbol, setup, dir, bm lúc tạo, bs lúc tạo, t0, ts tạo, thứ tự tạo trong nến) – duy nhất cho mỗi thể hiện kể cả khi IP-21 trùng khóa."""
import os, random, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.environ.get("ATA_GOC") or os.path.dirname(D)   # ATA_GOC: chạy bản sao module (kiểm đột biến)
sys.path.insert(0, D)
import hop_dong as HD   # noqa: E402

SS = {2: "ARMED", 4: "SKIP", 5: "EXPIRED", 6: "VOID"}


def _na(x, NA):
    return x is None or x is NA


class BoGhi:
    """Gắn vào một PIPE (kiem_cach_ly.PIPE, shadow=True). Gọi buoc(bar_dict) thay cho pipe.bar."""

    def __init__(self, pipe, symbol, engine_version="0.3.9", source="SYNTH", tf="5"):
        from khung039 import NA
        self.NA, self.p, self.sym, self.ev_ver, self.src, self.tf = NA, pipe, symbol, engine_version, source, tf
        self.seq = 0
        self.events, self.signals = [], []
        self.theo_doi = {}            # id(obj) → dict(obj, setup_id, st, song)
        self.thong_ke = dict(mo_ho=0, khong_ghep=0)

    def _f(self, x):
        return None if _na(x, self.NA) else float(x)

    def _ev(self, info, et, ts, state, reason, step=None):
        o = info["obj"].f
        r = dict(schema_version=HD.SCHEMA_VERSION, engine_version=self.ev_ver, source=self.src, symbol=self.sym, tf=self.tf, setup="SU%d" % o["su"], mode="SHADOW",
                 setup_id=info["setup_id"], event_id=HD.hid(info["setup_id"], et, ts, self.seq), emit_seq=self.seq, event_type=et, step=step,
                 ts=HD.ts_tu_ms(ts), ts_ms=ts, dir=int(o["d"]), state=int(state), reason=int(reason), anchor_price=self._f(o["lv"]), ext_price=self._f(o["ext"]))
        self.seq += 1
        self.events.append(r)
        return r

    def gan(self, driver):
        """Bọc driver.bar (PIPE hoặc SHD) để mọi nến đều đi qua bộ ghi. Trả driver."""
        goc = driver.bar
        driver.bar = lambda *a, **k: self.buoc(lambda: goc(*a, **k))
        return driver

    def buoc(self, chay):
        g, ts = self.p.g, self.p.T
        ip, chup = self.p.ip, []
        goc = ip.bar

        def moc(blk):                         # chụp mảng sh ngay sau khối tiền-kích hoạt (nơi DUY NHẤT tạo thể hiện: SH.new dòng 2851, 2865)
            goc(blk)
            if blk is self.p.pre:
                chup.extend(g["sh"].v)
        ip.bar = moc
        try:
            out = chay()
        finally:
            ip.bar = goc
        sau = {id(x): x for x in g["sh"].v}
        moi = [x for x in chup if id(x) not in self.theo_doi] + [x for x in g["sh"].v if id(x) not in self.theo_doi and x not in chup]
        for j, x in enumerate(moi):
            f = x.f
            sid = HD.hid(self.sym, f["su"], f["d"], f["bm"], f["bs"], f["t0"], ts, j)
            # SH.new luôn tạo với st = 0 (khai báo type SH: 'int st = 0'); st đổi CÙNG nến tạo sẽ được phát STEP ngay sau CREATED
            self.theo_doi[id(x)] = info = dict(obj=x, setup_id=sid, st=0, song=True, tao=ts)
            self._ev(info, "CREATED", ts, 0, 0, step=0)
        # thể hiện tạo ở khối tiền-kích hoạt rồi kết thúc ngay ở khối M5 cùng nến vẫn được thấy nhờ ảnh chụp sau khối tiền-kích hoạt
        da_ghep = set()
        for e in g["evS"].v:
            f = e.f
            ung = [i for k, i in self.theo_doi.items() if i["song"] and k not in da_ghep and i["obj"].f["su"] == f["su"] and i["obj"].f["d"] == f["dir"]
                   and i["obj"].f["bm"] == f["bosMin"] and i["obj"].f["bs"] == f["baseMin"]]
            if not ung:
                self.thong_ke["khong_ghep"] += 1; continue
            ket_thuc = bool(f["trig"]) or f["state"] != 2
            # lọc theo hệ quả quan sát được: sự kiện kết thúc ↔ thể hiện đã rời mảng sh; ARMED ↔ thể hiện vừa chuyển sang st = 2
            loc = [i for i in ung if (id(i["obj"]) not in sau) == ket_thuc and (ket_thuc or (i["st"] != 2 and i["obj"].f["st"] == 2))]
            if loc:
                ung = loc
            if len(ung) > 1:
                self.thong_ke["mo_ho"] += 1
                # các ứng viên còn lại giống hệt nhau về khóa và về hệ quả → không phân biệt được (IP-21); chọn theo thứ tự tạo
            info = sorted(ung, key=lambda i: (i["tao"], i["setup_id"]))[0]
            self._buoc_trung_gian(info, ts)
            if f["trig"]:
                r = self._ev(info, "TRIGGER", ts, f["state"], f["reason"], step=int(info["obj"].f["st"]))
                da_ghep.add(id(info["obj"]))
                self._sig(info, r, f, ts)
            elif f["state"] in SS:
                self._ev(info, SS[f["state"]], ts, f["state"], f["reason"], step=int(info["obj"].f["st"]))
                if f["state"] != 2:
                    da_ghep.add(id(info["obj"]))
            else:
                self.thong_ke["khong_ghep"] += 1
        for k, info in list(self.theo_doi.items()):
            if not info["song"]:
                continue
            if k in da_ghep:
                info["song"] = False; continue
            self._buoc_trung_gian(info, ts)
            if k not in sau:
                info["song"] = False
                self._ev(info, "END_NO_EVENT", ts, 0, 0, step=int(info["obj"].f["st"]))
        return out

    def _buoc_trung_gian(self, info, ts):
        """Phát STEP cho mọi giá trị st trung gian đã đi qua kể từ lần ghi trước (chỉ st = 1; st = 2 do sự kiện ARMED của engine).
        st chỉ tăng 0 → 1 → 2 trong mã (dòng 2834, 3556, 3559, 3563) nên st nhảy 0 → 2 nghĩa là đã qua 1."""
        moi = int(info["obj"].f["st"])
        for v in range(int(info["st"]) + 1, moi + 1):
            if v != 2:
                self._ev(info, "STEP", ts, 0, 0, step=v)
        info["st"] = max(int(info["st"]), moi)

    def _sig(self, info, ev, f, ts):
        p, sl = float(f["pRef"]), float(f["sl"])
        tp = self._f(f["tp1"])
        d = int(f["dir"]); su = "SU%d" % f["su"]
        rr = abs(tp - p) / abs(p - sl) if tp is not None and p != sl else None
        self.signals.append(dict(schema_version=HD.SCHEMA_VERSION, engine_version=self.ev_ver, source=self.src, symbol=self.sym, setup=su, setup_id=info["setup_id"],
                                 signal_id=HD.hid(info["setup_id"], ts), emit_seq=ev["emit_seq"], dir=d, trigger_ts=HD.ts_tu_ms(ts), trigger_ts_ms=ts, p_ref=p, sl=sl, tp1=tp,
                                 rr=rr, reason=int(f["reason"]), perm_reg=None, perm_vol=None, dup_key=f"{self.sym}|{su}|{d}|{ts}"))


def replay_synth(seed, n_bars=120, symbol="XAUUSD"):
    """Kịch bản GIẢ LẬP (SYNTH): bối cảnh vùng/cụm/sự kiện cấu trúc được TIÊM ngẫu nhiên (không tính từ OHLCV), giá ngẫu nhiên.
    Trả dict(events, signals, bars, idx) – idx: trigger_ts_ms → chỉ số nến. KHÔNG dùng để đánh giá hiệu quả chiến lược."""
    sys.path.insert(0, os.path.join(G, "kiem_toan039"))
    import kiem_cach_ly as CL
    from khung039 import S39, zone
    r2 = random.Random(seed)
    pp = CL.PIPE(S39, True); pp.ctx(r2.choice((1, 2, 3, 4)))
    bg = BoGhi(pp, symbol); bg.gan(pp)
    p = 2000.0
    for _ in range(2):
        d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(2, 8), 1)
        pp.g["zones"].v.append(zone(pp.ip, 60, d, b0 - 2, b0 + 2, bm=pp.T // 60000 - 600, pos=1))
    for _ in range(3):
        d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(1, 6), 1)
        pp.g["zones"].v.append(zone(pp.ip, 15, d, b0 - 1, b0 + 1, bm=pp.T // 60000 + r2.choice((15, 30, 60)), bs=r2.randint(0, 99), pos=1))
    cl = sorted(round(p + r2.uniform(-8, 8), 1) for _ in range(3))
    pp.g.update(cLo=CL.PArr([x - 0.4 for x in cl]), cHi=CL.PArr([x + 0.4 for x in cl]), cRank=CL.PArr([r2.randint(1, 5) for _ in cl]))
    bars, idx = [], {}
    for j in range(n_bars):
        o = p; c = round(p + r2.gauss(0, 1.8), 1); h = round(max(o, c) + abs(r2.gauss(0, 0.7)), 1); l = round(min(o, c) - abs(r2.gauss(0, 0.7)), 1)
        m15 = j % 3 == 0
        bb = dict(o=o, h=h, l=l, c=c, m15=m15, ev=r2.choice((0, 0, 1, 2, 3, 4)) if m15 else 0, ref=round(p + r2.uniform(-3, 3), 1),
                  h1=(c, r2.choice((0, 3, 4)), r2.random() < 0.6) if (m15 and j % 12 == 0) else None, pend=False)
        t = pp.T
        pp.bar(bb)
        bars.append(dict(t=t, o=o, h=h, l=l, c=c)); idx[t] = j
        p = c
    return dict(events=bg.events, signals=bg.signals, bars=bars, idx=idx, thong_ke=bg.thong_ke)


def replay_su3_co_dinh(them_nen=None, symbol="XAUUSD"):
    """Kịch bản CÓ ĐỊNH HƯỚNG (SYNTH) đưa SU-3 BUY tới TRIGGER 17/16 – cùng dữ liệu với S3-11 của kiem_su3_su5.py (driver SHD, khối Pine nguyên văn).
    SYNTH không ngẫu nhiên không sinh được trigger SU-3, nên kịch bản này lấp lỗ phủ của E2E cho SU-3. them_nen: list (o, h, l, c) chạy sau trigger
    (để giả lập lệnh). Trả dict(events, signals, bars, idx, thong_ke)."""
    sys.path.insert(0, os.path.join(G, "kiem_toan039"))
    from khung039 import SHD, S39, zone
    s = SHD(S39)
    bg = BoGhi(s, symbol); bg.gan(s)
    bars, idx = [], {}
    goc = s.bar

    def bar(o, h, l, c, **kw):
        t = s.T
        r = goc(o, h, l, c, **kw)
        idx[t] = len(bars); bars.append(dict(t=t, o=float(o), h=float(h), l=float(l), c=float(c)))
        return r
    s.ctx(reg=2, atr15=8.0)
    s.g["zones"].v.append(zone(s.ip, 60, 1, 1990.0, 1995.0, bm=s.T // 60000 - 600))
    s.m15(1997, 1998, 1994.0, 1996.5)
    bar(1996.5, 1997, 1996, 1996.8)
    s.m15(1996, 1997, 1993.0, 1996)
    for _ in range(3):
        bar(1996, 1996.3, 1995.7, 1996.1)
    s.m15(1996, 2003, 1995.5, 2002, h1=(2002.0, 3, True))
    Z2 = zone(s.ip, 15, 1, 2000.0, 2002.0, bm=s.T // 60000 - 30, bs=7)
    s.g["zones"].v.append(Z2)
    bar(2004, 2005, 2003.5, 2004.5)
    Z2.f["touches"], Z2.f["moved"] = 1, True
    bar(2003.0, 2003.2, 2001.5, 2002.8)
    Z2.f["moved"] = False
    bar(2002.8, 2003.3, 2001.2, 2002.0)
    bar(2002.0, 2002.6, 2001.4, 2002.3)
    bar(2004.0, 2005.5, 2003.9, 2005.2)
    for o, h, l, c in (them_nen or []):
        bar(o, h, l, c)
    return dict(events=bg.events, signals=bg.signals, bars=bars, idx=idx, thong_ke=bg.thong_ke)
