#!/usr/bin/env bash
# Tái lập toàn bộ kiểm thử Build 0.3.9. Chạy từ thư mục gốc gói (chứa src038/, src039/, kiem_toan035/, kiem_toan039/ …).
set -u
cd "$(dirname "$0")/.."
echo "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13  src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine" | sha256sum -c - || { echo "SAI SHA BASELINE 0.3.8 – DỪNG"; exit 3; }
python3 tools033/dung_build_039.py 2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0 || exit 1
cp src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine hoi_quy034/src/
mkdir -p ket_qua039/hoi_quy_bo_038_tren_039
python3 kiem_toan039/hoi_quy_bo_038_tren_039.py > ket_qua039/hoi_quy_bo_038_tren_039/nhat_ky.txt 2>&1; echo "hồi quy bộ 0.3.8 trên 0.3.9: exit=$? (1 = có FAIL lịch sử/token đã phân loại)"
(cd kiem_toan039 && python3 chay_039.py > ../ket_qua039/stdout_chay_039.txt 2>&1); rc=$?
echo "bộ 0.3.9: exit=$rc (1 = còn FAIL T-01 token; 2 = còn BLOCKED/NOT TESTED)"
tail -1 ket_qua039/nhat_ky_039.txt
exit $rc
