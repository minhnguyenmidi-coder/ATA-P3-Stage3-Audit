# -*- coding: utf-8 -*-
"""BỘ KIỂM TỔNG BUILD 0.3.9 – SU-3/SU-5 SHADOW. python3 kiem_toan039/chay_039.py → ket_qua039/ket_qua_039.{json,csv}, nhat_ky_039.txt, dot_bien_039.txt
Nhãn phương pháp: STATIC · SOURCE-DERIVED (khối Pine nguyên văn trên pine_mini – KHÔNG phải TradingView) · MODEL-BASED · HỒI QUY · ĐỘT BIẾN · PLATFORM.
Mã thoát: 3 sai SHA baseline (dừng) · 1 có FAIL · 2 còn BLOCKED/NOT TESTED · 0 tất cả PASS."""
import csv, hashlib, json, os, re, subprocess, sys, time, traceback
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, D)
import khung039 as KH            # noqa: E402
import kiem_su3_su5 as TS        # noqa: E402
import kiem_cach_ly as CL        # noqa: E402

OUT = os.path.join(G, "ket_qua039"); os.makedirs(OUT, exist_ok=True)
SHA38 = "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13"
F038, F039 = KH.F038, KH.F039
KQ, LOG = [], []
TYLE = 101360 / 29909
NGUONG = 100256


def log(*a):
    s = " ".join(str(x) for x in a); LOG.append(s); print(s)


def rec(tid, module, desc, method, inp, exp, act, res, evid="—", lim="—"):
    assert res in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")
    KQ.append(dict(test_id=tid, module=module, description=desc, method=method, input=inp, expected=exp, actual=act, result=res, evidence=evid, limitation=lim))
    log(f"[{res:10}] {tid} – {desc[:120]}")


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def tok(s):
    return len(re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\S', "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n"))))


LIM = "pine_mini là trình thông dịch thu gọn, không phải TradingView – không chứng minh compile/runtime trên nền tảng"


def ghi_nhom(rows, module, method, evid="—", lim=LIM):
    for r in rows:
        tid, mo, kv, tt, ok = r[:5]
        m = r[5] if len(r) > 5 else method
        rec(tid, module, mo, m, "khối Pine nguyên văn của 0.3.9" if "SOURCE" in m else "mã nguồn", kv, tt, "PASS" if ok else "FAIL", evid, lim if "SOURCE" in m else "Kiểm tĩnh: không thực thi")


# ===================================================================================================== đột biến (chỉ trên bản sao trong bộ nhớ)
DOT = [
    ("SU-3 bỏ điều kiện MSS (a) – CHoCH thường cũng được", "else if sH1.mssA and sH1.ev == (d == 1 ? EV_CHOCH_UP : EV_CHOCH_DN)", "else if sH1.ev == (d == 1 ? EV_CHOCH_UP : EV_CHOCH_DN)", "S3"),
    ("SU-3 đảo chiều MSS", "else if sH1.mssA and sH1.ev == (d == 1 ? EV_CHOCH_UP : EV_CHOCH_DN)", "else if sH1.mssA and sH1.ev == (d == 1 ? EV_CHOCH_DN : EV_CHOCH_UP)", "S3"),
    ("SU-3 bỏ vô hiệu Close H1 qua MỐC", "                    if d * (sH1.cls - x.lv) < 0\n", "                    if false\n", "S3"),
    ("SU-3 biên MỐC ≤ thay <", "                    if d * (sH1.cls - x.lv) < 0\n", "                    if d * (sH1.cls - x.lv) <= 0\n", "S3"),
    ("SU-3 bỏ cập nhật ĐÁY_1_RUNNING", "x.ext := d == 1 ? math.min(x.ext, xM15.loS) : math.max(x.ext, xM15.hiS)", "x.ext := x.ext", "S3"),
    ("SU-3 bỏ vô hiệu vùng H1 bước 1", "                if na(f_zS(60, d, x.bm, x.bs))\n", "                if false\n", "S3"),
    ("SU-3 hết hạn bước 2: 24 → 25 nến H1", "                    else if x.k >= 24\n", "                    else if x.k >= 25\n", "S3"),
    ("SU-3 bước 3 nhận vùng có j = t1", "q.bosMin + 15 > f_min(x.t0)", "q.bosMin + 15 >= f_min(x.t0)", "S3"),
    ("SU-3 bước 3 chọn j sớm nhất", "(na(z) or q.bosMin > z.bosMin or", "(na(z) or q.bosMin < z.bosMin or", "S3"),
    ("SU-3 bỏ điều kiện lần chạm đầu tiên", "z.moved and z.touches == 1 and ", "z.moved and ", "S3"),
    ("SU-3 bỏ điều kiện không gap", " and d * (open - (d == 1 ? z.bot : z.top)) >= 0\n", "\n", "S3"),
    ("SU-3 bỏ điều kiện nến mở ≥ t2", " and time >= x.t2 and ", " and ", "S3", "TƯƠNG ĐƯƠNG: x.st = 1 chỉ được gán trong khối tiền-kích hoạt khi dữ liệu H1 của t2 vừa về (newH1, t2 = sH1.tClose); khối M5 chạy sau trên nến M5 có thời điểm mở ≥ thời điểm đóng H1 (D.4/R1–R10, request.security lookahead_on + [1]) nên time ≥ t2 luôn đúng khi x.st = 1. Điều kiện được giữ để bám đúng chữ J.2 bước 4."),
    ("SU-3 hết hạn bước 4: 48 → 47", "if x.k >= 48", "if x.k >= 47", "S3"),
    ("SU-3 bỏ vô hiệu vùng bước 3", "                    e := f_evS(x, SS_VOID, 6)                                                   // vùng bước 3 bị vô hiệu", "                    e := na", "S3"),
    ("SU-3 quyền dùng lớp THUẬN thay ĐẢO CHIỀU", "x.su == 3 ? f_permRev(d) : f_perm(d)", "f_perm(d)", "S3S5"),
    ("SL chọn mức GẦN thay XA (max/min đảo)", "d == 1 ? math.min(p, q) : math.max(p, q)", "d == 1 ? math.max(p, q) : math.min(p, q)", "S3S5"),
    ("SU-5 Lv ưu tiên REF thay cụm", "(rc > rk or rc == rk and d5 * (u - lv) > 0)", "(rk < 0 and rc > rk)", "S5"),
    ("SU-5 bằng hạng chọn U thấp hơn", "rc == rk and d5 * (u - lv) > 0)", "rc == rk and d5 * (u - lv) < 0)", "S5"),
    ("SU-5 nhận cụm hạng 1", "if rc >= 2 and d5", "if rc >= 1 and d5", "S5"),
    ("SU-5 nhận CHoCH như BOS", "int d5 = sM15.ev == EV_BOS_UP ? 1 : sM15.ev == EV_BOS_DN ? -1 : 0", "int d5 = sM15.ev == EV_BOS_UP or sM15.ev == EV_CHOCH_UP ? 1 : sM15.ev == EV_BOS_DN or sM15.ev == EV_CHOCH_DN ? -1 : 0", "S5"),
    ("SU-5 rời mức 0,5A → 0,25A", "d * (close - x.lv) >= 0.5 * x.ext", "d * (close - x.lv) >= 0.25 * x.ext", "S5"),
    ("SU-5 retest cùng nến rời mức", "            else if x.su == 5 and x.st == 1 and low", "            if x.su == 5 and x.st == 1 and low", "S5"),
    ("SU-5 gap không kết thúc (vẫn ARMED)", "                else\n                    e := f_evS(x, SS_SKIP, 4)", "                else\n                    x.st := 2", "S5"),
    ("SU-5 vô hiệu neo 0,25A → 0,2A", "d * (sM15.cls - x.lv) < -0.25 * x.ext)", "d * (sM15.cls - x.lv) < -0.2 * x.ext)", "S5"),
    ("SU-5 bỏ vô hiệu BOS ngược phá Lv", " or (sM15.ev == (d == 1 ? EV_BOS_DN : EV_BOS_UP) and d * (sM15.cls - x.lv) < 0)", "", "S5"),
    ("SU-5 hết hạn trước retest 24 → 25", "else if x.st < 2 and x.k >= 24", "else if x.st < 2 and x.k >= 25", "S5"),
    ("SU-5 bỏ lọc nến mở ≥ T_j cho H*/L*", "if time[off + j] >= x.t0", "if true", "S5"),
    ("L*/H* cập nhật không nghiêm ngặt (b muộn nhất)", "if d * (x.lx - (d == 1 ? low : high)) > 0", "if d * (x.lx - (d == 1 ? low : high)) >= 0", "S5"),
    ("SU-5 bỏ ghi nhớ Lv đã kết thúc (J.4.3)", "        array.push(s5L, x.d * x.lv)", "        array.clear(s5L)", "S5"),
    ("Hết hạn sau ARMED 23 → 24", "else if x.k5 >= K_EXPIRE", "else if x.k5 >= K_EXPIRE + 1", "S3S5"),
    ("Bỏ chặn khung chờ khi trigger", "if not (pendM15 or pendH1 or pendH4) and d * (close - x.hs) > 0", "if d * (close - x.hs) > 0", "S3S5"),
    ("S1 SHADOW bỏ lý do 15", "pm == 15 ? 15 : not (d * (close - sl) > 0)", "not (d * (close - sl) > 0)", "S3S5"),
    ("S1 SHADOW bỏ thiếu dữ liệu pool", " or not md4OK or not md5OK ? 8 : pm == 15", " or not md4OK ? 8 : pm == 15", "S3S5"),
    ("S1 SHADOW ĐẠT ghi trạng thái FINAL thay 17", "e.state := e.reason == 16 ? 17 :", "e.state := e.reason == 16 ? SS_FINAL :", "S3S5"),
    ("CÁCH LY: sự kiện SHADOW đẩy vào trigE (vào S2a/sổ)", "                f_shEnd(i, x, e)\n    shTxt", "                f_shEnd(i, x, e)\n                array.push(trigE, e)\n    shTxt", "I"),
    ("CÁCH LY: SHADOW chiếm ô Data Window trước actionable", "            array.push(pick, e)", "            array.unshift(pick, e)", "I"),
    ("CÁCH LY: SHADOW ghi vùng MD-3 (đổi số lần chạm)", "                    x.st := 2\n            else if x.su == 5 and x.st == 0", "                    x.st := 2\n                    z.touches := 2\n            else if x.su == 5 and x.st == 0", "I"),
    ("CÁCH LY: SHADOW đếm vào passBuy (xung đột S2a)", "                        pT := e.reason == 16 ?", "                        passBuy += e.reason == 16 ? 1 : 0\n                        pT := e.reason == 16 ?", "I"),
    ("CÁCH LY: SHADOW tăng bộ đếm lỗi 14", "                        pT := e.reason == 16 ?", "                        bar14 += e.reason == 14 ? 1 : 0\n                        pT := e.reason == 16 ?", "I"),
    ("CÁCH LY: SHADOW phát cảnh báo", "    shTxt := pT != \"\" ?", "    if pT != \"\"\n        alert(pT)\n    shTxt := pT != \"\" ?", "I"),
    ("CÁCH LY: SHADOW xóa thể hiện SU-4", "    int nS = array.size(sh)\n", "    int nS = array.size(sh)\n    array.clear(s4)\n", "I"),
    ("CÁCH LY: SHADOW đẩy vào evs (ô Data Window actionable)", "    if newM15\n        // SU-3 bước 1", "    if newM15 and array.size(sh) > 0\n        array.push(evs, f_evS(array.get(sh, 0), SS_WAIT, 0))\n    if newM15\n        // SU-3 bước 1", "I"),
]


def chay_nhom(src, nhom, n_rt=40):
    fails = []
    groups = []
    if "S3" in nhom:
        groups.append(("S3", lambda: TS.nhom_su3(src)))
    if "S5" in nhom:
        groups.append(("S5", lambda: TS.nhom_su5(src)))
    groups += [("I-tinh", lambda: CL.nhom_tinh(src)), ("I-04", lambda: CL.nhom_snapshot(src, n=n_rt)), ("I-06", lambda: CL.nhom_vi_sai(src, n=n_rt))]
    for g_, fn in groups:
        try:
            for r in fn():
                if not r[4]:
                    fails.append(r[0])
        except Exception as ex:          # noqa: BLE001
            fails.append(f"{g_}: dừng do lỗi chạy ({type(ex).__name__}: {str(ex)[:60]})")
    return fails


def main():
    t0 = time.time()
    h38 = sha(F038)
    rec("V-01", "Phiên bản", "SHA-256 baseline 0.3.8 khớp giá trị đã xác minh (không sửa, không ghi đè)", "STATIC", "src038/…0.3.8…pine", SHA38, h38, "PASS" if h38 == SHA38 else "FAIL", "Chỉ thị mục 2")
    if h38 != SHA38:
        json.dump(dict(dung=True, ket_qua=KQ), open(os.path.join(OUT, "ket_qua_039.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        sys.exit(3)
    h39 = sha(F039)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_039.py"), h39], cwd=G, capture_output=True, text=True)
    rec("V-02", "Phiên bản", "0.3.9 tái lập từ script dựng có khóa SHA đầu vào (tools033/dung_build_039.py) → cùng SHA; baseline không bị ghi", "STATIC", "dung_build_039.py", h39,
        r.stdout.strip()[:200], "PASS" if r.returncode == 0 and sha(F039) == h39 and sha(F038) == SHA38 else "FAIL", "tools033/dung_build_039.py")
    hq = os.path.join(G, "hoi_quy034", "src", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine")
    rec("V-03", "Phiên bản", "Bản sao 0.3.9 dùng cho hoi_quy034 trùng SHA build", "STATIC", "hoi_quy034/src", h39, sha(hq) if os.path.exists(hq) else "thiếu", "PASS" if os.path.exists(hq) and sha(hq) == h39 else "FAIL")
    # ----------------------------------------------------------------------------------------------- phạm vi mã
    ghi_nhom(CL.nhom_tinh(), "C · phạm vi mã / cô lập tĩnh", "STATIC")
    S38, S39 = KH.S38, KH.S39
    cnt = lambda s, p: len(re.findall(p, CL.bo_cm(s)))  # noqa: E731
    v = {k: (cnt(S38, p), cnt(S39, p)) for k, p in (("input", r"\binput\.\w+\("), ("plot", r"\bplot\("), ("request.security", r"\brequest\.security\("), ("alert", r"\balert(?:condition)?\("),
                                                     ("label.new", r"\blabel\.new\("), ("box/line", r"\b(?:box|line)\.new\("), ("ta.", r"\bta\.\w+\("))}
    ok = all(a == b for a, b in v.values())
    rec("C-04", "C · phạm vi mã", "Không thêm input, plot, request.security, alert, label, box/line, ta.* (K.5 không cho phép ô nhập chế độ ở 0.3.9 – xem IP-22)", "STATIC", "0.3.8 vs 0.3.9", "không đổi", v, "PASS" if ok else "FAIL")
    pre = "\n".join(KH.K.doan(S39, KH.MK_PRE[0], KH.MK_PRE[1])[0])
    su3_tao = pre[pre.index("// SU-3 bước 1"):pre.index("// SU-5 bước 1")]
    ok = "cLo" not in su3_tao and "cRank" not in su3_tao and "z.tf == 60" in su3_tao
    rec("C-05", "C · IP chặn", "SU-3 bước 1 nhánh cụm MD-4 hạng ≥ 3 KHÔNG được triển khai (BLOCKED – IP-19): đoạn tạo SU-3 chỉ đọc vùng H1, không đọc cụm", "STATIC", "đoạn tạo SU-3", "không có cLo/cRank", dict(doc_cum="cLo" in su3_tao),
        "PASS" if ok else "FAIL", "IP-19")
    rec("C-06", "C · IP chặn", "SU-3 bước 1 qua cụm MD-4 hạng ≥ 3 (có mức HỖ TRỢ theo F.4) và vô hiệu 'cụm bị vô hiệu/FLIPPED xuống'", "—", "—", "triển khai theo J.2",
        "Không triển khai: đặc tả không định nghĩa danh tính một cụm qua các lần gom lại (F.4: trạng thái lưu theo MỨC; cụm tính lại mỗi nến H1) nên không xác định được 'cụm ở bước 1 bị vô hiệu/FLIPPED' – chờ IP-19",
        "BLOCKED", "J.2; F.3; F.4", "Nhánh vùng H1 vẫn hoạt động")
    rec("C-07", "C · IP chặn", "Hạng A/B của SU-3/SU-5 (C-1, C-2, X-D, X-S)", "—", "—", "—",
        "Không tính trong SHADOW: K.5 chỉ cần P_ref/SL/TP1; SU-3 luôn tối đa B; SU-5 – I.5 yêu cầu C-1, C-2 nhưng J.4 không định nghĩa C-1/C-2 cho SU-5 (IP-23)", "BLOCKED", "I.5; J.4", "Không ảnh hưởng chế độ SHADOW")
    # ----------------------------------------------------------------------------------------------- SU-3, SU-5
    ghi_nhom(TS.nhom_su3(), "S3 · SU-3 SHADOW", "SOURCE-DERIVED", "J.2; E.2; K.5")
    ghi_nhom(TS.nhom_su5(), "S5 · SU-5 SHADOW", "SOURCE-DERIVED", "J.4; K.5")
    # ----------------------------------------------------------------------------------------------- cô lập khi chạy
    ghi_nhom(CL.nhom_snapshot(n=300), "I · cô lập SHADOW (chạy)", "SOURCE-DERIVED", "K.5 (1)–(5)")
    ghi_nhom(CL.nhom_vi_sai(n=400), "I · cô lập SHADOW (vi sai)", "SOURCE-DERIVED", "K.5 (1)–(5)")
    rec("I-07", "I · cô lập SHADOW", "Sổ X-0…X-4, f_ledger, giá SL/TP quản lý lệnh: mã trùng 0.3.8 (I-02) và chạy TRƯỚC khối SHADOW trong cùng nến; đầu vào sổ (fins) trùng 0.3.8 từng nến (I-06); SHADOW không ghi biến sổ (I-03, I-04) → đầu ra sổ trùng",
        "STATIC + SOURCE-DERIVED (suy từ I-02/I-03/I-04/I-06)", "—", "trùng", "Bằng chứng gián tiếp: driver không chạy chính các hàm sổ (f_x0, f_exec) trên dữ liệu ngẫu nhiên", "PASS" if all(x["result"] == "PASS" for x in KQ if x["test_id"] in ("I-02", "I-03", "I-04", "I-06")) else "FAIL",
        "—", "Kiểm sổ trực tiếp khi chạy: chưa (driver dùng chỉ số sổ đơn giản cho cả hai bản)")
    # ----------------------------------------------------------------------------------------------- Data Window / dashboard
    p8 = [l for l in S38.split("\n") if l.startswith("plot(")]
    p9 = [l for l in S39.split("\n") if l.startswith("plot(")]
    rec("DW-01", "DW · Data Window", "56 plot Data Window của 0.3.8 trùng từng ký tự trong 0.3.9 (không thêm plot); sự kiện SHADOW chỉ hiện ở ô sự kiện còn trống (trạng thái 17 khi ĐẠT – K.5)", "STATIC", "plot(", "56 = 56, trùng",
        dict(so=(len(p8), len(p9)), trung=p8 == p9), "PASS" if p8 == p9 and len(p9) == 56 else "FAIL")
    rows = sorted(int(x) for x in re.findall(r"^\s+f_cell\((\d+),", S39, re.M))
    dong = [l.strip() for l in S39.split("\n") if 'f_cell(15,' in l]
    d38 = {int(m.group(1)): l for l in S38.split("\n") for m in [re.match(r"^\s+f_cell\((\d+),", l)] if m}
    d39 = {int(m.group(1)): l for l in S39.split("\n") for m in [re.match(r"^\s+f_cell\((\d+),", l)] if m}
    doi = [k for k in d38 if d38[k] != d39.get(k) and k != 0]
    txt = re.findall(r'"(SHADOW[^"]*|THEO DÕI|LIVE|ĐẠT \(không giao dịch\))"', S39)
    ok = rows == list(range(16)) and dong and '"SHADOW (không giao dịch)"' in dong[0] and not doi and all("KIỂM THỬ" not in t for t in txt)
    rec("DW-02", "DW · dashboard", "Dashboard 16 hàng (0…15, mỗi chỉ số 1 lần); hàng 15 'SHADOW (không giao dịch)' với nội dung 'SHADOW: SU-x BUY/SELL – THEO DÕI / LIVE / ĐẠT (không giao dịch)' (K.5 (3)); 14 hàng baseline 1…14 trùng 0.3.8 (hàng 0 chỉ đổi số phiên bản); không nhãn tín hiệu cho SHADOW",
        "STATIC", "f_cell", "0…15; 0 hàng baseline đổi", dict(hang=rows, hang_moi=dong[0][:90] if dong else None, hang_doi=doi, chuoi=txt), "PASS" if ok else "FAIL")
    # LIVE chỉ trên nến chưa đóng, chỉ hiển thị
    seg = S39[S39.index("    string sT = shTxt"):S39.index('    f_cell(15, "SHADOW')]
    ok = "if not barstate.isconfirmed" in seg and not re.search(r":=\s*|\+=", seg.replace("sT :=", ""))
    rec("DW-03", "DW · dashboard", "'LIVE' chỉ tính khi nến chưa đóng (barstate.isconfirmed sai), trong khối hiển thị cuối, chỉ gán biến hiển thị sT; không có EARLY cho SHADOW (H-11)", "STATIC", "khối dashboard", "chỉ gán sT",
        seg.strip()[:300], "PASS" if ok else "FAIL", "K.5 (3), (6)", "LIVE dùng H*/L* của nến đã đóng gần nhất (nến đang chạy có thể đổi L*) – chỉ hiển thị, repaint theo thiết kế")
    # ----------------------------------------------------------------------------------------------- hồi quy
    p_new = os.path.join(OUT, "hoi_quy_bo_038_tren_039", "ket_qua_038.json")
    p_old = os.path.join(G, "ket_qua038", "ket_qua_038.json")
    if os.path.exists(p_new):
        a = {x["id"]: x for x in json.load(open(p_old, encoding="utf-8"))["ket_qua"]}
        b = {x["id"]: x for x in json.load(open(p_new, encoding="utf-8"))["ket_qua"]}
        dem = {}
        for x in b.values():
            dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
        khac = {k: (a.get(k, {}).get("ket_qua"), b.get(k, {}).get("ket_qua")) for k in set(a) | set(b) if a.get(k, {}).get("ket_qua") != b.get(k, {}).get("ket_qua")}
        LY_DO = {"T-01": "token tăng do SU-3/SU-5 – ƯỚC LƯỢNG vượt ngưỡng (FAIL thật về ngân sách token, xem T-01 của bộ 0.3.9)",
                 "R.A35.A-11": "cùng nguyên nhân với T-01 (ước lượng token vượt ngưỡng)",
                 "R.t_md5_song_song": "assertion cũ so TOÀN BỘ biến của vùng DX032 với 0.3.4a; 4 biến khác đúng là 4 biến SHADOW mới khai báo trong vùng (sh, s5L, evS, shTxt) – kiểm thay thế R-02",
                 "R.PHAN_LOAI": "hệ quả của R.A35.A-11 và R.t_md5_song_song (danh sách FAIL đã phân loại thay đổi)"}
        chua_giai_thich = {k: v_ for k, v_ in khac.items() if k not in LY_DO}
        rec("R-01", "R · hồi quy baseline", "Chạy lại TOÀN BỘ bộ 0.3.8 (chay_038.py, không sửa assertion – chỉ đổi đích sang 0.3.9 bằng script sinh tự động): SU-1, SU-4, SU-6, MD-6, MD-7, S1, S2a, VOID/EXPIRED/TRIGGER, Data Window, dashboard, sổ, cảnh báo, 18 đột biến cũ, hoi_quy034 (đích '039'). So TỪNG ID với kết quả bộ đó trên 0.3.8",
            "HỒI QUY (SOURCE-DERIVED/STATIC)", "kiem_toan039/hoi_quy_bo_038_tren_039.py", "0 ID đổi kết quả ngoài các ID đã giải thích",
            dict(dem_tren_039=dem, khac=khac, giai_thich={k: LY_DO[k] for k in khac if k in LY_DO}), "PASS" if not chua_giai_thich else "FAIL",
            "ket_qua039/hoi_quy_bo_038_tren_039/ket_qua_038.json", "Các FAIL lịch sử của bộ 0.3.8 (5 ID) giữ nguyên, không đóng")
    else:
        rec("R-01", "R · hồi quy baseline", "Chạy lại toàn bộ bộ 0.3.8 trên 0.3.9", "HỒI QUY", "—", "—", "chưa có kết quả", "NOT TESTED")
    # R-02: thay thế cho R.t_md5_song_song – cùng 4 kịch bản (7.100 nến), MD-5 nguyên văn 0.3.4a ↔ 0.3.9, loại thêm đúng 4 biến SHADOW khỏi phép so
    try:
        import chay_035 as C35, kiem_toan_035e as KT
        import md5_song_song as MS
        KT.dat_ma(S39)
        goc = MS.trang_thai
        MOI = {"plB", "prB", "plS", "prS", "REG_NA", "REG_UP", "REG_DN", "REG_RG", "REG_TR", "VOL_X", "META_VER"}
        SHV = {"sh", "s5L", "evS", "shTxt"}
        bien_khac = set()

        def tt(m):         # như bộ 0.3.8 (chay_038.py dòng 441–442: bỏ s4 của MD-8 đợt 1) + 4 biến SHADOW
            return {k: v_ for k, v_ in goc(m).items() if k not in MOI | SHV | {"s4"}}
        kq2 = []
        MS.trang_thai = tt
        try:
            for ten, n, seed in (("lien_tuc", 1500, 1), ("cum_dong_thoi", 1500, 2), ("tong_hop", 2600, 3), ("bat_kip_hai_phia", 1500, 4)):
                r2 = MS.chay(ten, n, seed, so_sanh=True, kiem_bb=True, text_a=C35.S34, text_b=S39, ghi_moc=0)
                kq2.append((ten, r2["nen_chay"], r2["sai_khac"], r2["loi_chay"], len(r2["loi_bat_bien"])))
        finally:
            MS.trang_thai = goc
        old = json.load(open(p_new, encoding="utf-8"))["ket_qua"] if os.path.exists(p_new) else []
        txt_old = next((str(x["thuc_te"]) for x in old if x["id"] == "R.t_md5_song_song"), "")
        bien_cu = set(re.findall(r"'bien': \[([^\]]*)\]", txt_old))
        bien_cu = {b_.strip(" '") for grp in bien_cu for b_ in grp.split(",")}
        ok = all(x[2] is None and x[3] is None and x[4] == 0 and x[1] > 1000 for x in kq2) and bien_cu == SHV
        rec("R-02", "R · hồi quy baseline (thay thế)", "THAY THẾ cho R.t_md5_song_song (assertion cũ giữ nguyên, vẫn FAIL): (1) biến khác trong kết quả cũ đúng bằng 4 biến SHADOW khai báo trong vùng DX032; (2) chạy lại cùng 4 kịch bản (7.100 nến) MD-5 nguyên văn 0.3.4a ↔ 0.3.9, loại 4 biến đó (và s4 như bộ 0.3.8 đã làm): 0 khác, 0 lỗi chạy, 0 lỗi bất biến",
            "SOURCE-DERIVED (vi sai MD-5)", "md5_song_song.chay × 4", "biến cũ = {sh, s5L, evS, shTxt}; 0 khác", dict(bien_khac_cu=sorted(bien_cu), ket_qua=kq2), "PASS" if ok else "FAIL",
            "kiem_toan034a/md5_song_song.py", LIM)
    except Exception as ex:          # noqa: BLE001
        rec("R-02", "R · hồi quy baseline (thay thế)", "Thay thế R.t_md5_song_song", "SOURCE-DERIVED", "—", "—", "LỖI CHẠY " + repr(ex) + traceback.format_exc()[-300:], "FAIL")
    # ----------------------------------------------------------------------------------------------- đột biến
    nk, song, khong, tdg = [], [], [], []
    for dong in DOT:
        ten, cu, moi, nhom = dong[:4]
        n = S39.count(cu)
        if n != 1:
            nk.append((ten, f"KHÔNG ÁP ĐƯỢC (mẫu xuất hiện {n} lần)", [])); khong.append(ten); continue
        f = chay_nhom(S39.replace(cu, moi), nhom)
        if not f and len(dong) > 4:
            nk.append((ten, "SỐNG SÓT – TƯƠNG ĐƯƠNG", [dong[4]])); tdg.append((ten, dong[4])); continue
        nk.append((ten, "BẮT" if f else "SỐNG SÓT", f[:6]))
        if not f:
            song.append(ten)
    with open(os.path.join(OUT, "dot_bien_039.txt"), "w", encoding="utf-8") as fh:
        for ten, kq, ct in nk:
            fh.write(f"{kq:34} | {ten} | test bắt: {ct}\n")
    rec("M-01", "M · đột biến", f"{len(DOT)} đột biến dựa trên logic thực của SU-3/SU-5 và cách ly (bỏ xác nhận, đảo điều kiện, đổi ngưỡng/biên, đổi thứ tự sự kiện, bỏ VOID/hết hạn, cho trùng, bỏ đồng bộ khung chờ, nối SHADOW vào trigE/S2a, ô Data Window, vùng MD-3, passBuy, bar14, cảnh báo, s4, evs) – áp lên BẢN SAO trong bộ nhớ",
        "ĐỘT BIẾN (SOURCE-DERIVED + STATIC)", "bản sao chuỗi mã 0.3.9", "mọi đột biến không tương đương bị bắt; đột biến tương đương phải có chứng minh", dict(tong=len(DOT), bat=len(DOT) - len(song) - len(khong) - len(tdg), song_sot=song, tuong_duong=tdg, khong_ap=khong),
        "PASS" if not song and not khong else "FAIL", "ket_qua039/dot_bien_039.txt")
    # ----------------------------------------------------------------------------------------------- token
    t33 = tok(KH.K.doc(os.path.join(G, "src033", "ATA_P3_Build_0.3.3_Candidate_Indicator.pine"))); t37 = tok(KH.K.doc(os.path.join(G, "src037", "ATA_P3_Build_0.3.7_Candidate_Indicator.pine")))
    t38, t39 = tok(S38), tok(S39)
    nguong_tv = round(NGUONG / TYLE)
    uoc = round(t39 * TYLE)
    ins, _, _ = CL.chen()
    L = S39.split("\n")
    khoi = {f"dòng {j1 + 1}–{j2}": tok("\n".join(L[j1:j2])) for j1, j2 in ins}
    rec("T-01", "T · token", "Token 0.3.9 – ƯỚC LƯỢNG (token từ vựng × tỷ lệ hiệu chỉnh từ điểm đo thật duy nhất 0.3.3 = 101.360 biên dịch / 29.909 từ vựng) phải ≤ ngưỡng 100.256",
        "STATIC (ƯỚC LƯỢNG – không phải token biên dịch thật)", "src033/037/038/039", "≤ 100.256 (≈ ≤ 29.583 từ vựng)",
        dict(tu_vung=dict(v033=t33, v037=t37, v038=t38, v039=t39, them=t39 - t38), uoc_bien_dich_039=uoc, nguong_tu_vung_uoc=nguong_tv, vuot_uoc_tu_vung=t39 - nguong_tv,
             vuot_so_voi_0_3_3_da_FAIL=t39 - t33, chi_phi_khoi=khoi), "PASS" if uoc <= NGUONG else "FAIL", "ket_qua039/ket_qua_039.json",
        "Tỷ lệ chỉ từ 1 điểm đo; 0.3.3 (29.909 từ vựng) đã FAIL CE10117, 0.3.7 (29.368) và 0.3.8 (28.369) compile được (chủ dự án)")
    rec("T-02", "T · token", "Token biên dịch THẬT của 0.3.9", "PLATFORM", "—", "số TradingView báo", "Chưa đo – chỉ TradingView cho số thật (CE10117 in số token khi vượt)", "BLOCKED", "—", "Cần một lần compile trên TradingView")
    for tid, mt in (("TV-COMPILE", "Compile 0.3.9 trên TradingView"), ("TV-M5", "M5 EXNESS: dashboard dòng SHADOW, SU-1/SU-4 như 0.3.8"), ("TV-RELOAD", "Tải lại: kết quả SHADOW trên nến đã đóng không đổi"),
                    ("TV-KHUNG", "M15…Y: không lỗi")):
        rec(tid, "TradingView", mt, "PLATFORM", "—", "bằng chứng TradingView", "Chưa có", "BLOCKED", "—", "Cần quyền TradingView của chủ dự án")
    rec("TV-EXNESS", "TradingView", "Dữ liệu Exness thật / Profiler / CSV", "PLATFORM", "—", "—", "chưa có", "NOT TESTED", "—", "Ngoài phạm vi tự động hóa")
    rec("V-04", "Phiên bản", "Baseline 0.3.8 không đổi sau toàn bộ kiểm thử", "STATIC", "src038", SHA38, sha(F038), "PASS" if sha(F038) == SHA38 else "FAIL")
    dem = {}
    for x in KQ:
        dem[x["result"]] = dem.get(x["result"], 0) + 1
    json.dump(dict(summary=dict(build="0.3.9", sha256_039=h39, sha256_038=h38, counts=dem, seconds=round(time.time() - t0)), results=KQ),
              open(os.path.join(OUT, "ket_qua_039.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(OUT, "ket_qua_039.csv"), "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh); w.writerow(["test_id", "module", "result", "method", "description"])
        for x in KQ:
            w.writerow([x["test_id"], x["module"], x["result"], x["method"], x["description"]])
    open(os.path.join(OUT, "nhat_ky_039.txt"), "w", encoding="utf-8").write("\n".join(LOG) + f"\n{dem}\n")
    print(dem, round(time.time() - t0), "s")
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0)


if __name__ == "__main__":
    main()
