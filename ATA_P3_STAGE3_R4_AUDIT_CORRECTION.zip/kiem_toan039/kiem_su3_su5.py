# -*- coding: utf-8 -*-
"""Kiểm thử SU-3 (J.2) và SU-5 (J.4) SHADOW – chạy NGUYÊN VĂN khối Pine của 0.3.9 trên pine_mini (driver SHD).
Mỗi hàm nhận mã nguồn (để dùng lại khi kiểm đột biến) và trả danh sách (id, mô tả, kỳ vọng, thực tế, ok)."""
import random
from khung039 import SHD, NA, PArr, K, zone, ev_t, S39

EV_BOS_UP, EV_BOS_DN, EV_CHOCH_UP, EV_CHOCH_DN = 1, 2, 3, 4
SS_WAIT, SS_SKIP, SS_EXPIRED, SS_VOID, SS_INVAR = 2, 4, 5, 6, 8
SHADOW = 17


def mins(T):
    return T // 60000


# ===================================================================================================== SU-3
def su3_dung(src, z1=(1990.0, 1995.0), reg=2, m15_bars=3, atr15=8.0):
    """Dựng SU-3 BUY tới trạng thái 'đã chạm vùng H1' (t1). ATR_M15 = 8 để SL ≤ 2×ATR_M15 trong các ca trigger. Trả (driver, vùng H1)."""
    s = SHD(src)
    s.ctx(reg=reg, atr15=atr15)
    Z1 = zone(s.ip, 60, 1, z1[0], z1[1], bm=mins(s.T) - 600)
    s.g["zones"].v.append(Z1)
    s.m15(1997, 1998, 1994.0, 1996.5)
    s.bar(1996.5, 1997, 1996, 1996.8)
    return s, Z1


def m15_tiep(s, o, h, l, c, h1=None, n_m5=3, m5=None):
    """Chạy n_m5 nến M5; nến M5 đầu tiên mang dữ liệu M15 (và H1 nếu có) vừa đóng."""
    out = []
    s.m15(o, h, l, c, h1=h1)
    for j in range(n_m5):
        b = (m5[j] if m5 else (c, c + 0.3, c - 0.3, c + 0.1))
        out.append(s.bar(*b))
    return out


def nhom_su3(src=S39):
    R = []

    def T(i, mo, kv, tt, ok):
        R.append((i, mo, kv, tt, bool(ok)))
    # S3-01 khởi tạo
    s, Z1 = su3_dung(src)
    xs = s.xs()
    ok = len(xs) == 1 and xs[0].f["su"] == 3 and xs[0].f["d"] == 1 and xs[0].f["lv"] == 1994.0 and xs[0].f["ext"] == 1994.0 and xs[0].f["st"] == 0 and xs[0].f["bm"] == Z1.f["bosMin"]
    s2 = SHD(src); s2.ctx()
    s2.g["zones"].v += [zone(s2.ip, 60, 1, 1990.0, 1995.0, bm=mins(s2.T) - 600), zone(s2.ip, 15, 1, 1993.0, 1995.0, bm=mins(s2.T) - 300),
                        zone(s2.ip, 60, -1, 2010.0, 2012.0, bm=mins(s2.T) - 600)]
    s2.m15(1997, 1998, 1995.01, 1996.5); s2.bar(1996.5, 1997, 1996, 1996.8)          # không giao cắt (Low > biên trên)
    n_khong = len(s2.xs())
    s2.m15(2008, 2010.0, 2005, 2009); s2.bar(2009, 2009.5, 2008.5, 2009)               # chạm vùng Supply H1 → SU-3 SELL, MỐC = High
    sell = [(x.f["d"], x.f["lv"]) for x in s2.xs()]
    T("S3-01", "Bước 1 (nhánh vùng H1): nến M15 đã đóng giao cắt vùng Demand H1 → SU-3 BUY, MỐC_ĐÁY = ĐÁY_1_RUNNING = Low[t1]; không giao cắt → không tạo; vùng M15 không dùng cho bước 1; Supply H1 → SELL, MỐC_ĐỈNH = High",
      "BUY lv = 1994; 0 khi Low 1995,01; SELL lv = 2010", dict(buy=[(x.f["d"], x.f["lv"], x.f["st"]) for x in xs], khong_giao_cat=n_khong, sell=sell),
      ok and n_khong == 0 and sell == [(-1, 2010.0)])
    s3 = SHD(src); s3.ctx()
    zf = zone(s3.ip, 60, 1, 1990.0, 1995.0, bm=mins(s3.T) - 600); zf.f["dead"] = False
    s3.g["zones"].v.append(zf)
    s3.g["f_frozen_force"] = True
    # vùng ĐÓNG BĂNG: f_frozen đọc trạng thái toàn vẹn; mô phỏng bằng cách đặt hàm thành luôn đúng
    s3.ip.funcs["f_frozen"] = (["z"], s3.ip.funcs["f_frozen"][1]) if False else s3.ip.funcs["f_frozen"]
    T("S3-01b", "Nhánh cụm MD-4 hạng ≥ 3 của bước 1: KHÔNG triển khai (BLOCKED – IP-19); chạm cụm không tạo SU-3", "0 thể hiện khi chỉ có cụm",
      None, None)
    s4_ = SHD(src); s4_.ctx()
    s4_.g.update(cLo=PArr([1993.0]), cHi=PArr([1995.0]), cRank=PArr([4]))
    s4_.m15(1997, 1998, 1994.0, 1996.5); s4_.bar(1996.5, 1997, 1996, 1996.8)
    R[-1] = ("S3-01b", R[-1][1], R[-1][2], dict(the_hien=len(s4_.xs())), len(s4_.xs()) == 0)
    # S3-02 RUNNING / FINAL
    s, Z1 = su3_dung(src)
    x = s.xs()[0]                                                                    # theo dõi đúng thể hiện tạo tại t1 (nến M15 sau còn giao cắt vùng sẽ tạo thể hiện khác – S3-14)
    s.g["zones"].v.append(zone(s.ip, 15, 1, 2000.0, 2002.0, bm=x.f["t0"] // 60000 + 15, bs=1))
    m15_tiep(s, 1996, 1997, 1993.0, 1996)
    m15_tiep(s, 1996, 1997, 1992.5, 1996)
    run_ = x.f["ext"]
    m15_tiep(s, 1996, 2003, 1992.0, 2002, h1=(2002.0, EV_CHOCH_UP, True))          # nến M15 cuối kỳ H1 chứa t2: Low 1992 được tính
    fin = x.f["ext"]
    st_ = x.f["st"]
    m15_tiep(s, 2002, 2004, 1991.0, 2003)                                            # sau t2: không cập nhật
    T("S3-02", "H-16: ĐÁY_1_RUNNING = min Low các nến M15 trong (t1, t2] (gồm nến M15 cuối kỳ H1 chứa t2); FINAL khóa tại t2, không đổi sau đó",
      "1992,5 trước t2; FINAL 1992; giữ 1992 sau t2", dict(running=run_, final=fin, sau=x.f["ext"], st=st_, con=x in s.xs()),
      run_ == 1992.5 and fin == 1992.0 and x.f["ext"] == 1992.0 and st_ == 1 and x in s.xs())
    # S3-03 MSS H1
    kq = {}
    for ten, h1 in (("MSS↑", (2002.0, EV_CHOCH_UP, True)), ("CHoCH↑ không MSS", (2002.0, EV_CHOCH_UP, False)), ("BOS↑", (2002.0, EV_BOS_UP, True)), ("MSS↓", (2002.0, EV_CHOCH_DN, True))):
        s, Z1 = su3_dung(src)
        s.g["zones"].v.append(zone(s.ip, 15, 1 if ten != "MSS↓" else -1, 2000.0, 2002.0, bm=s.xs()[0].f["t0"] // 60000, bs=1))
        m15_tiep(s, 1996, 1997, 1995.5, 1996)
        m15_tiep(s, 1996, 2003, 1995.5, 2002, h1=h1)
        kq[ten] = [(x.f["st"], x.f["t2"] is not NA and x.f["t2"] is not None) for x in s.xs()]
    T("S3-03", "Bước 2: chỉ MSS↑ H1 theo D.3 (a) (CHoCH↑ + cờ mssA) tại t2 > t1 chuyển sang chờ vùng; CHoCH không MSS, BOS, MSS ngược chiều → không", "MSS↑ → st 1; còn lại st 0",
      kq, kq["MSS↑"] == [(1, True)] and kq["CHoCH↑ không MSS"] == [(0, False)] and kq["BOS↑"] == [(0, False)] and kq["MSS↓"] == [(0, False)])
    # S3-04 vô hiệu trước bước 2
    s, Z1 = su3_dung(src)
    ev1 = m15_tiep(s, 1995, 1996, 1993.0, 1993.9, h1=(1993.9, 0, False))               # Close H1 1993,9 < MỐC 1994
    s2, Z1b = su3_dung(src)
    s2.g["zones"].v.remove(Z1b)                                                        # vùng H1 bị gỡ (vô hiệu/quá tuổi)
    ev2 = m15_tiep(s2, 1996, 1997, 1995.5, 1996)
    s3, _ = su3_dung(src)
    x3 = s3.xs()[0]
    ev3 = m15_tiep(s3, 1995, 1996, 1994.2, 1994.0, h1=(1994.0, 0, False))              # Close H1 = MỐC → không vô hiệu
    f = lambda o: [ev_t(e) for b in o for e in b[0]]  # noqa: E731
    T("S3-04", "Vô hiệu trước bước 2: Close H1 (đóng sau t1) < MỐC_ĐÁY → VOID 6; vùng H1 bước 1 bị gỡ → VOID 6; Close H1 = MỐC → không", "VOID 6 / VOID 6 / không",
      dict(close_duoi_moc=f(ev1), vung_go=f(ev2), bang_moc=(f(ev3), x3 in s3.xs())),
      f(ev1) == [(3, 1, SS_VOID, 6)] and f(ev2) == [(3, 1, SS_VOID, 6)] and f(ev3) == [] and x3 in s3.xs())
    # S3-05 hết hạn bước 2: 24 nến H1 kể từ nến H1 chứa t1
    def h1_n(n_h1, mss_at=None):
        s, _ = su3_dung(src)
        s.g["zones"].v.append(zone(s.ip, 15, 1, 2000.0, 2002.0, bm=s.xs()[0].f["t0"] // 60000 + 15, bs=1))
        evs = []
        for k in range(1, n_h1 + 1):
            for q in range(3):
                h1 = None
                if q == 2:
                    h1 = (1996.0, EV_CHOCH_UP, True) if k == mss_at else (1996.0, 0, False)
                o = m15_tiep(s, 1996, 1997, 1995.5, 1996, h1=h1, n_m5=3)
                evs += [ev_t(e) for b in o for e in b[0]]
                if s.xs() and s.xs()[0].f["st"] == 1 or not s.xs():
                    return s, evs, k
        return s, evs, n_h1
    sA, eA, kA = h1_n(30)
    sB, eB, kB = h1_n(30, mss_at=24)
    sC, eC, kC = h1_n(30, mss_at=25)
    T("S3-05", "Hết hạn bước 2: MSS phải ở nến H1 thứ 1…24 kể từ nến H1 chứa t1. Không MSS → HẾT HẠN (7) tại nến H1 thứ 24; MSS ở nến thứ 24 → được nhận; MSS ở nến 25 → đã hết hạn",
      "hết hạn ở H1 #24; MSS #24 → st 1; MSS #25 → hết hạn #24", dict(khong=(eA, kA), mss24=(kB, [x.f["st"] for x in sB.xs()]), mss25=(eC, kC)),
      eA == [(3, 1, SS_EXPIRED, 7)] and kA == 24 and kB == 24 and [x.f["st"] for x in sB.xs()] == [1] and eC == [(3, 1, SS_EXPIRED, 7)] and kC == 24)
    # S3-06 bước 3 – chọn vùng M15 mới
    def chon(vung):
        s, _ = su3_dung(src)
        t1 = s.xs()[0].f["t0"] // 60000
        m15_tiep(s, 1996, 1997, 1995.5, 1996)
        s.m15(1996, 2003, 1995.5, 2002, h1=(2002.0, EV_CHOCH_UP, True))
        t2 = s.T // 60000
        Zs = [zone(s.ip, 15, d_, b_, b_ + 2, bm=f(t1, t2), bs=bs_) for d_, b_, f, bs_ in vung]
        s.g["zones"].v += Zs
        s.bar(2002, 2002.5, 2001.8, 2002.2)
        x = s.xs()
        return (x[0].f["bm"], x[0].f["bs"]) if x else "kết thúc", Zs
    k1, Zs = chon([(1, 1998.0, lambda a, b: a - 15 + 1, 1), (1, 1999.0, lambda a, b: b - 15 - 15, 2), (1, 2000.0, lambda a, b: b - 15, 3), (-1, 2005.0, lambda a, b: b - 15, 4)])
    k2, Zs2 = chon([(1, 1998.0, lambda a, b: a - 15, 1)])                                 # j = t1 → tồn tại trước (loại)
    k3, Zs3 = chon([(1, 1998.0, lambda a, b: b - 30, 5), (1, 1999.0, lambda a, b: b - 30, 9)])
    T("S3-06", "Bước 3: vùng Demand M15 có t1 < j ≤ t2 (j = thời điểm ĐÓNG nến BOS = bosMin + 15), lấy j muộn nhất (j = t2 được nhận); j = t1 bị loại (tồn tại trước, E.2/M-10); bằng j → base muộn hơn; không có vùng → kết thúc không sự kiện (IP-20)",
      "chọn vùng j = t2; j = t1 → kết thúc; bằng j → base 9", dict(chon=k1, j_bang_t1=k2, bang_j=k3),
      k1 == (Zs[2].f["bosMin"], 3) and k2 == "kết thúc" and k3 == (Zs3[1].f["bosMin"], 9))
    # S3-07 … S3-13: dựng tới bước 3 rồi kiểm bước 4, 5
    def toi_b3(z2=(2000.0, 2002.0)):
        s, Z1 = su3_dung(src)
        m15_tiep(s, 1996, 1997, 1993.0, 1996)
        s.m15(1996, 2003, 1995.5, 2002, h1=(2002.0, EV_CHOCH_UP, True))
        Z2 = zone(s.ip, 15, 1, z2[0], z2[1], bm=s.T // 60000 - 30, bs=7)
        s.g["zones"].v.append(Z2)
        s.bar(2004, 2005, 2003.5, 2004.5)
        return s, Z2
    def cham(s, Z2, o, h, l, c, touches=1, moved=True):
        Z2.f["touches"], Z2.f["moved"] = touches, moved
        r = s.bar(o, h, l, c)
        Z2.f["moved"] = False
        return r
    s, Z2 = toi_b3()
    e1, t1x = cham(s, Z2, 2003.0, 2003.2, 2001.5, 2002.8)
    a_ok = s.xs()[0].f["st"] == 2 and [ev_t(e) for e in e1] == [(3, 1, SS_WAIT, 0)] and "SU-3 BUY – THEO DÕI" in t1x
    sg, Z2g = toi_b3()
    eg, _ = cham(sg, Z2g, 1999.5, 2002.0, 1999.0, 2001.5)                              # gap: Open < biên dưới
    sb, Z2b = toi_b3()
    cham(sb, Z2b, 2003.0, 2003.2, 2001.5, 2002.8, touches=2)                           # lần chạm thứ 2
    T("S3-07", "Bước 4: lần chạm ĐẦU TIÊN của vùng (P1: touches 0 → 1 trên nến này), không gap (Open ≥ biên dưới), nến mở ≥ t2 → ARMED tại a, sự kiện CHỜ, dashboard 'SHADOW: SU-3 BUY – THEO DÕI'; gap hoặc lần chạm thứ 2 → không ARMED",
      "ARMED; gap → st 1; chạm 2 → st 1", dict(armed=a_ok, gap=[x.f["st"] for x in sg.xs()], cham2=[x.f["st"] for x in sb.xs()]), a_ok and [x.f["st"] for x in sg.xs()] == [1] and [x.f["st"] for x in sb.xs()] == [1])
    # S3-08 hết hạn bước 4: 48 nến M15 kể từ t3
    s, Z2 = toi_b3()
    k0 = s.xs()[0].f["k"]
    n = 0
    evx = []
    while s.xs() and n < 60:
        o = m15_tiep(s, 2004, 2005, 2003.5, 2004.5, n_m5=3)
        evx += [ev_t(e) for b in o for e in b[0]]
        n += 1
    T("S3-08", "Hết hạn bước 4: 48 nến M15 kể từ t3 mà chưa ARMED → HẾT HẠN 7 (bộ đếm bắt đầu bằng số nến M15 từ t3 tới t2)", "t3 = t2 − 15 phút → k0 = 1; hết hạn sau 47 nến M15 nữa",
      dict(k0=k0, so_nen_M15=n, su_kien=evx), k0 == 1 and n == 47 and evx == [(3, 1, SS_EXPIRED, 7)])
    # S3-09 vùng bước 3 bị gỡ (trước và sau ARMED)
    s, Z2 = toi_b3()
    s.g["zones"].v.remove(Z2)
    e9, _ = s.bar(2004, 2005, 2003.5, 2004.5)
    s2, Z2b = toi_b3()
    cham(s2, Z2b, 2003.0, 2003.2, 2001.5, 2002.8)
    s2.g["zones"].v.remove(Z2b)
    e9b, _ = s2.bar(2003, 2003.5, 2002.5, 2003)
    T("S3-09", "Vùng bước 3 bị gỡ (vô hiệu nguồn/quá tuổi/hết lượt) trước bước 4 hoặc sau ARMED → VOID 6", "VOID 6 hai ca", ([ev_t(e) for e in e9], [ev_t(e) for e in e9b]),
      [ev_t(e) for e in e9] == [(3, 1, SS_VOID, 6)] and [ev_t(e) for e in e9b] == [(3, 1, SS_VOID, 6)] and not s.xs() and not s2.xs())
    # S3-10 P4
    s, Z2 = toi_b3()
    cham(s, Z2, 2003.0, 2003.2, 2001.5, 2002.8)
    e10a, _ = s.bar(2001, 2001.2, 1999.85, 1999.91)                                    # 1999,91 > 2000 − 0,1 = 1999,9 → không
    e10b, _ = s.bar(2000, 2000.2, 1999.5, 1999.89)
    T("S3-10", "P4 sau ARMED: Close M5 < biên dưới vùng − 0,1×ATR_M5 → VOID 5; đúng biên không vô hiệu", "không / VOID 5", ([ev_t(e) for e in e10a], [ev_t(e) for e in e10b]),
      [ev_t(e) for e in e10a] == [] and [ev_t(e) for e in e10b] == [(3, 1, SS_VOID, 5)])
    # S3-11, S3-12 L*/H*, trigger, SL, S1
    def toi_trig(reg=2, pend=False, last=(2002.0, 2004.0, 2001.9, 2003.6)):
        s, Z2 = toi_b3()
        s.ctx(reg=reg, atr15=8.0) if reg != 2 else None
        cham(s, Z2, 2003.0, 2003.2, 2001.5, 2002.8)                 # a: L* = 2001,5; b = a
        s.bar(2002.8, 2003.3, 2001.2, 2002.0)                         # L* 2001,2 (b mới)
        s.bar(2002.0, 2002.6, 2001.4, 2002.3)
        return s, s.bar(*last, pendH1=pend) if pend else s.bar(*last)
    s, (e11, t11) = toi_trig()
    x_hs = None
    sP, (e11p, _) = toi_trig(pend=True)
    sN, (e11n, _) = toi_trig(last=(2003.5, 2003.6, 2002.4, 2002.5))   # nến giảm
    e = e11[0] if e11 else None
    # H* = max High của b−1…b−3 với b = nến 2001,2: nến a (2003,2), nến toi_b3 (2005), nến M15 trước (2002,3) → 2005
    ok11 = e is not None and e.f["state"] == SHADOW and e.f["reason"] == 16 and abs(e.f["sl"] - min(2001.2 - 0.2 * 1.0, 1993.0 - 0.2 * 5.0)) < 1e-9 and e.f["pRef"] == 2003.6
    T("S3-11", "Bước 5 + S1 SHADOW: H* = High lớn nhất của b−1…b−3 (Phase 1.5), trigger khi Close > H* và nến tăng; SL = min(L* − 0,2×ATR_M5, ĐÁY_1_FINAL − 0,2×ATR_M15(t2)); quyền ĐẢO CHIỀU (REG DOWNTREND) → trạng thái 17, lý do 16; dashboard 'ĐẠT (không giao dịch)'",
      "H* = 2005 → Close 2003,6 không trigger", dict(su_kien=[(ev_t(v), v.f["sl"]) for v in e11], txt=t11), None)
    # Close 2003,6 < H* 2005 → không trigger: ghi đúng kỳ vọng
    ok11 = not e11 and sN and True
    s, (e11, t11) = toi_trig(last=(2004.0, 2005.5, 2003.9, 2005.2))
    e = e11[0] if e11 else None
    ok11 = e is not None and e.f["state"] == SHADOW and e.f["reason"] == 16 and abs(e.f["sl"] - min(2001.2 - 0.2, 1993.0 - 0.2 * 8.0)) < 1e-9 and e.f["pRef"] == 2005.2 and "SU-3 BUY – ĐẠT (không giao dịch)" in t11
    sP, (e11p, _) = toi_trig(pend=True, last=(2004.0, 2005.5, 2003.9, 2005.2))
    sN, (e11n, _) = toi_trig(last=(2005.6, 2005.7, 2005.0, 2005.1))
    R[-1] = ("S3-11", R[-1][1], "Close 2005,2 > H* 2005, nến tăng → 17/16, SL = min(2001,0; 1993 − 0,2×8 = 1991,4) = 1991,4; khung chờ hoặc nến giảm → không trigger",
             dict(su_kien=[(ev_t(v), v.f["sl"], v.f["tp1"], v.f["rr"]) for v in e11], txt=t11, khung_cho=len(e11p), nen_giam=len(e11n)), ok11 and not e11p and not e11n)
    kq = {}
    for reg, ten in ((1, "UPTREND"), (3, "RANGE"), (2, "DOWNTREND")):
        s, (ex, _) = toi_trig(reg=reg, last=(2004.0, 2005.5, 2003.9, 2005.2))
        kq[ten] = [(v.f["state"], v.f["reason"]) for v in ex]
    T("S3-12", "Quyền I.3 lớp ĐẢO CHIỀU tại nến trigger (H-20): SU-3 BUY cần REG DOWNTREND (hoặc TRANSITION có LAST_CHOCH = ↑); UPTREND/RANGE → lý do 15, trạng thái BỎ QUA (15 trước 16)",
      "UP/RANGE: (4, 15); DOWN: (17, 16)", kq, kq["UPTREND"] == [(SS_SKIP, 15)] and kq["RANGE"] == [(SS_SKIP, 15)] and kq["DOWNTREND"] == [(SHADOW, 16)])
    # S3-13 hết hạn sau ARMED
    s, Z2 = toi_b3()
    cham(s, Z2, 2003.0, 2003.2, 2001.5, 2002.8)
    evx, n = [], 0
    while s.xs() and n < 40:
        e_, _ = s.bar(2002.5, 2003.0, 2002.0, 2002.6)
        evx += [ev_t(v) for v in e_]
        n += 1
    T("S3-13", "Hết hạn sau ARMED: 24 nến M5 kể từ a (P8: hết hạn tại a + 23 nếu không trigger)", "HẾT HẠN 7 ở nến thứ 23 sau a", dict(n=n, su_kien=evx), n == 23 and evx == [(3, 1, SS_EXPIRED, 7)])
    # S3-14 trùng: mỗi nến M15 giao cắt tạo một thể hiện (đặc tả không có quy tắc khử trùng – IP-21); một thể hiện chỉ ARMED một lần
    s, Z1 = su3_dung(src)
    m15_tiep(s, 1996, 1997, 1994.5, 1996)
    n2 = len(s.xs())
    T("S3-14", "FACT: hai nến M15 liên tiếp giao cắt cùng vùng H1 tạo hai thể hiện độc lập (J.2 không có quy tắc khử trùng – IP-21, chưa quyết); mỗi thể hiện chỉ một lần ARMED và bị gỡ khi kết thúc",
      "2 thể hiện", n2, n2 == 2)
    # S3-15 SELL đối xứng tới trigger
    s = SHD(src); s.ctx(reg=1, atr15=8.0)
    s.g["zones"].v.append(zone(s.ip, 60, -1, 2005.0, 2010.0, bm=mins(s.T) - 600))
    s.m15(2003, 2006.0, 2002, 2004); s.bar(2004, 2004.3, 2003.7, 2003.9)
    m15_tiep(s, 2004, 2007.0, 2003, 2004)
    s.m15(2004, 2005, 1996, 1997, h1=(1997.0, EV_CHOCH_DN, True))
    Z2 = zone(s.ip, 15, -1, 1998.0, 2000.0, bm=s.T // 60000 - 15, bs=3)
    s.g["zones"].v.append(Z2)
    s.bar(1996, 1996.5, 1995, 1995.5)
    Z2.f["touches"], Z2.f["moved"] = 1, True
    s.bar(1997.0, 1998.8, 1996.8, 1997.2); Z2.f["moved"] = False                      # a: H* = 1998,8
    s.bar(1997.2, 1999.0, 1996.9, 1998.0)                                              # H* 1999 (b)
    s.bar(1998.0, 1998.5, 1997.5, 1998.0)
    e15, t15 = s.bar(1997.5, 1997.6, 1994.5, 1994.6)                                   # L* = min Low b−1…b−3 = 1995 → Close 1994,6 < 1995, nến giảm
    ok = len(e15) == 2 and all(v.f["dir"] == -1 and v.f["state"] == SHADOW and abs(v.f["sl"] - max(1999.0 + 0.2, 2007.0 + 0.2 * 8.0)) < 1e-9 for v in e15) and "SU-3 SELL" in t15
    T("S3-15", "SU-3 SELL đối xứng: MỐC_ĐỈNH = High[t1], ĐỈNH_1_FINAL = max High tới t2, MSS↓ H1, vùng Supply M15, L* = Low nhỏ nhất b−1…b−3, SL = max(H* + 0,2×ATR_M5, ĐỈNH_1_FINAL + 0,2×ATR_M15); REG UPTREND có quyền ĐẢO CHIỀU",
      "2 thể hiện (t1 ở 2 nến M15 giao cắt vùng – S3-14) cùng 17/16, SL = max(1999,2; 2007 + 1,6) = 2008,6", [(ev_t(q), q.f["sl"]) for q in e15], ok)
    # S3-16 thiếu dữ liệu: md4OK sai → lý do 8 (TP1 không chứng minh được)
    s, (e16, _) = (lambda: (lambda s_: (s_, None))(None))() if False else (None, (None, None))
    s, Z2 = toi_b3()
    cham(s, Z2, 2003.0, 2003.2, 2001.5, 2002.8)
    s.bar(2002.8, 2003.3, 2001.2, 2002.0); s.bar(2002.0, 2002.6, 2001.4, 2002.3)
    e16, _ = s.bar(2004.0, 2005.5, 2003.9, 2005.2, md5OK=False)
    T("S3-16", "Thiếu dữ liệu tại S1 (pool MD-5 chưa khả dụng) → lý do 8, trạng thái BỎ QUA (8 đứng đầu thứ tự lý do)", "(4, 8)", [(q.f["state"], q.f["reason"]) for q in e16],
      [(q.f["state"], q.f["reason"]) for q in e16] == [(SS_SKIP, 8)])
    return R


# ===================================================================================================== SU-5
def su5_dung(src, d=1, lv_ref=2000.0, cl=(), reg=1, clsP=1999.0, c=2003.0, ev=None):
    s = SHD(src); s.ctx(reg=reg)
    if cl:
        s.g.update(cLo=PArr([x[0] for x in cl]), cHi=PArr([x[1] for x in cl]), cRank=PArr([x[2] for x in cl]))
    if d == 1:
        s.m15(clsP, c + 1, clsP - 1, c, ev=EV_BOS_UP if ev is None else ev, refH=lv_ref, clsP=clsP)
    else:
        s.m15(clsP, clsP + 1, c - 1, c, ev=EV_BOS_DN if ev is None else ev, refL=lv_ref, clsP=clsP)
    return s


def nhom_su5(src=S39):
    R = []

    def T(i, mo, kv, tt, ok):
        R.append((i, mo, kv, tt, bool(ok)))
    lvof = lambda s: [(x.f["su"], x.f["d"], x.f["lv"], x.f["ext"]) for x in s.xs()]  # noqa: E731
    # S5-01 Lv
    kq = {}
    s = su5_dung(src); s.bar(2003, 2003.2, 2002.8, 2003); kq["REF"] = lvof(s)
    s = su5_dung(src, cl=((2000.5, 2001.0, 2), (2001.5, 2002.0, 3), (1990.0, 1991.0, 5))); s.bar(2003, 2003.2, 2002.8, 2003); kq["hang_cao"] = lvof(s)
    s = su5_dung(src, cl=((2000.5, 2001.0, 3), (2001.5, 2002.0, 3))); s.bar(2003, 2003.2, 2002.8, 2003); kq["bang_hang_U_cao"] = lvof(s)
    s = su5_dung(src, cl=((2000.5, 2001.0, 1),)); s.bar(2003, 2003.2, 2002.8, 2003); kq["hang1"] = lvof(s)
    s = su5_dung(src, cl=((1998.5, 1999.0, 4),)); s.bar(2003, 2003.2, 2002.8, 2003); kq["U_bang_close_truoc"] = lvof(s)
    s = su5_dung(src, cl=((2002.5, 2003.0, 4),)); s.bar(2003, 2003.2, 2002.8, 2003); kq["U_bang_close"] = lvof(s)
    T("S5-01", "Bước 1 BUY: BOS↑ M15 tại j; Lv = REF_H, hoặc cạnh trên U của cụm hạng ≥ 2 thỏa Close[j−1] ≤ U < Close[j]; ưu tiên cụm, hạng cao hơn, bằng hạng thì U cao hơn; A = ATR_M15(j)",
      "REF 2000; hạng 3 → 2002; bằng hạng → 2002; hạng 1 → REF; U = Close[j−1] 1999 → nhận; U = Close[j] → REF", kq,
      kq["REF"] == [(5, 1, 2000.0, 5.0)] and kq["hang_cao"] == [(5, 1, 2002.0, 5.0)] and kq["bang_hang_U_cao"] == [(5, 1, 2002.0, 5.0)] and kq["hang1"] == [(5, 1, 2000.0, 5.0)]
      and kq["U_bang_close_truoc"] == [(5, 1, 1999.0, 5.0)] and kq["U_bang_close"] == [(5, 1, 2000.0, 5.0)])
    kq = {}
    s = su5_dung(src, d=-1, lv_ref=2000.0, clsP=2001.0, c=1997.0, cl=((1998.0, 1998.5, 2), (1999.0, 1999.5, 2))); s.bar(1997, 1997.2, 1996.8, 1997); kq["SELL"] = lvof(s)
    s = su5_dung(src, ev=EV_CHOCH_UP); s.bar(2003, 2003.2, 2002.8, 2003); kq["CHoCH"] = lvof(s)
    s = su5_dung(src); s.g["md4OK"] = False; s.bar(2003, 2003.2, 2002.8, 2003); kq["md4_sai"] = lvof(s)
    s = su5_dung(src); s.g["s5L"].v.append(2000.0); s.bar(2003, 2003.2, 2002.8, 2003); kq["Lv_da_dung"] = lvof(s)
    T("S5-02", "SELL đối xứng (Close[j] < D ≤ Close[j−1], bằng hạng → D thấp hơn); CHoCH không phải BOS → không tạo; MD-4 chưa khả dụng → không tạo (không xác định được ưu tiên cụm); Lv đã có SU-5 kết thúc → không tạo (J.4.3)",
      "SELL Lv 1998; 0; 0; 0", kq, kq["SELL"] == [(5, -1, 1998.0, 5.0)] and kq["CHoCH"] == [] and kq["md4_sai"] == [] and kq["Lv_da_dung"] == [])
    # S5-03 rời mức / S5-04 retest
    s = su5_dung(src)
    s.bar(2003, 2003.2, 2001.0, 2002.49)                       # chưa rời (cần ≥ 2002,5)
    st1 = s.xs()[0].f["st"]
    s.bar(2002.5, 2002.6, 2001.6, 2002.5)                       # rời đúng biên
    st2 = s.xs()[0].f["st"]
    T("S5-03", "Bước 2 rời mức: nến M5 mở ≥ T_j với Close ≥ Lv + 0,5A (đúng biên được tính)", "st 0 → 1 tại Close 2002,5", (st1, st2), st1 == 0 and st2 == 1)
    s = su5_dung(src)
    e_, t_ = s.bar(2003, 2003.2, 2001.0, 2003.0)              # rời + giao cắt dải cùng nến → chưa retest
    stA = s.xs()[0].f["st"]
    e2, t2 = s.bar(2002.0, 2002.2, 2001.25, 2001.8)             # Low = Lv + 0,25A đúng biên → ARMED
    stB = s.xs()[0].f["st"]
    sg = su5_dung(src); sg.bar(2003, 2003.2, 2002.8, 2003)
    eg, _ = sg.bar(1998.7, 2000.0, 1998.5, 1999.5)              # gap: Open 1998,7 < Lv − 0,25A = 1998,75 → kết thúc lý do 4
    T("S5-04", "Bước 3 retest: nến M5 ĐẦU TIÊN sau bước 2 giao cắt dải Lv ± 0,25A (cùng nến rời mức không tính); Open ≥ Lv − 0,25A → ARMED; lần giao cắt đầu mà gap → không kích hoạt, kết thúc lý do 4 (J.4.3)",
      "st 1 → 2; gap → (4, 4)", dict(cung_nen=stA, armed=(stB, [ev_t(v) for v in e2], t2), gap=([ev_t(v) for v in eg], len(sg.xs()))),
      stA == 1 and stB == 2 and [ev_t(v) for v in e2] == [(5, 1, SS_WAIT, 0)] and "SU-5 BUY – THEO DÕI" in t2 and [ev_t(v) for v in eg] == [(5, 1, SS_SKIP, 4)] and not sg.xs())
    # S5-05 vô hiệu neo, S5-06 hết hạn trước retest
    def m15n(s, n, c, ev=0):
        out = []
        for _ in range(n):
            s.m15(c, c + 0.5, c - 0.5, c, ev=ev)
            out += [ev_t(v) for v in s.bar(c, c + 0.3, c - 0.3, c)[0]]
            out += [ev_t(v) for v in s.bar(c, c + 0.3, c - 0.3, c)[0]]
            out += [ev_t(v) for v in s.bar(c, c + 0.3, c - 0.3, c)[0]]
        return out
    s = su5_dung(src); s.bar(2003, 2003.2, 2002.8, 2003)
    o1 = m15n(s, 1, 1998.7)                                     # Close M15 < Lv − 0,25A = 1998,75
    s2 = su5_dung(src); s2.bar(2003, 2003.2, 2002.8, 2003)
    o2 = m15n(s2, 1, 1998.75)                                   # đúng biên → không
    s3 = su5_dung(src); s3.bar(2003, 2003.2, 2002.8, 2003)
    o3 = m15n(s3, 1, 1999.5, ev=EV_BOS_DN)                      # BOS↓ đóng dưới Lv
    T("S5-05", "Vô hiệu neo (M15 đã đóng): Close M15 < Lv − 0,25A trong j+1…j+24 → VOID 6 (đúng biên không); BOS↓ M15 đóng dưới Lv → VOID 6", "VOID 6 / không / VOID 6",
      (o1, o2, o3), o1 == [(5, 1, SS_VOID, 6)] and not any(q[2] == SS_VOID for q in o2) and len(s2.xs()) == 1 and o3 == [(5, 1, SS_VOID, 6)])
    s = su5_dung(src); s.bar(2003, 2003.2, 2002.8, 2003)
    o = m15n(s, 24, 2004.0)
    T("S5-06", "Hết hạn: chưa có retest tới nến M15 j + 24 → HẾT HẠN 7 (tại lần nhận M15 j + 24)", "1 sự kiện HẾT HẠN, ở nến M15 thứ 24", (o, len(s.xs())), o == [(5, 1, SS_EXPIRED, 7)] and not s.xs())
    # S5-07 vô hiệu setup sau ARMED
    s = su5_dung(src); s.bar(2003, 2003.2, 2002.8, 2003)
    s.bar(2002.0, 2002.2, 2001.2, 2001.8)                       # ARMED
    eA, _ = s.bar(1999.0, 1999.2, 1998.6, 1998.65)              # 1998,65 = 1998,75 − 0,1 → đúng biên, không
    eB, _ = s.bar(1998.7, 1998.8, 1998.5, 1998.64)
    T("S5-07", "Vô hiệu setup (M5, sau ARMED): Close < (Lv − 0,25A) − 0,1×ATR_M5 → VOID 5; đúng biên không", "không / VOID 5", ([ev_t(v) for v in eA], [ev_t(v) for v in eB]),
      [ev_t(v) for v in eA] == [] and [ev_t(v) for v in eB] == [(5, 1, SS_VOID, 5)])
    # S5-08 L*/H* đặc biệt của J.4
    s = SHD(src); s.ctx(reg=1)
    s.bar(2010, 2010.5, 2009.5, 2010)                           # nến trước T_j (mở < T_j): High 2010,5 không được dùng
    s.m15(1999, 2004, 1998, 2003, ev=EV_BOS_UP, refH=2000.0, clsP=1999.0)
    s.bar(2003, 2003.4, 2002.8, 2003.0)                         # mở = T_j: rời mức
    s.bar(2002.0, 2002.2, 2001.0, 2001.6)                       # a = b: L* 2001; b−1 = 2003,4 (mở ≥ T_j), b−2 mở < T_j → H* = 2003,4
    x = s.xs()[0]
    hsA = x.f["hs"]
    s.bar(2001.6, 2001.9, 2001.0, 2001.7)                       # Low = L* → không cập nhật (b sớm nhất)
    bA = x.f["b"]
    s2 = SHD(src); s2.ctx(reg=1)
    s2.m15(1999, 2004, 1998, 2003, ev=EV_BOS_UP, refH=2000.0, clsP=1999.0)
    s2.bar(2002.4, 2002.6, 2001.0, 2002.5)                      # mở = T_j: rời mức (Close 2002,5) – cùng nến có giao cắt, chưa retest
    s2.bar(2001.5, 2001.6, 2000.5, 2001.0)                      # retest (a = b): b−1 = nến trên (mở ≥ T_j) → H* = 2002,6
    hsB = s2.xs()[0].f["hs"]
    T("S5-08", "J.4 L*/H*: L* = Low nhỏ nhất từ a, chỉ cập nhật khi nhỏ hơn nghiêm ngặt (b = nến sớm nhất); H* = High lớn nhất của b−1…b−3 có thời điểm mở ≥ T_j (nến mở trước T_j bị loại)",
      "H* = 2003,4 (bỏ High 2010,5 của nến trước T_j); b giữ nguyên khi Low bằng; ca 2: H* = 2002,6", dict(hs=hsA, b_giu=(bA, x.f["b"]), hs2=hsB),
      hsA == 2003.4 and bA == x.f["b"] and hsB == 2002.6)
    # S5-09 trigger, SL, quyền THUẬN
    def toi_trig5(reg=1, last=(2001.8, 2004.0, 2001.7, 2003.9), **kw):
        s = su5_dung(src, reg=reg)
        s.bar(2003, 2003.4, 2002.8, 2003.0)
        s.bar(2002.0, 2002.2, 2001.0, 2001.6)                   # ARMED, L* 2001, H* 2003,4
        return s, s.bar(*last, **kw)
    s, (e9, t9) = toi_trig5()
    v = e9[0] if e9 else None
    ok = v is not None and (v.f["state"], v.f["reason"]) == (SHADOW, 16) and abs(v.f["sl"] - min(2001.0 - 0.2, 2000.0 - 0.5 * 5.0)) < 1e-9 and "SU-5 BUY – ĐẠT (không giao dịch)" in t9
    kq = {}
    for reg, ten in ((2, "DOWNTREND"), (3, "RANGE"), (4, "TRANSITION")):
        _, (ex, _) = toi_trig5(reg=reg)
        kq[ten] = [(q.f["state"], q.f["reason"]) for q in ex]
    _, (ev_, _) = toi_trig5(last=(2004.0, 2004.2, 2003.5, 2003.9))        # nến giảm
    _, (ep_, _) = toi_trig5(pendM15=True)
    T("S5-09", "Trigger Close > H* và nến tăng; SL = min(L* − 0,2×ATR_M5, Lv − 0,5A) = min(2000,8; 1997,5); quyền I.3 lớp THUẬN (f_perm, như SU-1): REG không phải UPTREND → 15; nến giảm hoặc khung chờ → không trigger",
      "17/16, SL 1997,5; DOWN/RANGE/TRANSITION → (4, 15)", dict(dat=[(ev_t(q), q.f["sl"], q.f["tp1"], q.f["rr"]) for q in e9], quyen=kq, nen_giam=len(ev_), khung_cho=len(ep_)),
      ok and all(v_ == [(SS_SKIP, 15)] for v_ in kq.values()) and not ev_ and not ep_)
    # S5-10 hết hạn sau ARMED
    s = su5_dung(src); s.bar(2003, 2003.2, 2002.8, 2003); s.bar(2002.0, 2002.2, 2001.2, 2001.8)
    evx, n = [], 0
    while s.xs() and n < 40:
        e_, _ = s.bar(2002.0, 2002.3, 2001.5, 2002.1)
        evx += [ev_t(q) for q in e_]
        n += 1
    T("S5-10", "Hết hạn sau ARMED: 24 nến M5 (hết hạn tại a + 23)", "HẾT HẠN ở nến thứ 23 sau a", (n, evx), n == 23 and evx == [(5, 1, SS_EXPIRED, 7)])
    # S5-11 Lv kết thúc không tạo SU-5 mới (J.4.3)
    s = su5_dung(src); s.bar(2003, 2003.2, 2002.8, 2003)
    m15n(s, 1, 1998.7)                                          # VOID → Lv 2000 ghi nhớ
    s.m15(1999, 2004, 1998, 2003, ev=EV_BOS_UP, refH=2000.0, clsP=1999.0)
    s.bar(2003, 2003.2, 2002.8, 2003)
    s.m15(1999, 2006, 1998, 2005, ev=EV_BOS_UP, refH=2001.0, clsP=2000.0)
    s.bar(2005, 2005.2, 2004.8, 2005)
    T("S5-11", "J.4.3: khi thể hiện SU-5 kết thúc (mọi lý do), mức Lv không tạo SU-5 mới; BOS qua mức khác vẫn tạo", "Lv 2000 bị chặn; Lv 2001 tạo", (list(s.g["s5L"].v), lvof(s)),
      list(s.g["s5L"].v) == [2000.0] and lvof(s) == [(5, 1, 2001.0, 5.0)])
    # S5-12 nhiều thể hiện + mô hình độc lập (vòng đời BUY) trên 300 chuỗi ngẫu nhiên
    R.append(mo_hinh_su5(src))
    return R


def mo_hinh_su5(src, n=300):
    """Mô hình Python ĐỘC LẬP viết từ J.4.1 (chỉ vòng đời M5: rời → retest/gap → ARMED → P4 / trigger / hết hạn; L*/H* có lọc T_j).
    Đơn giản hóa: không có nến M15 mới sau j (không vô hiệu neo, không hết hạn trước retest), không S1 (chỉ thời điểm và loại kết thúc), REG UPTREND."""
    Rr = random.Random(5)
    sai = []
    for k in range(n):
        lv, A, a5 = 2000.0, 5.0, 1.0
        s = su5_dung(src)
        pre = [(2000 + Rr.uniform(-3, 3)) for _ in range(3)]
        bars = []
        p = 2003.0
        for j in range(30):
            o = p; c = round(p + Rr.gauss(0, 1.6), 1); h = round(max(o, c) + abs(Rr.gauss(0, 0.6)), 1); l_ = round(min(o, c) - abs(Rr.gauss(0, 0.6)), 1)
            bars.append((o, h, l_, c)); p = c
        # mô hình
        st, Ls, b, kq_m, kk = 0, None, None, None, 0
        hist = []
        for j, (o, h, l_, c) in enumerate(bars):
            hist.append((o, h, l_, c, j))
            if st == 0:
                if c >= lv + 0.5 * A:
                    st = 1
                continue
            if st == 1:
                if l_ <= lv + 0.25 * A and h >= lv - 0.25 * A:
                    if o >= lv - 0.25 * A:
                        st, Ls, b, kk = 2, l_, j, 0
                    else:
                        kq_m = ("GAP", j); break
                else:
                    continue
            if st == 2:
                if c < (lv - 0.25 * A) - 0.1 * a5:
                    kq_m = ("VOID", j); break
                if l_ < Ls:
                    Ls, b = l_, j
                cands = [bars[q][1] for q in (b - 1, b - 2, b - 3) if q >= 0]
                Hs = max(cands) if cands else bars[b][1]
                if c > Hs and c > o:
                    kq_m = ("TRIG", j); break
                if kk >= 23:
                    kq_m = ("EXP", j); break
                kk += 1
        # Pine nguyên văn
        kq_p = None
        for j, b_ in enumerate(bars):
            e_, _ = s.bar(*b_)
            for v in e_:
                stt = v.f["state"]
                if stt == SS_SKIP and v.f["reason"] == 4:
                    kq_p = ("GAP", j)
                elif stt == SS_VOID:
                    kq_p = ("VOID", j)
                elif stt == SS_EXPIRED:
                    kq_p = ("EXP", j)
                elif v.f["trig"]:
                    kq_p = ("TRIG", j)
            if kq_p:
                break
        if kq_m != kq_p:
            sai.append((k, kq_m, kq_p))
    return ("S5-12", "Đối chiếu 300 chuỗi ngẫu nhiên với MÔ HÌNH ĐỘC LẬP viết từ J.4.1 (rời mức, retest/gap, ARMED, P4, L*/H* lọc theo T_j, trigger, hết hạn 24 nến M5) – thời điểm và loại kết thúc",
            "0 khác", f"khác {len(sai)}/{n}: {sai[:3]}", not sai)
