# -*- coding: utf-8 -*-
"""Tạo AUDIT CAPSULE 0.3.9 (văn bản thuần, chia phần) bằng cách TRÍCH XUẤT từ gói ZIP đã giao – không sửa source, không chạy lại bộ test.
Ngoại lệ có ghi rõ: phần C.4 chạy lại driver vi sai I-06 cho 3 kịch bản seed cố định để in dữ liệu so sánh từng nến (I-06 gốc chỉ lưu thống kê).
python3 tao_audit_capsule.py <thư mục kt đã giải nén> <thư mục ra>"""
import difflib, hashlib, json, os, re, sys

ROOT, OUTD = sys.argv[1], sys.argv[2]
os.makedirs(OUTD, exist_ok=True)
J = lambda *p: os.path.join(ROOT, *p)  # noqa: E731
rd = lambda *p: open(J(*p), encoding="utf-8").read()  # noqa: E731
sha = lambda *p: hashlib.sha256(open(J(*p), "rb").read()).hexdigest()  # noqa: E731
P38, P39 = "src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine"
S38, S39 = rd(P38), rd(P39)
L38, L39 = S38.split("\n"), S39.split("\n")
K39 = json.load(open(J("ket_qua039", "ket_qua_039.json"), encoding="utf-8"))
R39 = {x["test_id"]: x for x in K39["results"]}
RQ_NEW = json.load(open(J("ket_qua039", "hoi_quy_bo_038_tren_039", "ket_qua_038.json"), encoding="utf-8"))
RQ_OLD = json.load(open(J("ket_qua038", "ket_qua_038.json"), encoding="utf-8"))
SUMS = {l.split("  ", 1)[1].lstrip("./").strip(): l.split("  ", 1)[0] for l in open(J("SHA256SUMS.txt"), encoding="utf-8") if "  " in l}


def tok(s):
    return len(re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\S', "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n"))))


def cat(s, n=600):
    s = s if isinstance(s, str) else json.dumps(s, ensure_ascii=False, default=str)
    s = s.replace("\n", " ")
    return s if len(s) <= n else s[:n] + f" …[cắt, {len(s)} ký tự – đủ trong file nguồn]"


def tbl(head, rows):
    o = ["| " + " | ".join(head) + " |", "|" + "---|" * len(head)]
    for r in rows:
        o.append("| " + " | ".join(str(c).replace("|", "/").replace("\n", " ") for c in r) + " |")
    return "\n".join(o)


SEC = []  # (tiêu đề, nội dung)
SRC_JSON = "ket_qua039/ket_qua_039.json"

# =========================================================================================== A
sm = difflib.SequenceMatcher(None, L38, L39, autojunk=False)
ops = [o for o in sm.get_opcodes() if o[0] != "equal"]
ins = sum(j2 - j1 for op, i1, i2, j1, j2 in ops if op == "insert")
rep = [(i1, i2, j1, j2) for op, i1, i2, j1, j2 in ops if op == "replace"]
dele = [(i1, i2) for op, i1, i2, j1, j2 in ops if op == "delete"]
cmt = sum(1 for op, i1, i2, j1, j2 in ops for l in L39[j1:j2] if l.strip().startswith("//"))
blank = sum(1 for op, i1, i2, j1, j2 in ops for l in L39[j1:j2] if not l.strip())
ct = J("hoi_quy034", "tests", "chay_test.py"); ct0 = J("BAN_GIAO_039", "cong_cu_truoc_039", "chay_test_truoc_039.py")
dct = list(difflib.unified_diff(open(ct0, encoding="utf-8").read().split("\n"), open(ct, encoding="utf-8").read().split("\n"), "chay_test.py (trước 0.3.9)", "chay_test.py (0.3.9)", lineterm="", n=0))
a = []
a.append("A.1–A.2 HASH (tính lại bằng sha256 trên file trong gói; khớp SHA256SUMS.txt của gói)")
a.append(tbl(["File", "SHA-256", "Khớp SHA256SUMS"], [[P38, sha(P38), SUMS.get(P38) == sha(P38)], [P39, sha(P39), SUMS.get(P39) == sha(P39)],
                                                     ["ket_qua039/ket_qua_039.json", sha("ket_qua039", "ket_qua_039.json"), SUMS.get("ket_qua039/ket_qua_039.json") == sha("ket_qua039", "ket_qua_039.json")]]))
a.append("SHA baseline đã xác minh trong chỉ thị: 79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13 → " + ("KHỚP" if sha(P38) == "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13" else "KHÔNG KHỚP"))
a.append("\nA.3 FILE THAY ĐỔI / THÊM MỚI so với gói 0.3.8")
a.append(tbl(["File", "Loại", "Ghi chú"], [
    [P39, "MỚI (build)", "0.3.8 không bị sửa; 0.3.9 là file riêng"],
    ["tools033/dung_build_039.py", "MỚI", "script dựng 0.3.9 từ 0.3.8 có khóa SHA đầu vào"],
    ["kiem_toan039/*.py, chay_tat_ca_039.sh", "MỚI", "bộ test 0.3.9"],
    ["kiem_toan039/hoi_quy_bo_038_tren_039.py", "MỚI (sinh tự động)", "bản sao chay_038.py, chỉ đổi đích/thư mục (A.7)"],
    ["hoi_quy034/tests/chay_test.py", "SỬA (chỉ ánh xạ đích '039')", f"{sum(1 for l in dct if l.startswith('+') and not l.startswith('+++'))} dòng thêm/sửa; bản cũ: BAN_GIAO_039/cong_cu_truoc_039/chay_test_truoc_039.py"],
    ["hoi_quy034/src/ATA_P3_Build_0.3.9_Candidate_Indicator.pine", "BẢN SAO", f"SHA {sha('hoi_quy034', 'src', 'ATA_P3_Build_0.3.9_Candidate_Indicator.pine')[:16]}… = build"]]))
a.append("\nA.5 THỐNG KÊ THAY ĐỔI PINE (difflib, từng dòng)")
a.append(tbl(["Chỉ số", "Giá trị"], [["Số dòng 0.3.8 / 0.3.9", f"{len(L38)} / {len(L39)}"], ["Dòng CHÈN", ins], ["Dòng SỬA (thay)", sum(i2 - i1 for i1, i2, _, _ in rep)], ["Dòng XÓA", sum(i2 - i1 for i1, i2 in dele)],
                                     ["Trong dòng chèn/sửa: chú thích / trống", f"{cmt} / {blank}"], ["Ghi chú đếm", "báo cáo ghi '+198 dòng' = số dòng '+' KHÔNG RỖNG trong patch (200 chèn + 5 sửa − 7 dòng trống); difflib: 200 chèn, 5 sửa"], ["Token từ vựng 0.3.8 → 0.3.9", f"{tok(S38)} → {tok(S39)} (+{tok(S39) - tok(S38)})"],
                                     ["Khối chèn (dòng 0.3.9, token)", "; ".join(f"{j1 + 1}–{j2} ({tok(chr(10).join(L39[j1:j2]))})" for op, i1, i2, j1, j2 in ops if op == "insert")]]))
a.append("\nA.6 THAY ĐỔI NGOÀI SCOPE – 5 dòng SỬA (toàn bộ, nguyên văn):")
for i1, i2, j1, j2 in rep:
    for k in range(i2 - i1):
        a.append(f"  0.3.8:{i1 + k + 1}  - {L38[i1 + k][:200]}\n  0.3.9:{j1 + k + 1}  + {L39[j1 + k][:200]}")
i01 = R39["I-01"]
a.append(f"Test I-01 ({i01['result']}): {cat(i01['actual'], 500)}")
a.append("Kết luận trích xuất: không có dòng nào bị xóa; 5 dòng sửa thuộc thông tin phiên bản/kích thước bảng dashboard; mọi thay đổi khác là khối chèn SHADOW (xem I.1).")
a.append("\nA.7 DIFF CÔNG CỤ hoi_quy034/tests/chay_test.py (toàn bộ):\n" + "\n".join(dct))
g = rd("kiem_toan039", "hoi_quy_bo_038_tren_039.py").split("\n"); g0 = rd("kiem_toan035", "chay_038.py").split("\n")
dg = [l for l in difflib.unified_diff(g0, g, "chay_038.py", "hoi_quy_bo_038_tren_039.py", lineterm="", n=0)]
a.append("\nA.8 DIFF chay_038.py → hoi_quy_bo_038_tren_039.py (chứng minh không sửa assertion; toàn bộ):\n" + "\n".join(dg))
SEC.append(("PHẦN A – BASELINE VÀ SOURCE IDENTITY", "\n".join(a)))
diff_txt = rd("ket_qua039", "DIFF_038_039.patch")
SEC.append(("PHẦN A.4 – DIFF 0.3.8 → 0.3.9 (nguyên văn ket_qua039/DIFF_038_039.patch, SHA " + sha("ket_qua039", "DIFF_038_039.patch")[:16] + "…)", diff_txt))

# =========================================================================================== B
def nhom(t):
    m = t["module"]
    if m.startswith("S3"): return "SU-3"
    if m.startswith("S5"): return "SU-5"
    if m.startswith("I ") or m.startswith("I·") or m.startswith("I "): return "Shadow Isolation"
    if m.startswith("I"): return "Shadow Isolation"
    if m.startswith("R"): return "Regression"
    if "Data Window" in m: return "Data Window"
    if "dashboard" in m: return "Dashboard"
    if m.startswith("M"): return "Mutation"
    if m.startswith("T ·"): return "Token"
    if t["test_id"] in ("I-01", "I-02", "I-03"): return "Shadow Isolation"
    return "Khác (phiên bản/phạm vi/IP/TradingView)"


for t in K39["results"]:
    if t["test_id"] in ("I-01", "I-02", "I-03"):
        t["_g"] = "Shadow Isolation"
    else:
        t["_g"] = nhom(t)
b = [f"Nguồn: {SRC_JSON} (summary: {json.dumps(K39['summary'], ensure_ascii=False)}); log: ket_qua039/nhat_ky_039.txt, ket_qua039/stdout_chay_039.txt"]
grs = ["SU-3", "SU-5", "Shadow Isolation", "Regression", "Data Window", "Dashboard", "Mutation", "Token", "Khác (phiên bản/phạm vi/IP/TradingView)"]
rows = []
for gname in grs:
    xs = [t for t in K39["results"] if t["_g"] == gname]
    c = {r: sum(1 for t in xs if t["result"] == r) for r in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")}
    rows.append([gname, c["PASS"], c["FAIL"], c["BLOCKED"], c["NOT TESTED"], len(xs)])
rows.append(["TỔNG bộ 0.3.9"] + [sum(r[i] for r in rows) for i in range(1, 6)])
b.append(tbl(["Nhóm", "PASS", "FAIL", "BLOCKED", "NOT TESTED", "Tổng"], rows))
rn = RQ_NEW["ket_qua"]
c2 = {r: sum(1 for t in rn if t["ket_qua"] == r) for r in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")}
b.append(f"\nBộ hồi quy 0.3.8 chạy trên 0.3.9 (ket_qua039/hoi_quy_bo_038_tren_039/ket_qua_038.json): {c2}, tổng {len(rn)} ID – chi tiết PHẦN D.")
SEC.append(("PHẦN B – TEST SUMMARY (tổng hợp)", "\n".join(b)))
for gname in grs:
    xs = [t for t in K39["results"] if t["_g"] == gname]
    rr = [[t["test_id"], t["result"], cat(t["method"], 60), cat(t["description"], 260), cat(t["actual"], 420), t["evidence"] if t["evidence"] != "—" else SRC_JSON] for t in xs]
    SEC.append((f"PHẦN B – TEST CHI TIẾT · nhóm {gname} ({len(xs)} test)", tbl(["ID", "KQ", "Phương pháp", "Nội dung", "Thực tế (trích JSON)", "Bằng chứng"], rr) +
                f"\nNguồn đầy đủ (kỳ vọng, đầu vào, giới hạn): {SRC_JSON}"))

# =========================================================================================== C
c = []
for tid in ("I-01", "I-02", "I-03", "I-04", "I-06", "I-07"):
    t = R39[tid]
    c.append(f"[{tid}] {t['result']} · {t['method']}\n  Nội dung: {t['description']}\n  Kỳ vọng: {cat(t['expected'], 300)}\n  Thực tế (nguyên văn JSON): {cat(t['actual'], 1500)}\n  Giới hạn: {t['limitation']}")
mapq = [("Không tạo actionable signal", "I-03 (không ghi trigE/fins/evs; không label), I-06 (trigE/fins/evs trùng 0.3.8 từng nến), M: 'đẩy vào trigE', 'đẩy vào evs' bị bắt"),
        ("Không tác động SIG/EXE/PORT, ledger", "I-02 (khối sổ + f_ledger trùng ký tự), I-03 (không gọi f_ledger/f_x0/f_exec, không ghi LS/LE/LP), I-07 (gián tiếp), I-06 (fins = đầu vào sổ trùng; portSlot/mainEv trùng)"),
        ("Không tác động S1/S2a", "I-02 (khối S1/S2a trùng), I-06 (trigE: SL/TP1-3/RR/hạng/lý do; fins trùng), M: 'đếm passBuy', 'bypass S2a' bị bắt"),
        ("Không tác động SU-1/SU-4", "I-04 (chụp sâu: vùng MD-3, s4 không đổi), I-06 (evs/zones/s4 trùng), M: 'ghi vùng MD-3', 'xóa s4' bị bắt"),
        ("Không tạo actionable alert", "C-04 (alert 0 → 0), I-03 (không gọi alert), M: 'SHADOW phát cảnh báo' bị bắt (I-03, I-04)"),
        ("So sánh baseline vs 0.3.9 cùng dữ liệu", "I-06: 400 kịch bản × 36 nến = 14.400 nến, 0 nến khác; dữ liệu từng nến mẫu ở C.4")]
c.append("\nC.2 BẢNG ÁNH XẠ YÊU CẦU → BẰNG CHỨNG\n" + tbl(["Yêu cầu", "Bằng chứng (ID test trong JSON)"], mapq))
SEC.append(("PHẦN C – SHADOW ISOLATION EVIDENCE (C.1 trích nguyên văn, C.2 ánh xạ)", "\n\n".join(c)))
# C.3: đoạn mã chèn tiếp xúc pipeline (nguyên văn) + C.4 dữ liệu vi sai từng nến
sys.path.insert(0, J("kiem_toan039"))
os.chdir(J("kiem_toan039"))
c4 = ["C.4 DỮ LIỆU SO SÁNH TỪNG NẾN – chạy lại driver I-06 (kiem_toan039/kiem_cach_ly.py::PIPE, mã 0.3.8 và 0.3.9 nguyên văn) cho 3 kịch bản (seed cố định, chọn theo tiêu chí ghi bên dưới).",
      "Lý do chạy lại: I-06 gốc chỉ lưu thống kê (0 khác / 14.400 nến), không lưu từng nến. Không sửa source, không đổi test.",
      "Mỗi dòng: nến j · digest SHA-1 (12 ký tự) của TOÀN BỘ đầu ra actionable [evs, trigE, fins, zones, s4, bar14, cnt14, passBuy/Sell, slotOverflow, mainEv, portSlot, SU-6, ô Data Window actionable] ở 0.3.8 và 0.3.9 · số trigger SU-1/SU-4 · sự kiện SHADOW của nến (0.3.9)."]
try:
    import random
    import kiem_cach_ly as CL
    from khung039 import S38 as KS38, S39 as KS39, zone
    tong_khac = 0

    def chay_seed(seed):
        outs = []
        for src, sd in ((KS38, False), (KS39, True)):
            r2 = random.Random(seed)
            pp = CL.PIPE(src, sd); pp.ctx(r2.choice((1, 2, 3, 4)))
            p = 2000.0
            for _ in range(2):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(2, 8), 1)
                pp.g["zones"].v.append(zone(pp.ip, 60, d, b0 - 2, b0 + 2, bm=pp.T // 60000 - 600, pos=1))
            for _ in range(3):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(1, 6), 1)
                pp.g["zones"].v.append(zone(pp.ip, 15, d, b0 - 1, b0 + 1, bm=pp.T // 60000 + r2.choice((15, 30, 60)), bs=r2.randint(0, 99), pos=1))
            d = r2.choice((1, -1))
            pp.g["s4"].v.append(CL.K.obj(pp.ip, "S4", d=d, sd=-d, e=round(p - d * 6, 1), ln=round(p - d * 5, 1), rk=2, dw=False, eq=False, c1=True, atrC=8.0, tS=1))
            cl = sorted(round(p + r2.uniform(-8, 8), 1) for _ in range(3))
            pp.g.update(cLo=CL.PArr([x - 0.4 for x in cl]), cHi=CL.PArr([x + 0.4 for x in cl]), cRank=CL.PArr([r2.randint(1, 5) for _ in cl]))
            log_ = []
            for j in range(36):
                o = p; cc = round(p + r2.gauss(0, 1.8), 1); h = round(max(o, cc) + abs(r2.gauss(0, 0.7)), 1); l_ = round(min(o, cc) - abs(r2.gauss(0, 0.7)), 1)
                m15 = j % 3 == 0
                bb = dict(o=o, h=h, l=l_, c=cc, m15=m15, ev=r2.choice((0, 0, 1, 2, 3, 4)) if m15 else 0, ref=round(p + r2.uniform(-3, 3), 1),
                          h1=(cc, r2.choice((0, 3, 4)), r2.random() < 0.6) if (m15 and j % 12 == 0) else None, pend=r2.random() < 0.04)
                out = pp.bar(bb)
                shv = [f"SU{e.f['su']}{'B' if e.f['dir'] == 1 else 'S'}:st{e.f['state']}/r{e.f['reason']}" for e in pp.g["evS"].v] if sd else []
                if sd:
                    out["pick"] = [x for x in out["pick"] if x[0][1] not in ("3", "5")]
                log_.append((hashlib.sha1(json.dumps(out, sort_keys=True, default=str).encode()).hexdigest()[:12], sum(1 for t in out["trig"] if t[0][1] == "1"),
                             sum(1 for t in out["trig"] if t[0][1] == "4"), shv))
                p = cc
            outs.append(log_)
        return outs
    tim = {"ĐẠT (trạng thái 17)": None, "SHADOW trigger cùng nến với SU-1/SU-4": None, "SU-3 và SU-5 cùng có sự kiện": None}
    for seed in range(1, 400):
        if all(v is not None for v in tim.values()):
            break
        o2 = chay_seed(seed)
        b9 = o2[1]
        if tim["ĐẠT (trạng thái 17)"] is None and any("st17" in x for r in b9 for x in r[3]):
            tim["ĐẠT (trạng thái 17)"] = (seed, o2)
        elif tim["SHADOW trigger cùng nến với SU-1/SU-4"] is None and any((r[1] or r[2]) and any(re.search(r":st(17|4|8)/r(?!0$)", x) for x in r[3]) for r in b9):
            tim["SHADOW trigger cùng nến với SU-1/SU-4"] = (seed, o2)
        elif tim["SU-3 và SU-5 cùng có sự kiện"] is None and any(x.startswith("SU3") for r in b9 for x in r[3]) and any(x.startswith("SU5") for r in b9 for x in r[3]):
            tim["SU-3 và SU-5 cùng có sự kiện"] = (seed, o2)
    c4.append("Chọn kịch bản: quét seed 1…399 theo thứ tự, lấy seed ĐẦU TIÊN thỏa từng tiêu chí (mỗi seed dùng cho tối đa 1 tiêu chí). Trigger SHADOW = sự kiện có trạng thái 17 (ĐẠT) hoặc 4/8 với lý do ≠ 0 sau S1.")
    for tieu_chi, v in tim.items():
        if v is None:
            c4.append(f"\nKhông tìm thấy kịch bản cho tiêu chí: {tieu_chi}")
            continue
        seed, outs = v
        c4.append(f"\nKịch bản seed {seed} – tiêu chí: {tieu_chi}")
        c4.append(tbl(["j", "digest 0.3.8", "digest 0.3.9", "=", "trig SU-1", "trig SU-4", "SHADOW (0.3.9)"],
                      [[j, a_[0], b_[0], "✓" if a_[0] == b_[0] else "KHÁC", a_[1], a_[2], ",".join(b_[3]) or "–"] for j, (a_, b_) in enumerate(zip(*outs))]))
        k = sum(1 for a_, b_ in zip(*outs) if a_[0] != b_[0]); tong_khac += k
        c4.append(f"→ nến khác: {k}/36")
    c4.append(f"\nTỔNG nến khác trên các kịch bản in ở trên: {tong_khac}")
except Exception as ex:      # noqa: BLE001
    c4.append("KHÔNG CHẠY ĐƯỢC: " + repr(ex))
SEC.append(("PHẦN C.4 – DỮ LIỆU VI SAI 0.3.8 ↔ 0.3.9 TỪNG NẾN (thực tế)", "\n".join(c4)))
st = S39.index("// ---- 0.3.9 SU-3/SU-5 SHADOW trên M5") if False else None
idx_m5 = next(i for i, l in enumerate(L39) if "0.3.9 SU-3/SU-5 SHADOW trên M5" in l)
idx_dw = next(i for i, l in enumerate(L39) if "0.3.9 K.5: sự kiện SHADOW" in l)
c3 = [f"C.3 ĐIỂM TIẾP XÚC PIPELINE (nguyên văn 0.3.9, có số dòng)", "a) Vị trí khối M5 SHADOW: ngay sau lệnh chọn sổ cuối cùng (f_ledger) – actionable đã quyết xong trước khi SHADOW chạy:"]
c3 += [f"{k + 1:5d} | {L39[k]}" for k in range(idx_m5 - 6, idx_m5 + 2)]
c3.append("b) Ô Data Window – lệnh duy nhất SHADOW thêm vào pick (sau khi actionable đã chọn ô và tính 'tràn'):")
c3 += [f"{k + 1:5d} | {L39[k]}" for k in range(idx_dw - 6, idx_dw + 3)]
c3.append("c) S2a (không đổi so với 0.3.8) – chỉ lấy từ trigE; SHADOW không đẩy vào trigE (I-03):")
i2a = next(i for i, l in enumerate(L39) if l.strip() == "// ---- S2a" or "// ---- S2a" in l)
c3 += [f"{k + 1:5d} | {L39[k]}" for k in range(i2a, i2a + 14)]
SEC.append(("PHẦN C.3 – ĐOẠN MÃ TIẾP XÚC PIPELINE (nguyên văn)", "\n".join(c3)))

# =========================================================================================== D
old = {x["id"]: x for x in RQ_OLD["ket_qua"]}; new = {x["id"]: x for x in rn}
rows = []
for k in sorted(set(old) | set(new)):
    a_, b_ = old.get(k, {}).get("ket_qua"), new.get(k, {}).get("ket_qua")
    rows.append([k, cat(new.get(k, old.get(k))["muc_tieu"], 110), a_, b_, "ĐỔI" if a_ != b_ else ""])
d = [f"D.1 TOÀN BỘ ID bộ hồi quy 0.3.8 (kiem_toan035/chay_038.py) – kết quả trên 0.3.8 (ket_qua038/ket_qua_038.json) và trên 0.3.9 (ket_qua039/hoi_quy_bo_038_tren_039/ket_qua_038.json); log: ket_qua039/hoi_quy_bo_038_tren_039/nhat_ky.txt",
     tbl(["ID", "Mục tiêu", "trên 0.3.8", "trên 0.3.9", ""], rows)]
SEC.append(("PHẦN D.1 – REGRESSION: danh sách đã chạy", "\n".join(d)))
d2 = ["D.2 TEST FAIL / BLOCKED / NOT TESTED của bộ hồi quy trên 0.3.9 (thực tế trích nguyên văn)"]
for x in rn:
    if x["ket_qua"] != "PASS":
        d2.append(f"[{x['id']}] {x['ket_qua']} (trên 0.3.8: {old.get(x['id'], {}).get('ket_qua')})\n  Mục tiêu: {cat(x['muc_tieu'], 250)}\n  Thực tế: {cat(x['thuc_te'], 700)}")
r01, r02 = R39["R-01"], R39["R-02"]
d2.append(f"\nD.3 ĐÁNH GIÁ KHÁC BIỆT (R-01, {r01['result']}): {cat(r01['actual'], 1500)}")
d2.append(f"\nD.4 THAY ASSERTION – chỉ 1 thay thế ở vòng 0.3.9 (test cũ GIỮ NGUYÊN, vẫn FAIL):\n  Cũ: R.t_md5_song_song – FAIL trên 0.3.9.\n  Thay thế R-02 ({r02['result']}): {r02['description']}\n  Thực tế: {cat(r02['actual'], 800)}\n  Mã: kiem_toan039/chay_039.py (khối '# R-02'); tiền lệ bộ 0.3.8 bỏ s4 ở kiem_toan035/chay_038.py dòng 441–442 (trích dưới)")
c38 = rd("kiem_toan035", "chay_038.py").split("\n")
d2 += [f"    {k + 1}: {c38[k]}" for k in range(436, 446)]
d2.append("\nD.5 FAIL lịch sử có từ trước 0.3.9 (R.t_data_window, R.A35.A-02/05/09/10): giữ nguyên; bằng chứng thay thế thuộc vòng kiểm toán bổ sung 0.3.8 (ATA_P3_Build_0.3.8_Supplemental_*), không đổi ở 0.3.9.")
d2.append("D.6 LƯU Ý PHẠM VI: các ID GA-01…GA-05 và A-R.* của bộ 0.3.8 so sánh 0.3.7 với mã giai đoạn A (gỡ chẩn đoán) – chúng chạy lại nhưng KHÔNG phụ thuộc mã 0.3.9; V-01 của bộ 0.3.8 khi đổi đích chỉ còn ý nghĩa tái lập SHA. Các ID kiểm hành vi SU-1/SU-4/SU-6/MD-6/MD-7/S1/S2a/Data Window/18 đột biến/hoi_quy034 chạy trên mã 0.3.9.")
d2.append("D.7 CHƯA CHẠY: không có ID nào của bộ 0.3.8 bị bỏ; các ID TV-* là BLOCKED (cần TradingView). Bộ 0.3.8 trên chính 0.3.8 không chạy lại ở vòng này – dùng kết quả lần chạy lại gần nhất (ket_qua038/ket_qua_038.json).")
SEC.append(("PHẦN D.2–D.6 – REGRESSION: thất bại, thay assertion, chưa chạy", "\n".join(d2)))

# =========================================================================================== E
src_chay = rd("kiem_toan039", "chay_039.py")
ns = {}
blk = src_chay[src_chay.index("DOT = ["):src_chay.index("\n]\n", src_chay.index("DOT = [")) + 3]
exec(blk, ns)
dotlog = {}
for l in open(J("ket_qua039", "dot_bien_039.txt"), encoding="utf-8"):
    p_ = [x.strip() for x in l.split("|")]
    if len(p_) >= 3:
        dotlog[p_[1]] = (p_[0], p_[2].replace("test bắt:", "").strip())
MT = {"S3": "SU-3", "S5": "SU-5", "S3S5": "SU-3 + SU-5", "I": "Cách ly"}
rows = []
for dng in ns["DOT"]:
    ten, cu, moi, nh = dng[:4]
    kq, ct_ = dotlog.get(ten, ("?", ""))
    rows.append([ten, MT.get(nh, nh), kq, cat(ct_, 160), "ket_qua039/dot_bien_039.txt"])
e = [tbl(["Mutation", "Mục tiêu", "Kết quả", "Test phát hiện", "Evidence"], rows)]
m01 = R39["M-01"]
e.append(f"\nM-01 ({m01['result']}): {cat(m01['actual'], 900)}")
e.append(f"Tổng {len(rows)} · bị phát hiện {sum(1 for r in rows if r[2] == 'BẮT')} · sống sót (tương đương, có chứng minh) {sum(1 for r in rows if 'TƯƠNG ĐƯƠNG' in r[2])} · sống sót không tương đương {sum(1 for r in rows if r[2] == 'SỐNG SÓT')} · không chạy được {sum(1 for r in rows if 'KHÔNG ÁP' in r[2])}")
db = new.get("R.DB", {})
e.append(f"18 đột biến cũ của bộ 0.3.8 trên 0.3.9 (R.DB): {db.get('ket_qua')} – {cat(db.get('thuc_te', ''), 300)}")
e.append("Lỗ hổng mutation testing (trích từ log, không suy đoán thêm):\n"
         "  1) 'CÁCH LY: SHADOW tăng bộ đếm lỗi 14' chỉ bị bắt bằng kiểm tĩnh I-03 (dòng log: test bắt: ['I-03']) – dữ liệu ngẫu nhiên không sinh lý do 14 cho SHADOW.\n"
         "  2) 'SU-3 bỏ vô hiệu vùng bước 3' bị bắt do test dừng với lỗi chạy (truy cập trường của đối tượng na), không phải assertion kết quả.\n"
         "  3) Đột biến tương đương 'bỏ điều kiện nến mở ≥ t2' – không thể bắt bằng hành vi; chứng minh trong M-01.\n"
         "  4) Đột biến chỉ áp lên mã SHADOW và đường cách ly; không có đột biến mới cho phần actionable ở vòng này (dùng 18 đột biến cũ R.DB).\n"
         "  5) Mẫu đột biến kiểm bằng pine_mini, không phải TradingView.")
SEC.append(("PHẦN E – MUTATION", "\n".join(e)))

# =========================================================================================== F
t1, t2 = R39["T-01"], R39["T-02"]
f = [f"T-01 ({t1['result']}) – phương pháp: {t1['method']}", f"  {t1['description']}", f"  Thực tế (nguyên văn JSON): {cat(t1['actual'], 1200)}", f"  Giới hạn: {t1['limitation']}",
     "  Công thức: ước lượng biên dịch = token từ vựng × (101.360 / 29.909 = 3,3889). Biểu thức đếm: regex trong kiem_toan039/chay_039.py::tok (bỏ chú thích //).",
     "  Điểm đo THẬT duy nhất: 0.3.3 → TradingView báo CE10117 với 101.360 token biên dịch (29.909 từ vựng). Compile THẬT PASS (chủ dự án xác nhận): 0.3.7 (29.368 từ vựng), 0.3.8 (28.369 từ vựng).",
     f"T-02 ({t2['result']}): {t2['actual']}",
     "Token biên dịch thực tế của 0.3.9: KHÔNG CÓ. TradingView compile 0.3.9: KHÔNG CÓ bằng chứng (TV-COMPILE BLOCKED).",
     "Chưa kiểm: compile, runtime M5/M15…Y, tải lại/realtime, giới hạn thời gian chạy vòng lặp SHADOW, bộ nhớ trên TradingView."]
for tid in ("TV-COMPILE", "TV-M5", "TV-RELOAD", "TV-KHUNG", "TV-EXNESS"):
    f.append(f"  [{tid}] {R39[tid]['result']} – {R39[tid]['description']} – {R39[tid]['actual']}")
SEC.append(("PHẦN F – TOKEN VÀ COMPILE (ước lượng ≠ token biên dịch thật)", "\n".join(f)))

# =========================================================================================== G
gg = ["G.1 IP / ĐIỂM MỞ (nguyên văn ket_qua039/IP_CON_MO_039.md):", rd("ket_qua039", "IP_CON_MO_039.md")]
gg.append("\nG.2 BLOCKED / NOT TESTED (từ JSON 0.3.9):")
for t in K39["results"]:
    if t["result"] in ("BLOCKED", "NOT TESTED"):
        gg.append(f"  [{t['test_id']}] {t['result']} – {t['description']} – {cat(t['actual'], 300)}")
gg.append("  Bộ hồi quy trên 0.3.9: " + ", ".join(f"{x['id']}={x['ket_qua']}" for x in rn if x["ket_qua"] in ("BLOCKED", "NOT TESTED")))
rep_md = rd("ket_qua039", "BAO_CAO_ATA_P3_Build_0.3.9.md")
sec17 = rep_md[rep_md.index("## 17."):rep_md.index("## 18.")]
gg.append("\nG.3 RỦI RO (nguyên văn mục 17 báo cáo):\n" + sec17.strip())
gg.append("\nG.4 ASSUMPTION (trích từ phương pháp và giới hạn trong JSON):")
lims = sorted({t["limitation"] for t in K39["results"] if t["limitation"] not in ("—", "")})
gg += [f"  - {l}" for l in lims]
gg.append("  - Driver đặt dữ liệu khung lớn tại nến M5 có thời điểm mở = thời điểm đóng nến khung lớn (giả định R1–R10).")
gg.append("  - Toán tử lịch sử [] của high/low/open/close/time được bổ sung riêng trong kiem_toan039/khung039.py::Ip39 (lấy từ lịch sử nến driver ghi).")
gg.append("\nG.5 HYPOTHESIS: chưa có hypothesis nào được dùng làm căn cứ PASS. Các diễn giải IP-20…IP-30 là cách mã hiện làm, chưa được duyệt.")
gg.append("\nG.6 THAY ĐỔI CHƯA ĐỦ EVIDENCE: (a) toàn bộ 0.3.9 chưa có bằng chứng TradingView; (b) sổ X-0…X-4 chỉ kiểm gián tiếp (I-07); (c) hiệu năng/bộ nhớ SHADOW trên TradingView chưa đo; (d) hàng dashboard SHADOW và LIVE chưa quan sát trên biểu đồ.")
SEC.append(("PHẦN G – OPEN ITEMS", "\n".join(gg)))

# =========================================================================================== H
want = [("Source", [P38, P39]), ("Diff", ["ket_qua039/DIFF_038_039.patch", "src039/DIFF_038_039.patch"]),
        ("Build script", ["tools033/dung_build_039.py"]),
        ("Test scripts", ["kiem_toan039/chay_039.py", "kiem_toan039/kiem_su3_su5.py", "kiem_toan039/kiem_cach_ly.py", "kiem_toan039/khung039.py", "kiem_toan039/hoi_quy_bo_038_tren_039.py", "kiem_toan039/chay_tat_ca_039.sh", "kiem_toan035/chay_038.py", "kiem_toan034a/pine_mini.py", "kiem_toan034a/md5_song_song.py"]),
        ("JSON / CSV", ["ket_qua039/ket_qua_039.json", "ket_qua039/ket_qua_039.csv", "ket_qua039/hoi_quy_bo_038_tren_039/ket_qua_038.json", "ket_qua038/ket_qua_038.json"]),
        ("Test logs", ["ket_qua039/nhat_ky_039.txt", "ket_qua039/stdout_chay_039.txt"]), ("Mutation log", ["ket_qua039/dot_bien_039.txt"]),
        ("Regression log", ["ket_qua039/hoi_quy_bo_038_tren_039/nhat_ky.txt"]), ("Báo cáo", ["ket_qua039/BAO_CAO_ATA_P3_Build_0.3.9.md", "ket_qua039/IP_CON_MO_039.md"]),
        ("Hashes", ["HASH_039.txt", "SHA256SUMS.txt"]), ("Công cụ trước sửa", ["BAN_GIAO_039/cong_cu_truoc_039/chay_test_truoc_039.py", "hoi_quy034/tests/chay_test.py"])]
rows = []
for loai, fs in want:
    for fp in fs:
        rows.append([loai, fp, sha(*fp.split("/"))[:24] + "…", os.path.getsize(J(*fp.split("/"))), "✓" if SUMS.get(fp) == sha(*fp.split("/")) or fp == "SHA256SUMS.txt" else "✗"])
h = [f"Gói: ATA_P3_Build_0.3.9_Full.zip (SHA-256 14c3163ca5157ae99a3d7ea01ced61f0bf029c8853ae907173b2ff4f3ebadb79), thư mục gốc kt/. Tái lập: bash kiem_toan039/chay_tat_ca_039.sh",
     tbl(["Loại", "Đường dẫn trong gói", "SHA-256 (24 ký tự đầu)", "Byte", "Khớp SHA256SUMS"], rows)]
SEC.append(("PHẦN H – EVIDENCE INDEX", "\n".join(h)))

# =========================================================================================== I
def dong(pat, src_lines=L39, start=0):
    return next(i for i in range(start, len(src_lines)) if pat in src_lines[i]) + 1


def ham(name, src_lines=L39):
    i = next(k for k, l in enumerate(src_lines) if l.startswith(name + "(") or l == "type " + name or l.startswith("type " + name + "\n"))
    j = i + 1
    while j < len(src_lines) and (not src_lines[j] or src_lines[j][0] in " \t"):
        j += 1
    while not src_lines[j - 1].strip():
        j -= 1
    return f"{i + 1}–{j}"


N_AL39 = sum(1 for l in L39 if re.search(r"\balert(condition)?\(", re.sub(r"//.*", "", l)))
N_AL38 = sum(1 for l in L38 if re.search(r"\balert(condition)?\(", re.sub(r"//.*", "", l)))
ins_blocks = [(j1 + 1, j2) for op, i1, i2, j1, j2 in ops if op == "insert"]
rows = [
    ["SU-3/SU-5 chung", "type SH, var sh/s5L/shTxt, evS", ham("type SH") if False else f"{dong('type SH')}–{dong('array<Ev> evS = array.new<Ev>()')}", P39],
    ["SU-3/SU-5 chung", "f_zS / f_evS / f_shT / f_shEnd", f"{ham('f_zS')}; {ham('f_evS')}; {ham('f_shT')}; {ham('f_shEnd')}", P39],
    ["SU-3/SU-5 S1", "f_shS1 (S1 SHADOW, lý do 8>15>14>9>1>2>16, trạng thái 17)", ham("f_shS1"), P39],
    ["SU-3 bước 1–2, SU-5 bước 1 + vô hiệu neo/hết hạn", "Khối tiền-kích hoạt M15/H1 (trước MD-4)", f"{ins_blocks[1][0]}–{ins_blocks[1][1]}", P39],
    ["SU-3 bước 3–5, SU-5 bước 2–4, P4, L*/H*, trigger, hết hạn", "Khối M5 SHADOW (sau f_ledger)", f"{ins_blocks[3][0]}–{ins_blocks[3][1]}", P39],
    ["Shadow isolation – Data Window", "Ô Data Window còn trống", f"{ins_blocks[4][0]}–{ins_blocks[4][1]}", P39],
    ["Shadow isolation – dashboard", "Hàng 15 + LIVE", f"{ins_blocks[5][0]}–{ins_blocks[5][1]}", P39],
    ["Signal routing / S1 SU-1", "P1…P5 + S1 SU-1", f"{dong('// ---- P1…P5 cho từng vùng')}–{dong('// ---- 0.3.8 SU-4 (J.3): P4') - 1}", P39],
    ["Signal routing / SU-4", "Khối SU-4 (P4/trigger/S1/P8)", f"{dong('// ---- 0.3.8 SU-4 (J.3): P4')}–{dong('// ---- S2a') - 1}", P39],
    ["S2a", "S2a", f"{dong('// ---- S2a')}–{dong('// ---- P7, P8') - 1}", P39],
    ["Ledger", "P7/P8, X-0…X-4, f_ledger (gọi)", f"{dong('// ---- P7, P8')}–{dong('int chP = f_ledger(LP, fins)')}", P39],
    ["Ledger", "hàm f_ledger / f_exec / f_x0", f"{ham('f_ledger')}; {ham('f_exec')}; {ham('f_x0')}", P39],
    ["Alerts", "alert/alertcondition", f"{N_AL39} lệnh trong 0.3.9, {N_AL38} trong 0.3.8", P39],
    ["Nhãn tín hiệu", "label.new(bar_index, w.dir …)", str(dong("label.new(bar_index, w.dir")), P39],
    ["Quyền I.3", "f_perm / f_permRev", f"{ham('f_perm')}; {ham('f_permRev')}", P39],
    ["Regression driver SU-4/SU-6", "SU4/SU6/may/sto", "kiem_toan035/chay_038.py", "—"],
    ["Driver SHADOW", "Ip39 (toán tử [] mở rộng), may39, SHD", "kiem_toan039/khung039.py", "—"],
    ["Driver vi sai", "PIPE, nhom_vi_sai, nhom_snapshot, nhom_tinh", "kiem_toan039/kiem_cach_ly.py", "—"],
    ["Test SU-3/SU-5", "nhom_su3, nhom_su5, mo_hinh_su5", "kiem_toan039/kiem_su3_su5.py", "—"],
    ["Đột biến", "DOT, chay_nhom", "kiem_toan039/chay_039.py", "—"]]
SEC.append(("PHẦN I – TRÍCH XUẤT SOURCE KHI CẦN AUDIT (dòng tính trên " + P39 + ")", tbl(["Chủ đề", "Hàm / khối", "Dòng (0.3.9) hoặc file", "File"], rows) +
            "\nKhối chèn đầy đủ (dòng 0.3.9): " + ", ".join(f"{a_}–{b_}" for a_, b_ in ins_blocks) + ". Mọi khối khác trùng 0.3.8 (I-02)."))

# thứ tự: C.3 trước C.4
_i3 = next(i for i, x in enumerate(SEC) if x[0].startswith("PHẦN C.3")); _i4 = next(i for i, x in enumerate(SEC) if x[0].startswith("PHẦN C.4"))
if _i3 > _i4:
    SEC[_i4], SEC[_i3] = SEC[_i3], SEC[_i4]
# =========================================================================================== chia phần
LIM = 24000
parts, cur = [], []
for title, body in SEC:
    chunk = f"=== {title} ===\n{body}\n"
    if len(chunk) > LIM:
        if cur:
            parts.append("\n".join(cur)); cur = []
        lines = body.split("\n")
        piece, n = [], 0
        head = ""
        if lines and lines[0].startswith("|"):
            head = ""
        k = 1
        for ln in lines:
            if sum(len(x) + 1 for x in piece) + len(ln) > LIM - 400 and piece:
                # không cắt giữa bảng: lặp lại tiêu đề bảng ở phần sau
                parts.append(f"=== {title} (đoạn {k}) ===\n" + "\n".join(piece) + "\n")
                k += 1
                th = [x for x in piece if x.startswith("|")][:2] if piece[-1].startswith("|") else []
                piece = th[:] if th and ln.startswith("|") else []
            piece.append(ln)
        parts.append(f"=== {title} (đoạn {k}) ===\n" + "\n".join(piece) + "\n")
        continue
    if cur and sum(len(x) for x in cur) + len(chunk) > LIM:
        parts.append("\n".join(cur)); cur = []
    cur.append(chunk)
if cur:
    parts.append("\n".join(cur))
N = len(parts)
for i, p in enumerate(parts, 1):
    hdr = (f"AUDIT CAPSULE 0.3.9 – PART {i}/{N}\n"
           f"Build 0.3.9 SHA-256 {sha(P39)} · baseline 0.3.8 SHA-256 {sha(P38)}\n"
           "Trích xuất tự động bằng kiem_toan039/tao_audit_capsule.py từ ATA_P3_Build_0.3.9_Full.zip – không sửa source, không đổi kết quả test.\n"
           + "-" * 100 + "\n")
    open(os.path.join(OUTD, f"AUDIT_CAPSULE_039_PART_{i:02d}_of_{N:02d}.txt"), "w", encoding="utf-8").write(hdr + p + f"\n--- HẾT PART {i}/{N} ---\n")
print(N, [len(p) for p in parts])
