# SINH TỰ ĐỘNG bởi kiem_toan039/chay_039.py từ kiem_toan035/chay_038.py – CHỈ đổi đích (0.3.8 → 0.3.9) và thư mục kết quả; KHÔNG sửa assertion.
# -*- coding: utf-8 -*-
"""BỘ KIỂM BUILD 0.3.8 – PA-A (gỡ 3 bảng chẩn đoán) + MD-8 đợt 1 (SU-4, SU-6). python3 kiem_toan035/chay_038.py → ket_qua038/ket_qua_038.{json,csv}
Nhãn: TĨNH · THÔNG DỊCH (khối Pine NGUYÊN VĂN chạy trên pine_mini – không phải TradingView) · MÔ HÌNH (Python độc lập viết từ J.3/J.5) · HỒI QUY · ĐỘT BIẾN.
Mã thoát: 1 có FAIL · 2 còn BLOCKED/NOT TESTED · 0 tất cả PASS."""
import csv, difflib, hashlib, json, os, random, re, subprocess, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "kiem_toan035"))
import chay_035 as C            # noqa: E402
import khung as K               # noqa: E402
import kiem_toan_035e as KT     # noqa: E402
import pine_mini as PM          # noqa: E402
from khung import NA, PArr      # noqa: E402

G = K.G
OUT = os.path.join(G, "ket_qua039", "hoi_quy_bo_038_tren_039"); os.makedirs(OUT, exist_ok=True)
F037 = os.path.join(G, "src037", "ATA_P3_Build_0.3.7_Candidate_Indicator.pine")
FA = os.path.join(G, "src038", "giai_doan_A_037_go_chan_doan.pine")
F038 = os.path.join(G, "src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine")   # SINH TỰ ĐỘNG: chạy bộ 0.3.8 trên mã 0.3.9
SHA7 = "f116c3ba850a903061fb5c1a45fec19effcbf4edf1211111b0c9a3c47e261b2e"
S37, SA, S38 = K.doc(F037), K.doc(FA), K.doc(F038)
L37, LA, L38 = S37.split("\n"), SA.split("\n"), S38.split("\n")
HAM = C.HAM + ("f_permRev", "f_permSwp", "f_ev4", "f_min")
TYLE = 101360 / 29909


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def tok(s):
    return len(re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\S', "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n"))))


def dif(a, b):
    return [l for l in difflib.unified_diff(a, b, lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]


def ghi(*a):
    C.ghi(*a)


def dat_ma38(src):
    """Như KT.dat_ma nhưng khối S1 của SU-1 kết thúc trước khối SU-4 (0.3.8 chèn SU-4 giữa S1 và S2a)."""
    KT.dat_ma(src)
    if "// ---- 0.3.8 SU-4 (J.3): P4" in src:
        C.S1_35 = K.doan(src, "int nt = array.size(trigE)", "// ---- 0.3.8 SU-4 (J.3): P4", 4)


class Ip(K.Ip):
    def call_builtin(self, name, args, kw):
        if name == "str.format_time":
            return "T%s" % args[0]
        return super().call_builtin(name, args, kw)


def may(src):
    ip = Ip()
    ip.g.update(K.hang_so(src))
    ip.g.update(tick=0.01, TICK_TOL=ip.g.get("TICK_TOL", 1e-6))
    for t in ("StructOut", "StructX", "Zone", "Ev", "S4", "ERec"):
        if re.search(r"^type " + t + r"\b", src, re.M):
            Lb, b = K.khoi(src, t); ip.load(PM.parse_program(Lb, b))
    for f in HAM:
        if re.search(r"^" + f + r"\(", src, re.M):
            Lb, b = K.khoi(src, f); ip.load(PM.parse_program(Lb, b))
    return ip


def khoi_chay(ip, src, dau, cuoi):
    lines, base = K.doan(src, dau, cuoi, 4)
    return ip.load(PM.parse_program(lines, base))


def sto(ip, hs=(), ls=(), **f):
    d = dict(atr=f.pop("atr", 5.0), shN=len(hs), slN=len(ls), shInc=False, slInc=False, st=0, reg=0, vr=1.0, cls=NA)
    for i in range(10):
        d[f"sh{i}"] = hs[i] if i < len(hs) else NA
        d[f"sl{i}"] = ls[i] if i < len(ls) else NA
    d.update(f)
    return K.obj(ip, "StructOut", **d)


# ======================================================================= SU-4 driver (khối nguyên văn)
class SU4:
    def __init__(self, src=S38):
        self.src = src
        self.ip = ip = may(src)
        self.arm = khoi_chay(ip, src, "// ---- 0.3.8 MD-8 (B.2.2 bước 5)", "// ---- 0.3.8 SU-6")
        self.blk = khoi_chay(ip, src, "// ---- 0.3.8 SU-4 (J.3): P4", "// ---- S2a")
        self.s2a = khoi_chay(ip, src, "// ---- S2a", "// ---- P7, P8")
        self.g = ip.g
        self.g.update(iVoidK=0.1, iSlBufK=0.2, iSlMaxK=2.0, iRRMin=1.5, iInject=False, md4OK=True, md5OK=True, okM15=True, okH1=True, okH4=True, okD=False,
                      pendM15=False, pendH1=False, pendH4=False, atrM5=1.0, isXAU=False, time=0, zones=PArr([]), cLo=PArr([]), cHi=PArr([]), cRank=PArr([]),
                      plB=PArr([]), prB=PArr([]), plS=PArr([]), prS=PArr([]), s4=PArr([]), bar_index=0, newM15=False, dueH1=False, h1o=NA, h1t=NA, h1oP=NA, h1tP=NA)
        self.set_ctx()

    def set_ctx(self, reg=1, vr=1.0, m15h=(2010.0, 2020.0), m15l=(1980.0, 1970.0), atr15=5.0, m15cls=1995.0, stD=0, sh0=NA, sl0=NA, inc=False):
        ip = self.ip
        self.g.update(sM15=sto(ip, m15h, m15l, atr=atr15, cls=m15cls), sH1=sto(ip, (), ()), sH4=sto(ip, m15h, m15l, reg=reg, vr=vr, sh0=sh0, sl0=sl0, shInc=inc),
                      sD=sto(ip, (), (), st=stD))

    def them(self, d=1, e=1990.0, ln=1991.0, rk=2, dw=False, eq=False, c1=True, atrC=2.0, tS=60000 * 100):
        x = K.obj(self.ip, "S4", d=d, sd=-d, e=e, ln=ln, rk=rk, dw=dw, eq=eq, c1=c1, atrC=atrC, tS=tS)
        self.g["s4"].v.append(x)
        return x

    def bar(self, o, h, l, c, s2a=False, trig=None, **kw):
        g = self.g
        g.update(open=o, high=h, low=l, close=c, evs=PArr([]), trigE=PArr(list(trig or [])), passBuy=kw.pop("passBuy", 0), passSell=kw.pop("passSell", 0), bar14=0)
        g.update(kw)
        self.ip.bar(self.arm)
        self.ip.bar(self.blk)
        if s2a:
            self.ip.bar(self.s2a)
        g["bar_index"] += 1
        return g["evs"].v, g["trigE"].v


def mo_hinh_su4(bars, a, d, e, hs, atr5=1.0, vk=0.1, kexp=23):
    """Mô hình J.3 (độc lập): trả (kết cục, chỉ số nến). bars: list (o,h,l,c,newM15,m15cls,pend)."""
    k = 0
    for j, (o, h, l, c, nm, mc, pend) in enumerate(bars):
        if (nm and j > a and d * (mc - e) < 0) or d * (c - e) < -vk * atr5:
            return ("VOID", j)
        if j > a and not pend and d * (c - hs) > 0 and d * (c - o) > 0:
            return ("TRIG", j)
        if k >= kexp:
            return ("EXP", j)
        k += 1
    return ("MỞ", None)


# ======================================================================= SU-6 driver
class SU6:
    def __init__(self, src=S38):
        self.ip = ip = may(src)
        self.blk = khoi_chay(ip, src, "// ---- 0.3.8 SU-6 (J.5): H1 Close", "// ---- P0 (khung nguồn")      # khối đánh giá (không gồm phần lưu giá mở)
        self.g = ip.g

    def chay(self, reg, cls, clsP, o, atr, cl, khop=True, md4=True, okH4=True, newH1=True):
        ip = self.ip
        self.g.update(newH1=newH1, md4OK=md4, okH4=okH4, xH1=K.obj(ip, "StructX", tOpS=1000, clsP=clsP), h1tP=1000 if khop else 999, h1oP=o,
                      sH4=sto(ip, reg=reg), sH1=sto(ip, cls=cls, atr=atr), cLo=PArr([x[0] for x in cl]), cHi=PArr([x[1] for x in cl]), cRank=PArr([x[2] for x in cl]),
                      su6Txt="–", time=5)
        ip.bar(self.blk)
        return self.g["su6Txt"]


def main():
    t0 = time.time()
    # ================================================================ phiên bản
    h7, hA, h8 = sha(F037), sha(FA), sha(F038)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_038.py")], cwd=G, capture_output=True, text=True)
    ghi("V-01", "E · phiên bản", "0.3.7 đầu vào đúng SHA, không ghi đè; giai đoạn A và 0.3.8 tái lập từ script", "TĨNH", "0.3.7 = f116c3ba…; dựng lại cùng SHA",
        f"0.3.7 {h7}; A {hA} → {sha(FA)}; 0.3.8 {h8} → {sha(F038)}", "PASS" if h7 == SHA7 and sha(FA) == hA and sha(F038) == h8 and r.returncode == 0 else "FAIL", "tools033/dung_build_038.py")
    # ================================================================ GIAI ĐOẠN A – gỡ chẩn đoán
    dA = dif(L37, LA)
    them = [l for l in dA if l.startswith("+") and l.strip() != "+"]
    bot = [l for l in dA if l.startswith("-")]
    ok = len(them) == 1 and "0.3.8 PA-A" in them[0] and len(bot) == 133
    ghi("GA-01", "A · gỡ chẩn đoán", "Giai đoạn A chỉ XÓA dòng (3 input, f_evTxt, f_px, f_lbl + khối nhãn, bảng MD-4/MD-5, bảng MTF) và sửa 1 dòng chú thích; không thêm/sửa dòng mã nào khác",
        "TĨNH (difflib 0.3.7 → A)", "1 dòng + (chú thích), chỉ dòng −", f"+{len(them)} / −{len(bot)}; dòng +: {[l[:80] for l in them]}", "PASS" if ok else "FAIL", "src038/DIFF_037_giaidoanA.patch")
    go = "\n".join(l[1:] for l in bot)
    ten_go = ["f_evTxt", "f_px", "f_lbl", "f_c45", "f_drow", "t45", "td", "iDiag45", "iDiag", "iLblTF"]
    con = {n: len(re.findall(r"(?<![\w.])" + n + r"\b", "\n".join(re.sub(r"\s*//.*$", "", l) for l in LA))) for n in ten_go}
    ghi("GA-02", "A · gỡ chẩn đoán", "Không còn tham chiếu treo: mọi định danh chỉ thuộc khối đã gỡ có 0 lần dùng trong mã còn lại", "TĨNH", "0 tham chiếu", con,
        "PASS" if not any(con.values()) else "FAIL", "—")
    # khối gỡ không ghi vào trạng thái ngoài: phép gán / thao tác thay đổi chỉ trên biến cục bộ hoặc đối tượng hiển thị của chính nó
    go_ma = "\n".join(re.sub(r"\s*//.*$", "", l) for l in go.split("\n"))
    gan = set(re.findall(r"(?<![\w.])([A-Za-z_]\w*)\s*(?::=|\+=|-=)", go_ma))
    cuc_bo = set(re.findall(r"(?:^|\n)\s*(?:var\s+)?(?:string|float|int|bool|table|label|color)\s+([A-Za-z_]\w*)\s*=", go_ma)) | {"t"}
    mang_cb = set(re.findall(r"array<\w+>\s+([A-Za-z_]\w*)\s*=\s*array\.new", go_ma))       # mảng khai báo cục bộ trong khối gỡ
    dot = [(f, t) for f, t in re.findall(r"\b(array\.(?:push|set|remove|clear|insert|unshift|shift|pop)|map\.(?:put|remove|clear))\s*\(\s*(\w+)", go_ma) if t not in mang_cb]
    dot += re.findall(r"\b(alert|alertcondition|plot\w*|strategy\.\w+)\s*\(", go_ma)
    ve = sorted(set(re.findall(r"\b(table\.\w+|label\.\w+|box\.\w+|line\.\w+)\(", go_ma)))
    ngoai = gan - cuc_bo
    ghi("GA-03", "A · gỡ chẩn đoán", "Khối đã gỡ không tham gia logic: không gán biến ngoài phạm vi của nó, không thay đổi mảng/map ngoài (chỉ mảng cục bộ của chính khối), không alert/plot/strategy; chỉ gọi hàm vẽ bảng/nhãn",
        "TĨNH (quét phép gán và lệnh gọi)", "0 biến ngoài; 0 thao tác thay đổi; chỉ table/label", f"gán ngoài {sorted(ngoai)}; thao tác trên dữ liệu ngoài {dot}; mảng cục bộ {sorted(mang_cb)}; vẽ {ve}",
        "PASS" if not ngoai and not dot and all(v.split(".")[0] in ("table", "label") for v in ve) else "FAIL", "—")
    cnt = lambda s, p: len(re.findall(p, "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n"))))  # noqa: E731
    sl = {k: (cnt(S37, p), cnt(SA, p)) for k, p in (("input", r"\binput\.\w+\("), ("plot", r"\bplot\("), ("request.security", r"\brequest\.security\("), ("alert", r"\balert(?:condition)?\("))}
    ghi("GA-04", "A · gỡ chẩn đoán", "Sau giai đoạn A: input 64 → 61 (đúng 3 input chẩn đoán), plot Data Window giữ 56, request.security giữ 8, alert 0", "TĨNH", "61/56/8/0", sl,
        "PASS" if sl["input"] == (64, 61) and sl["plot"][0] == sl["plot"][1] == 56 and sl["request.security"] == (8, 8) and sl["alert"] == (0, 0) else "FAIL", "—")
    for t in ("t_perm", "t_grade", "t_s1_hoi_quy", "t_s1_muc_tieu", "t_data_window", "t_md5_song_song", "t_a07_pine", "t_reg_vi_sai"):
        def cmp(t=t):
            KT.dat_ma(S37); k7 = getattr(C, t)()
            KT.dat_ma(SA); kA = getattr(C, t)()
            return k7[0] == kA[0] and str(k7[1]) == str(kA[1]), f"0.3.7: {k7[0]} · A: {kA[0]} · chi tiết trùng: {str(k7[1]) == str(kA[1])}"
        C.an_toan("A-R." + t, "A · gỡ chẩn đoán (hồi quy)", "Chạy " + t + " trên 0.3.7 và mã giai đoạn A – kết quả và chi tiết trùng nhau", "THÔNG DỊCH (vi sai)", "trùng 0.3.7", "chay_035.py::" + t, cmp)
    t7, tA, t8 = tok(S37), tok(SA), tok(S38)
    ghi("GA-05", "A · token", "Token sau gỡ chẩn đoán (hiệu chỉnh theo điểm thật 0.3.3 = 101.360)", "TĨNH (ƯỚC LƯỢNG)", "giảm ≈ 2.237 từ vựng",
        f"từ vựng 0.3.7 {t7} → A {tA} ({tA - t7}); ước lượng biên dịch {round(t7 * TYLE)} → {round(tA * TYLE)}", "PASS" if t7 - tA >= 2200 else "FAIL", "ket_qua038/cong_token_md8.json")
    # ================================================================ SU-1 không đổi
    def kh(src, ten):
        return "\n".join(K.khoi(src, ten)[0])
    ham = ["f_struct", "f_regNext", "f_regBase", "f_vol", "f_perm", "f_permRev", "f_permSwp", "f_grade", "f_d8", "f_ledger", "f_lvPick", "f_listPick", "f_zonePick", "f_better",
           "f_lowestSince", "f_highestSince", "f_tfReq", "f_avail", "f_p0", "f_addZone", "f_newEv", "f_x0"]
    doi = [h for h in ham if kh(S37, h) != kh(S38, h)]
    blk = lambda s, a, b: "\n".join(K.doan(s, a, b)[0])  # noqa: E731
    p15_7, p15_8 = blk(S37, "// ---- P1…P5 cho từng vùng", "// ---- S1 cho từng setup"), blk(S38, "// ---- P1…P5 cho từng vùng", "// ---- S1 cho từng setup")
    s1_7, s1_8 = blk(S37, "// ---- S1 cho từng setup", "// ---- S2a"), blk(S38, "// ---- S1 cho từng setup", "// ---- 0.3.8 SU-4 (J.3): P4")
    p78_7, p78_8 = blk(S37, "// ---- P7, P8", "// ---- Phần riêng từng sổ"), blk(S38, "// ---- P7, P8", "// ---- Phần riêng từng sổ")
    rs7 = [l for l in L37 if "request.security(" in l]; rs8 = [l for l in L38 if "request.security(" in l]
    ok = not doi and p15_7 == p15_8 and s1_7 == s1_8 and p78_7 == p78_8 and rs7 == rs8
    ghi("S1-01", "B · SU-1 không đổi", "SU-1 (P1…P5, S1, P7/P8), MD-2…MD-7, S2b (f_d8, f_ledger), TP, MD-3 (f_p0, f_addZone), request.security: trùng 0.3.7 từng ký tự", "TĨNH", "0 khác",
        f"hàm khác {doi}; P1…P5 {p15_7 == p15_8}; S1 {s1_7 == s1_8}; P7/P8 {p78_7 == p78_8}; request {rs7 == rs8}", "PASS" if ok else "FAIL", "—")
    # S2a: dòng duy nhất đổi 'if nt > 0' → 'if array.size(trigE) > 0'; khi không có SU-4, cỡ trigE = nt (SU-1 S1 không thêm/bớt trigE) → tương đương
    s2_7, s2_8 = blk(S37, "// ---- S2a", "// ---- P7, P8"), blk(S38, "// ---- S2a", "// ---- P7, P8")
    dd = dif(s2_7.split("\n"), s2_8.split("\n"))
    s1_ghi = re.findall(r"array\.(?:push|remove|insert|set|clear)\(trigE", s1_8)
    # chạy S2a 0.3.7 và 0.3.8 trên 300 bộ trigE ngẫu nhiên (chỉ SU-1)
    R = random.Random(8)
    i7, i8 = may(S37), may(S38)
    b7, b8 = khoi_chay(i7, S37, "// ---- S2a", "// ---- P7, P8"), khoi_chay(i8, S38, "// ---- S2a", "// ---- P7, P8")
    sai = 0
    for _ in range(300):
        spec = [(R.choice((1, -1)), R.random() < 0.6) for _ in range(R.randint(0, 4))]
        out = []
        for ip, bb in ((i7, b7), (i8, b8)):
            es = [K.obj(ip, "Ev", dir=d_, su=1) for d_, _ in spec]
            for e_, (_, p_) in zip(es, spec):
                e_.f["pass"] = p_
            ip.g.update(trigE=PArr(es), evs=PArr([]), passBuy=sum(1 for d_, p_ in spec if p_ and d_ == 1), passSell=sum(1 for d_, p_ in spec if p_ and d_ == -1), nt=len(es))
            ip.bar(bb)
            out.append([(e_.f.get("state"), e_.f.get("reason"), e_.f.get("fin")) for e_ in es] + [len(ip.g["fins"].v), len(ip.g["evs"].v)])
        sai += out[0] != out[1]
    ok = len(dd) == 2 and "array.size(trigE) > 0" in dd[1] and not s1_ghi and sai == 0
    ghi("S1-02", "B · SU-1 không đổi", "S2a: chỉ đổi điều kiện 'nt > 0' → 'array.size(trigE) > 0'; S1 SU-1 không thêm/bớt trigE nên khi không có SU-4 hai điều kiện trùng; S2a 0.3.7 và 0.3.8 cho kết quả trùng trên 300 bộ",
        "TĨNH + THÔNG DỊCH (vi sai)", "1 dòng; 0 khác", f"dòng khác {dd}; S1 ghi trigE {s1_ghi}; khác {sai}/300", "PASS" if ok else "FAIL", "—")
    dat_ma38(S38)
    C.an_toan("S1-03", "B · SU-1 không đổi", "Hồi quy S1 SU-1 (812 setup) trùng 0.3.4a; 29 kịch bản S1", "THÔNG DỊCH (vi sai)", "0 khác", "chay_035.py::t_s1_hoi_quy",
              lambda: (C.t_s1_hoi_quy()[0] and C.t_s1_muc_tieu()[0], "t_s1_hoi_quy + t_s1_muc_tieu"))
    lb = [l for l in dif(L37, L38) if "label.new(bar_index, w.dir" in l]
    ghi("S1-04", "B · SU-1 không đổi", "Nhãn tín hiệu: chuỗi 'SU-1 ' thay bằng 'SU-' + loại setup → với SU-1 văn bản nhãn trùng hệt", "TĨNH", "chỉ đổi tiền tố", [l[:120] for l in lb],
        "PASS" if len(lb) == 2 and '"SU-" + str.tostring(w.su) + " "' in lb[1] else "FAIL", "—")
    # ================================================================ SU-4
    def kb(**kw):
        s = SU4(); s.set_ctx(**{k: v for k, v in kw.items() if k in ("reg", "vr", "m15h", "m15l", "atr15", "m15cls", "stD", "sh0", "sl0", "inc")})
        return s
    # SU4-01 ARMED tại a, H* = High[a], sự kiện WAIT; không trigger tại a
    s = kb(); x = s.them()
    ev, tr = s.bar(1994, 1996, 1993, 1995.5, newM15=True, m15cls=1995)
    st1 = (x.f["a"], x.f["hs"], [(e.f["su"], e.f["state"]) for e in ev], len(tr))
    ok = st1 == (0, 1996, [(4, s.g["SS_WAIT"])], 0)
    ghi("SU4-01", "C · SU-4", "ARMED tại a = nến xử lý XÁC NHẬN (nến M5 đầu tiên nhận M15 của c); H*_SU4 = High[a]; sự kiện CHỜ XÁC NHẬN su = 4; không trigger trên nến a", "THÔNG DỊCH",
        "(a 0, H* 1996, [(4, WAIT)], 0 trigger)", st1, "PASS" if ok else "FAIL", "J.3 bước 3–4")
    # SU4-02 trigger t ≥ a+1: close > H* và nến tăng → PASS với SL theo E
    s = kb(); x = s.them(); s.bar(1994, 1996, 1993, 1995.5)
    ev, tr = s.bar(1995, 1998, 1994.8, 1997)
    e = tr[0] if tr else None
    tt = None if e is None else dict(su=e.f["su"], trig=e.f["trig"], sl=round(e.f["sl"], 4), tp1=e.f["tp1"], rr=round(e.f["rr"], 3), pas=e.f["pass"], reason=e.f["reason"])
    ok = tt == dict(su=4, trig=True, sl=1989.6, tp1=2010.0, rr=round(13 / 7.4, 3), pas=True, reason=0) and not s.g["s4"].v
    ghi("SU4-02", "C · SU-4", "Trigger tại a+1 khi Close > H*_SU4 và nến tăng; S1: SL = E − 0,2×ATR_M15(c) = 1990 − 0,4; TP1 gần nhất; R:R; thể hiện kết thúc (một lần trigger)", "THÔNG DỊCH",
        "sl 1989,6 · tp1 2010 · rr 1,757 · pass", tt, "PASS" if ok else "FAIL", "J.3 bước 4, SL")
    # SU4-03 không trigger: nến giảm; Close = H*; Close ≤ H*
    res = []
    for o, c in ((1997.5, 1997.0), (1995.0, 1996.0), (1995.0, 1995.9)):
        s = kb(); s.them(); s.bar(1994, 1996, 1993, 1995.5)
        _, tr = s.bar(o, 1998, 1994.8, c)
        res.append(len(tr))
    ghi("SU4-03", "C · SU-4", "Không trigger khi nến giảm, khi Close = H*_SU4, khi Close < H*_SU4", "THÔNG DỊCH", "[0, 0, 0]", res, "PASS" if res == [0, 0, 0] else "FAIL", "J.3 bước 4")
    # SU4-04 SELL đối xứng
    s = kb(m15h=(2020.0, 2030.0), m15l=(1980.0, 1970.0), reg=2); x = s.them(d=-1, e=2005.0, ln=2004.0)
    s.bar(2001, 2002, 1999, 2000)       # a: L* = 1999
    _, tr = s.bar(2000, 2000.5, 1997, 1998)
    e = tr[0] if tr else None
    tt = None if e is None else (round(e.f["sl"], 4), e.f["tp1"], e.f["pass"], e.f["dir"])
    ghi("SU4-04", "C · SU-4", "SELL đối xứng: L*_SU4 = Low[a]; trigger Close < L* và nến giảm; SL = E + 0,2×ATR_M15", "THÔNG DỊCH", "(2005,4, 1980, True, −1)", tt,
        "PASS" if tt == (2005.4, 1980.0, True, -1) else "FAIL", "J.3")
    # SU4-05 vô hiệu M15 (Close M15 < E, nến sau a) / không vô hiệu bằng M15 tại chính nến a
    s = kb(); x = s.them()
    ev0, _ = s.bar(1994, 1996, 1993, 1995.5, newM15=True, m15cls=1989.0)
    sau_a = [e.f["state"] for e in ev0]
    ev1, _ = s.bar(1994, 1995, 1993, 1994, newM15=True, sM15=sto(s.ip, (2010.0,), (), atr=5.0, cls=1989.0))
    tt = (sau_a, [(e.f["state"], e.f["reason"]) for e in ev1], len(s.g["s4"].v))
    ok = tt == ([s.g["SS_WAIT"]], [(s.g["SS_VOID"], 5)], 0)
    ghi("SU4-05", "C · SU-4", "Vô hiệu khi Close M15 < E ở nến M15 sau a (lý do 5); Close M15 của chính nến c tại a không vô hiệu", "THÔNG DỊCH", "(WAIT tại a; VOID 5 sau; gỡ)", tt,
        "PASS" if ok else "FAIL", "J.3 vô hiệu")
    # SU4-06 vô hiệu M5: Close < E − 0,1×ATR_M5; đúng biên không vô hiệu
    res = []
    for c in (1989.89, 1989.9):
        s = kb(); s.them()
        ev, _ = s.bar(1990.5, 1991, 1989.5, c)
        res.append([(e.f["state"], e.f["reason"]) for e in ev])
    ok = res[0][-1] == (s.g["SS_VOID"], 5) and all(st != s.g["SS_VOID"] for st, _ in res[1])
    ghi("SU4-06", "C · SU-4", "Vô hiệu M5: Close < E − 0,1×ATR_M5 (1989,89 < 1989,9) → VOID; đúng biên 1989,9 → không", "THÔNG DỊCH", "VOID / không", res, "PASS" if ok else "FAIL", "J.3")
    # SU4-07 hết hạn 24 nến M5 kể từ a (cùng quy ước bộ đếm với P8 của SU-1)
    s = kb(); s.them()
    het = None
    for j in range(30):
        ev, _ = s.bar(1994, 1995, 1993.5, 1994.2)
        if any(e.f["state"] == s.g["SS_EXPIRED"] for e in ev):
            het = j; break
    p8 = "if z.sK >= K_EXPIRE" in S38 and "z.sK := z.sK + 1" in S38
    ghi("SU4-07", "C · SU-4", "Hết hạn: nến thứ 24 kể từ a (chỉ số a + 23, K_EXPIRE = 23 như P8 của SU-1), lý do 7", "THÔNG DỊCH", "a + 23", f"hết hạn tại a + {het}; P8 SU-1 cùng quy ước {p8}",
        "PASS" if het == 23 and p8 else "FAIL", "J.3, P8")
    # SU4-08 mô hình độc lập trên 400 đường giá ngẫu nhiên (kết cục và thời điểm)
    R = random.Random(4)
    sai = []
    for n in range(400):
        d_ = R.choice((1, -1))
        e0 = 1990.0 if d_ == 1 else 2010.0
        s = kb(reg=1 if d_ == 1 else 2, m15h=(2040.0,), m15l=(1960.0,), atr15=20.0)
        x = s.them(d=d_, e=e0, ln=e0, atrC=2.0)
        p = 2000.0
        bars = []
        for j in range(30):
            o = p; c = round(p + R.gauss(0, 2.2), 1); h = max(o, c) + round(abs(R.gauss(0, 0.6)), 1); lw = min(o, c) - round(abs(R.gauss(0, 0.6)), 1)
            nm = j % 3 == 0; mc = round(p + R.gauss(0, 3), 1); pend = R.random() < 0.05
            bars.append((o, h, lw, c, nm, mc, pend)); p = c
        kq = ("MỞ", None)
        hs = None
        for j, (o, h, lw, c, nm, mc, pend) in enumerate(bars):
            ev, tr = s.bar(o, h, lw, c, newM15=nm, sM15=sto(s.ip, (2040.0,), (1960.0,), atr=20.0, cls=mc), pendH4=pend)
            if j == 0:
                hs = x.f["hs"]
            if tr:
                kq = ("TRIG", j); break
            st = [e.f["state"] for e in ev]
            if s.g["SS_VOID"] in st:
                kq = ("VOID", j); break
            if s.g["SS_EXPIRED"] in st:
                kq = ("EXP", j); break
        mh = mo_hinh_su4(bars, 0, d_, e0, hs)
        if kq != mh:
            sai.append((n, kq, mh))
    ghi("SU4-08", "C · SU-4", "400 đường giá ngẫu nhiên BUY/SELL: kết cục (VOID/TRIG/EXP) và nến xảy ra trùng mô hình J.3 viết độc lập (gồm M15 đóng, dữ liệu khung lớn chờ)",
        "THÔNG DỊCH + MÔ HÌNH", "0 sai", f"sai {len(sai)} {sai[:3]}", "PASS" if not sai else "FAIL", "J.3")
    # SU4-09 quyền chỉ tại trigger (I.3/H-20): regime đổi giữa a và t
    def s1_reg(reg, dw=False, rk=2, vr=1.0, okH4=True, pend=False):
        s = kb(reg=1); s.them(dw=dw, rk=rk); s.bar(1994, 1996, 1993, 1995.5)
        s.set_ctx(reg=reg, vr=vr, sh0=2020.0, sl0=1985.0)      # range H4 1985–2020: L_NEO 1991 nằm trong 25 % biên dưới (quy tắc tạm sẽ cấp quyền)
        _, tr = s.bar(1995, 1998, 1994.8, 1997, okH4=okH4, pendH4=pend)
        return (tr[0].f["reason"], tr[0].f["pass"]) if tr else ("không trigger",)
    ca = [("REG UP tại a, DOWN tại t, DW sai → 15", s1_reg(2), (15, False)), ("DOWN tại t, DW đúng → có quyền", s1_reg(2, dw=True), (0, True)),
          ("TRANSITION tại t → có quyền (không thêm)", s1_reg(4), (0, True)), ("HẠNG_NEO 1 → 15", s1_reg(1, rk=1), (15, False)),
          ("VOL-CỰC (VR 2,6) → 15 theo I.3 – IP-4 chờ", s1_reg(1, vr=2.6), (15, False)), ("REG chưa đủ dữ liệu → 8", s1_reg(0), (8, False)),
          ("H4 không khả dụng → 8", s1_reg(1, okH4=False), (8, False)), ("H4 đang chờ → không trigger (chờ, như SU-1)", s1_reg(1, pend=True), ("không trigger",))]
    sai = [(n, g_, k_) for n, g_, k_ in ca if g_ != k_]
    ghi("SU4-09", "C · SU-4", "Quyền SWEEP kiểm DUY NHẤT ở S1 bước 0 tại nến trigger, với REG/VOL tại t (regime ở a không dùng); lý do 8/15 đúng", "THÔNG DỊCH", "đúng 8/8 ca",
        f"{[(n, g_) for n, g_, _ in ca]}; sai {sai}", "PASS" if not sai else "FAIL", "I.3, H-20")
    # SU4-10 RANGE: nhánh phụ thuộc IP-11…IP-14 bị cô lập → không cấp quyền
    rg = s1_reg(3)
    ghi("SU4-10", "C · SU-4", "REGIME RANGE: nhánh 25 % biên phụ thuộc IP-11…IP-14 (chưa duyệt) bị cô lập – không cấp quyền (lý do 15), không dùng quy tắc tạm", "THÔNG DỊCH",
        "(15, False)", rg, "PASS" if rg == (15, False) else "FAIL", "Chỉ thị MD-8 mục 7")
    ghi("SU4-10b", "C · SU-4", "Quyền SU-4 trong RANGE theo quy tắc 25 % đã duyệt", "—", "—", "BLOCKED: chờ chủ dự án quyết IP-11…IP-14", "BLOCKED", "—")
    # SU4-11 lý do S1: 9 (không TP1), 1 (SL rộng), 2 (R:R), 14 (tiêm lỗi)
    def s1_case(**kw):
        s = kb(**{k: v for k, v in kw.items() if k in ("m15h", "atr15")}); s.them(atrC=kw.get("atrC", 2.0)); s.bar(1994, 1996, 1993, 1995.5)
        _, tr = s.bar(1995, 1998, 1994.8, 1997, iInject=kw.get("inj", False), sH4=sto(s.ip, (), (), reg=1, vr=1.0) if kw.get("noTP") else s.g["sH4"])
        return tr[0].f["reason"]
    res = (s1_case(m15h=(), noTP=True), s1_case(atr15=3.0), s1_case(m15h=(2005.0,)), s1_case(inj=True))
    ghi("SU4-11", "C · SU-4", "S1 SU-4: không TP1 → 9; SL rộng > 2×ATR_M15 → 1; R:R < 1,5 → 2; SL sai phía (tiêm lỗi) → 14", "THÔNG DỊCH", "(9, 1, 2, 14)", res, "PASS" if res == (9, 1, 2, 14) else "FAIL", "J.0")
    # SU4-12 hạng I.5
    def hang(reg=1, c1=True, eq=False, rk=2, stD=1, xau=True, tm=7 * 3600000, cl=()):
        s = kb(reg=reg, stD=stD); s.g.update(isXAU=xau, okD=True, time=tm)
        if cl:
            s.g.update(cLo=PArr([cl[0]]), cHi=PArr([cl[0] + 0.4]), cRank=PArr([cl[1]]))
        s.them(c1=c1, eq=eq, rk=rk, dw=True); s.bar(1994, 1996, 1993, 1995.5)
        _, tr = s.bar(1995, 1998, 1994.8, 1997)
        return tr[0].f["grade"] if tr and tr[0].f["pass"] else None
    ca = [("REG theo d, C-1, C-2 (HẠNG 3), X-D + X-S → A", hang(rk=3), True), ("C-2 bằng EQ_NEO → A", hang(eq=True), True), ("Thiếu C-2 → B", hang(), False),
          ("Thiếu C-1 → B", hang(c1=False, rk=3), False), ("REG ngược d (có DW) → B tối đa", hang(reg=2, rk=3), False), ("TRANSITION → B tối đa", hang(reg=4, rk=3), False),
          ("BTC: X-S không áp dụng, chỉ X-D → B", hang(rk=3, xau=False), False), ("BTC: X-D + X-T (TP1 là cụm hạng 3 ở 2009, R:R 1,62) → A", hang(rk=3, xau=False, cl=(2009.0, 3)), True)]
    sai = [(n, g_, k_) for n, g_, k_ in ca if g_ != k_]
    ghi("SU4-12", "C · SU-4", "Hạng I.5 cho SU-4: A chỉ khi REG theo d, C-1 (CHoCH + thân), C-2 (EQ_NEO hoặc HẠNG_NEO ≥ 3), ≥ 2 trong X-D/X-S (chỉ XAU)/X-T", "THÔNG DỊCH", "đúng 8/8",
        f"sai {sai}", "PASS" if not sai else "FAIL", "I.5, J.3")
    # SU4-13 thuộc tính NEO chép nguyên từ EV khóa tại s (dòng tạo trong MD-5 bước 5)
    ip = may(S38)
    ip.g.update(s4=PArr([]), sg=-1, q=0, sM15=sto(ip, mssA=True, atr=4.2), evConf=0)
    er = ip.new_obj("ERec", [], dict(id=5, sd=-1, ln=1991.5, e=1990.25, rk=3, dw=True, eq=True, t=777, fl=False))
    ip.g["eR"] = PArr([er])
    m_ = re.search(r"\n(\s+ERec r4 = array\.get\(eR, q\).*\n\s+array\.push\(s4, S4\.new\(.*\)\)\n)", S38)
    lines = [l.strip() for l in m_.group(1).strip("\n").split("\n")]
    rest = ip.load(PM.parse_program(lines, 1)); ip.bar(rest)
    x = ip.g["s4"].v[0]
    er.f.update(e=1.0, rk=0)          # thay đổi EV sau đó không ảnh hưởng thể hiện (sao chép giá trị)
    tt = {k: x.f[k] for k in ("d", "sd", "e", "ln", "rk", "dw", "eq", "c1", "atrC", "tS")}
    ok = tt == dict(d=1, sd=-1, e=1990.25, ln=1991.5, rk=3, dw=True, eq=True, c1=True, atrC=4.2, tS=777) and S38.count("array.push(s4, S4.new(") == 1
    ghi("SU4-13", "C · SU-4", "Thể hiện SU-4 chép HẠNG_NEO, DW_NEO, EQ_NEO, L_NEO, E đã khóa tại s từ EV; C-1 và ATR_M15 lấy tại c; EV đổi sau đó không ảnh hưởng; chỉ tạo ở MD-5 bước 5 (một chỗ)",
        "THÔNG DỊCH (dòng nguyên văn)", "đúng mọi trường", tt, "PASS" if ok else "FAIL", "G.3 bước 4f, J.3")
    # SU4-14 S2a: SU-4 và SU-1 ngược chiều cùng nến → xung đột hai chiều (lý do 11); SU-4 một mình → FINAL
    s = kb(); s.them(); s.bar(1994, 1996, 1993, 1995.5)
    e1 = K.obj(s.ip, "Ev", dir=-1, su=1); e1.f["pass"] = True
    _, tr = s.bar(1995, 1998, 1994.8, 1997, s2a=True, trig=[e1], passSell=1)
    x1 = [(e.f["su"], e.f["reason"], e.f["state"]) for e in tr]
    s = kb(); s.them(); s.bar(1994, 1996, 1993, 1995.5)
    _, tr = s.bar(1995, 1998, 1994.8, 1997, s2a=True)
    x2 = [(e.f["su"], e.f["state"], e.f["fin"]) for e in tr]
    ok = x1 == [(1, 11, s.g["SS_SKIP"]), (4, 11, s.g["SS_SKIP"])] and x2 == [(4, s.g["SS_FINAL"], True)]
    ghi("SU4-14", "C · SU-4", "S2a: SU-4 BUY + SU-1 SELL cùng nến → cả hai lý do 11; chỉ SU-4 → ỨNG VIÊN CUỐI vào sổ (ACTIONABLE)", "THÔNG DỊCH (S1 SU-4 + S2a nguyên văn)", "đúng", (x1, x2),
        "PASS" if ok else "FAIL", "J.0, S2a")
    # SU4-15 nhiều thể hiện độc lập
    s = kb(); a1 = s.them(e=1990.0); a2 = s.them(e=1994.5, tS=60000 * 200)
    ev, _ = s.bar(1994, 1996, 1993, 1995.5)
    ev2, tr = s.bar(1995, 1998, 1993.0, 1993.5)
    tt = ([e.f["state"] for e in ev2], len(s.g["s4"].v))
    ghi("SU4-15", "C · SU-4", "Hai thể hiện SU-4 cùng lúc độc lập: một bị vô hiệu M5 (E 1994,5), một vẫn chờ", "THÔNG DỊCH", "([VOID], 1)", tt,
        "PASS" if tt == ([s.g["SS_VOID"]], 1) else "FAIL", "I-2")
    ghi("SU4-16", "C · SU-4", "EV XÁC NHẬN ở đường bắt kịp (P4 desync) không tạo SU-4", "TĨNH", "chỉ đường bước 5 tạo", "Đường bắt kịp không có ATR_M15/MSS của nến c → không tạo (diễn giải IP-15, xem báo cáo)",
        "PASS" if S38.count("array.push(s4,") == 1 else "FAIL", "—")
    # ================================================================ SU-6
    s6 = SU6()
    cl = [(2000.0, 2001.0, 3), (2003.0, 2004.0, 2), (2005.0, 2006.0, 3)]
    ca = [("UP: vượt cụm hạng 3 (U 2001, 2006), thân 7 ≥ 1,5×4 → mức cao nhất bị vượt 2006", s6.chay(1, 2007.0, 1999.0, 2000.0, 4.0, cl), "BREAKOUT ↑ 2006.00 – theo dõi retest · T5"),
          ("UP: thân 5,9 < 6 → không", s6.chay(1, 2005.9, 1999.0, 2000.0, 4.0, cl), "–"),
          ("UP: chỉ vượt cụm hạng 2 → không", s6.chay(1, 2004.5, 2002.0, 1998.0, 4.0, cl), "–"),
          ("DOWN: Close < D 2000 ≤ Close trước → ↓ 2000", s6.chay(2, 1993.0, 2001.5, 2000.5, 4.0, cl), "BREAKOUT ↓ 2000.00 – theo dõi retest · T5"),
          ("RANGE → không", s6.chay(3, 2007.0, 1999.0, 2000.0, 4.0, cl), "–"),
          ("Ngược chiều regime (UP, nến giảm qua cụm) → không", s6.chay(1, 1993.0, 2001.5, 2000.5, 4.0, cl), "–"),
          ("Giá mở H1 không khớp thời điểm → không đánh giá", s6.chay(1, 2007.0, 1999.0, 2000.0, 4.0, cl, khop=False), "–"),
          ("MD-4 không khả dụng → không", s6.chay(1, 2007.0, 1999.0, 2000.0, 4.0, cl, md4=False), "–"),
          ("Không có cụm → không (không lỗi chỉ số)", s6.chay(1, 2007.0, 1999.0, 2000.0, 4.0, []), "–")]
    sai = [(n, g_, k_) for n, g_, k_ in ca if g_ != k_]
    ghi("SU6-01", "D · SU-6", "SU-6 (J.5): H1 Close vượt cụm MD-4 hạng ≥ 3 theo chiều regime, thân ≥ 1,5×ATR_H1 → chỉ chuỗi thông tin", "THÔNG DỊCH (khối nguyên văn)", "đúng 9/9",
        f"sai {sai}", "PASS" if not sai else "FAIL", "J.5")
    b6 = "\n".join(K.doan(S38, "// ---- 0.3.8 SU-6 (J.5): H1 Close", "// ---- P0 (khung nguồn")[0])
    gan6 = set(re.findall(r"(?<![\w.])([A-Za-z_]\w*)\s*:=", re.sub(r"//.*", "", b6)))
    bad = re.findall(r"array\.(?:push|set|remove)|f_ledger|trigE|evs|label\.new|alert|S4\.new", b6)
    ghi("SU6-02", "D · SU-6", "SU-6 không tạo ARMED/trigger/S1/sổ/cảnh báo: khối chỉ gán su6Txt và biến cục bộ, không đụng trigE/evs/sổ/nhãn", "TĨNH", "chỉ su6Txt, lv6",
        f"gán {sorted(gan6)}; lệnh cấm {bad}", "PASS" if gan6 <= {"su6Txt", "lv6"} and not bad else "FAIL", "J.5")
    # giá mở H1 theo dõi trên biểu đồ
    ip = may(S38)
    lines, base = K.doan(S38, "if dueH1\n", "// =====================================================================\n// 11d", 0) if False else (None, None)
    m_ = re.search(r"\n    if dueH1 .*\n((?:        .*\n)+)", S38)
    rest = ip.load(PM.parse_program(["if dueH1"] + [l[4:] for l in m_.group(1).rstrip("\n").split("\n")], 1))
    ip.g.update(h1o=NA, h1t=NA, h1oP=NA, h1tP=NA)
    seq = [(True, 3600, 10.0), (False, 3900, 11.0), (True, 7200, 12.0)]
    for due, tm, o in seq:
        ip.g.update(dueH1=due, time=tm, open=o); ip.bar(rest)
    tt = (ip.g["h1oP"], ip.g["h1tP"], ip.g["h1o"], ip.g["h1t"])
    ghi("SU6-03", "D · SU-6", "Giá mở nến H1 vừa đóng = Open nến M5 đầu kỳ H1 (lưu khi timeframe.change H1), kèm thời điểm để khớp với ngữ cảnh H1", "THÔNG DỊCH", "(10, 3600, 12, 7200)", tt,
        "PASS" if tt == (10.0, 3600, 12.0, 7200) else "FAIL", "—")
    # ================================================================ hồi quy toàn bộ
    T = ["t_reg_vi_sai", "t_reg_bien", "t_vol", "t_perm", "t_lvpick", "t_grade", "t_d8", "t_a07_pine", "t_a07_tc", "t_a07_tac_dong", "t_zq3", "t_s1_hoi_quy", "t_s1_muc_tieu",
         "t_chuoi_md6_md7_s1", "t_xep_hang_s2b", "t_data_window", "t_hien_thi_canh_bao", "t_md5_song_song"]
    dat_ma38(S38)
    goc_tt = None
    import md5_song_song as MS
    goc_tt = MS.trang_thai

    def tt_loc(m):     # MD-5 vi sai: bỏ biến SU-4 mới khỏi so sánh (s4 do MD-8 dùng)
        return {k: v for k, v in goc_tt(m).items() if k not in ("s4",)}
    MS.trang_thai = tt_loc
    try:
        for t in T:
            C.an_toan("R." + t, "E · hồi quy", "Chạy lại " + t + " trên 0.3.8", "THÔNG DỊCH/THAM CHIẾU", "như 0.3.7", "chay_035.py::" + t, getattr(C, t))
    finally:
        MS.trang_thai = goc_tt
    KT.S35E, KT.L35E = S38, L38
    for tid, fn, mt in (("R.K-03", KT.k_khong_gia_tri_gia, "Khung không dùng không tạo trạng thái giả"), ("R.K-04", KT.k_chan_tin_hieu, "Tín hiệu chỉ trên M5")):
        C.an_toan(tid, "E · hồi quy", mt, "TĨNH/THÔNG DỊCH", "đúng", "kiem_toan_035e.py::" + fn.__name__, fn)
    gate = [i + 1 for i, l in enumerate(L38) if re.search(r"S4\.new|f_ev4\(x, SS_|array\.push\(s4", l)]
    i_run = next(i + 1 for i, l in enumerate(L38) if l.startswith("if runBar") and "newM15 and okM15 and okH1 and not na(sH1.atr)" in l)
    i_pipe = next(i + 1 for i, l in enumerate(L38) if l == "if runBar")
    ok = all((i_run < g_ < i_pipe) or g_ > i_pipe for g_ in gate)
    ghi("R.M5", "E · hồi quy", "SU-4/SU-6 chỉ chạy trong khối 'if runBar' (M5, mã hợp lệ, nến đã đóng) → M15…Y không có SU-4/SU-6; không dùng nến đang chạy", "TĨNH", "mọi dòng tạo/ARMED/sự kiện trong khối runBar",
        f"dòng {gate}; MD-5 runBar từ {i_run}; pipeline từ {i_pipe}", "PASS" if ok else "FAIL", "—")
    rs = [l for l in L38 if "request.security(" in l and not l.strip().startswith("//")]
    ghi("R.MTF", "E · hồi quy", "8 request.security không đổi (vô điều kiện, lookahead_on + [1]) – không dùng dữ liệu tương lai", "TĨNH", "8, trùng 0.3.7", f"{len(rs)}; trùng {rs == [l for l in L37 if 'request.security(' in l and not l.strip().startswith('//')]}",
        "PASS" if len(rs) == 8 and rs == [l for l in L37 if "request.security(" in l and not l.strip().startswith("//")] else "FAIL", "—")
    p = os.path.join(G, "hoi_quy034")
    r = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "039"], cwd=p, capture_output=True, text=True, timeout=900)
    try:
        dj = json.load(open(os.path.join(p, "results", "ket_qua_test_039.json"), encoding="utf-8"))
        rows = dj if isinstance(dj, list) else next(v for v in dj.values() if isinstance(v, list))
        fail = sorted(x["id"] for x in rows if x["trang_thai"] == "FAIL")
        dem = {}
        for x in rows:
            dem[x["trang_thai"]] = dem.get(x["trang_thai"], 0) + 1
        moi = sorted(set(fail) - set(C.KY_VONG_HQ))
        ghi("R.HQ034", "E · hồi quy cũ", "hoi_quy034 trên 0.3.8 (chỉ thêm đích '038', không sửa assertion)", "HỒI QUY", "FAIL ngoài 6 test đã phân loại phải được giải thích",
            f"{dem}; mã thoát gốc {r.returncode}; FAIL {fail}; FAIL mới {moi}", "PASS" if not moi else "FAIL", "hoi_quy034/results/ket_qua_test_038.json")
    except Exception as ex:     # noqa: BLE001
        ghi("R.HQ034", "E · hồi quy cũ", "hoi_quy034 trên 0.3.8", "HỒI QUY", "—", repr(ex) + r.stdout[-300:] + r.stderr[-300:], "FAIL", "—")
    C.an_toan("R.VD", "E · hồi quy", "Vòng đời MD-5 2.054 bước", "HỒI QUY", "0 FAIL", "ket_qua034a_nt/vong_doi.json", C.t_vong_doi)
    # đột biến
    import dot_bien_035 as DB
    def t_su4():
        s = SU4(C.S35); s.them(); s.bar(1994, 1996, 1993, 1995.5)
        _, tr = s.bar(1995, 1998, 1994.8, 1997)
        ok1 = bool(tr) and round(tr[0].f["sl"], 4) == 1989.6 and tr[0].f["pass"]
        s = SU4(C.S35); s.them()
        _, tr0 = s.bar(1994, 1996, 1993, 1996)       # đúng bằng High[a] tại a → không trigger
        s = SU4(C.S35); s.them(); s.bar(1994, 1996, 1993, 1995.5)
        s.set_ctx(reg=3, sh0=2020.0, sl0=1985.0)
        _, tr3 = s.bar(1995, 1998, 1994.8, 1997)
        s = SU4(C.S35); s.them()
        het = None
        for j in range(30):
            ev, _ = s.bar(1994, 1995, 1993.5, 1994.2)
            if any(e.f["state"] == s.g["SS_EXPIRED"] for e in ev):
                het = j; break
        s = SU4(C.S35); s.them()
        ev, _ = s.bar(1990.5, 1991, 1989.5, 1989.89)
        s = SU4(C.S35); s.them()
        evb, _ = s.bar(1990.5, 1991, 1989.5, 1989.9)       # đúng biên: không vô hiệu
        return ok1 and not tr0 and tr3 and tr3[0].f["reason"] == 15 and het == 23 and any(e.f["state"] == s.g["SS_VOID"] for e in ev) \
            and not any(e.f["state"] == s.g["SS_VOID"] for e in evb), ""

    def t_su6():
        s6 = SU6(C.S35)
        return s6.chay(1, 2007.0, 1999.0, 2000.0, 4.0, cl) == "BREAKOUT ↑ 2006.00 – theo dõi retest · T5" and s6.chay(1, 2005.9, 1999.0, 2000.0, 4.0, cl) == "–" \
            and s6.chay(1, 2004.5, 2002.0, 1998.0, 4.0, cl) == "–", ""
    C.T_SU4, C.T_SU6 = t_su4, t_su6
    DBX = DB.DB + [("SU-4 SL dùng ATR_M5 thay ATR_M15(c)", "float sl = x.e - d * iSlBufK * x.atrC", "float sl = x.e - d * iSlBufK * atrM5", ["T_SU4"]),
                   ("SU-4 bỏ chặn RANGE (dùng quy tắc tạm)", "int pm = sH4.reg == REG_RG and okH4 and not pendH4 ? 15 : ", "int pm = ", ["T_SU4"]),
                   ("SU-4 hết hạn sau 25 nến", "            else if x.k >= K_EXPIRE\n", "            else if x.k > K_EXPIRE\n", ["T_SU4"]),
                   ("SU-4 vô hiệu M5 dùng ≤", "d * (close - x.e) < -iVoidK * atrM5", "d * (close - x.e) <= -iVoidK * atrM5 + 0.02", ["T_SU4"]),
                   ("SU-6 thân ≥ 1,4×ATR", ">= 1.5 * sH1.atr", ">= 1.4 * sH1.atr", ["T_SU6"]),
                   ("SU-6 nhận cụm hạng 2", "if array.get(cRank, k) >= 3 and d6", "if array.get(cRank, k) >= 2 and d6", ["T_SU6"])]
    song = []
    for ten, cu_, moi, tests in DBX:
        assert S38.count(cu_) >= 1, ten
        dat_ma38(S38.replace(cu_, moi))
        bat = False
        for t in tests:
            try:
                bat = bat or not getattr(C, t)()[0]
            except Exception:       # noqa: BLE001
                bat = True
        song += [] if bat else [ten]
    dat_ma38(S38)
    ghi("R.DB", "E · đối chứng âm", f"{len(DBX)} đột biến (12 cũ + 6 cho SU-4/SU-6) trên bản sao 0.3.8 đều bị bắt", "ĐỘT BIẾN", f"{len(DBX)}/{len(DBX)}", f"sống sót {song}",
        "PASS" if not song else "FAIL", "dot_bien_035.py + chay_038.py")
    C.nhom_a()
    for x in C.KQ:
        if re.fullmatch(r"A-\d\d", x["id"]):
            x["id"] = "R.A35." + x["id"]
    vol = len(re.findall(r"v >= 1\.5", S38)); su6 = len(re.findall(r">= 1\.5 \* sH1\.atr", S38))
    ghi("R.A10b", "E · hồi quy (thay A-10)", "Ngưỡng VOL vẫn định nghĩa một chỗ (f_vol); hằng 1,5 mới là ngưỡng thân nến SU-6 (J.5 {1,5}×ATR_H1), không phải logic VOL trùng lặp", "TĨNH",
        "VOL 1 chỗ; SU-6 1 chỗ", f"'v >= 1.5': {vol}; '>= 1.5 * sH1.atr': {su6}", "PASS" if vol == 1 and su6 == 1 else "FAIL", "—")
    cu = {"R.t_data_window": "dashboard hiện đủ 4 lớp VOL từ 0.3.6 (C-DB của bộ 0.3.6)", "R.A35.A-02": "diff tích lũy so với 0.3.4a (A-01 chuỗi SHA; 0 hunk Q2, 0 dòng D14–D19)",
          "R.A35.A-05": "input 64 → 61 và label.new 3 → 2 do PA-A đã duyệt (A-04, A-02/A-03)", "R.A35.A-09": "StructOut 86 trường từ 0.3.6 (V-03 của bộ 0.3.6)",
          "R.A35.A-10": "hằng 1,5 của SU-6 (R.A10b)"}
    that = sorted(x["id"] for x in C.KQ if x["ket_qua"] == "FAIL" and (x["id"].startswith("R.A35.") or x["id"].startswith("R.t_")))
    ghi("R.PHAN_LOAI", "E · hồi quy", "Test cũ FAIL chỉ là các assertion lỗi thời do thay đổi đã duyệt, mỗi cái có test độc lập thay thế; không sửa test cũ", "TĨNH (đối chiếu danh sách)",
        "FAIL cũ = danh sách đã phân loại", f"FAIL cũ {that}; phân loại {cu}", "PASS" if set(that) == set(cu) else "FAIL", "—")
    ghi("T-01", "E · token", "Token 0.3.8 (hiệu chỉnh theo điểm thật 0.3.3)", "TĨNH (ƯỚC LƯỢNG)", "≤ 100.256 với dư địa", f"từ vựng {t8}; ước lượng {round(t8 * TYLE)}; dư địa ≈ {100256 - round(t8 * TYLE)} biên dịch ≈ {round(100256 / TYLE) - t8} từ vựng",
        "PASS" if t8 * TYLE <= 100256 else "FAIL", "—")
    for tid, mt in (("TV-COMPILE", "Compile 0.3.8"), ("TV-M5", "M5: chỉ báo, dashboard (dòng SU-6), tín hiệu SU-1 như 0.3.7, SU-4 xuất hiện khi có EV XÁC NHẬN"),
                    ("TV-RELOAD", "Tải lại/realtime: SU-4/SU-6 trên nến đã đóng không đổi"), ("TV-KHUNG", "M15…Y: không lỗi, dashboard hiện")):
        ghi(tid, "TradingView", mt, "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "—")
    ghi("TV-EXNESS", "TradingView", "Exness thật / Profiler / CSV", "TRADINGVIEW", "—", "chưa có", "NOT TESTED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    json.dump(dict(tom_tat=dict(build="0.3.8", sha=h8, sha_giai_doan_A=hA, dem=dem, token=dict(tu_vung=t8, uoc=round(t8 * TYLE)), giay=round(time.time() - t0, 1)), ket_qua=C.KQ),
              open(os.path.join(OUT, "ket_qua_038.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(OUT, "ket_qua_038.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem, round(time.time() - t0), "s")
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0)


if __name__ == "__main__":
    main()
