# -*- coding: utf-8 -*-
"""Khung kiểm thử Build 0.3.9 – driver chạy NGUYÊN VĂN các khối Pine SHADOW (SU-3/SU-5) trên pine_mini.
Mở rộng trình thông dịch (chỉ cho bộ 0.3.9): toán tử lịch sử [] cho high/low/open/close/time (từ lịch sử nến do driver ghi),
array.includes, str.contains. Không phải TradingView."""
import os, re, sys
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, os.path.join(G, "kiem_toan035"))
import chay_038 as R8      # noqa: E402
import khung as K          # noqa: E402
import pine_mini as PM     # noqa: E402
from khung import NA, PArr  # noqa: E402

F038 = R8.F038
F039 = os.path.join(G, "src039", "ATA_P3_Build_0.3.9_Candidate_Indicator.pine")
S38 = R8.S38
S39 = K.doc(F039)
L39 = S39.split("\n")
SERIES = ("high", "low", "open", "close", "time")
MK_PRE = ("// ---- 0.3.9 SU-3/SU-5 SHADOW – bước tiền-kích hoạt", "if runBar and okH1")
MK_M5 = ("    // ---- 0.3.9 SU-3/SU-5 SHADOW trên M5", "    // ---- Ô Data Window")
HAM39 = R8.HAM + ("f_zS", "f_evS", "f_shT", "f_shEnd", "f_shS1")


class Ip39(R8.Ip):
    def ev(self, e, sc):
        if e[0] == "hist" and e[1][0] == "name" and e[1][1] in SERIES:
            n = int(self.ev(e[2], sc))
            H = self.g["__H"]
            return H[-1 - n][e[1][1]] if 0 <= n < len(H) else NA
        return super().ev(e, sc)

    def call_builtin(self, name, args, kw):
        if name == "array.includes":
            return args[1] in args[0].v
        if name == "str.contains":
            return args[1] in args[0]
        if name == "array.unshift":
            args[0].v.insert(0, args[1]); return None
        if name == "alert":                      # chỉ để đột biến 'SHADOW phát cảnh báo' được ghi nhận khi chạy
            self.g.setdefault("__ALERT", PArr([])).v.append(args[0]); return None
        return super().call_builtin(name, args, kw)


def may39(src):
    ip = Ip39()
    ip.g.update(K.hang_so(src))
    ip.g.update(tick=0.01, TICK_TOL=ip.g.get("TICK_TOL", 1e-6))
    for t in ("StructOut", "StructX", "Zone", "Ev", "S4", "ERec", "SH"):
        if re.search(r"^type " + t + r"\b", src, re.M):
            Lb, b = K.khoi(src, t); ip.load(PM.parse_program(Lb, b))
    for f in HAM39:
        if re.search(r"^" + f + r"\(", src, re.M):
            Lb, b = K.khoi(src, f); ip.load(PM.parse_program(Lb, b))
    return ip


def doan0(ip, src, dau, cuoi, thut):
    lines, base = K.doan(src, dau, cuoi, thut)
    return ip.load(PM.parse_program(lines, base))


def zone(ip, tf, d, bot, top, bm, bs=None, touches=0, moved=False, pos=1):
    return K.obj(ip, "Zone", tf=tf, dir=d, bot=bot, top=top, atrZ=2.0, baseMin=bm - 15 if bs is None else bs, bosMin=bm, touches=touches, moved=moved, pos=pos)


class SHD:
    """Khối tiền-kích hoạt M15/H1 (cột 0) và khối M5 (thụt 4) NGUYÊN VĂN, cùng một bộ nhớ, thứ tự như trong script."""
    def __init__(self, src=S39):
        self.src = src
        self.ip = ip = may39(src)
        self.pre = doan0(ip, src, MK_PRE[0], MK_PRE[1], 0)
        self.m5 = doan0(ip, src, MK_M5[0], MK_M5[1], 4)
        g = self.g = ip.g
        g.update(iVoidK=0.1, iSlBufK=0.2, iSlMaxK=2.0, iRRMin=1.5, iMssK=1.5, md4OK=True, md5OK=True, okM15=True, okH1=True, okH4=True, okD=False, runBar=True,
                 pendM15=False, pendH1=False, pendH4=False, atrM5=1.0, isXAU=False, zones=PArr([]), cLo=PArr([]), cHi=PArr([]), cRank=PArr([]),
                 plB=PArr([]), prB=PArr([]), plS=PArr([]), prS=PArr([]), sh=PArr([]), s5L=PArr([]), shTxt="–", bar_index=0, newM15=False, newH1=False, __H=[])
        self.T = 60000 * 1000000          # thời điểm mở nến M5 hiện tại (ms), bội số 15 phút
        self.ctx()

    def ctx(self, reg=2, vr=1.0, lch=0, h1st=0, m15st=0, m15h=(2040.0, 2050.0), m15l=(1960.0, 1950.0), atr15=5.0):
        ip = self.ip
        self.g.update(sH4=R8.sto(ip, m15h, m15l, reg=reg, vr=vr, lch=lch), sD=R8.sto(ip), sH1=R8.sto(ip, (), (), st=h1st, tClose=NA, ev=0, mssA=False, cls=NA),
                      sM15=R8.sto(ip, m15h, m15l, atr=atr15, st=m15st, cls=NA, ev=0, tClose=NA, refH=NA, refL=NA), xM15=K.obj(ip, "StructX"))
        self.atr15 = atr15
        self.m15h, self.m15l = m15h, m15l

    def m15(self, o, h, l, c, ev=0, refH=NA, refL=NA, clsP=NA, h1=None):
        """Đặt dữ liệu nến M15 vừa đóng (tClose = thời điểm mở nến M5 hiện tại) và tùy chọn nến H1 vừa đóng cùng thời điểm."""
        ip, g = self.ip, self.g
        g["sM15"] = R8.sto(ip, self.m15h, self.m15l, atr=self.atr15, cls=c, ev=ev, refH=refH, refL=refL, tClose=self.T)
        g["xM15"] = K.obj(ip, "StructX", loS=l, hiS=h, clsP=clsP)
        g["newM15"] = True
        if h1 is not None:
            hc, hev, hmss = h1
            g["sH1"] = R8.sto(ip, (), (), cls=hc, ev=hev, mssA=hmss, tClose=self.T, st=g["sH1"].f["st"])
            g["newH1"] = True

    def h1(self, c, ev=0, mss=False):
        ip, g = self.ip, self.g
        g["sH1"] = R8.sto(ip, (), (), cls=c, ev=ev, mssA=mss, tClose=self.T, st=g["sH1"].f["st"])
        g["newH1"] = True

    def bar(self, o, h, l, c, chay_m5=True, **kw):
        """Một nến M5 đã đóng: khối tiền-kích hoạt (nếu có nến M15/H1 mới) rồi khối M5. Trả về (sự kiện SHADOW, shTxt)."""
        g = self.g
        g["__H"].append(dict(open=o, high=h, low=l, close=c, time=self.T))
        g.update(open=o, high=h, low=l, close=c, time=self.T, evS=PArr([]))
        g.update(kw)
        self.ip.bar(self.pre)
        if chay_m5:
            self.ip.bar(self.m5)
        g["bar_index"] += 1
        g["newM15"] = False
        g["newH1"] = False
        self.T += 300000
        return list(g["evS"].v), g["shTxt"]

    def xs(self):
        return list(self.g["sh"].v)


def ev_t(e):
    return (e.f["su"], e.f["dir"], e.f["state"], e.f["reason"])
