# -*- coding: utf-8 -*-
"""Kiểm thử cô lập SHADOW (SU-3/SU-5) của Build 0.3.9 – bằng chứng tĩnh + chạy nguyên văn (pine_mini).
I-01 dựng lại 0.3.8 từ 0.3.9 · I-02 khối/hàm actionable trùng từng ký tự · I-03 tập ghi của mã chèn · I-04 chụp toàn bộ trạng thái khi chạy
khối SHADOW · I-05 vi sai đuôi pipeline (ô Data Window, mainEv, portSlot) · I-06 vi sai nhiều nến SU-1 + SU-4 + S2a (+ SHADOW) 0.3.8 vs 0.3.9."""
import difflib, random, re
import khung039 as KH
from khung039 import K, PM, NA, PArr, S38, S39, may39, doan0, zone

L38, L39 = S38.split("\n"), S39.split("\n")


def bo_cm(s):
    return "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n"))


def chen(src38=S38, src39=S39):
    """Các khối chèn và dòng thay của 0.3.9 so với 0.3.8."""
    a, b = src38.split("\n"), src39.split("\n")
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    ins, rep, dele = [], [], []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "insert":
            ins.append((j1, j2))
        elif op == "replace":
            rep.append((i1, i2, j1, j2))
        elif op == "delete":
            dele.append((i1, i2))
    return ins, rep, dele


def snap(v, memo=None):
    memo = {} if memo is None else memo
    if isinstance(v, PArr):
        return ("A", tuple(snap(x, memo) for x in v.v))
    if hasattr(v, "f") and hasattr(v, "t"):
        k = id(v)
        if k in memo:
            return ("R", k)
        memo[k] = True
        return ("O", v.t, k, tuple(sorted((n, snap(x, memo)) for n, x in v.f.items())))
    if v is NA or v is None:
        return "NA"
    if isinstance(v, (int, float, str, bool)):
        return v
    return ("?", type(v).__name__)


def nhom_tinh(src39=S39):
    R = []
    ins, rep, dele = chen(S38, src39)
    b = src39.split("\n")
    # I-01
    rebuilt = []
    keep = [True] * len(b)
    for j1, j2 in ins:
        for j in range(j1, j2):
            keep[j] = False
    rep_lines = []
    for i1, i2, j1, j2 in rep:
        rep_lines.append((L38[i1:i2], b[j1:j2]))
    # dựng lại: bỏ dòng chèn, thay dòng sửa bằng bản 0.3.8
    sm = difflib.SequenceMatcher(None, L38, b, autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            rebuilt += b[j1:j2]
        elif op in ("replace", "delete"):
            rebuilt += L38[i1:i2]
    cho_phep = ("// AI Trading Assistant – Phase 3 – Build", "indicator(\"AI Trading Assistant", "const int META_VER", "    f_cell(0, syminfo.tickerid", "var table tb = table.new(f_pos(iDashPos), 2, ")
    sua_ngoai = [(o, n) for o, n in rep_lines if not all(any(x.startswith(p) for p in cho_phep) for x in o + n)]
    ok = "\n".join(rebuilt) == S38 and not dele and not sua_ngoai and len(rep_lines) == 5
    R.append(("I-01", "Dựng lại: bỏ các khối CHÈN của 0.3.9 và trả 5 dòng SỬA về bản 0.3.8 → trùng 0.3.8 từng ký tự. 5 dòng sửa chỉ là thông tin phiên bản (tiêu đề, META_VER, dòng 0 dashboard) và số hàng bảng dashboard 15 → 16; không xóa dòng nào",
              "trùng; 0 dòng xóa; 5 dòng sửa đều thuộc danh sách cho phép", dict(khoi_chen=[(j1 + 1, j2) for j1, j2 in ins], dong_sua=[(o[0][:60], n[0][:60]) for o, n in rep_lines], xoa=dele, sua_ngoai=sua_ngoai), ok, "STATIC"))
    # I-02 hàm và khối actionable trùng
    def fns(s):
        return {m.group(1) for m in re.finditer(r"^(f_\w+)\(", s, re.M)}
    f38 = fns(S38)
    khac = [f for f in sorted(f38) if "\n".join(K.khoi(S38, f)[0]) != "\n".join(K.khoi(src39, f)[0])]
    blk = lambda s, a, c: "\n".join(K.doan(s, a, c)[0])  # noqa: E731
    seg = [("P1…P5 + S1 SU-1", "// ---- P1…P5 cho từng vùng", "// ---- 0.3.8 SU-4 (J.3): P4"), ("SU-4", "// ---- 0.3.8 SU-4 (J.3): P4", "// ---- S2a"),
           ("S2a", "// ---- S2a", "// ---- P7, P8"), ("P7/P8 + sổ X-0…X-4 + f_ledger", "// ---- P7, P8", "    int chP = f_ledger(LP, fins)"), ("ARMED SU-4 + SU-6", "// ---- 0.3.8 MD-8 (B.2.2 bước 5)", "// ---- P0 (khung nguồn"),
           ("MD-5", "if runBar and newM15 and okM15 and okH1 and not na(sH1.atr) and not pendH1", "// ---- 0.3.9 SU-3/SU-5 SHADOW – bước tiền-kích hoạt"),
           ("MD-4", "if runBar and okH1\n" if False else "    float w    = iWK * sH1.atr", "f_vol(float v) =>"), ("mainEv/portSlot/cnt14/nhãn", "    // ---- Tín hiệu chính cho phần tóm tắt", "// 12. HIỂN THỊ"),
           ("Data Window (plot)", "// 13. DATA WINDOW", "\u0000")]
    kq = {}
    for ten, a_, c_ in seg:
        try:
            x38 = blk(S38, a_, c_ if ten != "MD-5" else "if runBar and okH1") if c_ != "\u0000" else S38[S38.index(a_):]
            x39 = blk(src39, a_, c_) if c_ != "\u0000" else src39[src39.index(a_):]
            kq[ten] = x38 == x39
        except StopIteration:
            kq[ten] = "không tìm thấy mốc"
    req = ([l for l in L38 if "request.security(" in l], [l for l in b if "request.security(" in l])
    ok = not khac and all(v is True for v in kq.values()) and req[0] == req[1]
    R.append(("I-02", f"Mọi hàm của 0.3.8 ({len(f38)} hàm) và các khối actionable (SU-1 P1…P5/S1, SU-4, S2a, P7/P8 + sổ, ARMED SU-4 + SU-6, MD-5, MD-4, mainEv/nhãn, Data Window) trùng từng ký tự trong 0.3.9; 8 request.security trùng",
              "0 khác", dict(ham_khac=khac, khoi=kq, request_trung=req[0] == req[1]), ok, "STATIC"))
    # I-03 tập ghi của mã chèn
    ma = "\n".join(b[j] for j1, j2 in ins for j in range(j1, j2))
    m = bo_cm(ma)
    gan = set(re.findall(r"(?<![\w.])([A-Za-z_]\w*)\s*(?::=|\+=|-=)", m))
    gan_tr = set(re.findall(r"(?<![\w.])([A-Za-z_]\w*)\.(\w+)\s*(?::=|\+=|-=)", m))
    khai = set(re.findall(r"(?:^|\n)\s*(?:var\s+)?(?:int|float|string|bool|Zone|SH|Ev|array<\w+>)\s+([A-Za-z_]\w*)\s*=", m)) | {"r", "e", "z", "lv", "rk", "m", "i", "c", "x", "q", "j"}
    dot = re.findall(r"\barray\.(push|set|remove|clear|insert|unshift|shift|pop|sort|reverse|fill)\s*\(\s*(\w+)", m)
    mang_ok = {"sh", "s5L", "evS", "pick"}
    cam = {"trigE", "fins", "evs", "slotEv", "mainEv", "portSlot", "bar14", "cnt14", "zones", "s4", "passBuy", "passSell", "su6Txt", "LS", "LE", "LP", "trigZ", "slotOverflow", "eR", "plB", "plS", "cLo", "cHi", "cRank"}
    goi = sorted(set(re.findall(r"\b(alert\w*|label\.\w+|plot\w*|strategy\.\w+|f_ledger|f_x0|f_exec|box\.\w+|line\.\w+|request\.\w+|input\.\w+)\s*\(", m)))
    gan_ngoai = sorted((gan - khai) - {"shTxt"})
    truong = sorted({o for o, _ in gan_tr} - {"x", "e"})
    dot_ngoai = sorted({t for _, t in dot} - mang_ok)
    push_pick = [l.strip() for l in ma.split("\n") if "array.push(pick" in l]
    ok = not gan_ngoai and not truong and not dot_ngoai and not (gan & cam) and not goi and len(push_pick) == 1
    R.append(("I-03", "Tập ghi của TOÀN BỘ mã chèn: chỉ gán biến cục bộ của chính nó và shTxt; chỉ gán trường của thể hiện SH (x.*) và sự kiện SHADOW mới tạo (e.*); chỉ thay đổi mảng sh, s5L, evS và đúng 1 lệnh thêm vào pick (ô Data Window còn trống); không gọi alert/label/plot/strategy/f_ledger/f_x0/f_exec/request/input; không ghi trigE, fins, evs, sổ, zones, s4, bar14…",
              "0 vi phạm", dict(gan_ngoai=gan_ngoai, truong_doi_tuong_khac=truong, mang_ngoai=dot_ngoai, cham_cam=sorted(gan & cam), goi_cam=goi, them_pick=push_pick), ok, "STATIC"))
    return R


# ============================================================================== chạy (pine_mini)
def kich_ban(R, s, n_bar=36, the_hien=True):
    """Sinh dữ liệu ngẫu nhiên cho driver SHD: vùng H1/M15 quanh giá, cụm MD-4, BOS M15, CHoCH/MSS H1, cờ chạm vùng như P1 đã ghi."""
    p = 2000.0
    ip, g = s.ip, s.g
    if the_hien:
        for _ in range(R.randint(1, 3)):
            d = R.choice((1, -1)); b0 = round(p - d * R.uniform(2, 8), 1)
            g["zones"].v.append(zone(ip, 60, d, b0 - 2, b0 + 2, bm=s.T // 60000 - R.choice((600, 900))))
        for _ in range(R.randint(0, 3)):
            d = R.choice((1, -1)); b0 = round(p - d * R.uniform(0, 6), 1)
            g["zones"].v.append(zone(ip, 15, d, b0 - 1, b0 + 1, bm=s.T // 60000 + R.choice((15, 30, 60, 90)), bs=R.randint(0, 99)))
    cl = sorted(round(p + R.uniform(-10, 10), 1) for _ in range(R.randint(0, 4)))
    g.update(cLo=PArr([c - 0.5 for c in cl]), cHi=PArr([c + 0.5 for c in cl]), cRank=PArr([R.randint(1, 5) for _ in cl]))
    seq = []
    for j in range(n_bar):
        o = p; c = round(p + R.gauss(0, 1.8), 1); h = round(max(o, c) + abs(R.gauss(0, 0.7)), 1); l_ = round(min(o, c) - abs(R.gauss(0, 0.7)), 1)
        m15 = j % 3 == 0
        ev = R.choice((0, 0, 0, 1, 2, 3, 4)) if m15 else 0
        h1 = (round(c, 1), R.choice((0, 3, 4)), R.random() < 0.6) if (m15 and j % 12 == 0) else None
        seq.append(dict(o=o, h=h, l=l_, c=c, m15=m15, ev=ev, ref=round(p + R.uniform(-3, 3), 1), h1=h1, cham=R.random() < 0.25, pend=R.random() < 0.05))
        p = c
    return seq


def chay_bar(s, b, R=None, zones_cham=True):
    g = s.g
    if b["m15"]:
        s.m15(b["o"], b["h"] + 0.5, b["l"] - 0.5, b["c"], ev=b["ev"], refH=b["ref"], refL=b["ref"], clsP=b["o"], h1=b["h1"])
    if zones_cham:
        for z in g["zones"].v:
            if z.f["tf"] == 15 and b["cham"] and b["l"] <= z.f["top"] and b["h"] >= z.f["bot"]:
                z.f["touches"] += 1; z.f["moved"] = True
            else:
                z.f["moved"] = False
    return s.bar(b["o"], b["h"], b["l"], b["c"], pendH1=b["pend"])


def nhom_snapshot(src39=S39, n=150):
    """I-04: chụp TOÀN BỘ biến toàn cục (sâu: mảng, đối tượng, trường) trước và sau từng lần chạy khối SHADOW; chỉ được đổi: sh, s5L, evS, shTxt
    và biến cục bộ khai báo trong chính khối. Trạng thái actionable giả lập có mặt đầy đủ (evs, trigE, fins, sổ giả, s4, bar14, cnt14, zones có trạng thái SU-1)."""
    R = random.Random(304)
    ins, _, _ = chen(S38, src39)
    b = src39.split("\n")
    ma = bo_cm("\n".join(b[j] for j1, j2 in ins for j in range(j1, j2)))
    cuc_bo = set(re.findall(r"(?:^|\n)\s*(?:int|float|string|bool|Zone|SH|Ev)\s+([A-Za-z_]\w*)\s*=", ma)) | {"i", "c", "z", "q", "j", "x", "e"}
    cho = {"sh", "s5L", "evS", "shTxt", "bar_index", "__H", "open", "high", "low", "close", "time", "newM15", "newH1", "sM15", "xM15", "sH1", "pendH1"} | cuc_bo
    vp = []
    so_su_kien = 0
    for k in range(n):
        s = KH.SHD(src39)
        s.ctx(reg=R.choice((1, 2, 3, 4)), atr15=8.0)
        ip = s.ip
        ev_a = [K.obj(ip, "Ev", dir=R.choice((1, -1)), su=R.choice((1, 4)), grp=R.randint(0, 2)) for _ in range(R.randint(0, 4))]
        s.g.update(evs=PArr(ev_a), trigE=PArr(ev_a[:2]), fins=PArr(ev_a[:1]), bar14=R.randint(0, 2), cnt14=R.randint(0, 9), passBuy=1, passSell=0,
                   s4=PArr([K.obj(ip, "S4", d=1, sd=-1, e=1990.0, ln=1991.0, rk=2, dw=False, eq=False, c1=True, atrC=2.0, tS=1)]), su6Txt="BREAKOUT ↑", mainEv=ev_a[0] if ev_a else NA,
                   LE=K.obj(ip, "Ev", dir=1), slotEv=PArr(ev_a[:3]), portSlot=0)
        seq = kich_ban(R, s)
        for bb in seq:
            truoc = {kk: snap(v) for kk, v in s.g.items() if kk not in cho and not callable(v)}
            e_, _ = chay_bar(s, bb, zones_cham=False)
            so_su_kien += len(e_)
            sau = {kk: snap(v) for kk, v in s.g.items() if kk not in cho and not callable(v)}
            doi = [kk for kk in set(truoc) | set(sau) if truoc.get(kk) != sau.get(kk)]
            if doi:
                vp.append((k, doi[:5]))
                break
    return [("I-04", f"Chạy NGUYÊN VĂN khối tiền-kích hoạt + khối M5 SHADOW trên {n} kịch bản ngẫu nhiên × 36 nến (vùng H1/M15 có trạng thái, cụm MD-4, BOS/CHoCH/MSS, khung chờ) với trạng thái actionable giả lập đầy đủ; chụp sâu toàn bộ biến toàn cục trước/sau mỗi nến: chỉ biến SHADOW (sh, s5L, evS, shTxt) và biến cục bộ của khối được đổi – kể cả mọi trường của vùng MD-3 mà SU-1 dùng",
             "0 biến ngoài danh sách bị đổi; có sự kiện SHADOW phát sinh", dict(vi_pham=vp[:3], su_kien_shadow=so_su_kien), not vp and so_su_kien > 50, "SOURCE-DERIVED")]


# ------------------------------------------------------------------------------ I-05 / I-06: vi sai 0.3.8 vs 0.3.9
class PIPE:
    """Đoạn pipeline nguyên văn: ARMED SU-4 (+SU-6) → SU-1 P1…P5 + S1 → SU-4 → S2a → [SHADOW M5 – chỉ 0.3.9] → ô Data Window/mainEv/portSlot/cnt14.
    0.3.9 thêm khối tiền-kích hoạt SHADOW khi có M15/H1 mới (đặt trước như trong script). Sổ (X-0…X-4, f_ledger) chạy trước SHADOW và không đổi (I-02):
    driver dùng chỉ số sổ đơn giản (ứng viên đầu tiên) cho cả hai bản."""
    def __init__(self, src, shadow):
        self.src, self.shadow = src, shadow
        self.ip = ip = may39(src)
        for f in ("f_newEv", "f_grade", "f_frozen", "f_zonePick"):
            if re.search(r"^" + f + r"\(", src, re.M):
                Lb, b = K.khoi(src, f); ip.load(PM.parse_program(Lb, b))
        self.arm = doan0(ip, src, "// ---- 0.3.8 MD-8 (B.2.2 bước 5)", "// ---- 0.3.8 SU-6", 4)
        self.p15 = doan0(ip, src, "// ---- P1…P5 cho từng vùng", "// ---- 0.3.8 SU-4 (J.3): P4", 4)
        self.su4 = doan0(ip, src, "// ---- 0.3.8 SU-4 (J.3): P4", "// ---- S2a", 4)
        self.s2a = doan0(ip, src, "// ---- S2a", "// ---- P7, P8", 4)
        self.tail = doan0(ip, src, "    // ---- Ô Data Window", "    cnt14 += bar14", 4)
        if shadow:
            self.pre = doan0(ip, src, KH.MK_PRE[0], KH.MK_PRE[1], 0)
            self.m5 = doan0(ip, src, KH.MK_M5[0], KH.MK_M5[1], 4)
        g = self.g = ip.g
        g.update(iVoidK=0.1, iSlBufK=0.2, iSlMaxK=2.0, iRRMin=1.5, iInject=False, iSU1="KIỂM THỬ", md4OK=True, md5OK=True, okM15=True, okH1=True, okH4=True, okD=False,
                 runBar=True, pendM15=False, pendH1=False, pendH4=False, atrM5=1.0, isXAU=True, zones=PArr([]), cLo=PArr([]), cHi=PArr([]), cRank=PArr([]),
                 plB=PArr([]), prB=PArr([]), plS=PArr([]), prS=PArr([]), s4=PArr([]), sh=PArr([]), s5L=PArr([]), shTxt="–", bar_index=0, newM15=False, newH1=False,
                 dueH1=False, h1o=NA, h1t=NA, h1oP=NA, h1tP=NA, __H=[], cnt14=0, slotEv=PArr([]), slotOverflow=0, mainEv=NA, portSlot=0, su6Txt="–", md4OKx=True,
                 evS=PArr([]))
        self.T = 60000 * 1000000

    def ctx(self, reg, atr15=8.0, hs=(2040.0, 2050.0), ls=(1960.0, 1950.0)):
        ip = self.ip
        self.hs, self.ls, self.atr15 = hs, ls, atr15
        self.g.update(sH4=R8sto(ip, hs, ls, reg=reg, vr=1.0, lch=1), sD=R8sto(ip), sH1=R8sto(ip, hs, ls, st=0, tClose=NA, ev=0, mssA=False, cls=NA, atr=6.0),
                      sM15=R8sto(ip, hs, ls, atr=atr15, cls=1995.0, ev=0, tClose=NA, refH=NA, refL=NA), xM15=K.obj(ip, "StructX"), xH1=K.obj(ip, "StructX"))

    def bar(self, b):
        ip, g = self.ip, self.g
        g["__H"].append(dict(open=b["o"], high=b["h"], low=b["l"], close=b["c"], time=self.T))
        g.update(open=b["o"], high=b["h"], low=b["l"], close=b["c"], time=self.T, evs=PArr([]), trigE=PArr([]), passBuy=0, passSell=0, bar14=0, evS=PArr([]),
                 newM15=b["m15"], newH1=b["h1"] is not None, pendH1=b["pend"])
        if b["m15"]:
            g["sM15"] = R8sto(ip, self.hs, self.ls, atr=self.atr15, cls=b["c"], ev=b["ev"], refH=b["ref"], refL=b["ref"], tClose=self.T)
            g["xM15"] = K.obj(ip, "StructX", loS=b["l"] - 0.5, hiS=b["h"] + 0.5, clsP=b["o"])
        if b["h1"] is not None:
            g["sH1"] = R8sto(ip, self.hs, self.ls, cls=b["h1"][0], ev=b["h1"][1], mssA=b["h1"][2], tClose=self.T, st=0, atr=6.0)
        if self.shadow:
            ip.bar(self.pre)
        ip.bar(self.arm)
        ip.bar(self.p15)
        ip.bar(self.su4)
        ip.bar(self.s2a)
        fins = g["fins"].v
        g.update(chS=0 if fins else -1, chE=0 if fins else -1, chP=-1)
        if self.shadow:
            ip.bar(self.m5)
        ip.bar(self.tail)
        g["cnt14"] += g["bar14"]
        out = dict(evs=[ev_snap(e) for e in g["evs"].v], trig=[ev_snap(e) for e in g["trigE"].v], fins=[ev_snap(e) for e in fins],
                   zones=[tuple(sorted((k, str(v)) for k, v in z.f.items())) for z in g["zones"].v], s4=[tuple(sorted((k, str(v)) for k, v in x.f.items())) for x in g["s4"].v],
                   bar14=g["bar14"], cnt14=g["cnt14"], passB=g["passBuy"], passS=g["passSell"], slotOverflow=g["slotOverflow"], mainEv=ev_snap(g["mainEv"]) if g["mainEv"] is not NA else None,
                   portSlot=g["portSlot"], su6=g["su6Txt"], pick=[ev_snap(e) for e in g["slotEv"].v])
        g["bar_index"] += 1
        self.T += 300000
        return out


def R8sto(ip, hs=(), ls=(), **f):
    return KH.R8.sto(ip, hs, ls, **f)


def ev_snap(e):
    if e is NA or e is None:
        return None
    return tuple((k, str(e.f.get(k))) for k in ("su", "dir", "tf", "state", "reason", "flags", "trig", "pass", "fin", "pRef", "sl", "tp1", "tp2", "tp3", "rr", "grade", "bosMin", "baseMin", "touches", "pos", "grp"))


def nhom_vi_sai(src39=S39, n=120):
    """I-06 (gồm I-05): cùng dữ liệu, cùng trạng thái ban đầu; so đầu ra actionable từng nến giữa 0.3.8 (không SHADOW) và 0.3.9 (có SHADOW)."""
    R = random.Random(606)
    sai, dem = [], dict(nen=0, shadow_su_kien=0, shadow_dat=0, shadow_o_trong=0, su1_trig=0, su4_trig=0, dong_thoi=0, the_hien_max=0)
    for k in range(n):
        seed = R.randint(0, 10 ** 9)
        reg = R.choice((1, 2, 3, 4))
        outs = []
        for src, sd in ((S38, False), (src39, True)):
            r2 = random.Random(seed)
            pp = PIPE(src, sd)
            pp.ctx(reg)
            p = 2000.0
            for _ in range(r2.randint(1, 3)):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(2, 8), 1)
                pp.g["zones"].v.append(zone(pp.ip, 60, d, b0 - 2, b0 + 2, bm=pp.T // 60000 - r2.choice((600, 900)), pos=1))
            for _ in range(r2.randint(1, 4)):
                d = r2.choice((1, -1)); b0 = round(p - d * r2.uniform(1, 6), 1)
                pp.g["zones"].v.append(zone(pp.ip, 15, d, b0 - 1, b0 + 1, bm=pp.T // 60000 + r2.choice((15, 30, 60)), bs=r2.randint(0, 99), pos=1))
            for _ in range(r2.randint(0, 2)):
                d = r2.choice((1, -1))
                pp.g["s4"].v.append(K.obj(pp.ip, "S4", d=d, sd=-d, e=round(p - d * 6, 1), ln=round(p - d * 5, 1), rk=r2.choice((1, 2, 3)), dw=False, eq=False, c1=True, atrC=8.0, tS=1))
            cl = sorted(round(p + r2.uniform(-8, 8), 1) for _ in range(r2.randint(0, 3)))
            pp.g.update(cLo=PArr([c - 0.4 for c in cl]), cHi=PArr([c + 0.4 for c in cl]), cRank=PArr([r2.randint(1, 5) for _ in cl]))
            log_ = []
            for j in range(36):
                o = p; c = round(p + r2.gauss(0, 1.8), 1); h = round(max(o, c) + abs(r2.gauss(0, 0.7)), 1); l_ = round(min(o, c) - abs(r2.gauss(0, 0.7)), 1)
                m15 = j % 3 == 0
                b = dict(o=o, h=h, l=l_, c=c, m15=m15, ev=r2.choice((0, 0, 1, 2, 3, 4)) if m15 else 0, ref=round(p + r2.uniform(-3, 3), 1),
                         h1=(c, r2.choice((0, 3, 4)), r2.random() < 0.6) if (m15 and j % 12 == 0) else None, pend=r2.random() < 0.04)
                o_ = pp.bar(b)
                if sd:
                    shp = [x for x in o_["pick"] if x[0][1] in ("3", "5")]
                    idx = [q for q, x in enumerate(o_["pick"]) if x[0][1] in ("3", "5")]
                    if idx and (min(idx) < len(o_["pick"]) - len(idx) or len(o_["pick"]) > 3):
                        dem["vi_tri_sai"] = dem.get("vi_tri_sai", 0) + 1
                    dem["shadow_o_trong"] += len(shp)
                    dem["shadow_su_kien"] += len(pp.g["evS"].v)
                    dem["shadow_dat"] += sum(1 for e in pp.g["evS"].v if e.f["state"] == 17)
                    dem["the_hien_max"] = max(dem["the_hien_max"], len(pp.g["sh"].v))
                    if any(e.f["trig"] for e in pp.g["evS"].v) and o_["trig"]:
                        dem["dong_thoi"] += 1
                    o_["pick"] = [x for x in o_["pick"] if x[0][1] not in ("3", "5")]
                else:
                    dem["su1_trig"] += sum(1 for t in o_["trig"] if t[0][1] == "1")
                    dem["su4_trig"] += sum(1 for t in o_["trig"] if t[0][1] == "4")
                log_.append(o_)
                p = c
            outs.append(log_)
        dem["nen"] += 36
        for j, (a, b) in enumerate(zip(*outs)):
            if a != b:
                kd = [kk for kk in a if a[kk] != b[kk]]
                sai.append((k, j, kd))
                break
    return [("I-06", f"VI SAI 0.3.8 ↔ 0.3.9 trên {n} kịch bản × 36 nến (cùng dữ liệu, cùng trạng thái ban đầu): chạy nguyên văn ARMED SU-4 + SU-6 → SU-1 P1…P5 + S1 → SU-4 → S2a → [tiền-kích hoạt + M5 SHADOW chỉ ở 0.3.9] → ô Data Window/mainEv/portSlot/cnt14. So TỪNG NẾN: sự kiện SU-1/SU-4 (evs), trigger và S1 (trigE: SL/TP1/TP2/TP3/R:R/hạng/lý do), ứng viên cuối S2a (fins), trạng thái vùng MD-3, thể hiện SU-4, bar14/cnt14, passBuy/Sell, slotOverflow, mainEv, portSlot, SU-6, các ô Data Window actionable",
             "0 nến khác; SHADOW thực sự hoạt động (có sự kiện, có ĐẠT, có trigger đồng thời với SU-1/SU-4, có ô trống được điền)", dict(khac=sai[:3], thong_ke=dem),
             not sai and not dem.get("vi_tri_sai") and dem["shadow_su_kien"] > 0 and dem["shadow_dat"] > 0 and dem["shadow_o_trong"] > 0, "SOURCE-DERIVED (vi sai)")]
