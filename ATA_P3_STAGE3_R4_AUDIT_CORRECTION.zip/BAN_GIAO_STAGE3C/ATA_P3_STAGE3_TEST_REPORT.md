# ATA P3 · STAGE 3 · BÁO CÁO KIỂM THỬ – CORRECTION VÒNG 2

Sinh tự động từ kết quả của lần chạy này (không dùng kết quả cũ làm bằng chứng). Lệnh tái lập từ thư mục gốc gói: `python3 kiem_doc_lap/chay_doc_lap.py`.

## 1. Tổng hợp

| Bộ | Số test | Kết quả | Assertion thực chạy |
|---|---|---|---|
| Bộ ĐỘC LẬP (KD-*): kỳ vọng tính tay + oracle viết lại | 91 | BLOCKED 6 · NOT TESTED 1 · PASS 84 | 80.754 |
| Hồi quy: bộ Stage 3 trước (88 test, KHÔNG sửa) | 88 | BLOCKED 6 · FAIL 3 · NOT TESTED 3 · PASS 76 | (bộ cũ không đếm assertion) |
| Hồi quy: bộ Stage 3 gốc (22 test, KHÔNG sửa) qua shim harness | 22 | BLOCKED 4 · FAIL 2 · PASS 16 | — |
| Hồi quy: bộ 0.3.9 (56 test) + bộ 0.3.8 trên 0.3.9 – qua REG-02 | 56 + 82 | REG-02 = PASS: {"bo_038_tren_039": {"moi": "{'PASS': 67, 'BLOCKED': 5, 'FAIL': 9, 'NOT TESTED': 1}", "goc": "{'PASS': 67, 'BLOCKED': 5, 'FAIL': 9, 'NOT TESTED': 1}"}, "moi": {"PASS": 47, "BLOCKED": 7, "FAIL": 1, "NOT TESTED": 1}, "goc": {"PASS": 47, "BLOCKED": 7, "FAIL": 1,  | — |

Thời gian bộ độc lập: 78.3 s · Python 3.13.18.

SHA-256 module được kiểm: mo_phong_lenh.py `982e5894cd193f36…`, hop_dong.py `57d50a4aff8a5eb5…`, chi_so.py `7ae22509c8bf6e1c…`, may_trang_thai.py `8968afa389a88dcd…`, chuan_hoa.py `623b0fe35c605792…`, pipeline.py `051cadb39b21f2ba…`

SHA-256 oracle/vector/runner: oracle.py `71c2a90f24dc22ea…`, vector_vang.py `a2a2c250f3746558…`, chay_doc_lap.py `b5b2d57983f9da59…`

## 2. FAIL của hồi quy – đã phân loại (không sửa test cũ, không sửa expected)

- **OT-05** – lỗi thời do thay đổi có chủ đích của vòng này; test thay thế: xem KD-REG-S3 trong JSON.
- **OT-06** – lỗi thời do thay đổi có chủ đích của vòng này; test thay thế: xem KD-REG-S3 trong JSON.
- **HD-01** – lỗi thời do thay đổi có chủ đích của vòng này; test thay thế: xem KD-REG-S3 trong JSON.
  - OT-05: Nến hỏng SAU khi vào nay ghi INVALID_BAR_AFTER_FILL (tách trạng thái, P0-9) – thay bằng KD-GOLD-R1-BADBAR, KD-ORACLE-PROP
  - OT-06: Thời gian lùi/trùng sau khi vào nay ghi NON_MONOTONIC_TIME_AFTER_FILL – thay bằng KD-ORACLE-PROP, KD-SM-TRADE
  - HD-01: Fixture dựng tay thiếu sự kiện STEP (CREATED → ARMED) – máy trạng thái 1.2 bác đúng; thay bằng KD-HD-VALID, KD-SM-TABLE

Bộ 22 test gốc: chạy nguyên trạng dừng ở DUP-01 (tín hiệu mẫu không có emit_seq – thay đổi có chủ đích F2); với shim harness: HD-01 và E2E-01 cũ FAIL – lỗi thời, đã phân loại từ vòng trước.

## 3. Chi tiết bộ độc lập

### Golden giả lập (code được kiểm) (43)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-GOLD-R1-TP | PASS | 12 | R1 BUY chạm TP1 ở nến 2 | {"outcome": "TP1", "exit_price": 2010.0, "exit_ts": 60000600000, "r_gross": 2.0, "mfe": 2.0, "mae": -0.2, "held": 2, "gap": false, "conflict": false, "entry_price": 2000.0, "entry_ts": 60000000000, "r… |
| KD-GOLD-R1-SL | PASS | 6 | R1 BUY chạm SL ở nến 2; phía có lợi của nến thoát (1998) không tính | {"outcome": "SL", "exit_price": 1995.0, "r_gross": -1.0, "mfe": 0.6, "mae": -1.0, "held": 2} |
| KD-GOLD-R1-TPNULL | PASS | 7 | R1 TP1 null: giá lên 2050 không thoát; nến 2 chạm SL → SL, MFE 10 | {"outcome": "SL", "exit_price": 1995.0, "r_gross": -1.0, "mfe": 10.0, "mae": -1.0, "held": 2, "rr_entry": null} |
| KD-GOLD-R1-TIMEOUT | PASS | 7 | max_bars 3, không chạm → TIMEOUT tại Close nến 3 (R 0,1) | {"outcome": "TIMEOUT", "exit_price": 2000.5, "exit_ts": 60000900000, "r_gross": 0.1, "mfe": 0.2, "mae": -0.2, "held": 3} |
| KD-GOLD-R1-OPEN | PASS | 7 | max_bars 5, chỉ có 2 nến sau → OPEN (R tạm 0,1, không thoát) | {"outcome": "OPEN", "exit_price": null, "exit_ts": null, "r_gross": 0.1, "mfe": 0.2, "mae": -0.2, "held": 2} |
| KD-GOLD-R1-GAPSL | PASS | 7 | Gap: Open nến 1 = 1990 < SL → thoát tại Open, R −2 | {"outcome": "SL", "exit_price": 1990.0, "r_gross": -2.0, "mfe": 0.0, "mae": -2.0, "held": 1, "gap": true} |
| KD-GOLD-R1-GAPTP | PASS | 7 | Gap: Open nến 1 = 2015 > TP1 → thoát tại Open, R +3 | {"outcome": "TP1", "exit_price": 2015.0, "r_gross": 3.0, "mfe": 3.0, "mae": 0.0, "held": 1, "gap": true} |
| KD-GOLD-R1-GAPXA | PASS | 7 | Gap qua xa nhiều mức: Open 1900 → R −20 | {"outcome": "SL", "exit_price": 1900.0, "r_gross": -20.0, "mfe": 0.0, "mae": -20.0, "held": 1, "gap": true} |
| KD-GOLD-R1-SB-SL | PASS | 8 | Cùng nến chạm SL và TP1, mặc định sl_first → SL, cờ xung đột, MFE không lấy nến đó | {"outcome": "SL", "exit_price": 1995.0, "r_gross": -1.0, "mfe": 0.0, "mae": -1.0, "held": 1, "conflict": true, "gap": false} |
| KD-GOLD-R1-SB-TP | PASS | 7 | Cùng nến, biến thể độ nhạy tp_first → TP1, MFE 2, MAE −1,2 (Low 1994 đã qua SL) | {"outcome": "TP1", "exit_price": 2010.0, "r_gross": 2.0, "mfe": 2.0, "mae": -1.2, "held": 1, "conflict": true} |
| KD-GOLD-R1-NOLOOK | PASS | 5 | High/Low nến trigger (2020/1990) KHÔNG được dùng ở R1 → TIMEOUT | {"outcome": "TIMEOUT", "r_gross": 0.1, "mfe": 0.2, "mae": -0.2, "held": 4} |
| KD-GOLD-R1-COST | PASS | 3 | Chi phí 0,5 giá / rủi ro 5 → r_net = 2,0 − 0,1 = 1,9 | {"outcome": "TP1", "r_gross": 2.0, "r_net": 1.9} |
| KD-GOLD-R1-GAPLAST | PASS | 6 | max_bars 3, nến 3 (nến cuối) mở gap 1990 → SL gap tại nến 3, KHÔNG phải TIMEOUT | {"outcome": "SL", "exit_price": 1990.0, "r_gross": -2.0, "held": 3, "gap": true, "mae": -2.0} |
| KD-GOLD-R1-HITLAST | PASS | 5 | max_bars 3, chạm TP1 đúng nến 3 → TP1 giữ 3 | {"outcome": "TP1", "held": 3, "r_gross": 2.0, "mfe": 2.0, "mae": -0.2} |
| KD-GOLD-R1-HITAFTER | PASS | 4 | max_bars 3, chạm ở nến 4 → TIMEOUT tại nến 3 | {"outcome": "TIMEOUT", "held": 3, "exit_ts": 60000900000, "r_gross": 0.1} |
| KD-GOLD-R1-LASTTRIG | PASS | 5 | Trigger ở nến cuối → OPEN, giữ 0, R 0 | {"outcome": "OPEN", "held": 0, "r_gross": 0.0, "mfe": 0.0, "mae": 0.0} |
| KD-GOLD-R1-INVRISK | PASS | 5 | SL 2001 > P_ref → INVALID INVALID_RISK | {"outcome": "INVALID", "note": "INVALID_RISK", "r_gross": null, "mfe": null, "exit_price": null} |
| KD-GOLD-R1-TPWRONG | PASS | 2 | TP1 1990 dưới P_ref của BUY → INVALID TP_WRONG_SIDE | {"outcome": "INVALID", "note": "TP_WRONG_SIDE"} |
| KD-GOLD-R1-DIR0 | PASS | 2 | dir 0 → INVALID INVALID_SIGNAL | {"outcome": "INVALID", "note": "INVALID_SIGNAL"} |
| KD-GOLD-R1-BADBAR | PASS | 3 | Nến 1 hỏng (High < Low) sau khi đã vào → NO_DATA INVALID_BAR_AFTER_FILL | {"outcome": "NO_DATA", "note": "INVALID_BAR_AFTER_FILL", "r_gross": null} |
| KD-GOLD-R2-A-E | PASS | 9 | R2 A+E: Open 2003 giữa ET và TP1 → khớp, rủi ro TĂNG 5 → 8, TP1 → R 7/8; rr_entry 0,875 | {"outcome": "TP1", "entry_price": 2003.0, "entry_ts": 60000300000, "exit_price": 2010.0, "r_gross": 0.875, "mfe": 0.875, "mae": -0.125, "held": 2, "rr_entry": 0.875} |
| KD-GOLD-R2-B-F | PASS | 7 | R2 B+F: Open 1997 giữa ET và SL → khớp, rủi ro GIẢM 5 → 2, TP1 → R 6,5 | {"outcome": "TP1", "entry_price": 1997.0, "r_gross": 6.5, "mfe": 6.5, "mae": -0.5, "held": 2, "rr_entry": 6.5} |
| KD-GOLD-R2-C | PASS | 8 | R2 C/H: Open 1994 vượt SL → NO_FILL GAP_BEYOND_SL (giá vào không còn hợp lệ) | {"outcome": "NO_FILL", "note": "GAP_BEYOND_SL", "entry_ts": 60000300000, "entry_price": 1994.0, "r_gross": null, "mfe": null, "exit_price": null, "held": 0} |
| KD-GOLD-R2-C-EQ | PASS | 2 | R2: Open đúng bằng SL 1995 → NO_FILL GAP_BEYOND_SL (rủi ro 0) | {"outcome": "NO_FILL", "note": "GAP_BEYOND_SL"} |
| KD-GOLD-R2-D | PASS | 3 | R2 D: Open 2015 vượt TP1 → NO_FILL GAP_BEYOND_TP | {"outcome": "NO_FILL", "note": "GAP_BEYOND_TP", "entry_price": 2015.0} |
| KD-GOLD-R2-D-EQ | PASS | 2 | R2: Open đúng bằng TP1 2010 → NO_FILL GAP_BEYOND_TP | {"outcome": "NO_FILL", "note": "GAP_BEYOND_TP"} |
| KD-GOLD-R2-G | PASS | 3 | R2 G: RR tại giá vào 0,875 < 1,5 → VẪN khớp (R2 không chạy lại S1 – ASSUMPTION), ghi rr_entry | {"outcome": "OPEN", "rr_entry": 0.875, "entry_price": 2003.0} |
| KD-GOLD-R2-I | PASS | 6 | R2 I: TP1 null, Open 2003 → nến 2 chạm SL → R = (1995 − 2003)/8 = −1 | {"outcome": "SL", "r_gross": -1.0, "mfe": 0.125, "mae": -1.0, "held": 2, "rr_entry": null} |
| KD-GOLD-R2-J | PASS | 4 | R2 J: không có nến kế → NO_DATA NO_NEXT_BAR (thiếu dữ liệu, KHÔNG phải NO_FILL) | {"outcome": "NO_DATA", "note": "NO_NEXT_BAR", "entry_ts": 60000000000, "entry_price": null} |
| KD-GOLD-R2-K | PASS | 2 | R2 K: hình học hỏng (SL trên P_ref) → INVALID trước mọi xử lý giá vào | {"outcome": "INVALID", "note": "INVALID_RISK"} |
| KD-GOLD-R2-L | PASS | 2 | R2 L: nến kế hỏng (giá ≤ 0) → NO_DATA INVALID_BAR (chưa vào) | {"outcome": "NO_DATA", "note": "INVALID_BAR"} |
| KD-GOLD-R2-M | PASS | 5 | R2 M: khớp 2003, nến 2 mở 1980 (qua SL rất xa) → SL gap tại 1980, R −2,875 | {"outcome": "SL", "exit_price": 1980.0, "r_gross": -2.875, "gap": true, "held": 2} |
| KD-GOLD-R2-N | PASS | 5 | R2 N: nến đầu đánh giá = nến vào (Open là giá vào, không phải gap); nến 2 mở 2012 > TP1 → TP1 gap R 1,125 | {"outcome": "TP1", "exit_price": 2012.0, "r_gross": 1.125, "gap": true, "held": 2} |
| KD-GOLD-R2-O | PASS | 4 | R2 O: max_bars 2, nến cuối mở gap 1990 → SL gap R −1,625 (không TIMEOUT) | {"outcome": "SL", "r_gross": -1.625, "held": 2, "gap": true} |
| KD-GOLD-R2-ENTRYBAR | PASS | 4 | R2: nến vào chạm TP1 trong nến (sau Open) → TP1 giữ 1, không gap | {"outcome": "TP1", "held": 1, "gap": false, "r_gross": 1.5} |
| KD-GOLD-S-R1-TP | PASS | 6 | R1 SELL chạm TP1 1990 ở nến 2 | {"outcome": "TP1", "exit_price": 1990.0, "r_gross": 2.0, "mfe": 2.0, "mae": -0.2, "held": 2} |
| KD-GOLD-S-R1-GAPSL | PASS | 5 | R1 SELL: Open 2010 > SL → SL gap R −2 | {"outcome": "SL", "exit_price": 2010.0, "r_gross": -2.0, "mae": -2.0, "gap": true} |
| KD-GOLD-S-R2-B | PASS | 7 | R2 SELL: Open 2003 giữa ET và SL → rủi ro 2, TP1 → R 6,5 | {"outcome": "TP1", "entry_price": 2003.0, "r_gross": 6.5, "mfe": 6.5, "mae": -0.5, "held": 2, "rr_entry": 6.5} |
| KD-GOLD-S-R2-D | PASS | 2 | R2 SELL: Open 1988 vượt TP1 → NO_FILL GAP_BEYOND_TP | {"outcome": "NO_FILL", "note": "GAP_BEYOND_TP"} |
| KD-GOLD-S-SB-TP | PASS | 5 | SELL cùng nến, tp_first → TP1, MAE (2000 − 2006)/5 = −1,2 | {"outcome": "TP1", "r_gross": 2.0, "mfe": 2.0, "mae": -1.2, "conflict": true} |
| KD-GOLD-S-SB-SL | PASS | 5 | SELL cùng nến, sl_first → SL R −1, MFE 0 | {"outcome": "SL", "r_gross": -1.0, "mfe": 0.0, "mae": -1.0, "conflict": true} |
| KD-GOLD-S-TIMEOUT | PASS | 5 | SELL TIMEOUT tại Close 1999,5 → R 0,1 | {"outcome": "TIMEOUT", "r_gross": 0.1, "mfe": 0.2, "mae": -0.2, "held": 3} |
| KD-GOLD-EXTRA | PASS | 7 | Biên chính xác (tính tay): SL = P_ref → INVALID; Open = SL → SL gap R −1; Low = SL → SL; High = TP1 → TP1; MAE nến thoát TP1 có Low dưới giá vào (−0,6); trượt giá 0,25 → chi phí 0,5 → r_net 1,9 | 7 biên |

### Golden giả lập (oracle) (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-ORACLE-GOLD | PASS | 216 | Oracle độc lập khớp MỌI golden vector (xác nhận oracle trước khi dùng làm chuẩn so sánh) | 42 vector |

### Đối xứng BUY/SELL (2)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-MIRROR-GOLD | PASS | 924 | Mỗi golden BUY → ảnh gương SELL (giá → 4000 − giá): cùng kết cục, ghi chú, R, MFE, MAE, giữ, cờ, rr_entry; giá vào/thoát = 4000 − giá BUY; code và oracle | {"so_cap": 66, "so_lech": 0, "bo_qua_ngoai_mien": ["G-R2-L"]} |
| KD-MIRROR-PROP | PASS | 1 | Thuộc tính: 6.000 ca ngẫu nhiên (gap, TP1 null, R1/R2, sl/tp_first, max_bars 1…40, chi phí, khoảng trống thời gian, nến hỏng, rủi ro hỏng) – code: BUY vs ảnh gương SELL, MỌI trường; lưu mọi ca lệch | {"so_ca": 6000, "so_ca_lech": 0} |

### Oracle vs code (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-ORACLE-PROP | PASS | 2 | Thuộc tính: 8.000 ca ngẫu nhiên – code được kiểm và oracle độc lập cho KẾT QUẢ Y HỆT (kết cục, ghi chú, giá/thời điểm vào-thoát, R gross/net, MFE, MAE, giữ, cờ, rr_entry); lưu mọi ca lệch | {"so_ca": 8000, "so_ca_lech": 0, "phu_ket_cuc": {"OPEN": 1537, "SL": 1924, "TIMEOUT": 1489, "TP1": 1196, "NO_FILL": 667, "NO_DATA": 877, "INVALID": 310}} |

### R1/R2 không nhìn trước (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-R1-NOLOOK | PASS | 3132 | R1: đổi High/Low nến trigger (giữ Close) → kết quả y hệt; R1/R2: thay mọi nến SAU nến thoát bằng giá vô lý → y hệt; R2 không dùng nến trigger ngoài thời điểm (đổi O/H/L) → y hệt (2.000 ca) | 1962 ca |

### R1/R2 giá vào (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-ENTRY-RETRO | PASS | 3095 | Giá vào không đổi hồi tố: R1 entry = P_ref và entry_ts = nến trigger; R2 entry = Open nến kế, entry_ts = nến kế; với mọi lệnh đã vào (4.000 ca) | 3095 lệnh đã vào |

### Bootstrap (2)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-PCT | PASS | 4 | Phân vị đối xứng (tính tay): B = 10 → (0, 9); B = 30 → (0, 29); B = 70 → (1, 68); B = 2000 → (50, 1949) | 4 giá trị B |
| KD-BOOT | PASS | 7 | CI i.i.d. và moving-block: xác định theo seed; i.i.d. không phụ thuộc thứ tự; n < 2 → null; R hằng → suy biến; L = round(n^(1/3)); chuỗi tự tương quan mạnh → CI khối rộng hơn i.i.d.; mọi giá trị hữu hạn | {"iid": [0.1, 0.85], "khoi_L10": [-0.5, 1.5], "ghi_chu": "chỉ kiểm cơ chế – không phải bằng chứng thống kê thị trường"} |

### Máy trạng thái (4)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-SM-TRADE-NEG | PASS | 4 | Vòng đời lệnh – vi phạm dựng tay: R2 vào TẠI nến trigger, R1 vào sau trigger, NO_FILL tại nến trigger → bị bắt | 4 ca |
| KD-SM-TABLE | PASS | 19 | Bảng chuyển tiếp: 9 chuỗi hợp lệ → 0 lỗi; 10 chuỗi không hợp lệ (CREATED→ARMED, STEP→STEP, CREATED→TRIGGER, sau kết thúc, SKIP ở SU-3, END ở SU-5, không có CREATED, 2 CREATED, ARMED→STEP, TRIGGER→VOID) → bắt hết | {"hop_le": 9, "khong_hop_le": 10} |
| KD-SM-ENGINE | PASS | 2 | Đầu ra engine thật (khối Pine nguyên văn qua adapter): 40 seed SYNTH + kịch bản SU-3 định hướng → mọi chuyển tiếp thuộc bảng; thống kê chuyển tiếp quan sát được | {"chuyen_tiep_quan_sat": {"(bắt đầu)→CREATED": 1290, "CREATED→STEP": 469, "CREATED→VOID": 627, "STEP→END_NO_EVENT": 185, "STEP→ARMED": 200, "ARMED→VOID": 92, "ARMED→TRIGGER": 97, "STEP→EXPIRED": 15, "… |
| KD-SM-TRADE | PASS | 5008 | Vòng đời lệnh: mọi đầu ra của code (5.000 ca) thỏa máy trạng thái lệnh; 8 vi phạm dựng tay (vào trước trigger, thoát trước vào, NO_FILL ở R1, OPEN có thoát, TIMEOUT không thoát, đã vào thiếu giá vào, lệnh cho tín hiệu bị bỏ, ghi chú lạ) đều bị bắt | {"hop_le": 5000, "vi_pham_bat": 8} |

### Khử trùng (3)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-DUP-GOLD | PASS | 6 | Golden: cùng symbol/setup/chiều/nến → trùng (giữ emit_seq nhỏ); khác chiều / khác setup / khác symbol / khác nến → KHÔNG trùng; tín hiệu bị bỏ (lý do 1) phát trước bản đạt S1 không che bản đạt S1 (F26) | ok |
| KD-DUP-PROP | PASS | 8000 | Thuộc tính: 800 tập ngẫu nhiên (va chạm thời điểm, chéo symbol/setup/chiều) × 5 lần xáo trộn → tập giữ = oracle (min emit_seq mỗi khóa), không phụ thuộc thứ tự đầu vào | 800 × 5 |
| KD-DUP-SEED | PASS | 2 | Va chạm chéo seed: gộp 2 lượt replay KHÔNG tiền tố → bộ kiểm cấp bảng báo trùng emit_seq/ID; pipeline gộp có tiền tố seed → phễu 'trùng' = số khử trùng thật | {"loi_gop": ["EVENTS: trùng emit_seq", "EVENTS: emit_seq 0 có ts_ms nhỏ hơn emit_seq 0"], "trung": 4, "trung_s1": 0} |

### Lọc danh mục (2)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-OCC-GOLD | PASS | 16 | Golden: NO_FILL/NO_DATA/INVALID không chiếm; OPEN chiếm tới hết; TP1/SL/TIMEOUT giải phóng sau thoát; vào ĐÚNG thời điểm thoát → bỏ (quy ước bảo thủ); vào sau → giữ; chéo symbol/setup không chặn; cùng thời điểm vào → theo emit_seq rồi signal_id | 7 ca |
| KD-OCC-PROP | PASS | 8000 | Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ 7 kết cục, va chạm biên, chéo khóa) × 4 lần xáo trộn → thỏa P1–P4 của oracle và đầu ra không phụ thuộc thứ tự | 1.000 × 4 |

### Hợp đồng dữ liệu (2)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-HD-MUT | PASS | 85 | 28 loại đột biến trên bộ hợp lệ dựng tay (BUY và SELL, có/không TP1) – mỗi đột biến vi phạm hợp đồng THEO CẤU TRÚC → bộ kiểm phải bác 100 % | {"so_dot_bien": 82, "lot": []} |
| KD-HD-VALID | PASS | 8 | Không báo nhầm: 8 bộ hợp lệ (BUY, SELL, TP1 null, R2 NO_FILL, R2 khớp, OPEN, NO_DATA sau khi vào, INVALID) → 0 lỗi | 8 bộ |

### JSON strict (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-JSON | PASS | 5 | Mọi file .json trong các thư mục kết quả/bàn giao parse được ở chế độ strict (không NaN/Infinity/−Infinity); mọi lệnh json.dump trong module Stage 3 mới dùng allow_nan=False; PF không có lỗ → null + trạng thái | {"so_file_json": 18, "khong_strict_lich_su": ["ket_qua_shadow_eval/ket_qua.json", "ket_qua_shadow_eval/ket_qua_truoc_sua.json"], "lenh_dump": {"pipeline.py:23": true, "kiem_thu_stage3.py:1041": true, … |

### Golden chỉ số (16)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-MET-ZERO | PASS | 22 | 0 lệnh đóng (chỉ OPEN, NO_FILL, NO_DATA, INVALID) | {"dong": 0, "net_r": 0.0, "expectancy": null, "win_rate": null, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THANG_THUA", "ty_le_tp1": null, "mo": 1, "khong_khop": 1, "khong_du_lieu": 1, "kh… |
| KD-MET-1WIN | PASS | 14 | 1 lệnh thắng TP1 +2 | {"dong": 1, "net_r": 2.0, "expectancy": 2.0, "win_rate": 1.0, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THUA", "ty_le_tp1": 1.0} |
| KD-MET-1LOSS | PASS | 12 | 1 lệnh thua SL −1 | {"dong": 1, "expectancy": -1.0, "win_rate": 0.0, "profit_factor": 0.0, "pf_trang_thai": "OK", "thua": 1} |
| KD-MET-1BE | PASS | 14 | 1 lệnh hòa vốn TIMEOUT 0 | {"dong": 1, "hoa_von": 1, "win_rate": 0.0, "win_rate_khong_hoa": null, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THANG_THUA", "expectancy": 0.0} |
| KD-MET-WINONLY | PASS | 12 | Chỉ thắng: TP1 +2, TIMEOUT +1,5 | {"net_r": 3.5, "expectancy": 1.75, "win_rate": 1.0, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THUA", "ty_le_tp1": 0.5} |
| KD-MET-LOSSONLY | PASS | 10 | Chỉ thua: −1, −1, TIMEOUT −0,5 | {"net_r": -2.5, "expectancy": -0.8333333333333334, "win_rate": 0.0, "profit_factor": 0.0, "pf_trang_thai": "OK"} |
| KD-MET-BEONLY | PASS | 8 | Chỉ hòa vốn ×2 | {"hoa_von": 2, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THANG_THUA", "win_rate": 0.0} |
| KD-MET-WINLOSS | PASS | 10 | +2, −1, −1 → net 0, PF 1,0, win 1/3 | {"net_r": 0.0, "expectancy": 0.0, "profit_factor": 1.0, "win_rate": 0.3333333333333333, "win_rate_khong_hoa": 0.3333333333333333} |
| KD-MET-WINBE | PASS | 8 | +2, 0 → win 0,5; win không hòa 1,0; PF null | {"win_rate": 0.5, "win_rate_khong_hoa": 1.0, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THUA"} |
| KD-MET-LOSSBE | PASS | 6 | −1, 0 → win 0; win không hòa 0; PF 0 | {"win_rate": 0.0, "win_rate_khong_hoa": 0.0, "profit_factor": 0.0} |
| KD-MET-OPEN | PASS | 8 | OPEN không vào R: TP1 +2, OPEN +5 | {"dong": 1, "mo": 1, "net_r": 2.0, "expectancy": 2.0} |
| KD-MET-TIMEOUTWIN | PASS | 8 | TIMEOUT +0,5 là thắng nhưng không phải TP1; SL −1 | {"win_rate": 0.5, "ty_le_tp1": 0.0, "profit_factor": 0.5, "net_r": -0.5} |
| KD-MET-TP1NEG | PASS | 8 | TP1 sau chi phí −0,05 → thua, nhưng tỷ lệ TP1 = 1 | {"win_rate": 0.0, "thua": 1, "ty_le_tp1": 1.0, "profit_factor": 0.0} |
| KD-MET-TP1NULLMIX | PASS | 4 | Tín hiệu TP1 null kết thúc SL vẫn ở mẫu số tỷ lệ TP1: SL −1, TP1 +2 | {"ty_le_tp1": 0.5, "profit_factor": 2.0} |
| KD-MET-POSNET | PASS | 6 | Net dương: +3, −1 | {"net_r": 2.0, "expectancy": 1.0, "profit_factor": 3.0} |
| KD-MET-NEGNET | PASS | 4 | Net âm: +1, −1, −1 | {"net_r": -1.0, "profit_factor": 0.5} |

### Chỉ số (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-MET-PROP | PASS | 51780 | Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ kết cục, R = 0 đúng, chi phí âm sau TP1) – code = oracle trên mọi trường chung; tách nhóm (symbol, setup) không rò rỉ | 1.000 tập |

### Phễu (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-FUNNEL | PASS | 26 | Golden phễu có mẫu số KHÓA: tỷ lệ = tử / mẫu theo MAU_SO; mẫu = 0 → null; đếm NO_FILL / NO_DATA / INVALID / đã vào từ TRADES; SU-3 và SU-5 tách riêng | {"tao": 4, "armed": 2, "trigger": 4, "s1_dat": 2, "bo_quyen": 1, "bo_khac": 1, "trung": 1, "lenh_gia_lap": 5, "khong_khop": 1, "khong_du_lieu": 1, "khong_hop_le": 1, "da_vao": 2, "ty_le_armed": 0.5, "… |

### Baseline (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-BASELINE | PASS | 1 | SHA-256 tính TRỰC TIẾP trên source Pine 0.3.8 và 0.3.9 trùng giá trị chuẩn | {"v038": "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13", "v039": "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"} |

### Hồi quy (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-REG-S3 | PASS | 1 | Chạy LẠI bộ Stage 3 trước (kiem_thu_stage3.py, 88 test, gồm REG-01 = bộ cũ 22 test, REG-02 = bộ 0.3.9) KHÔNG sửa: mọi FAIL phải là assertion lỗi thời đã phân loại, có test thay thế | {"tom_tat": {"PASS": 76, "FAIL": 3, "BLOCKED": 6, "NOT TESTED": 3}, "fail": ["OT-05", "OT-06", "HD-01"], "phan_loai": {"OT-05": "Nến hỏng SAU khi vào nay ghi INVALID_BAR_AFTER_FILL (tách trạng thái, P… |

### Đột biến mã nguồn (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-MUT-SRC | PASS | 33 | Kiểm đột biến MÃ NGUỒN: 32 đột biến có chủ đích trên các module đã sửa (biên, quy ước nến thoát, F1/F2/F3/F10/F11/F12 tái phát, chi phí, nhìn trước…) – mỗi đột biến chạy tập test nhanh độc lập trong bản sao; đột biến sống sót được liệt kê | {"tong": 32, "bi_giet": 32, "song_sot": []} |

### BLOCKED (6)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-REAL-XAU-SU3 | BLOCKED | 0 | Đánh giá SU-3 dữ liệu thật XAUUSD | Không có OHLCV lịch sử có nguồn (mạng của công cụ tắt) và chưa có replay bối cảnh từ OHLCV |
| KD-REAL-XAU-SU5 | BLOCKED | 0 | Đánh giá SU-5 dữ liệu thật XAUUSD | Như trên |
| KD-REAL-BTC-SU3 | BLOCKED | 0 | Đánh giá SU-3 dữ liệu thật BTCUSD | Như trên |
| KD-REAL-BTC-SU5 | BLOCKED | 0 | Đánh giá SU-5 dữ liệu thật BTCUSD | Như trên |
| KD-REPLAY-EQ | BLOCKED | 0 | Tương đương Python ↔ TradingView | Không có dữ liệu đối chứng; Data Window chỉ giữ một phần sự kiện SHADOW (B-1) |
| KD-TV-TOKEN | BLOCKED | 0 | Token biên dịch thật 0.3.9 | TradingView không in số token khi compile thành công |

### NOT TESTED (1)

| ID | Trạng thái | Assertion | Mục tiêu | Thực tế (rút gọn) |
|---|---|---|---|---|
| KD-REPLAY-FULL | NOT TESTED | 0 | Replay toàn script từ OHLCV (f_struct, MD-3/4/5, request.security, ta.*) | Chưa hiện thực – ngoài phạm vi (không xây full Pine interpreter) |

## 4. Ca lệch đã lưu

`ca_lech` trong ket_qua_doc_lap.json: KD-MIRROR-PROP: 0 ca, KD-ORACLE-PROP: 0 ca

