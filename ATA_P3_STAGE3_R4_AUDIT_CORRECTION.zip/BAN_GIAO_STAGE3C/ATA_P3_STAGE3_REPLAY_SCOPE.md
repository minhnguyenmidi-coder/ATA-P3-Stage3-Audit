# ATA P3 · STAGE 3 · PHẠM VI REPLAY (D) – cập nhật Correction vòng 2

"Replay" ở đây nghĩa là chạy lại logic của engine bằng Python, ngoài TradingView. Phần lớn chạy bằng trình thông dịch Pine thu nhỏ (`pine_mini` + `Ip39`), thực thi **nguyên văn** từng khối code Pine của 0.3.9.

Các nhãn dùng trong báo cáo:

- **VERIFIED**: khối chạy nguyên văn, có test xác định với kỳ vọng độc lập.
- **PARTIALLY VERIFIED**: chạy được, nhưng có phần được giản lược hoặc theo quy ước.
- **NOT IMPLEMENTED**: chưa có trong Python.
- **UNSUPPORTED**: trình thông dịch không hỗ trợ.
- **NOT TESTED**: có thể chạy nhưng chưa có test.

## 1. Bảng phạm vi

| Thành phần | Trạng thái | Bằng chứng / ghi chú |
|---|---|---|
| Khối SHADOW tiền-kích hoạt M15/H1 (0.3.9, từ dòng 2808) – tạo thể hiện SU-3/SU-5, hết hạn | VERIFIED | kiem_su3_su5 S3-01…16, S5-01…12 (bộ 0.3.9); RP-04 |
| Khối SHADOW trên M5 (bước 3–5, P4, H*/L*, trigger, f_shS1) | VERIFIED | S3-11, S3-12, S5-*; RP-04 (SL 1991,4 = công thức độc lập) |
| Cách ly SHADOW khỏi actionable | VERIFIED | I-01…I-06 bộ 0.3.9 (400 × 36 nến, 0 khác) |
| SU-1 P1–S1, SU-4, S2a, ARMED/SU-6 (đoạn pipeline) | VERIFIED (theo bộ 0.3.8/0.3.9) | kiem_cach_ly PIPE + hồi quy |
| MD-4 khối cụm, MD-5 (md5_song_song), f_ledger, dashboard dòng 11 | VERIFIED (các bộ trước) | hoi_quy034/035/038 |
| Sổ (X-0…X-4, f_ledger) trong driver PIPE | PARTIALLY VERIFIED | PIPE dùng chỉ số sổ giản lược (ứng viên đầu tiên) – F23; SHADOW không đọc sổ |
| Adapter engine → hợp đồng (chuan_hoa.BoGhi) – sự kiện evS (ARMED/SKIP/EXPIRED/VOID/TRIGGER) | VERIFIED | RP-02: số sự kiện evS thô = số sự kiện engine trong EVENTS, adapter không đổi đầu ra engine (15 seed) |
| Adapter – sự kiện suy ra (CREATED/STEP/END_NO_EVENT) | PARTIALLY VERIFIED | Engine không phát ra các sự kiện này; adapter suy ra bằng cách so mảng sh. **Vòng 2 (F28):** adapter cũ bỏ sót STEP khi st đổi cùng nến tạo/kết thúc/ARMED (221 vi phạm máy trạng thái); đã sửa, đầu ra 40 seed nay 0 vi phạm (KD-SM-ENGINE). Thứ tự STEP trong nến vẫn là QUY ƯỚC (đứng trước sự kiện engine của cùng thể hiện). Ghép sự kiện khi IP-21 trùng khóa vẫn mơ hồ (249 lần) – không coi là FACT |
| emit_seq của TRIGGER/SIGNAL (thứ tự thật trong evS) | VERIFIED | DUP-04, RP-05, KD-DUP-SEED |
| Máy trạng thái vòng đời (may_trang_thai.py) trên đầu ra engine | VERIFIED (SYNTH) | KD-SM-ENGINE: 10 loại chuyển tiếp quan sát được, đều thuộc bảng; CREATED→ARMED không còn xuất hiện |
| MTF D/W/M/12M (request.security lấy giá kỳ, dòng 1716–1719) | UNSUPPORTED | pine_mini không có request.security |
| Data Window (ô Ô1–Ô3, K.5) | PARTIALLY VERIFIED trong PIPE; đối chiếu TV: BLOCKED | Chỉ một phần sự kiện SHADOW (B-1) |
| Replay xác định (cùng seed → cùng kết quả) | VERIFIED | RP-01 (2 tiến trình riêng, 10 seed) |
| Bối cảnh từ OHLCV: f_struct (swing, BOS/CHoCH, MSS, vùng) | NOT IMPLEMENTED | Bối cảnh hiện được **tiêm** vào (SYNTH) |
| request.security (M15/H1/H4/D, D/W/M/12M) và lookahead/gaps | UNSUPPORTED | pine_mini không có |
| ta.* (ATR, pivot…) | UNSUPPORTED | ATR được tiêm làm tham số |
| MD-3 dựng vùng từ dữ liệu, MD-4 cụm từ dữ liệu, MD-5 pool từ dữ liệu | NOT IMPLEMENTED | — |
| Toán tử lịch sử cho biến người dùng | UNSUPPORTED | Ip39 chỉ có cho open/high/low/close/time |
| `%` với số âm | UNSUPPORTED (ngữ nghĩa Python) | F22; không có trong khối đã verify |
| Replay toàn script trên dữ liệu thật | NOT IMPLEMENTED | Ngoài phạm vi nhiệm vụ ("không tự xây full Pine interpreter") |
| Tương đương Python ↔ TradingView (REPLAY-EQ) | BLOCKED | Chưa có dữ liệu đối chứng. Data Window chỉ giữ một phần sự kiện SHADOW (B-1) |
| Kịch bản SU-3 trigger trên SYNTH ngẫu nhiên | NOT TESTED (không sinh được) | SYNTH ngẫu nhiên không tạo được trigger SU-3; được lấp bằng kịch bản có định hướng (RP-04, E2E-02) |

## 2. Đầu-cuối trong phạm vi

Chuỗi đầu-cuối SYNTH chạy đủ các bước sau và qua bộ kiểm cấp bảng với 0 lỗi (E2E-01, E2E-02, HD-10, HD-11):

khối Pine nguyên văn → adapter → EVENTS/SIGNALS → khử trùng (emit_seq) → giả lập → TRADES → kiểm hợp đồng → chỉ số/phễu

Đây chỉ là bằng chứng về **cơ chế**. Bối cảnh SYNTH được tiêm ngẫu nhiên nên **không** dùng để đánh giá hiệu quả chiến lược.

## 3. Hệ quả

Đánh giá trên thị trường thật bị BLOCKED vì **hai lý do độc lập**:

1. Chưa có dữ liệu OHLCV lịch sử.
2. Chưa có replay tính bối cảnh từ OHLCV.

Khi có dữ liệu, bước 1–3 của pipeline chạy được ngay (đã kiểm bằng DL-09). Bước 4 vẫn BLOCKED cho tới khi một trong hai điều sau xảy ra:

- (a) có replay toàn script; hoặc
- (b) chủ dự án chọn một nguồn sự kiện khác, ví dụ xuất sự kiện từ chính TradingView. Lựa chọn này đụng tới token và tới K.5, nên do chủ dự án quyết.
