# ATA P3 · STAGE 3 · BÁO CÁO SỬA LỖI – CORRECTION VÒNG 2 (INDEPENDENT AUDIT & CORRECTION)

Ngày: 2026-11-20 · Phạm vi: các module Stage 3 nằm ngoài Pine.

Baseline Pine được tính SHA-256 trực tiếp, trước và sau lượt chạy:
- 0.3.8: `79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13`
- 0.3.9: `2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0`

Cả hai **không đổi**. Không sửa Pine, không sửa logic SU-3/SU-5, không promote setup nào.

Tài liệu đi kèm:
- Ma trận finding đầy đủ: `ATA_P3_STAGE3_FINDINGS_MATRIX.csv` (149 dòng: 39 finding + 22 test bộ gốc + 88 test Stage 3).
- Kết quả test: `ATA_P3_STAGE3_TEST_REPORT.md`.

## 1. Kiến trúc kiểm độc lập (mục 21 của chỉ thị)

| Thành phần | File | Tính độc lập |
|---|---|---|
| Oracle giả lập, chỉ số, danh mục, khử trùng | `kiem_doc_lap/oracle.py` | Viết lại từ đặc tả. Không import shadow_eval. Cấu trúc khác: SELL được quy về BUY bằng đổi dấu giá nên chỉ có một nhánh logic. MFE/MAE tính từ danh sách mẫu giá. Lọc danh mục được kiểm bằng tính chất P1–P4, không mô phỏng lại thuật toán |
| Golden vectors | `kiem_doc_lap/vector_vang.py` | 43 vector giả lập và 16 vector chỉ số, **tính tay**. Không import code được kiểm |
| Runner | `kiem_doc_lap/chay_doc_lap.py` | Đếm assertion thật; lưu mọi ca lệch; metadata đầy đủ; có kiểm đột biến mã nguồn |

Oracle được tự kiểm trước khi dùng làm chuẩn (KD-ORACLE-GOLD: khớp cả 43 golden). Sau đó code được kiểm và oracle cho kết quả **y hệt** trên 8.000 ca ngẫu nhiên phủ đủ 7 kết cục (KD-ORACLE-PROP: 0 ca lệch).

## 2. Finding mới của vòng này

Mọi finding mới đều có bằng chứng tái hiện trên bản trước sửa. Bản đó nằm ở `shadow_eval/_truoc_sua_v2/`; bằng chứng ở `kiem_toan_stage3/bang_chung_vong2.txt`.

| ID | Mức | Nội dung | Bằng chứng | Sửa | Test |
|---|---|---|---|---|---|
| F26 | P0 | Khử trùng chạy trước lọc S1: một bản trùng bị bỏ (lý do 1/2/8/9/14/15) phát ra trước sẽ che bản đạt S1 phát ra sau | Bản cũ chọn được 0 lệnh từ cặp [lý do 1 → lý do 16] | `pipeline.chon_tin_hieu_lenh`: lọc lý do 16 trước rồi mới khử trùng. Phễu 'trùng' vẫn tính trên mọi tín hiệu | KD-DUP-GOLD |
| F28 | P0 | Adapter bỏ sót sự kiện STEP khi st đổi trong cùng nến với lúc tạo, kết thúc (IP-20) hoặc ARMED | Adapter cũ: **221 vi phạm** máy trạng thái trên 40 seed (CREATED→END_NO_EVENT 185, CREATED→ARMED 35) | CREATED luôn ghi st 0; phát STEP cho các st trung gian trước sự kiện engine / kết thúc | KD-SM-ENGINE (0 vi phạm) |
| F29 | P0 | NO_DATA trước khi vào và sau khi vào bị gộp chung ghi chú (gộp hai trạng thái khác nhau) | Bản cũ: nến hỏng sau khi vào → `INVALID_BAR`, giống hệt trường hợp chưa vào | Thêm `INVALID_BAR_AFTER_FILL`, `NON_MONOTONIC_TIME_AFTER_FILL` | KD-GOLD-R1-BADBAR, KD-SM-TRADE |
| F32 | P0 | Lọc danh mục phụ thuộc thứ tự đầu vào khi hai lệnh trùng cả entry_ts lẫn emit_seq | [a, b] giữ a; [b, a] giữ b | Thêm khóa phụ signal_id | KD-OCC-GOLD, KD-OCC-PROP |
| F27 | THẤP | Harness REG-01 ghi JSON không strict | kiem_thu_stage3.py dòng 1041 | Thêm allow_nan=False | KD-JSON |
| F31 | ASSUMPTION | R2 không chạy lại S1 khi RR tại giá vào thực tế không đạt | G-R2-G: rr_entry 0,875 < 1,5 vẫn khớp | Giữ quy ước, ghi rõ. Thêm trường `rr_entry` để phân tích. Chủ dự án quyết | KD-GOLD-R2-G |
| F30 | KHÔNG PHẢI LỖI | Báo cáo cũ ghi SIM-05 "Expected 0 khác / Actual khác 0 / PASS" và chỉ thị coi đây là mâu thuẫn | Dòng 62 của kiem_thu_shadow_eval.py: actual = `f"khác {len(sai)}"`, assertion là `not sai`. "khác 0" nghĩa là 0 ca lệch | Không sửa code. Nhãn mới rõ nghĩa: `so_ca_lech`. Xác minh lại bằng golden gương (66 cặp) và 6.000 ca ngẫu nhiên | KD-MIRROR-GOLD, KD-MIRROR-PROP: **0 lệch** |
| F33 | LỊCH SỬ | ket_qua_truoc_sua.json chứa `Infinity` | CS-01 cũ | Giữ nguyên làm bằng chứng của F10 (đúng lỗi đã sửa) | KD-JSON |
| F34 | KHUYẾN NGHỊ | Công cụ cũ mo_hinh_token.py ghi JSON không strict | Dòng 49 | Không sửa vì là công cụ cũ và đầu ra hiện hữu hạn; dùng cong_token.py | KD-JSON |

Một điểm phát sinh khi chạy test, ghi lại cho minh bạch: kiểm gương golden phát hiện G-R2-L (nến giá 0) có ảnh gương hợp lệ (4000 − 0 > 0). Đây **không phải** lỗi bất đối xứng: phép gương chỉ là phép đối xứng trên miền giá dương. Vector này được loại khỏi kiểm gương và ghi rõ trong kết quả (`bo_qua_ngoai_mien`).

## 3. Quy ước đã khóa (FACT về code hiện tại; ASSUMPTION về thị trường)

**R1 (giữ nguyên).**
- Vào tại Close nến trigger, giá = P_ref, entry_ts = nến trigger.
- Chỉ đánh giá từ nến sau nến trigger.
- High/Low của nến trigger không được dùng (KD-R1-NOLOOK: 2.000 ca).
- Giá vào không bị đổi hồi tố (KD-ENTRY-RETRO).

**R2.** Vào tại Open nến kế. Bảng chuyển trạng thái:

| Điều kiện | Kết quả |
|---|---|
| Tín hiệu hỏng (dir ≠ ±1, giá không hữu hạn, SL sai phía hoặc bằng P_ref, TP1 sai phía) | INVALID |
| Không có nến kế | NO_DATA NO_NEXT_BAR |
| Nến kế hỏng | NO_DATA INVALID_BAR |
| Open ≤ SL (BUY) | NO_FILL GAP_BEYOND_SL |
| Open ≥ TP1 (BUY) | NO_FILL GAP_BEYOND_TP |
| Còn lại | FILL, rủi ro = (Open − SL)·dir; có thể lớn hơn hoặc nhỏ hơn rủi ro của tín hiệu |

- Nến vào được đánh giá High/Low sau Open.
- Gap thoát chỉ xét từ nến thứ hai trở đi.
- Mọi NO_FILL đều được **lưu** cùng lý do, không chiếm vị thế, không vào chỉ số lệnh đóng, nhưng được đếm trong phễu.
- Golden đủ 16 ca A–P cho BUY; SELL có golden viết tay riêng và golden gương.

**Cùng nến chạm SL và TP1.**
- Mặc định `sl_first`: chỉ là **giả định bảo thủ**, không khẳng định SL xảy ra trước.
- Luôn gắn cờ `same_bar_conflict`, kèm mã quy tắc trong `sim_rule`.
- `tp_first` chỉ dùng để đo độ nhạy, không phải kết quả lịch sử.

**MFE / MAE / R.**
- R = (giá thoát − giá vào)·dir / rủi ro. r_net = r_gross − (spread + phí + 2 × trượt giá) / rủi ro.
- Quy tắc nến thoát:

| Cách thoát | Quy tắc |
|---|---|
| Gap | Chỉ tính giá Open |
| SL trong nến | Bỏ phía có lợi; MAE = min(MAE, −1) |
| TP1 trong nến | MFE chặn tại TP1; phía bất lợi tính đủ |
| tp_first | MFE chặn tại TP1; phía bất lợi tính đủ |
| TIMEOUT / OPEN | Nến cuối tính đủ |
| R2 | Nến vào tính từ sau Open |

- Được kiểm bằng golden vector **và** oracle, không chỉ bằng bất biến.

**Máy trạng thái** (`shadow_eval/may_trang_thai.py`, chuyển tiếp dẫn dòng 0.3.9).

Sự kiện của thể hiện:

| Từ | Đến |
|---|---|
| (bắt đầu) | CREATED |
| CREATED | STEP, VOID, EXPIRED |
| STEP | ARMED, VOID, EXPIRED, SKIP (chỉ SU-5), END_NO_EVENT (chỉ SU-3) |
| ARMED | TRIGGER, VOID, EXPIRED |

TRIGGER, VOID, EXPIRED, SKIP và END_NO_EVENT là trạng thái kết thúc.

Vòng đời lệnh:
- SIGNAL(16) → INVALID
- SIGNAL(16) → NO_DATA (trước khi vào)
- SIGNAL(16) → NO_FILL (chỉ R2)
- SIGNAL(16) → FILL → OPEN, TP1, SL, TIMEOUT, hoặc NO_DATA (sau khi vào)

Không thêm trạng thái mới, không gộp trạng thái. CANCELLED không tồn tại trong engine nên không dùng.

**Lọc danh mục.**
- Theo (symbol, setup); không chặn chéo SU-3/SU-5, không chặn chéo XAUUSD/BTCUSD.
- NO_FILL, NO_DATA và INVALID không chiếm vị thế.
- OPEN chiếm vị thế tới hết dữ liệu. TP1, SL, TIMEOUT giải phóng vị thế sau thời điểm thoát.
- Vào đúng thời điểm thoát của lệnh trước thì bị bỏ (ASSUMPTION bảo thủ).
- Thứ tự xét: (entry_ts_ms, emit_seq, signal_id).
- Mỗi lượt replay được lọc riêng.

**Khử trùng.**
- dup_key = symbol|setup|dir|trigger_ts_ms.
- Giữ bản có emit_seq nhỏ nhất. Thiếu, trùng emit_seq hoặc emit_seq kiểu bool thì báo lỗi, không tự sinh emit_seq.
- Để chọn lệnh: chỉ khử trùng trong nhóm tín hiệu đạt S1 (F26).
- **Giới hạn IP-21:** thứ tự giữa các thể hiện trùng khóa không phải FACT (249 lần ghép mơ hồ trên 40 seed; các ứng viên giống hệt nhau về khóa và hệ quả).

**Chỉ số** (`chi_so.py`, golden 16 vector).
- Mẫu = lệnh đóng TP1, SL, TIMEOUT; dùng r_net.
- Thắng: r > 1e-9; thua: r < −1e-9; còn lại là hòa vốn.
- win_rate = thắng / lệnh đóng; win_rate_khong_hoa = thắng / (thắng + thua).
- Tỷ lệ TP1 = số kết cục TP1 / lệnh đóng; tín hiệu TP1 null vẫn nằm trong mẫu số.
- Net R = tổng r_net. Expectancy = Net R / lệnh đóng.
- PF = tổng lời / |tổng lỗ|. Không có lệnh lỗ: PF = null kèm trạng thái KHONG_CO_LENH_THUA (có lời) hoặc KHONG_CO_LENH_THANG_THUA (không có lời lẫn lỗ).
- OPEN, NO_FILL, NO_DATA, INVALID chỉ được đếm, không vào chỉ số.

**Phễu.** Mẫu số được khóa trong `chi_so.MAU_SO`, dùng chung cho dashboard và báo cáo. Mẫu số = 0 thì tỷ lệ là null. Có thêm đếm NO_FILL, NO_DATA, INVALID và số lệnh đã vào từ bảng TRADES.

**Bootstrap.**
- Mốc tham chiếu: i.i.d.
- Độ nhạy: moving-block vòng theo entry_ts, độ dài khối L = round(n^(1/3)).
- Ghi rõ phương pháp, tổng thể, n, B, seed, độ tin cậy và giới hạn trong trường `phuong_phap_ci`.
- Chưa có dữ liệu thật, nên không có tuyên bố thống kê nào về thị trường.

**JSON strict.** Mọi lệnh `json.dump` trong module mới đều dùng allow_nan=False. 18 file JSON được kiểm ở chế độ strict. Chỉ 2 hiện vật lịch sử chứa Infinity (đúng bằng chứng F10).

## 4. Trả lời mục 24 của chỉ thị

**A. Lỗi đã xác nhận:**
- Vòng 1: F1–F21 (gồm F10b) và F25.
- Vòng 2: F26, F27, F28, F29, F32.

**B. Lỗi đã sửa:** tất cả lỗi ở mục A.

**C. Lỗi chưa sửa:** không có lỗi code nào còn mở. Các mục giữ nguyên có chủ đích:
- F31: ASSUMPTION về quy ước R2, chờ chủ dự án.
- F34: khuyến nghị cho công cụ cũ.
- B-1…B-4: quan sát về Pine; không sửa theo chỉ thị.

**D. Không phải lỗi:**
- F30: "mâu thuẫn" SIM-05.
- G-R2-L trong kiểm gương: ngoài miền phép gương.
- F22: không ảnh hưởng khối đã kiểm chứng.

**E. Finding BLOCKED:**
- B-1 / REPLAY-EQ.
- F24 / replay toàn script (NOT TESTED / NOT IMPLEMENTED).
- Đánh giá thị trường thật.
- Token thật.

**F–J. Test đã chạy** (đều chạy thực trong lượt này):

| Bộ | PASS | FAIL | BLOCKED | NOT TESTED |
|---|---|---|---|---|
| Bộ độc lập, 91 test | 84 | 0 | 6 | 1 |
| Hồi quy Stage 3, 88 test | 76 | 3 | 6 | 3 |
| Bộ 22 test gốc (qua shim) | 16 | 2 | 4 | 0 |

- 3 FAIL của hồi quy Stage 3 và 2 FAIL của bộ 22 test gốc đều là assertion lỗi thời đã phân loại, có test thay thế.
- Bộ 0.3.9 không đổi (REG-02 PASS).

**K. Số assertion thực tế:** 80.754 trong bộ độc lập.

**L. Hồi quy:**
- 88 + 22 test chạy lại, không sửa test.
- Bộ 0.3.9 (56 test) và bộ 0.3.8 trên 0.3.9 (82 test) được so từng test với lần gốc.

**M. Kiểm đột biến:**
- Mã nguồn: 32 đột biến, **32 bị giết**, 0 sống sót. Lần chạy đầu có 10 đột biến sống sót; tôi bổ sung test biên tính tay cho đúng các lỗ đó rồi chạy lại.
- Hợp đồng dữ liệu: 82 đột biến (28 loại × 3 bộ dữ liệu, trừ các ca không áp dụng), 0 lọt.
- Đột biến theo bản trước sửa: MUT-01…05 vẫn PASS.

**N. BUY/SELL:** không có lệch. Golden gương 66 cặp: 0 lệch. Thuộc tính 6.000 ca: 0 lệch. SELL viết tay 7 vector: đều PASS.

**O. R2 gap / NO_FILL:** xác minh bằng golden A–P (BUY) cộng SELL, oracle độc lập (8.000 ca, có R2), máy trạng thái lệnh (5.000 ca), lọc danh mục và phễu.

**P. MFE / MAE / R:** golden tính tay cho mọi nhánh, oracle cấu trúc khác cho kết quả y hệt, đột biến quy ước nến thoát đều bị giết.

**Q. Hợp đồng dữ liệu:** kiểm ở cấp bản ghi và cấp bảng, cộng máy trạng thái. Đột biến có phán quyết biết trước trên bộ dữ liệu dựng tay, độc lập pipeline. 8 bộ hợp lệ: không báo nhầm.

**R. Chỉ số:** 16 golden tính tay, so với cả code lẫn oracle; 1.000 tập ngẫu nhiên cho code = oracle.

**S. Baseline Pine có bị thay đổi?** Không.

**T. Hash tính trực tiếp:**
- Baseline, module, oracle: ghi trong ket_qua_doc_lap.json.
- Mọi file trong gói: ghi trong ATA_P3_STAGE3_MANIFEST_SHA256.txt.

**U. Đánh giá dữ liệu thật:** **chưa thực hiện, BLOCKED**.
- Proxy mạng chặn nguồn dữ liệu. Log: `ket_qua_stage3/log/thu_mang_du_lieu_that.txt`, Binance và Yahoo đều trả 403 CONNECT.
- Ngay cả khi lấy được Binance BTCUSDT, đó cũng không phải dữ liệu Exness BTCUSD.
- Ngoài ra replay bối cảnh từ OHLCV chưa được hiện thực.
- Đầu vào cần có: file M5 lịch sử XAUUSD/BTCUSD (xuất từ TradingView, hoặc MT5 Exness kèm độ lệch giờ máy chủ), và chủ dự án quyết nguồn sự kiện (Q-S3-1).

**V. Replay-equivalence:** chưa, BLOCKED (B-1).

**W. Token thật:** chưa biết. Chỉ có ước lượng, khoảng 95.929–99.807.

**X. Stage 3 đủ điều kiện kết thúc audit correction chưa?** Xem mục 5.

## 5. Cổng nghiệm thu (mục 25 của chỉ thị)

| Điều kiện | Trạng thái | Bằng chứng |
|---|---|---|
| Không còn P0 FAIL | ĐẠT | Bộ độc lập 0 FAIL; FAIL hồi quy đều là assertion lỗi thời đã phân loại |
| P0 có bằng chứng thực tế | ĐẠT | ket_qua_doc_lap.json + log |
| Không còn lệch BUY/SELL | ĐẠT | KD-MIRROR-* 0 lệch |
| R1/R2 có oracle | ĐẠT | KD-ORACLE-GOLD, KD-ORACLE-PROP |
| Vòng đời NO_FILL đã xác minh | ĐẠT | Golden R2-C/D, KD-SM-TRADE, KD-OCC-*, KD-FUNNEL |
| MFE/MAE/R đã xác minh | ĐẠT | Golden + oracle + đột biến |
| Lọc danh mục đã xác minh | ĐẠT | KD-OCC-GOLD, KD-OCC-PROP |
| Khử trùng và thứ tự đã xác minh | ĐẠT (giới hạn IP-21 đã công khai) | KD-DUP-* |
| Hợp đồng dữ liệu đã xác minh | ĐẠT | KD-HD-MUT, KD-HD-VALID |
| JSON strict | ĐẠT | KD-JSON |
| Golden chỉ số PASS | ĐẠT | 16/16 |
| Baseline Pine được bảo vệ | ĐẠT | KD-BASELINE |
| Manifest / hash đã kiểm | ĐẠT (xem log kiểm manifest trong gói) | ATA_P3_STAGE3_MANIFEST_SHA256.txt |
| Mọi BLOCKED được công khai | ĐẠT | 6 BLOCKED + 1 NOT TESTED |
| Không tuyên bố vượt bằng chứng | ĐẠT | Không có PASS nào cho thị trường thật, REPLAY-EQ hay token thật |
| Không promote SU-3/SU-5 | ĐẠT | — |

**Đề xuất:** phần **correction và verification trên SYNTH/golden** đủ điều kiện kết thúc.

Stage 3 **chưa thể được xác nhận hoàn tất** ở phần đánh giá thị trường thật, REPLAY-EQ và token thật: ba phần này vẫn BLOCKED vì thiếu dữ liệu, thiếu kênh đối chứng và thiếu khả năng replay toàn script.

Quyết định chấp nhận thuộc chủ dự án và kiểm toán viên.
