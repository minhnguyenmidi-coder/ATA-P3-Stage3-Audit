# Cổng tiền MD-6 – hướng dẫn tái chạy kiểm thử

## Yêu cầu
- Python ≥ 3.10, chỉ dùng thư viện chuẩn. Cần lệnh `patch` (cho DIFF-01).
- Chạy từ thư mục gốc của gói, là thư mục chứa `cong_tien_md6/`, `src034a/`, `src033/`, `goi/`, `hoi_quy034/`, `BAN_GIAO_034a_NT/`, `BAN_GIAO_033/`.
- RV-01…RV-03 đọc gói nghiệm thu `ATA_P3_Build_0.3.4a_Nghiem_Thu.zip`. Đường dẫn mặc định là `/mnt/user-data/outputs/…`; đặt biến `ATA_ZIP_NT=<đường dẫn ZIP>` nếu để chỗ khác. Không có ZIP → ba test này ghi NOT TESTED, không bao giờ ghi PASS.

## Chạy
```
python3 cong_tien_md6/chay_cong_tien.py            # đầy đủ (≈ 6–8 phút, gồm RV-02 tái lập nghiệm thu 0.3.4a)
python3 cong_tien_md6/chay_cong_tien.py --nhanh    # bỏ RV-02 (≈ 2 phút) → RV-02 = NOT TESTED
ATA_TIEM_LOI=1 python3 cong_tien_md6/chay_cong_tien.py --nhanh   # kiểm bộ chạy: phải trả mã thoát 1
```

**Mã thoát:**
- 1 – có FAIL;
- 2 – không FAIL nhưng còn BLOCKED/NOT TESTED (kết quả bình thường của vòng này: 31 PASS / 0 FAIL / 9 BLOCKED / 1 NOT TESTED);
- 0 – tất cả PASS.

## Đầu ra (`cong_tien_md6/ket_qua/`)

| Tệp | Nội dung |
|---|---|
| `KET_QUA_KIEM_THU.csv/.json`, `NHAT_KY.txt` | Từng test: mục tiêu, kỳ vọng, thực tế, kết quả, nhãn, phương pháp, bằng chứng |
| `MA_TRAN_VAN_DE_CON_TREO.csv` | 35 vấn đề × 11 cột; cột "Trích dẫn đã kiểm" ghi mã tài liệu:dòng tìm được |
| `MA_TRAN_SANG_SAN_SANG_MD6.csv` | Thành phần → trạng thái → bằng chứng → phụ thuộc MD-6 → rủi ro → kết luận |
| `MA_TRAN_TV_BLOCKED.csv` | TV-02…TV-10, đối chiếu số hiệu cũ, phần đã tự kiểm, bằng chứng còn cần |
| `du_lieu_A07_tac_dong.csv/.json` | Tác động A-07 trên 10 chuỗi H4 giả lập (hạt giống 1–5 và 1001–1005) |
| `du_lieu_Q2_D16.csv/.json` | Đối xứng BUY ↔ SELL gương theo loại giá và mức spread (hạt giống 7) |
| `so_tai_lieu.json` | Sổ tài liệu, SHA-256, tài liệu thiếu |

## Thành phần

| Tệp | Vai trò |
|---|---|
| `tai_lieu.py` | Sổ tài liệu (bản chép trong `ho_so/`, SHA ở `ho_so/SHA256_HO_SO.txt`) và hàm kiểm trích dẫn nguyên văn |
| `van_de.py` | Danh mục vấn đề còn treo (dữ liệu của ma trận) |
| `md2_tham_chieu.py` | Mô hình tham chiếu MD-2 (D.1–D.3.1), có biến thể A-07 (`loai_p0` = hiện tại/PA2, `gom_p0` = PA1) |
| `md6_tham_chieu.py` | Mô hình tham chiếu MD-6 (C.1–C.6) – **chuẩn nghiệm thu khi viết MD-6** |
| `q2_mo_hinh.py` | Quy tắc giá A (Rev.4 6.3) và B (tóm tắt Rev.19 + diff PA-B) |
| `giai_ma_toan_ven.py` | Giải mã cột Data Window "TOÀN VẸN" cho CSV thật (TV-07) |
| `chay_cong_tien.py` | Bộ chạy tổng |

## Nguyên tắc
- Không sửa Pine baseline: BASE-01 kiểm SHA trước và sau.
- Diff chỉ được thử trên bản sao tạm.
- Dữ liệu giả lập luôn được khai báo; không dùng thay dữ liệu Exness/TradingView thật.
- Mô hình Python không phải TradingView runtime/Profiler; các mục chỉ xác minh được trên TradingView luôn ghi BLOCKED.
