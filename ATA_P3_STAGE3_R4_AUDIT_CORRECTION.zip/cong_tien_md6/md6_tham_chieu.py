# -*- coding: utf-8 -*-
"""
MÔ HÌNH THAM CHIẾU MD-6 – MARKET REGIME (P2-1.5.1 mục C.1–C.6), viết thẳng từ văn bản đặc tả, độc lập với mã Pine.
Chưa có mã Pine MD-6. Mô hình này là CHUẨN ĐỐI CHIẾU để dùng khi phát triển MD-6 (TC-RG01…TC-RG09, TC-RG11).
Tham số trong {} của đặc tả là giá trị đề xuất [ĐX], để mặc định đúng như văn bản.

Đầu vào mỗi nến H4 đã đóng: ST_H4 (UP/DOWN/NONE), EV_H4 (sự kiện MD-2), Close, ATR14_H4 (hoặc High/Low/Close để tự tính).
"""
import math

TRANS, UPT, DNT, RANGE, THIEU = "TRANSITION", "UPTREND", "DOWNTREND", "RANGE", "KHÔNG ĐỦ DỮ LIỆU"
UP, DOWN, NONE = 1, -1, 0
CHOCH = (3, 4)          # mã sự kiện CHoCH↑, CHoCH↓ (cùng mã với md2_tham_chieu); MSS được tính là CHoCH


def atr_wilder(H, L, C, n=14):
    """ATR theo ta.atr của Pine: RMA của True Range, giá trị đầu = SMA n TR đầu (ASSUMPTION khớp ta.atr/ta.rma)."""
    out, tr = [], []
    a = None
    for i in range(len(C)):
        t = H[i] - L[i] if i == 0 else max(H[i] - L[i], abs(H[i] - C[i - 1]), abs(L[i] - C[i - 1]))
        tr.append(t)
        if i < n - 1:
            out.append(None)
        elif i == n - 1:
            a = sum(tr) / n
            out.append(a)
        else:
            a = (a * (n - 1) + t) / n
            out.append(a)
    return out


def er(C, i, n=20):
    """Kaufman ER tại nến i: |C − C[n]| ÷ Σ_{k=0..n−1}|C[i−k] − C[i−k−1]|; mẫu số 0 → 0; thiếu dữ liệu → None."""
    if i - n < 0:
        return None
    den = sum(abs(C[i - k] - C[i - k - 1]) for k in range(n))
    return 0.0 if den == 0 else abs(C[i] - C[i - n]) / den


def vr(A, i, n=100):
    """VR = ATR14 ÷ trung bình cộng ATR14 của n nến gần nhất (gồm nến hiện tại); thiếu → None."""
    if i - n + 1 < 0 or any(A[k] is None for k in range(i - n + 1, i + 1)):
        return None
    m = sum(A[i - n + 1:i + 1]) / n
    return None if m == 0 else A[i] / m


def lop_vol(v, cuc=2.5, cao=1.5, thap=0.7):
    if v is None:
        return None
    if v >= cuc:
        return "VOL-CỰC"
    if v >= cao:
        return "VOL-CAO"
    if v <= thap:
        return "VOL-THẤP"
    return "VOL-THƯỜNG"


class MD6:
    def __init__(self, min_bars=120, er_lo=0.20, er_hi=0.30, t_win=6, n_er=20, n_vr=100):
        self.p = dict(min_bars=min_bars, er_lo=er_lo, er_hi=er_hi, t_win=t_win, n_er=n_er, n_vr=n_vr)
        self.REG, self.T_CNT, self.LAST_CHOCH = THIEU, 0, None
        self.da_khoi_tao = False
        self.n = 0

    def _co_ban(self, st, e, reg_truoc):
        lo, hi = self.p["er_lo"], self.p["er_hi"]
        if st == NONE or e < lo:
            return RANGE
        if e >= hi:
            return UPT if st == UP else DNT
        if reg_truoc == UPT and st == UP:
            return UPT
        if reg_truoc == DNT and st == DOWN:
            return DNT
        if reg_truoc == RANGE:
            return RANGE
        return TRANS

    def step(self, st, ev, e, v):
        """Một nến H4 đóng. e = ER_H4, v = VR_H4 (None nếu chưa đủ). Trả về (REG, T_CNT, LAST_CHOCH, lớp VOL)."""
        self.n += 1
        if ev in CHOCH:                                   # C.6: cập nhật mọi lúc, không phụ thuộc đủ dữ liệu
            self.LAST_CHOCH = UP if ev == 3 else DOWN
        if not self.da_khoi_tao:
            if self.n >= self.p["min_bars"] and e is not None and v is not None:
                self.REG = self._co_ban(st, e, TRANS)       # REG trước coi như TRANSITION
                self.T_CNT = 0
                self.da_khoi_tao = True
            else:
                self.REG = THIEU
            return self.REG, self.T_CNT, self.LAST_CHOCH, lop_vol(v)
        if ev in CHOCH:                                   # bước 1
            self.REG, self.T_CNT = TRANS, 1
        elif self.REG == TRANS and 1 <= self.T_CNT < self.p["t_win"]:   # bước 2
            self.T_CNT += 1
        else:                                             # bước 3
            self.T_CNT = 0
            self.REG = self._co_ban(st, e, self.REG)
        return self.REG, self.T_CNT, self.LAST_CHOCH, lop_vol(v)


def chay(ST, EV, C, A, **kw):
    m = MD6(**kw)
    out = []
    for i in range(len(C)):
        e = er(C, i, m.p["n_er"])
        v = vr(A, i, m.p["n_vr"])
        out.append(m.step(ST[i], EV[i], e, v))
    return out


def hieu_luc_M5(t_dong_H4, t_mo_M5):
    """D.4 / C.6: giá trị H4 có hiệu lực từ nến M5 đầu tiên có thời điểm mở ≥ thời điểm đóng nến H4."""
    return t_mo_M5 >= t_dong_H4
