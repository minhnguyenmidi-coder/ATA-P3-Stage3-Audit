# -*- coding: utf-8 -*-
"""
MÔ HÌNH THAM CHIẾU MD-2 (P2-1.5.1 mục D.1–D.3.1) – viết thẳng từ văn bản đặc tả, độc lập với mã Pine.
Một khung, nến đã đóng. Dùng cho: (1) kiểm A-07 bằng các TC của chính đặc tả; (2) định lượng tác động A-07 lên chuỗi sự kiện
và lên MD-6; (3) tái sử dụng khi phát triển MD-6 (đầu vào ST_H4, EV_H4).

Biến thể A-07 (tham số `a07`):
  "loai_p0"  – hành vi hiện tại của 0.3.4a (f_lowestSince/f_highestSince quét p₀+1 … b) = Phương án 2 (đính chính đặc tả)
  "gom_p0"   – đúng chữ D.3.1 nhánh dự phòng ("Low thấp nhất của các nến p₀ … b") = Phương án 1
Nhánh swing (p₀ < p ≤ b, C(p) ≤ b − 1) giống nhau ở cả hai biến thể.
Không mô hình hóa: LB_CAP = 499 và cờ lịch sử bị cắt của mã Pine (giới hạn lưu trữ), ATR/nhãn HH-LH, cờ FAILED, vùng MD-3.
"""
NONE, UP, DOWN = 0, 1, -1
EV_NONE, BOS_UP, BOS_DN, CHOCH_UP, CHOCH_DN = 0, 1, 2, 3, 4


class MD2:
    def __init__(self, N=3, a07="loai_p0"):
        assert a07 in ("loai_p0", "gom_p0")
        self.N, self.a07 = N, a07
        self.H, self.L, self.C = [], [], []
        self.st = NONE
        self.vSH, self.vSL = [], []          # swing hợp lệ: (mức, nến pivot p, C(p)) theo thứ tự xác nhận
        self.hSH, self.hSL = [], []          # mọi swing đã xác nhận (cho PROT)
        self.protL = self.protLB = self.protH = self.protHB = None
        self.ev_log = []                     # (c, sự kiện, mức phá, p0, PROT mới, nhánh 'swing'/'du_phong')
        self.st_log = []
        self._choch_truoc = True             # móc kiểm thử (đối chứng âm): False = xét BOS trước CHoCH (SAI so với D.3)

    # D.1 – pivot: High[p] lớn nhất trong [p − N, p + N]; bằng nhau → nến sớm nhất (bên trái bằng → loại; bên phải bằng → giữ)
    def _piv(self, p, hi):
        N, X = self.N, (self.H if hi else self.L)
        if p - N < 0 or p + N >= len(X):
            return False
        v = X[p]
        for i in range(1, N + 1):
            if (X[p - i] >= v) if hi else (X[p - i] <= v):
                return False
            if (X[p + i] > v) if hi else (X[p + i] < v):
                return False
        return True

    def _fallback(self, p0, b, low):
        a = p0 if self.a07 == "gom_p0" else p0 + 1
        best = bb = None
        for k in range(a, b + 1):                 # cũ → mới, so sánh nghiêm ngặt → nến sớm nhất khi bằng nhau
            v = self.L[k] if low else self.H[k]
            if best is None or (v < best if low else v > best):
                best, bb = v, k
        return best, bb

    def step(self, h, l, c):
        self.H.append(h); self.L.append(l); self.C.append(c)
        b = len(self.C) - 1
        # Bước 1: REF như cuối nến c − 1
        refH = self.vSH[-1] if self.vSH else None
        refL = self.vSL[-1] if self.vSL else None
        # Bước 2–3: sự kiện; CHoCH xét trước BOS
        ev = EV_NONE
        if self.st == UP:
            if self.protL is not None and c < self.protL:
                ev = CHOCH_DN
            elif refH and c > refH[0]:
                ev = BOS_UP
            if not self._choch_truoc and refL and c < refL[0]:
                ev = BOS_DN
        elif self.st == DOWN:
            if self.protH is not None and c > self.protH:
                ev = CHOCH_UP
            elif refL and c < refL[0]:
                ev = BOS_DN
        else:
            if refH and c > refH[0]:
                ev = BOS_UP
            elif refL and c < refL[0]:
                ev = BOS_DN
        # Bước 4: PROT (D.3.1). Lịch sử swing chưa gồm swing xác nhận tại b → C(p) ≤ b − 1
        if ev in (BOS_UP, CHOCH_UP):
            p0 = refH[1] if ev == BOS_UP else self.protHB
            cand = [(v, p) for (v, p, cp) in self.hSL if p0 is not None and p0 < p <= b and cp <= b - 1]
            if cand:
                v, p = min(cand, key=lambda x: (x[0], x[1]))
                self.protL, self.protLB, nh = v, p, "swing"
            else:
                self.protL, self.protLB = self._fallback(p0, b, True)
                nh = "du_phong"
            self.st = UP
            self.ev_log.append((b, ev, refH[0] if ev == BOS_UP else None, p0, self.protL, nh))
        elif ev in (BOS_DN, CHOCH_DN):
            p0 = refL[1] if ev == BOS_DN else self.protLB
            cand = [(v, p) for (v, p, cp) in self.hSH if p0 is not None and p0 < p <= b and cp <= b - 1]
            if cand:
                v, p = max(cand, key=lambda x: (x[0], -x[1]))
                self.protH, self.protHB, nh = v, p, "swing"
            else:
                self.protH, self.protHB = self._fallback(p0, b, False)
                nh = "du_phong"
            self.st = DOWN
            self.ev_log.append((b, ev, refL[0] if ev == BOS_DN else None, p0, self.protH, nh))
        # Tiêu thụ mức (Close vượt)
        self.vSH = [s for s in self.vSH if not c > s[0]]
        self.vSL = [s for s in self.vSL if not c < s[0]]
        # Swing xác nhận tại b (pivot p = b − N): chỉ dùng được từ b + 1
        p = b - self.N
        if p >= 0:
            if self._piv(p, True):
                s = (self.H[p], p, b)
                self.vSH.append(s); self.hSH.append(s)
            if self._piv(p, False):
                s = (self.L[p], p, b)
                self.vSL.append(s); self.hSL.append(s)
        self.st_log.append(self.st)
        return ev


def chay(H, L, C, N=3, a07="loai_p0"):
    m = MD2(N, a07)
    evs = [m.step(h, l, c) for h, l, c in zip(H, L, C)]
    return m, evs
