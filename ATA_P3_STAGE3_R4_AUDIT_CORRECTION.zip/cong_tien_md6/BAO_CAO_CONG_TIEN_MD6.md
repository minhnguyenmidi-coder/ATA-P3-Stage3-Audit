# BÁO CÁO CỔNG TIỀN MD-6 – KIỂM TOÁN ĐIỀU KIỆN MỞ GIAI ĐOẠN TIẾP THEO

ATA Phase 3 · 14/11/2026 · Hội đồng 9 vai trò. Vòng này là kiểm toán, không viết mã MD-6.

| Mục | Giá trị |
|---|---|
| Baseline | `ATA_P3_Build_0.3.4a_Candidate_Indicator.pine`, SHA-256 `073234cc…f68605`. Không đổi: BASE-01 kiểm trước và sau mọi kiểm thử |
| Baseline đối chiếu | 0.3.3a, SHA-256 `d1fd298e…848f95e7d` |
| Không làm trong vòng này | Không sửa Pine, không tạo build mới, không triển khai MD-6, không nghiên cứu Library, không đổi đặc tả, không yêu cầu chủ dự án thao tác TradingView |
| Bộ kiểm | `cong_tien_md6/chay_cong_tien.py`: **31 PASS / 0 FAIL / 9 BLOCKED / 1 NOT TESTED**, mã thoát 2. Có tiêm lỗi để kiểm mã thoát: có FAIL thì mã thoát 1 |

**Quy ước nhãn:**
- **FACT:** có bằng chứng (văn bản, mã, kết quả chạy).
- **SUY LUẬN:** rút ra từ FACT.
- **ASSUMPTION / HYPOTHESIS:** giả định có nguồn / chưa kiểm được.
- **RECOMMENDATION:** khuyến nghị của hội đồng, không phải quyết định.

Mọi trích dẫn tài liệu trong ma trận được máy kiểm lại nguyên văn (DOC-03: 60/60 trích dẫn).

---

## TÓM TẮT ĐIỀU HÀNH

### KẾT LUẬN: **NOT READY** – chưa đủ điều kiện mở cổng MD-6

Có **hai nhóm điều kiện độc lập**, cả hai đều chưa đạt.

**1. Quyết định thiết kế đã được văn bản quy định là bắt buộc, nhưng chưa có (NOT READY):**
- **Q1–Q4:** Rev.19 Phần 5, Phần 7 mục 9 và P2-1.5.1 Q.1 ghi *"Q1–Q4 bắt buộc trước khi viết code"* (FACT, trích dẫn đã kiểm).
  - Không có hồ sơ phê duyệt.
  - Mã các bước 1–5 đã được viết trước khi duyệt. Đây là sai lệch quy trình đã xảy ra, cần chủ dự án xử lý.
- **D-P2-01:** P2-1.5.1 B.3 ghi *"Ghi vào D-P2-01, chờ duyệt"* cho các thay đổi I-1…I-6. Đây là những thay đổi bắt buộc để MD-6/MD-7 đi vào S1 (quyền, lý do 15) và Data Window (mã regime).

**2. Bằng chứng TradingView theo quyết định của chủ dự án (BLOCKED):**
- Câu "MD-6 vẫn khóa cho đến khi có bằng chứng TradingView cần thiết" cùng mục 9 của quyết định 0.3.3 (8 kiểm chứng TradingView).
- TV-03…TV-10 đều BLOCKED. Em không có quyền truy cập TradingView, và nhiệm vụ cấm giao thao tác cho chủ dự án.

**Kết luận chọn NOT READY chứ không chọn BLOCKED:** ngay cả khi có đủ bằng chứng TradingView, các quyết định ở nhóm 1 vẫn chưa có. Đó là điều kiện đã biết là chưa đạt, không phải điều kiện không kết luận được.

### Đã đóng bằng bằng chứng trong vòng này

| # | Nội dung |
|---|---|
| 1 | Xác minh lại gói nghiệm thu 0.3.4a từ chính ZIP: SHA, số đếm 19/0/8/0, mọi số liệu báo cáo khớp tệp kết quả. Tái lập bộ nghiệm thu trong thư mục sạch: 18/0/8/1, đúng dự kiến khi không chạy hồi quy dài (RV-01…03) |
| 2 | **A-07:** chứng minh mã lệch khỏi **chính hai TC của đặc tả** (TC-PROT02, TC-MS08). Định lượng tác động lên CHoCH, ST và REG của MD-6 trên mô hình |
| 3 | **Q2/D16:** phát hiện câu "B: hai chiều đối xứng" của Rev.19 **chỉ đúng khi biểu đồ dùng giá Bid**. Với giá Mid thì A mới đối xứng. Loại giá là U-02, vẫn chưa xác định |
| 4 | Dựng **mô hình tham chiếu MD-6** viết từ đặc tả, đạt TC-RG01…09, TC-RG11 (13/13), có đối chứng âm. Dùng làm chuẩn nghiệm thu khi viết MD-6 |
| 5 | Kiểm tĩnh rủi ro runtime "vượt bộ đệm lịch sử": mọi chỉ số `x[…]` có chặn ≤ 500. Một nghi vấn (`high[off + 3]`) được chứng minh là không thể xảy ra |
| 6 | Hoàn tất bộ giải mã cột Data Window "TOÀN VẸN" (việc tồn từ báo cáo 0.3.3), sẵn sàng cho CSV thật |
| 7 | Sửa test cũ lỗi thời (BLK-01-032) và đối chiếu hai cách đánh số TV |

---

## 1. Hồ sơ đã dùng

- **16 tài liệu**, chép vào `ho_so/` kèm SHA-256 (`ho_so/SHA256_HO_SO.txt`, DOC-01 khớp 16/16). Gồm Rev.4, 8, 16, 18, 19 Final, 19.1, 19.2, 19.3, P2-1.5.1, sáu văn bản nhiệm vụ/quyết định của chủ dự án, và danh sách lỗi 0.3.1.
- **Tài liệu được viện dẫn nhưng không có trong hồ sơ** (DOC-02, FACT):

| Thiếu | Hệ quả |
|---|---|
| Rev.5–7 | không đọc được chi tiết D10–D12 |
| Rev.9–15 | **không đọc được nguyên văn D14–D19, trong đó có D16 (quy tắc giá A/B)** |
| Rev.17 | — |
| P2-1.4 | không đọc được nội dung D-P2-02, 06, 07, 08 |

- **Mâu thuẫn hồ sơ đặc tả (HS-01, FACT):** các nhiệm vụ gọi Rev.19.2 là baseline. Nhưng P2-1.5.1 R.4 bàn giao "Rev.4 đến **Rev.19.3**", và mã 0.3.4a **đã có** plot `M4 KB_TIME` của Rev.19.3 (C-150/C-153, dòng 3487). Cần chủ dự án xác nhận revision nào có hiệu lực.
- **Trùng tên "Q2" (HS-03):** "Q2 – quy tắc giá (D16)" ở Rev.19 Phần 5 khác hoàn toàn với "Q2-0…Q2-8" (điều kiện parity Deep Backtesting) ở Rev.19.1–19.3. Báo cáo này luôn viết "Q2 (D16)".

## 2. Xác minh lại nghiệm thu 0.3.4a (không mặc định tin báo cáo)

| ID | Kiểm | Kết quả |
|---|---|---|
| RV-01 | Pine trong ZIP = SHA baseline; `nghiem_thu_034a.json` = 19/0/8/0; báo cáo ghi đúng | PASS |
| RV-02 | Giải nén ZIP vào thư mục sạch, chạy lại bộ nghiệm thu (không gồm hồi quy dài) | PASS: 18/0/8/1, mã thoát 2, 185 s |
| RV-03 | Số liệu báo cáo ↔ tệp kết quả: 28 lượt / 54.320 nến / 0 sai khác; vòng đời 2.054; R-7 90/90; suy giảm 9/9; độ phủ 658/659 | PASS |

**Giới hạn:** đây là Claude tự tái lập công việc của chính mình. Nó xác nhận tính nhất quán và khả năng tái lập, nhưng không phải kiểm định độc lập của bên thứ ba.

## 3. Nhiệm vụ 1 – Toàn bộ vấn đề còn treo

Chi tiết đủ 11 cột ở `MA_TRAN_VAN_DE_CON_TREO.csv` (35 mục, 60 trích dẫn đã kiểm). Tóm tắt theo lớp trạng thái:

| Lớp | Mục |
|---|---|
| **Chưa có quyết định thiết kế** | Q1, Q2 (D16), Q3, Q4; D-P2-01; A-07; HS-01 (revision hiệu lực); D-3 |
| **Đã có quyết định nhưng chưa triển khai** | MD6-IN: ER_H4, VR_H4, bộ đếm 120 nến H4. Đặc tả đã định nghĩa; là phần việc của bước MD-6 |
| **Đã triển khai nhưng chưa kiểm chứng** | D-P2-11 (sweep trên biểu đồ – chưa duyệt); L-2 (giới hạn đã biết); TOK (U-31); U-26…29 |
| **Đã kiểm chứng bằng mô hình, chưa kiểm chứng TradingView** | A-01/02/03/04/09/10/13; A-08; D-1/D-2; L-1 (A-L1-1/2, backfill); R-5…R-8; QT-01 |
| **Không thuộc phạm vi MD-6** | Q5, Q6, Q7; D-P2-03/04/05/09/10; U-02; các U còn lại (Rev.19 Phần 4); HS-03 |
| **BLOCKED – thiếu tài liệu** | D-P2-02/06/07/08; HS-02 |
| **Đã đóng** | A-05/A-06/A-11 (tĩnh); A-12 (compile 0.3.4a); RT-x (tĩnh, vòng này) |

## 4. Nhiệm vụ 2 – Q1–Q4, A-07, Q2/D16

### 4.1 Q1–Q4 (nguyên văn: Rev.19 Final Phần 5, dòng 187–190)

| Câu | Nội dung gốc | Phương án tài liệu cho phép | Ảnh hưởng | Liên quan MD-6 | Nhận xét hội đồng |
|---|---|---|---|---|---|
| Q1 | Mô hình giao dịch V1 (D1, D2, D4, D5, D7, D8, D9) | Duyệt cả gói, hoặc nêu điểm đổi; đổi D7 → Rev.20 | EXE/PORT, nhật ký, R. Không đổi đầu vào MD-6 | Không kỹ thuật; **có theo điều kiện "trước khi viết code"** | Mã đã theo đề xuất (D7: thoát 100 % tại TP1/SL). RECOMMENDATION: duyệt hoặc nêu điểm đổi; nếu đổi D7 phải có Rev.20 trước mọi mã sổ mới |
| Q2 | Quy tắc giá SL/TP (D16) | A, hoặc B (Rev.19 đề xuất B) | Kết cục lệnh SELL, R (EXE/PORT). **Không** ảnh hưởng MD-0…MD-6, SIG, SU-1 | Không kỹ thuật | Xem 4.3 – không thể chọn có căn cứ trước U-02 |
| Q3 | Cảnh báo (D3) | Giữ (đề xuất) | Chỉ MD-9. **0.3.4a chưa có lệnh alert nào** (ALERT-01) | Không | Duyệt cùng gói; triển khai ở bước 8 |
| Q4 | Lựa chọn kỹ thuật (D10–D15, D17, D19, D21, D22; D20 trừ c) | Duyệt cả gói | Chỉ cách kiểm chứng; không đổi logic | Không | D14, D15, D17, D19 không đọc được nguyên văn (thiếu Rev.9–15) → phần đánh giá nội dung BLOCKED |

**Về no-repaint, hiệu năng và khả năng kiểm thử:** Q1–Q4 không thay đổi cơ chế MTF hay chống repaint. Q2 và Q4 ảnh hưởng tới cách kiểm parity/CSV về sau.

**Kết luận 4.1:** tài liệu không trao quyền cho hội đồng chọn thay. Q1–Q4 = **CHỜ NGƯỜI DÙNG PHÊ DUYỆT**, và theo đặc tả là điều kiện bắt buộc.

### 4.2 A-07 – PROT p₀

| Khía cạnh | Kết luận | Nhãn / bằng chứng |
|---|---|---|
| Bản chất | Mã lệch khỏi chữ đặc tả, kèm một **mâu thuẫn nội tại của đặc tả**. Nhánh swing của D.3.1 ghi "p₀ **<** p ≤ b"; nhánh dự phòng và PROT_L_BAR ghi "p₀ **…** b". Mã loại p₀ ở cả hai nhánh (dòng 408, 427: `kMax = span − 1`) | FACT (A07-01) |
| Đối chiếu với TC của đặc tả | Kết quả mong đợi của **TC-PROT02 và TC-MS08 ghi nguyên văn "Low thấp nhất của nến p₀…b"**. Mô hình tham chiếu: khi Low[p₀] là thấp nhất, cách làm hiện tại **không đạt** TC; PA1 đạt | FACT (MD2-TC-PROT02) |
| Định lượng | Mô hình MD-2 → MD-6 trên 10 chuỗi H4 giả lập × 3.000 nến: | FACT về mô hình; độ lớn trên dữ liệu thật chưa biết |
| | • khoảng **33 %** sự kiện cấu trúc dùng nhánh dự phòng | |
| | • PROT khác ở trung bình 23 lần/chuỗi | |
| | • số CHoCH: 47,1 (hiện tại) so với 45,9 (PA1) | |
| | • ST khác ở **0,58 %** số nến | |
| | • REG của MD-6 khác ở **0,67 %** số nến | |
| | • LAST_CHOCH_H4 khác ở trung bình 17 nến/chuỗi | |
| Phụ thuộc dữ liệu thật | Không cần dữ liệu thật để quyết định (đây là định nghĩa); chỉ cần để biết độ lớn thực tế | SUY LUẬN |
| Diff | PA1 (3 dòng) vẫn áp sạch lên bản sao 0.3.4a, chỉ lệch vị trí dòng (DIFF-01). PA2 là văn bản đính chính, không đổi mã | FACT |
| Bắt buộc trước MD-6? | **Không phải điều kiện của đặc tả.** RECOMMENDATION: quyết trước khi viết MD-6, vì CHoCH H4 là đầu vào trực tiếp của C.2 bước 1 và LAST_CHOCH_H4. Nếu đổi sau, MD-6 phải nghiệm thu lại | RECOMMENDATION |

**So sánh hai phương án:**

| | PA1 – sửa mã theo chữ | PA2 – đính chính đặc tả |
|---|---|---|
| Mã | 3 dòng (diff sẵn) | Không đổi |
| TC-PROT02/MS08 | Đạt như văn bản | Phải sửa câu chữ TC |
| Hệ quả | PROT_L mới ≤ cũ → CHoCH cần đóng cửa sâu hơn → ít/muộn hơn (mô hình: −2,5 % CHoCH) | Giữ hành vi đã nghiệm thu |
| Nhất quán nội tại | Hai nhánh khác nhau (swing loại p₀, dự phòng gồm p₀) | Hai nhánh cùng loại p₀ |
| Chi phí kiểm lại | Build mới + hồi quy | Chỉ văn bản |

Hội đồng **không chọn thay**.

### 4.3 Q2/D16 – Quy tắc giá A/B

**Định nghĩa đang có:**
- **Quy tắc A** = bảng Rev.4 6.3: SL/TP ở đúng mức kỹ thuật; BUY kích hoạt theo Bid, SELL theo Ask.
- 0.3.4a khớp **13/13** biểu thức của bảng, kèm quy đổi δ_bid/δ_ask theo loại giá biểu đồ (EXE-A-01, có đối chứng âm).
- **Quy tắc B** = "lệnh SELL đặt lệch thêm một khoản spread" (Rev.19 tóm tắt; diff PA-B: mức lệnh SELL = mức kỹ thuật + S).
- **Văn bản gốc D16 không có trong hồ sơ** (Rev.9–15) → ASSUMPTION về cách tính R_kh khi chọn B.

**Mô-đun sử dụng:** chỉ X-1 (kết cục lệnh) của EXE/PORT, dòng 1436–1486. Không dùng ở MD-0…MD-6, SIG, S1, SU-1: các mô-đun này dùng giá biểu đồ. Không có nhiều nguồn giá cần chọn. Thời điểm hiệu lực là nến k ≥ t+1 theo Rev.4 6.3.

**Phát hiện chính (FACT – đại số và mô hình, `du_lieu_Q2_D16.csv`):**
- BUY và SELL gương đối xứng **khi và chỉ khi** độ dời mức SELL = δ_ask − δ_bid.
- Mô hình 3.000 lệnh cho mỗi ô; số lệnh lệch đối xứng (BUY so với SELL gương) như bảng dưới.

| Loại giá biểu đồ | δ_ask − δ_bid | A (dời 0) | B (dời +S) |
|---|---|---|---|
| Bid | S | lệch: 324 / 704 / 1.223 / 2.049 lệnh (S = 2 / 5 / 10 / 20 % R_kh) | **0 lệch – đối xứng** |
| Mid | 0 | **0 lệch – đối xứng** | lệch: 302 / 717 / 1.258 / 2.025 |
| Ask | −S | lệch | lệch nhiều hơn |

**Hệ quả:**
- Câu ở Rev.19 "A: lệnh SELL bị dừng sớm hơn BUY một khoản spread; B: hai chiều đối xứng" chỉ đúng khi feed biểu đồ là Bid.
- Loại giá của feed Exness trên TradingView là **U-02 – vẫn CHỜ DỮ LIỆU**.

**Trường hợp biên** (Q2-BIEN, PASS):
- SL và TP cùng nến → SL (D4) ở cả A và B.
- Gap qua SL ở nến vào → VÀO-RA NGAY.

**Kiểm được bằng dữ liệu tổng hợp:** công thức, đối xứng, trường hợp biên.
**Cần dữ liệu thật:**
- loại giá feed (U-02);
- spread thực tế theo phiên;
- độ lệch giá TradingView ↔ MT5;
- đối chiếu kết cục lệnh với Strategy Tester (CSV).

**Bắt buộc trước MD-6?** Không về kỹ thuật (MD-6 không dùng giá Bid/Ask). Q2 nằm trong gói Q1–Q4, mà đặc tả ghi "trước khi viết code".

**RECOMMENDATION:**
- Chốt U-02 trước, rồi mới quyết Q2.
- Nếu feed là Bid, B mang lại đối xứng; nếu Mid, A đã đối xứng.
- Nếu chủ dự án muốn đối xứng cho mọi loại giá, công thức tổng quát là "dời = δ_ask − δ_bid". Đây là **nhận xét toán học, không phải phương án có trong tài liệu**, nên chỉ nêu để chủ dự án cân nhắc; hội đồng không tự đặt.

### 4.4 Các diff chưa áp dụng

Trong `goi/diff_chua_ap_dung/`:
- `A-07_PhuongAn1_tinh_ca_p0.diff`, `A-07_PhuongAn2_dinh_chinh_dac_ta.md`, `Q2_D16_PhuongAnB_SELL_lech_spread.diff`.
- Cả ba được lập trên 0.3.1, và vẫn áp sạch lên **bản sao** 0.3.4a (DIFF-01: không fuzz, chỉ lệch vị trí dòng).
- Không áp dụng vào baseline.

## 5. Nhiệm vụ 3 – Các mục chỉ xác minh được trên TradingView (chi tiết: `MA_TRAN_TV_BLOCKED.csv`)

| ID | Đã tự kiểm thêm vòng này (mã/mô hình) | Trạng thái |
|---|---|---|
| TV-02 token | Tính lại ước lượng: **93.628**, khớp báo cáo cũ. Phương pháp: tỉ lệ tuyến tính với token từ vựng của 0.3.3 (101.360 là số thật). R-7 đổi cấu trúc biểu thức nên tỉ lệ có thể lệch; với sai số ±8 %, khoảng là 86.138–101.118, biên trên vượt 100.256. FACT duy nhất: < 100.256 (đã compile) | **BLOCKED – không có số compiled token thực tế** |
| TV-03 runtime | RT-01 (mọi `x[…]` ≤ 500); RT-02 (`high[off+3]` không thể vượt) | BLOCKED |
| TV-04 Replay | Không có phương án thay thế | BLOCKED |
| TV-05 no-repaint | RP-01 tĩnh: 8/8 request.security lookahead_on với nến đã đóng; không varip/timenow/isrealtime; pipeline gắn barstate.isconfirmed. **Không phải bằng chứng no-repaint trên TradingView** | BLOCKED |
| TV-06 Profiler | Mô hình chi phí Python (không phải Profiler) | BLOCKED |
| TV-07 CSV | CSV-01: bộ giải mã TOÀN VẸN (5.000 mã đúng, 7/7 mã sai bị từ chối). **Không dùng CSV giả lập thay CSV Exness** | BLOCKED |
| TV-08 L-1 | Mô phỏng đồng hồ 21 ngày (0.3.3) | BLOCKED |
| TV-09 so[1] | Tài liệu chính thức + mô hình 90/90 + kiểm không đột biến | BLOCKED |
| TV-10 *(mới)* | Số nến H4 khả dụng cho MD-6 (cần ≥ 120). Trang Limitations: *"the number of requested bars is the same as the number of chart bars available for the symbol and timeframe"* → SUY LUẬN: tương đương biểu đồ H4, dư xa 120 | BLOCKED (rủi ro thấp) |

**Đánh giá dư địa token khi mở rộng (HYPOTHESIS):**
- MD-6 theo C.1–C.6 là phần nhỏ: thêm ER/VR/bộ đếm trong ngữ cảnh H4, một máy trạng thái 3 bước, 2 trường I-5. Ước tính vài phần trăm token, chưa đo được.
- Rủi ro lớn nằm ở MD-7…MD-9.
- Pine Library chỉ là phương án tương lai **nếu có bằng chứng thiếu dư địa** (không đề xuất ở vòng này).

## 6. Nhiệm vụ 4 – Sẵn sàng kiến trúc cho MD-6 (chi tiết: `MA_TRAN_SANG_SAN_SANG_MD6.csv`)

| Nhóm | Thành phần |
|---|---|
| **Đủ điều kiện làm đầu vào** (còn giả định TradingView) | MD-0 (nhận H4, okH4/newH4/pendH4); dữ liệu đa khung (H4 có sẵn, không cần request mới – REQ-01: 8/40); đồng bộ, thiếu/trễ, suy giảm (C.5 ánh xạ được); mô hình tham chiếu MD-6 |
| **Còn giả định** | A-L1-1/2 (TV-08); số nến H4 (TV-10); lịch sử đối tượng (TV-09) |
| **BLOCKED** | Mọi kiểm chứng runtime (TV-03…TV-10) |
| **Cần quyết định thiết kế trước** | MD-2 cơ sở (A-07 – khuyến nghị); pipeline S1 và Data Window I-5 (D-P2-01); Q1–Q4 (điều kiện chung) |
| **Phải bổ sung trong chính bước MD-6** | VR_H4 (đặc tả xếp vào MD-1); ER_H4; bộ đếm 120 nến; REG/T_CNT/LAST_CHOCH_H4 |
| **Không được thay đổi trong bước MD-6** | MD-5 (nghiệm thu 0.3.4a; theo quyết định 0.3.3, chưa dùng làm đầu vào module giao dịch); SU-1; pipeline Phase 1.5 ngoài các thay đổi I-x đã được duyệt; quy tắc giá A (tới khi Q2 có quyết định) |
| **Không liên quan MD-6** | MD-3, MD-4, SIG/EXE/PORT, Alerts |

**Ngân sách:** plot 54 → 57/64 sau I-5 và M5_SETUP (PLOT-01; đặc tả ước lượng 55 vì gốc 52). Lời gọi request: 8/40.

## 7. Nhiệm vụ 5 – Bộ kiểm thử tự động bổ sung

Chạy: `python3 cong_tien_md6/chay_cong_tien.py`. Kết quả: `ket_qua/KET_QUA_KIEM_THU.csv/.json`, `NHAT_KY.txt`.

| Nhóm | Test | Kết quả |
|---|---|---|
| Hồ sơ | DOC-01…05 | 5 PASS |
| Xác minh lại | RV-01…03 | 3 PASS |
| Tĩnh trên 0.3.4a | EXE-A-01, A07-01, DIFF-01, MD6-IN-01, PLOT-01, REQ-01, RT-01, RT-02, RP-01, ALERT-01, TOK-01, CSV-01, STALE-01 | 13 PASS |
| Mô hình MD-2 | MD2-TC (10 TC đặc tả), MD2-TC-PROT02 (A-07), MD2-DB (đối chứng âm) | 3 PASS |
| A-07 | A07-IMP | PASS (đo được) |
| Mô hình MD-6 | MD6-TC 13/13, MD6-DB 3/3, MD6-DATA | 3 PASS; TC-RG10/12 NOT TESTED (thuộc MD-7) |
| Q2/D16 | Q2-SYM, Q2-BIEN | 2 PASS |
| TradingView | TV-02…TV-10 | 9 BLOCKED |
| Baseline | BASE-01 | PASS |

**Yêu cầu kỹ thuật đã đáp ứng:**
- hạt giống cố định trong mọi phép ngẫu nhiên (5.000 mã giải mã; 10 chuỗi H4; 45.000 lệnh Q2);
- dữ liệu và kết quả ở dạng JSON/CSV;
- nhật ký đầy đủ;
- FAIL → mã thoát 1 (đã tiêm lỗi để kiểm);
- BLOCKED và NOT TESTED đếm riêng;
- không sửa Pine (BASE-01);
- diff chỉ thử trên bản sao.

**Tái sử dụng cho MD-6:** `md2_tham_chieu.py` (ST/EV H4) và `md6_tham_chieu.py` (REG, T_CNT, VOL, LAST_CHOCH_H4, ER, VR) là chuẩn đối chiếu khi viết MD-6.

## 8. Lỗi phát hiện trong bộ kiểm, báo cáo cũ và tài liệu (đã ghi rõ và sửa phần bộ kiểm; không sửa Pine)

| # | Vấn đề | Xử lý |
|---|---|---|
| 1 | Test cũ `BLK-01-032` luôn trả BLOCKED với nội dung "chưa có xác nhận compile 0.3.2" – lỗi thời | Đã sửa theo bản đích: 0.3.3 FAIL CE10117; 0.3.3a PASS; 0.3.4 FAIL CE10137; 0.3.4a PASS (STALE-01) |
| 2 | Hai cách đánh số TV: `chay_034` TV-01…06; báo cáo nghiệm thu TV-01…09 | Bảng đối chiếu ở `MA_TRAN_TV_BLOCKED.csv` |
| 3 | Tài liệu: TC-MS13 mô tả kịch bản **không thể xảy ra** theo D.1. Tại nến xác nhận c = p+N, Close[c] ≤ High[c] ≤ High[p] | Kiểm thuộc tính: 0 vi phạm trên 30.000 nến. Nhận xét chất lượng đặc tả, mức thấp |
| 4 | Tài liệu: câu "B: hai chiều đối xứng" (Q2) chỉ đúng với feed Bid | Mục 4.3 |
| 5 | Bộ kiểm của chính vòng này: ba lỗi đã sửa trong lúc làm | (a) regex đối chứng âm EXE-A-01 không neo cuối dòng; (b) dữ liệu TC-MS13 ban đầu không tạo được swing; (c) chuỗi "BTC" ban đầu chỉ là bản phóng to của chuỗi XAU cùng seed – đã tách seed và động lực |

## 9. Danh sách quyết định cần chủ dự án phê duyệt (Nhóm B)

| # | Quyết định | Căn cứ | Hạn theo tài liệu |
|---|---|---|---|
| B1 | Q1 – mô hình giao dịch V1 | Rev.19 Phần 5 | Trước khi viết code (đã quá hạn – mã đã có) |
| B2 | Q2 (D16) – quy tắc A/B, **sau khi có U-02** | Rev.19 Phần 5; mục 4.3 | Trước khi viết code |
| B3 | Q3 – cảnh báo | Rev.19 Phần 5 | Trước khi viết code |
| B4 | Q4 – lựa chọn kỹ thuật | Rev.19 Phần 5 | Trước khi viết code |
| B5 | D-P2-01 – thay đổi tích hợp I-1…I-6 | P2-1.5.1 B.3 | Trước khi tích hợp MD-6/MD-7 vào S1 |
| B6 | A-07 – PA1 hoặc PA2 | Nhiệm vụ 0.3.1 VII; mục 4.2 | RECOMMENDATION: trước khi viết MD-6 |
| B7 | HS-01 – revision đặc tả hiệu lực (Rev.19.2 hay 19.3) | DOC-05 | RECOMMENDATION: trước bước tiếp theo |
| B8 | Tập bằng chứng TradingView tối thiểu để mở MD-6 | Quyết định 0.3.3 | Chủ dự án xác định |
| B9 | *(tùy chọn)* Bổ sung Rev.5–7, 9–15, 17, P2-1.4 vào hồ sơ | DOC-02 | Để đóng phần BLOCKED – thiếu tài liệu |

## 10. Nhiệm vụ 6 – Lộ trình theo thứ tự phụ thuộc

**Nhóm A – Claude tự hoàn thành được (không cần quyết định, không cần TradingView):**
- **A1.** Khi có quyết định A-07: dựng build mới từ 0.3.4a theo PA1, hoặc chỉ cập nhật văn bản theo PA2; chạy hồi quy và mô hình MD-2/MD-6.
- **A2.** Soạn sẵn kế hoạch kiểm thử MD-6 dựa trên `md6_tham_chieu.py` (TC-RG01…11, ánh xạ trạng thái Pine ↔ mô hình) để dùng ngay khi cổng mở.
- **A3.** Bản đặc tả hợp nhất (gộp Rev.4…19.3 + P2-1.5.1, không đổi nội dung), như Rev.19 Phần 8 và P2 R.4 đề xuất [RECOMMENDATION của tài liệu]. Cần B7 và B9 trước để không gộp thiếu.
- **A4.** Công cụ đối chiếu CSV hoàn chỉnh cho TV-07 (đã có bộ giải mã TOÀN VẸN): chuẩn bị luồng đọc CSV, kiểm thay đổi sau reload, so với mô hình.

**Nhóm B – Chủ dự án quyết định:** B1…B9 (mục 9). Không tự chốt thay.

**Nhóm C – Chỉ xác minh được trên TradingView:** TV-02…TV-10.
RECOMMENDATION về tập tối thiểu cho MD-6, chủ dự án quyết định:
- TV-03 runtime không lỗi trên XAUUSD/BTCUSD M5;
- TV-05 lịch sử ↔ reload/realtime không đổi;
- TV-08 cột TOÀN VẸN/dashboard "khung đến trễ" = 0/0 trên lịch sử;
- TV-10 có đủ ≥ 120 nến H4.

TV-09 được bao hàm trong TV-03/TV-05. TV-06 và TV-07 cần cho Phase sau, nhưng không phụ thuộc kỹ thuật của MD-6.

**Điều kiện cụ thể** (chỉ dùng điều kiện có trong tài liệu; phần khuyến nghị ghi rõ):

| Mục tiêu | Điều kiện |
|---|---|
| Đóng vấn đề đặc tả | B1–B4 có văn bản phê duyệt (đặc tả); B5 có phê duyệt (đặc tả B.3); B6, B7 có quyết định (RECOMMENDATION) |
| Đóng kiểm chứng tự động hóa được | Đã đóng ở vòng này. Còn A1 (sau B6) và A3 (sau B7/B9) |
| Đánh giá lại các mục TradingView BLOCKED | Khi có bất kỳ bằng chứng nào trong nhóm C. Hội đồng đối chiếu bằng công cụ có sẵn (CSV-01, doi_chieu_runtime.py) |
| **Mở cổng MD-6** | (1) Q1–Q4 được duyệt (đặc tả); (2) D-P2-01 được duyệt nếu MD-6 được tích hợp vào S1/Data Window, nếu không thì MD-6 chỉ tính và hiển thị (đặc tả B.3); (3) bằng chứng TradingView theo tập chủ dự án xác định (quyết định 0.3.3); (4) RECOMMENDATION: A-07 đã quyết. Sau đó hội đồng mới soạn prompt triển khai MD-6 |

## 11. Giới hạn

- Mô hình MD-2/MD-6 viết từ đặc tả, không phải mã Pine (MD-6 chưa có mã). Dữ liệu H4 và đường giá đều **giả lập**, khai báo rõ; độ lớn tác động trên dữ liệu thật chưa biết.
- Quy tắc B mô hình theo bản tóm tắt; văn bản gốc D16 không có.
- Kiểm tĩnh (RT, RP) giảm rủi ro nhưng **không thay** runtime, Replay, reload/realtime trên TradingView.
- Xác minh lại nghiệm thu 0.3.4a là tự tái lập, không phải kiểm định độc lập.

## 12. Kết luận cuối cùng

**NOT READY.** Mọi việc có thể đóng bằng mã và Python đã đóng trong vòng này. Các điều kiện còn lại đều là quyết định của chủ dự án (Q1–Q4 và D-P2-01 do đặc tả quy định; A-07 và HS-01 do hội đồng khuyến nghị) hoặc bằng chứng TradingView (quyết định 0.3.3). Không triển khai MD-6. Không soạn prompt MD-6 cho tới khi các điều kiện mục 10 được đáp ứng.

Manifest đầy đủ và SHA-256: `MANIFEST_SHA256.txt`. Hướng dẫn tái chạy: `README.md`.

**Nguồn (tài liệu TradingView đã dùng):**
- [Limitations](https://www.tradingview.com/pine-script-docs/writing/limitations)
- [Other timeframes and data](https://www.tradingview.com/pine-script-docs/concepts/other-timeframes-and-data)
- [Objects](https://www.tradingview.com/pine-script-docs/language/objects)
- [Migration to v6](https://tradingview.com/pine-script-docs/migration-guides/to-pine-version-6)
