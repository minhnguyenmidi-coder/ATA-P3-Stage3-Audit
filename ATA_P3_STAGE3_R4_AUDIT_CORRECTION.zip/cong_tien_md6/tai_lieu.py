# -*- coding: utf-8 -*-
"""Sổ tài liệu dùng trong kiểm toán cổng tiền MD-6: đường dẫn, SHA-256, và hàm kiểm trích dẫn (tệp + mẫu → số dòng + nguyên văn).
Mọi trích dẫn trong ma trận vấn đề được kiểm lại bằng máy: không tìm thấy nguyên văn → FAIL."""
import hashlib, os, re

D = os.path.dirname(os.path.abspath(__file__))
KT = os.path.dirname(D)
UP = os.path.join(D, "ho_so")      # bản chép tài liệu gốc (SHA-256 giữ nguyên, kiểm ở DOC-01)
TL = {
    "REV4": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev4.txt",
    "REV8": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev8.txt",
    "REV16": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev16.txt",
    "REV18": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev18.txt",
    "REV19": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev19_Final_Consolidation.txt",
    "REV19_1": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev19_1_Targeted_Correction.txt",
    "REV19_2": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev19_2_Targeted_Correction.txt",
    "REV19_3": f"{UP}/AI_Trading_Assistant_Phase_1_5_Rev19_3_Targeted_Correction.txt",
    "P2": f"{UP}/AI_Trading_Assistant_Phase_2_P2-1_5_1_Final_Consolidated.txt",
    "QD_031": f"{UP}/attachment-163d70d3.txt",          # nhiệm vụ Build 0.3.1 (mục VII: A-07, Q2/D16, Q1–Q4)
    "QD_031PC": f"{UP}/attachment-951d8ea4.txt",        # nhiệm vụ sau compile 0.3.1
    "QD_032": f"{UP}/attachment-2ff77450.txt",          # nhiệm vụ Build 0.3.2
    "QD_033": f"{UP}/attachment-cc51764b.txt",          # quyết định Build 0.3.3 (MD-6 khóa; 8 kiểm chứng TradingView)
    "QD_030": f"{UP}/attachment-19b6a199.txt",          # thiết lập hội đồng 0.3.0
    "PINE_034A": f"{KT}/src034a/ATA_P3_Build_0.3.4a_Candidate_Indicator.pine",
    "PINE_033A": f"{KT}/src033/ATA_P3_Build_0.3.3a_Candidate_Indicator.pine",
    "BC_034A": f"{KT}/BAN_GIAO_034a_NT/BAO_CAO_NGHIEM_THU_ATA_P3_Build_0.3.4a.md",
    "BC_033": f"{KT}/BAN_GIAO_033/BAO_CAO_ATA_P3_Build_0.3.3_Candidate.md",
    "DS_031": f"{UP}/DANH_SACH_LOI_VA_TRANG_THAI_0.3.1.md",
    "DIFF_A07_PA1": f"{KT}/goi/diff_chua_ap_dung/A-07_PhuongAn1_tinh_ca_p0.diff",
    "DIFF_A07_PA2": f"{KT}/goi/diff_chua_ap_dung/A-07_PhuongAn2_dinh_chinh_dac_ta.md",
    "DIFF_Q2_B": f"{KT}/goi/diff_chua_ap_dung/Q2_D16_PhuongAnB_SELL_lech_spread.diff",
}
# Tài liệu được viện dẫn nhưng KHÔNG có trong hồ sơ (kiểm bằng tên tệp trong thư mục tải lên)
THIEU = {
    "Rev.5–7": "Định nghĩa D10–D12 chi tiết (Rev.8 chỉ tóm tắt 'Các lựa chọn Rev.5/6/7')",
    "Rev.9–15": "Định nghĩa gốc D14–D19, trong đó có D16 (quy tắc giá A/B); Rev.16 chỉ ghi 'D1–D19 giữ nguyên'",
    "Rev.17": "Nội dung sửa đổi Rev.17",
    "P2-1.4": "Nội dung D-P2-01…D-P2-11 (P2-1.5.1 Q.2: 'giữ nguyên nội dung P2-1.4')",
}


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def doc_dong(ma):
    return open(TL[ma], encoding="utf-8").read().split("\n")


def trich(ma, mau):
    """Tìm mẫu regex trong tài liệu `ma`. Trả về (số dòng, nguyên văn ≤ 300 ký tự) hoặc None."""
    if ma not in TL or not os.path.exists(TL[ma]):
        return None
    for i, l in enumerate(doc_dong(ma)):
        if re.search(mau, l):
            return i + 1, l.strip()[:300]
    return None


def so_tai_lieu():
    out = []
    for ma, p in TL.items():
        out.append(dict(ma=ma, tep=os.path.basename(p), co=os.path.exists(p), sha256=sha(p) if os.path.exists(p) else None,
                        byte=os.path.getsize(p) if os.path.exists(p) else None))
    ten = " ".join(os.listdir(UP))
    thieu = []
    for k, v in THIEU.items():
        if k.startswith("Rev."):
            a = k[4:].split("–")
            nums = range(int(a[0]), int(a[-1]) + 1)
            co = [n for n in nums if re.search(rf"_Rev{n}\b|_Rev{n}\.txt", ten)]
        else:
            co = [1] if k.replace(".", "_") in ten else []
        thieu.append(dict(tai_lieu=k, noi_dung_phu_thuoc=v, co_trong_ho_so=bool(co)))
    return out, thieu
