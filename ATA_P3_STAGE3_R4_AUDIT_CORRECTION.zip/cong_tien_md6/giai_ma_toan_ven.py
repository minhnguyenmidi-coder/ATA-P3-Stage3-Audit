# -*- coding: utf-8 -*-
"""Giải mã cột Data Window "TOÀN VẸN D·H4·H1·M15" của 0.3.4a (dòng 3499) – dùng khi có CSV xuất từ TradingView (TV-07).
Mã = M15 + 10·H1 + 100·H4 + 1000·D  (mỗi chữ số 0–7 = mã toàn vẹn, 9 = khung chưa khả dụng)
     + 10⁴·(1·pendM15 + 2·pendH1 + 4·pendH4)  (mặt nạ CHƯA VỀ, L-1)
     + 10⁵·sysStatus (0–3).
Mã toàn vẹn mỗi khung = INT_PROT + INT_REF + INT_STATE (giá trị bit đọc từ mã Pine)."""
import re

KHUNG = ("M15", "H1", "H4", "D")


def doc_hang_so(pine_text):
    out = {}
    for n in ("INT_PROT", "INT_REF", "INT_STATE"):
        m = re.search(rf"^const int {n}\s*=\s*(\d+)", pine_text, re.M)
        out[n] = int(m.group(1)) if m else None
    return out


def ma_hoa(ig, pend, sys_status):
    """ig: dict khung → 0–7 hoặc 9; pend: (M15, H1, H4) bool; sys_status 0–3."""
    v = sum(ig[k] * 10 ** i for i, k in enumerate(KHUNG))
    v += 10000 * ((1 if pend[0] else 0) + (2 if pend[1] else 0) + (4 if pend[2] else 0))
    return v + 100000 * sys_status


def giai_ma(v, hs=None):
    if v is None or v != v:
        return None
    v = int(round(v))
    if v < 0:
        raise ValueError("mã âm")
    ss, r = divmod(v, 100000)
    pm, r = divmod(r, 10000)
    if pm > 7 or ss > 3:
        raise ValueError(f"mặt nạ/trạng thái ngoài miền: {pm}/{ss}")
    ig = {}
    for i, k in enumerate(KHUNG):
        d = (r // 10 ** i) % 10
        if d == 8:
            raise ValueError(f"chữ số 8 không hợp lệ ở khung {k}")
        ig[k] = dict(ma=d, chua_kha_dung=d == 9)
        if hs and d != 9:
            ig[k].update(PROT=bool(d & hs["INT_PROT"]), REF=bool(d & hs["INT_REF"]), STATE=bool(d & hs["INT_STATE"]))
    return dict(toan_ven=ig, chua_ve=dict(M15=bool(pm & 1), H1=bool(pm & 2), H4=bool(pm & 4)), sys_status=ss)
