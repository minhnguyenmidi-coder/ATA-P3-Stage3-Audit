# -*- coding: utf-8 -*-
"""
MÔ HÌNH Q2/D16 – QUY TẮC GIÁ SL/TP.
Quy tắc A: Rev.4 mục 6.3 (FACT – văn bản có trong hồ sơ). SL/TP đặt đúng mức kỹ thuật; BUY kích hoạt theo Bid, SELL theo Ask.
Quy tắc B: Rev.19 Phần 5 Q2 ("lệnh SELL đặt lệch thêm một khoản spread") + diff Q2_D16_PhuongAnB (mức lệnh SELL = mức kỹ thuật + S).
  [ASSUMPTION] Văn bản gốc D16 (Rev.9–15) không có trong hồ sơ; giả định R_kh (D9) vẫn tính theo SL kỹ thuật.
Ký hiệu Rev.4 6.2: δ_bid/δ_ask theo loại giá biểu đồ; s = trượt giá lệnh stop/market.
"""
import random

FEED = {"Bid": (0.0, 1.0), "Mid": (0.5, 0.5), "Ask": (1.0, 0.0)}   # (δ_bid/S, δ_ask/S)


def thoat(d, sl, tp, bars, S, feed="Bid", quy_tac="A", s=0.0, vao_nen_dau=True):
    """Duyệt các nến k ≥ t+1 (bars = [(o, h, l, c)]) theo thứ tự kiểm Rev.4 6.3. Trả về (mã, giá khớp, chỉ số nến).
    Mã: 1 TP, 2 SL, 3 SL gap, 4 TP gap, 5 VÀO-RA NGAY (SL gap ở nến vào), 6 TP gap ở nến vào, 7 SL&TP cùng nến (→ SL, D4), 0 chưa thoát."""
    db, da = FEED[feed][0] * S, FEED[feed][1] * S
    if d == -1 and quy_tac == "B":
        sl, tp = sl + S, tp + S
    for k, (o, h, l, c) in enumerate(bars):
        dau = vao_nen_dau and k == 0
        if d == 1:
            slG, tpG, slH, tpH = o - db <= sl, o - db >= tp, l - db <= sl, h - db >= tp
            if slG:
                return (5 if dau else 3), o - db - s, k
            if tpG:
                return (6 if dau else 4), o - db, k
            if slH and tpH:
                return 7, sl - s, k
            if slH:
                return 2, sl - s, k
            if tpH:
                return 1, tp, k
        else:
            slG, tpG, slH, tpH = o + da >= sl, o + da <= tp, h + da >= sl, l + da <= tp
            if slG:
                return (5 if dau else 3), o + da + s, k
            if tpG:
                return (6 if dau else 4), o + da, k
            if slH and tpH:
                return 7, sl + s, k
            if slH:
                return 2, sl + s, k
            if tpH:
                return 1, tp, k
    return 0, None, None


def vao(d, o, S, feed="Bid", s=0.0):
    db, da = FEED[feed][0] * S, FEED[feed][1] * S
    return o + da + s if d == 1 else o - db - s


def guong(bars, X):
    """Lật gương quanh X: p' = 2X − p; High ↔ Low."""
    return [(2 * X - o, 2 * X - l, 2 * X - h, 2 * X - c) for (o, h, l, c) in bars]


def duong_gia(R, n, p0, sig):
    out, p = [], p0
    for _ in range(n):
        o = p
        c = o + R.gauss(0, sig)
        h = max(o, c) + abs(R.gauss(0, sig * 0.6))
        l = min(o, c) - abs(R.gauss(0, sig * 0.6))
        if R.random() < 0.02:                       # gap
            g = R.gauss(0, sig * 3)
            o, c, h, l = o + g, c + g, h + g, l + g
        out.append((o, h, l, c))
        p = c
    return out


def thi_nghiem(seed=7, n_lenh=4000, ti_le_S=(0.0, 0.02, 0.05, 0.10, 0.20), feed="Bid"):
    """Mỗi lệnh: R_kh = 1 (đơn vị giá), TP = 1,5 R, S = tỉ lệ × R_kh. Đo: (a) đối xứng BUY ↔ SELL gương (A và B);
    (b) tỉ lệ lệnh SELL đổi kết cục A → B; (c) chênh R trung bình của SELL (A − B)."""
    R = random.Random(seed)
    out = []
    for r in ti_le_S:
        S = r * 1.0
        lech_A = lech_B = doi_SELL = 0
        sumR_A = sumR_B = 0.0
        for _ in range(n_lenh):
            bars = duong_gia(R, 60, 100.0, 0.25)
            o1 = bars[0][0]
            # BUY trên đường gốc: SL = o1 − 1, TP = o1 + 1,5 (mức kỹ thuật theo giá biểu đồ)
            kb = thoat(1, o1 - 1.0, o1 + 1.5, bars, S, feed, "A")
            g = guong(bars, o1)
            # SELL trên đường gương: SL = o1 + 1, TP = o1 − 1,5
            for qt in ("A", "B"):
                ks = thoat(-1, o1 + 1.0, o1 - 1.5, g, S, feed, qt)
                same = (kb[0] == ks[0] and kb[2] == ks[2])
                if qt == "A":
                    lech_A += 0 if same else 1
                    eA = vao(-1, g[0][0], S, feed)
                    sumR_A += 0 if ks[1] is None else (eA - ks[1]) / 1.0
                    kA = ks
                else:
                    lech_B += 0 if same else 1
                    eB = vao(-1, g[0][0], S, feed)
                    sumR_B += 0 if ks[1] is None else (eB - ks[1]) / 1.0
                    if (kA[0], kA[2]) != (ks[0], ks[2]):
                        doi_SELL += 1
        out.append(dict(S_tren_Rkh=r, feed=feed, so_lenh=n_lenh, lech_doi_xung_A=lech_A, lech_doi_xung_B=lech_B,
                        SELL_doi_ket_cuc_A_sang_B=doi_SELL, R_TB_SELL_A=round(sumR_A / n_lenh, 4), R_TB_SELL_B=round(sumR_B / n_lenh, 4)))
    return out
