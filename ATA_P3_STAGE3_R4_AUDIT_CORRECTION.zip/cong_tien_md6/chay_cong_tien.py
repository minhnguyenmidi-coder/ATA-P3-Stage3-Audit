# -*- coding: utf-8 -*-
"""
BỘ KIỂM CỔNG TIỀN MD-6 – python3 cong_tien_md6/chay_cong_tien.py [--nhanh]
  --nhanh : bỏ RV-02 (chạy lại bộ nghiệm thu 0.3.4a từ ZIP, ≈ 5 phút) → RV-02 = NOT TESTED
Đầu ra (cong_tien_md6/ket_qua/): KET_QUA_KIEM_THU.csv/.json, NHAT_KY.txt, MA_TRAN_*.csv, du_lieu_*.json
Mã thoát: 1 có FAIL · 2 không FAIL nhưng còn BLOCKED/NOT TESTED · 0 tất cả PASS.
Không sửa Pine baseline: SHA kiểm trước và sau (BASE-01). Mọi thao tác thử diff làm trên BẢN SAO tạm.
"""
import csv, hashlib, json, os, random, re, shutil, subprocess, sys, tempfile, time, zipfile
D = os.path.dirname(os.path.abspath(__file__)); KT = os.path.dirname(D)
sys.path.insert(0, D)
import tai_lieu as TL
import van_de as VD
import md2_tham_chieu as M2
import md6_tham_chieu as M6
import q2_mo_hinh as Q2
import giai_ma_toan_ven as GM

OUT = os.path.join(D, "ket_qua"); os.makedirs(OUT, exist_ok=True)
PINE = TL.TL["PINE_034A"]
SHA34A = "073234cc6d9a5a9fbb81380f59b81482acdf1640484264ac0116909267f68605"
SHA33A = "d1fd298e8c302009c8097679b79a530c89a05cdb4d0140875298fe7848f95e7d"
ZIP_NT = os.environ.get("ATA_ZIP_NT", "/mnt/user-data/outputs/ATA_P3_Build_0.3.4a_Nghiem_Thu.zip")
KQ, LOG = [], []


def ghi(tid, nhom, muc_tieu, ky_vong, thuc_te, kq, nhan, pp, bc):
    assert kq in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")
    KQ.append(dict(id=tid, nhom=nhom, muc_tieu=muc_tieu, ky_vong=ky_vong, thuc_te=str(thuc_te)[:2000], ket_qua=kq, nhan=nhan, phuong_phap=pp, bang_chung=bc))
    print(f"{kq:11} {tid:16} {muc_tieu[:95]}", flush=True)
    LOG.append(f"{kq:11} {tid:16} {muc_tieu}\n    kỳ vọng: {ky_vong}\n    thực tế: {str(thuc_te)[:1800]}")


def luu(ten, obj):
    json.dump(obj, open(os.path.join(OUT, ten), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)


def code_lines(p):
    return [re.sub(r"\s*//.*$", "", l) for l in open(p, encoding="utf-8").read().split("\n")]


# =============================================================== tài liệu
def t_tai_lieu():
    so, thieu = TL.so_tai_lieu()
    luu("so_tai_lieu.json", dict(tai_lieu=so, thieu=thieu))
    ref = os.path.join(D, "ho_so", "SHA256_HO_SO.txt")
    ghi_lai = {}
    if os.path.exists(ref):
        for l in open(ref, encoding="utf-8"):
            h, f = l.split(None, 1); ghi_lai[f.strip()] = h
    lech = [(x["tep"], x["sha256"][:12], ghi_lai.get(x["tep"], "?")[:12]) for x in so if x["tep"] in ghi_lai and ghi_lai[x["tep"]] != x["sha256"]]
    thieu_tep = [x["ma"] for x in so if not x["co"]]
    ghi("DOC-01", "Tài liệu", "Bản chép tài liệu gốc trong ho_so/ khớp SHA-256 đã ghi; mọi tệp trong sổ tài liệu tồn tại", "0 lệch, 0 thiếu",
        f"{len(so)} tệp; lệch {lech}; thiếu {thieu_tep}", "PASS" if not lech and not thieu_tep and ghi_lai else "FAIL", "FACT", "sha256", "ho_so/SHA256_HO_SO.txt, ket_qua/so_tai_lieu.json")
    co = [x for x in thieu if x["co_trong_ho_so"]]
    ghi("DOC-02", "Tài liệu", "Phát hiện tài liệu được viện dẫn nhưng không có trong hồ sơ (Rev.5–7, Rev.9–15, Rev.17, P2-1.4)",
        "liệt kê đúng; các mục phụ thuộc ghi BLOCKED – thiếu tài liệu", [(x["tai_lieu"], x["co_trong_ho_so"]) for x in thieu],
        "PASS" if not co else "FAIL", "FACT", "đối chiếu tên tệp trong hồ sơ", "ket_qua/so_tai_lieu.json")
    # trích dẫn trong ma trận vấn đề
    hong, n = [], 0
    for v in VD.VD:
        for ma, mau in v["trich"]:
            n += 1
            r = TL.trich(ma, mau)
            if r is None:
                hong.append((v["id"], ma, mau))
            else:
                v.setdefault("_trich_kq", []).append(f"{ma}:{r[0]}")
    ghi("DOC-03", "Tài liệu", f"Mọi trích dẫn trong ma trận vấn đề ({n} trích dẫn, {len(VD.VD)} mục) tìm thấy nguyên văn trong tài liệu nguồn", "0 trích dẫn hỏng",
        f"hỏng {hong}", "PASS" if not hong else "FAIL", "FACT", "regex trên văn bản gốc", "van_de.py, MA_TRAN_VAN_DE_CON_TREO.csv")
    a = TL.trich("REV19", r"^\| Q2 \| Quy tắc giá SL/TP \(D16\)"); b = TL.trich("REV19_2", r"^\| Q2-0 \|")
    ghi("DOC-04", "Tài liệu", "Trùng tên 'Q2': câu hỏi duyệt Q2 (D16) và điều kiện parity Q2-0…Q2-8 cùng tồn tại", "phát hiện cả hai", (a, b),
        "PASS" if a and b else "FAIL", "FACT", "regex", "HS-03")
    m4 = TL.trich("PINE_034A", r'plot\(kbTime, "M4 KB_TIME"'); r193 = TL.trich("REV19_3", r"^\| C-153 \|"); r4 = TL.trich("P2", r"^- Phase 1.5: Rev.4 đến Rev.19.3")
    ghi("DOC-05", "Tài liệu", "Hồ sơ đặc tả: mã 0.3.4a đã có plot M4 KB_TIME (Rev.19.3 C-150/C-153); P2-1.5.1 R.4 bàn giao 'Rev.4 đến Rev.19.3'; nhiệm vụ gọi Rev.19.2",
        "ghi nhận mâu thuẫn hồ sơ (HS-01) – cần chủ dự án xác nhận", (m4, r193, r4), "PASS" if m4 and r193 and r4 else "FAIL", "FACT", "regex", "HS-01")


# =============================================================== xác minh lại nghiệm thu 0.3.4a từ ZIP
def t_xac_minh(nhanh):
    if not os.path.exists(ZIP_NT):
        for t in ("RV-01", "RV-02", "RV-03"):
            ghi(t, "Xác minh lại", "Gói nghiệm thu 0.3.4a", "có ZIP", f"không thấy {ZIP_NT}", "NOT TESTED", "—", "—", "—")
        return
    z = zipfile.ZipFile(ZIP_NT)
    nm = z.namelist()
    def doc(suffix):
        f = next(x for x in nm if x.endswith(suffix))
        return z.read(f)
    h = hashlib.sha256(doc("src034a/ATA_P3_Build_0.3.4a_Candidate_Indicator.pine")).hexdigest()
    nt = json.loads(doc("ket_qua034a_nt/nghiem_thu_034a.json"))
    bc = doc("BAN_GIAO_034a_NT/BAO_CAO_NGHIEM_THU_ATA_P3_Build_0.3.4a.md").decode("utf-8")
    ok = h == SHA34A and nt["dem"] == {"PASS": 19, "FAIL": 0, "BLOCKED": 8, "NOT TESTED": 0} and "19 PASS / 0 FAIL / 8 BLOCKED / 0 NOT TESTED" in bc
    ghi("RV-01", "Xác minh lại", "Gói ZIP nghiệm thu: Pine trong gói = baseline SHA 073234cc…; JSON nghiệm thu = 19/0/8/0; báo cáo ghi đúng số đó",
        "khớp", f"SHA {h[:16]}…; JSON {nt['dem']}; mã thoát ghi {nt['ma_thoat']}", "PASS" if ok else "FAIL", "FACT", "đọc ZIP", os.path.basename(ZIP_NT))
    # đối chiếu số liệu báo cáo ↔ tệp kết quả trong ZIP
    ss = json.loads(doc("ket_qua034a_nt/song_song.json")); bs = [json.loads(doc(f"ket_qua034a_nt/{f}")) for f in ("song_song_bo_sung.json", "song_song_bo_sung_bat_kip_day.json", "song_song_bo_sung_hai_phia.json")]
    kb = [r for r in ss["ket_qua"] if r["loai"] == "kich_ban"] + [r for b in bs for r in b["ket_qua"]]
    nen = sum(r["nen_chay"] for r in kb); sai = sum(1 for r in kb if r["sai_khac"] is not None or r["loi_bat_bien"] or r["loi_chay"])
    vd = json.loads(doc("ket_qua034a_nt/vong_doi.json"))["dem"]; r7 = json.loads(doc("ket_qua034a_nt/r7_mo_hinh.json"))["dem"]
    tt = json.loads(doc("ket_qua034a_nt/trang_thai_suy_giam.json"))["dem"]; dp = json.loads(doc("ket_qua034a_nt/do_phu_md5.json"))
    thuc = dict(luot=len(kb), nen=nen, sai=sai, vong_doi=vd, r7=r7, suy_giam=tt, do_phu=f"{dp['da_chay']}/{dp['tong_cau_lenh']}")
    ok = (len(kb), nen, sai) == (28, 54320, 0) and vd == {"PASS": 2054, "FAIL": 0} and r7 == {"PASS": 90, "FAIL": 0} and tt == {"PASS": 9, "FAIL": 0} \
        and (dp["da_chay"], dp["tong_cau_lenh"]) == (658, 659) and "54.320" in bc and "2.054" in bc and "90/90" in bc and "658/659" in bc
    ghi("RV-03", "Xác minh lại", "Số liệu trong báo cáo nghiệm thu khớp tệp kết quả trong ZIP (28 lượt / 54.320 nến / 0 sai khác; vòng đời 2.054; R-7 90/90; suy giảm 9/9; độ phủ 658/659)",
        "khớp", thuc, "PASS" if ok else "FAIL", "FACT", "đọc ZIP", os.path.basename(ZIP_NT))
    if nhanh:
        ghi("RV-02", "Xác minh lại", "Chạy lại bộ nghiệm thu 0.3.4a (phần nhanh) từ ZIP trong thư mục sạch", "18 PASS / 0 FAIL", "bỏ qua (--nhanh)", "NOT TESTED", "—", "—", "—")
        return
    tmp = tempfile.mkdtemp(prefix="rv02_")
    z.extractall(tmp)
    root = os.path.join(tmp, nm[0].split("/")[0])
    t0 = time.time()
    r = subprocess.run([sys.executable, "kiem_toan034a/chay_034a_nt.py"], cwd=root, capture_output=True, text=True, timeout=3000)
    kj = json.load(open(os.path.join(root, "ket_qua034a_nt", "nghiem_thu_034a.json"), encoding="utf-8"))
    ok = kj["dem"]["FAIL"] == 0 and kj["dem"]["PASS"] >= 18 and r.returncode == 2
    ghi("RV-02", "Xác minh lại", "Chạy lại bộ nghiệm thu 0.3.4a (không gồm hồi quy dài) từ ZIP trong thư mục sạch – tái lập được",
        "≥ 18 PASS, 0 FAIL, mã thoát 2 (REG-ALL NOT TESTED do không chạy --hoi-quy)", f"{kj['dem']}, mã thoát {r.returncode}, {round(time.time() - t0)} s",
        "PASS" if ok else "FAIL", "FACT (tự tái lập – không phải kiểm định độc lập bên thứ ba)", "subprocess", "thư mục tạm")
    shutil.rmtree(tmp, ignore_errors=True)


# =============================================================== kiểm tĩnh trên 0.3.4a
def t_tinh():
    L = code_lines(PINE); S = "\n".join(L)
    # EXE quy tắc A ↔ Rev.4 6.3 (13 dòng)
    can = [r"L\.entry := L\.dir == 1 \? open \+ dAsk \+ cSe : open - dBid - cSe",
           r"bool slGap = open - dBid <= L\.sl", r"bool tpGap = open - dBid >= L\.tp", r"bool slHit = low - dBid <= L\.sl", r"bool tpHit = high - dBid >= L\.tp",
           r"px := open - dBid - cSsl", r"px := L\.sl - cSsl",
           r"bool slGap = open \+ dAsk >= L\.sl", r"bool tpGap = open \+ dAsk <= L\.tp", r"bool slHit = high \+ dAsk >= L\.sl", r"bool tpHit = low \+ dAsk <= L\.tp",
           r"px := open \+ dAsk \+ cSsl", r"px := L\.sl \+ cSsl"]
    thieu = [c for c in can if not re.search(c + r"\s*$", S, re.M)]
    rev4 = [TL.trich("REV4", r"^\| SL gap: điều kiện \| Open\[k\] − δ_bid ≤ SL \| Open\[k\] \+ δ_ask ≥ SL"), TL.trich("REV4", r"^\| TP bình thường: điều kiện \| High\[k\] − δ_bid ≥ TP \| Low\[k\] \+ δ_ask ≤ TP")]
    feed = re.search(r'float dBid\s*=\s*iFeed == "Bid" \? 0\.0 : iFeed == "Mid" \? cS / 2 : cS', S) and re.search(r'float dAsk\s*=\s*iFeed == "Bid" \? cS : iFeed == "Mid" \? cS / 2 : 0\.0', S)
    # đối chứng âm: bản sao có SELL theo B phải bị phát hiện là khác A
    Sm = S.replace("bool slHit = high + dAsk >= L.sl", "bool slHit = high + dAsk >= L.sl + cS")
    am = [c for c in can if not re.search(c + r"\s*$", Sm, re.M)]
    ghi("EXE-A-01", "Q2/D16", "Khối thực hiện lệnh 0.3.4a khớp đúng bảng công thức Rev.4 6.3 (quy tắc A): 13 biểu thức + quy đổi δ_bid/δ_ask theo loại giá; đối chứng âm (SELL dời theo B) bị phát hiện",
        "13/13; δ đúng bảng 6.2; đối chứng âm ≥ 1 biểu thức lệch", f"thiếu {thieu}; δ {bool(feed)}; Rev.4 {rev4}; đối chứng âm lệch {len(am)}",
        "PASS" if not thieu and feed and all(rev4) and am else "FAIL", "FACT", "tĩnh + đối chứng âm", "src034a dòng 1118–1119, 1436–1486")
    # A-07 trong mã
    k = [i + 1 for i, l in enumerate(L) if re.search(r"int kMax = span - 1", l)]
    sw = [i + 1 for i, l in enumerate(L) if re.search(r"if p > p0 and p <= b", l)]
    ghi("A07-01", "A-07", "Mã 0.3.4a loại nến p₀ ở nhánh dự phòng (f_lowestSince/f_highestSince: kMax = span − 1) và dùng p₀ < p ≤ b ở nhánh swing", "2 + 2 vị trí",
        f"kMax=span−1 tại {k}; p > p0 tại {sw}", "PASS" if len(k) == 2 and len(sw) == 2 else "FAIL", "FACT", "tĩnh", "src034a dòng 400–437, 441–471")
    # diff chưa áp dụng còn áp được lên bản sao 0.3.4a
    kq = {}
    for ten in ("A-07_PhuongAn1_tinh_ca_p0.diff", "Q2_D16_PhuongAnB_SELL_lech_spread.diff"):
        tmp = tempfile.mkdtemp(prefix="diff_")
        shutil.copy(PINE, os.path.join(tmp, "ATA_P3_Build_0.3.1_Candidate_Indicator.pine"))
        r = subprocess.run(["patch", "-p1", "--dry-run", "-i", os.path.join(KT, "goi", "diff_chua_ap_dung", ten)], cwd=tmp, capture_output=True, text=True)
        r2 = subprocess.run(["patch", "-p1", "-i", os.path.join(KT, "goi", "diff_chua_ap_dung", ten)], cwd=tmp, capture_output=True, text=True)
        out = open(os.path.join(tmp, "ATA_P3_Build_0.3.1_Candidate_Indicator.pine"), encoding="utf-8").read()
        kq[ten] = dict(dry_run=r.returncode, ap=r2.returncode, offset=re.findall(r"offset (-?\d+)", r.stdout), fuzz="fuzz" in r.stdout,
                       dau_vet=("[A-07 PA1]" in out) if "A-07" in ten else ("[Q2/D16 PB" in out))
        shutil.rmtree(tmp, ignore_errors=True)
    ok = all(v["dry_run"] == 0 and v["ap"] == 0 and not v["fuzz"] and v["dau_vet"] for v in kq.values()) and TL.sha(PINE) == SHA34A
    ghi("DIFF-01", "A-07, Q2/D16", "Hai diff chưa áp dụng (lập trên 0.3.1) còn áp sạch lên BẢN SAO 0.3.4a (chỉ lệch vị trí dòng, không fuzz); baseline không đổi", "áp sạch; SHA baseline giữ",
        kq, "PASS" if ok else "FAIL", "FACT", "patch --dry-run + áp trên bản sao", "goi/diff_chua_ap_dung/")
    # MD-6: đầu vào
    i = L.index("type StructOut"); f = []
    for l in L[i + 1:]:
        if not l.startswith("    "): break
        if l.strip(): f.append(l.split()[1])
    co = {x: x in f for x in ("st", "ev", "atr", "cls", "mssA", "warm", "ready")}
    khong = {x: bool(re.search(rf"\b{x}\b", S)) for x in ("erH4", "vrH4", "ER_H4", "VR_H4", "regime", "LAST_CHOCH")}
    h4 = bool(re.search(r'\[sH4, xH4\] = request\.security\(syminfo\.tickerid, "240"', S))
    ghi("MD6-IN-01", "Sẵn sàng MD-6", "Đầu vào MD-6 trong 0.3.4a: có ST/EV/ATR/Close/MSS/warm/ready của H4 (request H4 sẵn có); CHƯA có ER_H4, VR_H4, bộ đếm 120 nến, REG",
        "có đủ nhóm 1; nhóm 2 chưa có (đúng phạm vi bước 6)", f"trường có {co}; định danh MD-6 có trong mã {khong}; request H4 {h4}",
        "PASS" if all(co.values()) and h4 and not any(khong.values()) else "FAIL", "FACT", "tĩnh", "src034a dòng 165–200, 940")
    # ngân sách plot
    nplot = {k_: len(re.findall(rf"^\s*{k_}\(", S, re.M)) for k_ in ("plot", "plotshape", "plotchar", "plotarrow", "plotcandle", "plotbar", "bgcolor", "barcolor", "fill")}
    tong = sum(nplot.values())
    ghi("PLOT-01", "Sẵn sàng MD-6", "Ngân sách plot: hiện tại + I-5 (2 trường regime/loại setup) + M5_SETUP (1) ≤ 64", "≤ 64",
        f"hiện tại {tong} {nplot}; sau I-5 + M5_SETUP: {tong + 3}; đặc tả R.2 ước lượng 55 (gốc 52 Rev.19.3)", "PASS" if tong + 3 <= 64 else "FAIL",
        "FACT (đếm lệnh) / ASSUMPTION (mỗi lệnh = 1 plot count, U-44)", "tĩnh", "TC-PLOT03")
    nreq = len(re.findall(r"request\.(security|security_lower_tf|financial|economic|quandl|seed|dividends|earnings|splits)\(", S))
    ghi("REQ-01", "Sẵn sàng MD-6", "Số lời gọi request.*: hiện tại ≤ 40; MD-6 tính trong ngữ cảnh H4 sẵn có (R.1, R.2: Phase 2 không thêm lời gọi)", "≤ 40",
        f"{nreq} lời gọi", "PASS" if nreq <= 40 else "FAIL", "FACT", "tĩnh", "TC-REQ02")
    # RT-01: tham chiếu lịch sử
    mbb = int(re.search(r"max_bars_back = (\d+)", S).group(1))
    nmax = int(re.search(r"^const int N_MAX\s*=\s*(\d+)", S, re.M).group(1)); lbc = int(re.search(r"^const int LB_CAP\s*=\s*(\d+)", S, re.M).group(1))
    kexp = int(re.search(r"^const int K_EXPIRE\s*=\s*(\d+)", S, re.M).group(1))
    refs = {}
    for ln, l in enumerate(L):
        for m in re.finditer(r"\b([A-Za-z_]\w*)\[([^\[\]]+)\]", re.sub(r'"[^"]*"', '""', l)):
            if m.group(1) in ("array", "map") or re.match(r"^\s*(int|float|bool|string)\s*$", m.group(2)):
                continue
            refs.setdefault(m.group(2).strip(), []).append(ln + 1)
    can_tren = {"N": nmax, "N + i": 2 * nmax, "N - i": nmax, "k": lbc, "1": 1, "m": 3, "off + 1": kexp + 4, "off + 2": kexp + 5, "off + 3": kexp + 6}
    la = [x for x in refs if x not in can_tren]
    vuot = {x: can_tren[x] for x in refs if x in can_tren and can_tren[x] > mbb}
    ghi("RT-01", "TV-03 (bổ trợ)", f"Mọi tham chiếu lịch sử x[…] có chặn trên ≤ max_bars_back = {mbb} (N ≤ N_MAX = {nmax}; k ≤ LB_CAP = {lbc}; m ≤ 3; off ≤ K_EXPIRE + 3)",
        "0 chỉ số không xác định chặn; 0 vượt", f"chỉ số: {sorted(refs)}; không xác định chặn {la}; vượt {vuot}", "PASS" if not la and not vuot else "FAIL",
        "FACT (từng chặn đọc từ mã)", "tĩnh", "src034a dòng 17, 33, 36, 65")
    # RT-02: tiền đề chặn off
    td = dict(ready=bool(re.search(r"ready = warm and integ == 0", "\n".join(open(PINE, encoding="utf-8").read().split("\n")))) or "warm and integ == 0" in S,
              stateFlag_chi_bat=len(re.findall(r"stateFlag\s*:=\s*true", S)) == 1 and not re.search(r"stateFlag\s*:=\s*false", S),
              frozen_theo_ok=bool(re.search(r"\(z\.tf == 15 and not okM15\) or \(z\.tf == 60 and not okH1\)", S)),
              kich_hoat_dat_sA_sB=bool(re.search(r"z\.sA := bar_index", S)) and bool(re.search(r"z\.sK := 0", S)),
              het_han=bool(re.search(r"if z\.sK >= K_EXPIRE", S)),
              p5_cong_sA=bool(re.search(r"if bar_index > z\.sA", S)), p5_sB_cap_nhat=len(re.findall(r"z\.sB := bar_index", S)) == 3,
              ok_dieu_kien=bool(re.search(r"bool okM15 = avM15 and sM15\.ready", S)) and bool(re.search(r"bool avM15 = f_avail\(\"15\"\)\s+and sM15\.warm", S)))
    ghi("RT-02", "TV-03 (bổ trợ)", "Chặn off = bar_index − z.sB ở P5 (high[off+3]): okX chỉ đổi sai→đúng một lần (warm) rồi có thể thành sai vĩnh viễn (stateFlag chỉ bật) "
        "→ vùng không 'đóng băng rồi tan băng' khi đang CHỜ; setup hết hạn sau K_EXPIRE nến → off + 3 ≤ K_EXPIRE + 6 ≪ 500",
        "mọi tiền đề đúng trong mã", td, "PASS" if all(td.values()) else "FAIL", "FACT (tiền đề) + SUY LUẬN từ mã (kết luận)", "tĩnh", "src034a dòng 491–493, 906, 923, 970–977, 1369–1370, 2935–2959, 3104")
    # RP-01: chống repaint (tĩnh)
    sec = re.findall(r"request\.security\([^\n]*", S)
    sec_ok = all("lookahead = barmerge.lookahead_on" in x for x in sec)
    struct_ret = "    [so[1], sx[1]]" in S
    per_ret = len(re.findall(r"\[high\[1\], low\[1\], time\[1\], time_close\[1\]\]", S)) == 4
    bad = {k_: bool(re.search(k_, S)) for k_ in (r"\bvarip\b", r"\btimenow\b", r"barstate\.isrealtime", r"calc_on_every_tick")}
    run = bool(re.search(r"bool runBar = logicOn and symOK and barstate\.isconfirmed", S))
    # khối cấp cao nhất có thay đổi trạng thái nhưng không qua runBar
    top = [(i + 1, l.strip()[:80]) for i, l in enumerate(L) if re.match(r"^if ", l) and not re.search(r"runBar|barstate\.(islast|isfirst)|na\((s|x)(M15|H1|H4|D)\)|newM15|newH1|newH4|newD|avPY|logicOn", l)]
    # Phân loại (đọc mã): đặt lại cờ CHƯA VỀ khi khung mất hợp lệ (L-1, đồng hồ biểu đồ – realtime được quay lui mỗi tick); vẽ nhãn (chỉ hiển thị)
    da_phan_loai = [t for t in top if re.match(r"if not ok(M15|H1|H4)$", t[1]) or re.match(r'if iLblTF == "', t[1])]
    top = [t for t in top if t not in da_phan_loai]
    ghi("RP-01", "TV-05 (bổ trợ)", "Chống repaint (tĩnh): 8/8 request.security dùng lookahead_on với giá trị nến đã đóng ([so[1], sx[1]] và [high[1], …]); không varip/timenow/isrealtime; "
        "pipeline gắn barstate.isconfirmed; khối cấp cao nhất đều có cổng", "đạt đủ", f"lookahead_on {sec_ok} ({len(sec)}); so[1]/sx[1] {struct_ret}; kỳ [1] {per_ret}; cấm {bad}; runBar {run}; khối không cổng chưa phân loại {top}; đã phân loại (L-1 / chỉ vẽ) {[t[0] for t in da_phan_loai]}",
        "PASS" if sec_ok and struct_ret and per_ret and not any(bad.values()) and run and not top else "FAIL", "FACT (tĩnh) – KHÔNG phải bằng chứng no-repaint trên TradingView", "tĩnh", "src034a dòng 938–941, 1618, 1626–1629")
    na_ = len(re.findall(r"\balert(condition)?\(", S))
    ghi("ALERT-01", "Q3/D3", "Cảnh báo: 0.3.4a chưa có lệnh alert/alertcondition (Q3/D3 chưa triển khai – thuộc MD-9, R.3 bước 8)", "ghi nhận đúng thực trạng", f"{na_} lệnh",
        "PASS" if na_ == 0 else "FAIL", "FACT", "tĩnh", "—")
    # token
    TOK = re.compile(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\+=|-=|[^\s\w]')
    def lex(p):
        n = 0
        for l in open(p, encoding="utf-8").read().split("\n"):
            o, ins = "", False
            for j, c in enumerate(l):
                if c == '"': ins = not ins
                if not ins and l[j:j + 2] == "//": break
                o += c
            n += len(TOK.findall(o))
        return n
    p33 = os.path.join(KT, "src033", "ATA_P3_Build_0.3.3_Candidate_Indicator.pine")
    l33, l34 = lex(p33), lex(PINE)
    est = round(101360 * l34 / l33)
    dai = {f"tỉ lệ ±{d}%": (round(est * (1 - d / 100)), round(est * (1 + d / 100))) for d in (3, 5, 8)}
    ghi("TOK-01", "TV-02", "Token: tính lại ước lượng (biên dịch ≈ 101.360 × token_từ_vựng / token_từ_vựng(0.3.3)); FACT duy nhất: 0.3.4a < 100.256 (đã compile); "
        "ước lượng có độ bất định vì R-7 đổi cấu trúc biểu thức", "tính lại khớp 93.628 ± 1; ghi rõ là ƯỚC LƯỢNG", f"từ vựng 0.3.3 {l33}, 0.3.4a {l34}; ước lượng {est}; khoảng {dai}; dư địa ước lượng {round(100 * (100256 - est) / 100256, 1)} %",
        "PASS" if abs(est - 93628) <= 1 else "FAIL", "HYPOTHESIS (ước lượng) / FACT (< 100.256)", "đếm token từ vựng", "src033, src034a")
    # giải mã TOÀN VẸN
    hs = GM.doc_hang_so(open(PINE, encoding="utf-8").read())
    R = random.Random(11); sai = 0
    for _ in range(5000):
        ig = {k_: R.choice([0, 1, 2, 3, 4, 5, 6, 7, 9]) for k_ in GM.KHUNG}
        pend = (R.random() < .2, R.random() < .2, R.random() < .2); ss_ = R.randint(0, 3)
        v = GM.ma_hoa(ig, pend, ss_); g = GM.giai_ma(v, hs)
        if {k_: g["toan_ven"][k_]["ma"] for k_ in GM.KHUNG} != ig or tuple(g["chua_ve"].values()) != pend or g["sys_status"] != ss_:
            sai += 1
    loi = 0
    for bad_v in (8, 80, 800, 8000, 80000, 400000, -1):
        try:
            GM.giai_ma(bad_v, hs)
        except ValueError:
            loi += 1
    cong_thuc = "10000 * ((pendM15 ? 1 : 0) + (pendH1 ? 2 : 0) + (pendH4 ? 4 : 0)) + 100000 * sysStatus" in open(PINE, encoding="utf-8").read()
    ghi("CSV-01", "TV-07 (chuẩn bị)", "Bộ giải mã cột Data Window 'TOÀN VẸN' (việc tồn từ báo cáo 0.3.3): 5.000 mã ngẫu nhiên mã hóa ↔ giải mã khớp; 7 mã ngoài miền bị từ chối; công thức khớp dòng 3499",
        "0 sai; 7/7 từ chối", f"sai {sai}; từ chối {loi}/7; hằng số {hs}; công thức khớp {cong_thuc}", "PASS" if sai == 0 and loi == 7 and cong_thuc and all(hs.values()) else "FAIL",
        "FACT", "kiểm vòng mã hóa + đối chứng âm", "giai_ma_toan_ven.py")
    # STALE-01: test cũ đã sửa
    t = open(os.path.join(KT, "hoi_quy034", "tests", "chay_test.py"), encoding="utf-8").read()
    ghi("STALE-01", "Bộ kiểm cũ", "Test cũ BLK-01-032 trước đây luôn ghi 'chưa có xác nhận compile 0.3.2' – đã sửa theo bản đích (0.3.3 FAIL CE10117, 0.3.3a PASS, 0.3.4 FAIL CE10137, 0.3.4a PASS); "
        "hai cách đánh số TV (chay_034: TV-01…06; nghiệm thu: TV-01…09) – đối chiếu ở MA_TRAN_TV_BLOCKED.csv", "đã sửa", "STALE-01" in t and '"034a": ("PASS"' in t,
        "PASS" if "STALE-01" in t and '"034a": ("PASS"' in t else "FAIL", "FACT", "đọc mã bộ kiểm", "hoi_quy034/tests/chay_test.py")


# =============================================================== mô hình MD-2 (TC của đặc tả) và A-07
def thanh(bars):
    return [b[0] for b in bars], [b[1] for b in bars], [b[2] for b in bars]


def t_md2():
    res = {}
    # TC-PROT02 / TC-MS08: BOS↑ ở b; SL duy nhất trong (p₀, b] xác nhận ở b (hoặc sau) → dự phòng p₀…b. Low[p₀] là thấp nhất.
    # Dựng: N = 2. Đáy SL cũ để có REF, SH ở p₀ = 6 (High 12, Low 8.0), nến 7–8 hồi (Low 8.5, 8.6), nến 9 BOS (Close 12.5).
    seq = [(10, 9, 9.5), (10.2, 9.1, 9.6), (10.4, 9.0, 9.2), (11, 9.3, 10.8), (11.5, 9.8, 11), (11.8, 10, 11.2), (12, 8.0, 11.5),
           (11.6, 8.5, 9), (11.4, 8.6, 9.1), (12.6, 9.2, 12.5)]
    H, Lw, C = thanh(seq)
    for v in ("loai_p0", "gom_p0"):
        m, ev = M2.chay(H, Lw, C, N=2, a07=v)
        bos = [e for e in m.ev_log if e[1] == M2.BOS_UP]
        res[v] = bos[-1] if bos else None
    p0 = res["gom_p0"][3] if res["gom_p0"] else None
    kv = min(Lw[p0:10]) if p0 is not None else None
    ok_g = res["gom_p0"] and res["gom_p0"][5] == "du_phong" and res["gom_p0"][4] == kv
    ok_l = res["loai_p0"] and res["loai_p0"][4] == kv
    ghi("MD2-TC-PROT02", "A-07", "TC-PROT02/TC-MS08 của đặc tả (BOS↑ tại b, không SL đủ điều kiện → PROT_L = Low thấp nhất của nến p₀…b) với Low[p₀] là thấp nhất",
        "PA1 (gồm p₀) đạt; hành vi hiện tại (loại p₀) KHÔNG đạt chữ TC", f"p₀ = {p0}; mong đợi PROT_L = {kv}; gồm p₀ → {res['gom_p0']}; loại p₀ → {res['loai_p0']}",
        "PASS" if ok_g and not ok_l else "FAIL", "FACT (mô hình tham chiếu viết từ D.3.1)", "mô hình MD-2", "md2_tham_chieu.py; P2 dòng 1249, 1378")
    # Các TC khác (giống nhau ở hai biến thể)
    tc = []
    # TC-MS01: SH xác nhận đúng ở p + N
    m = M2.MD2(N=3)
    for h, l, c in [(1, 0, .5), (2, 1, 1.5), (3, 2, 2.5), (5, 4, 4.5), (3, 2, 2.5), (2.5, 1.5, 2), (2.4, 1.4, 1.8)]:
        m.step(h, l, c)
        if len(m.C) == 6:
            truoc = len(m.hSH)
    tc.append(("TC-MS01", truoc == 0 and len(m.hSH) == 1 and m.hSH[0][1] == 3 and m.hSH[0][2] == 6))
    # TC-MS02: phá bằng râu không BOS
    H2 = [1, 2, 3, 5, 3, 2.5, 2.4, 5.5]; L2 = [0, 1, 2, 4, 2, 1.5, 1.4, 2]; C2 = [.5, 1.5, 2.5, 4.5, 2.5, 2, 1.8, 4.9]
    m, ev = M2.chay(H2, L2, C2, N=3)
    tc.append(("TC-MS02", ev[7] == M2.EV_NONE))
    C2b = C2[:-1] + [5.2]
    m, ev = M2.chay(H2, L2, C2b, N=3)
    tc.append(("TC-MS11", ev[7] == M2.BOS_UP and not any(s[0] == 5 for s in m.vSH)))
    # TC-MS06: đỉnh phẳng → nến sớm nhất
    m, _ = M2.chay([1, 2, 5, 5, 3, 2, 1, 1], [0, 1, 4, 4, 2, 1, 0, 0], [.5, 1.5, 4.5, 4.5, 2.5, 1.5, .5, .5], N=2)
    tc.append(("TC-MS06", [s[1] for s in m.hSH] == [2]))
    # TC-MS13: theo D.1, kịch bản 'Close[c] vượt mức swing xác nhận tại c' KHÔNG THỂ xảy ra (Close[c] ≤ High[c] ≤ High[p]).
    # Kiểm thuộc tính trên 10 chuỗi giả lập × 3.000 nến: số lần Close[c] vượt mức swing xác nhận tại c phải = 0.
    vi_pham = 0
    for ma_, sig_ in (("XAU", 8.0), ("BTC", 600.0)):
        for sd_ in range(1, 6):
            Hh, Ll, Cc = du_lieu_H4(3000, sd_, sig_, ma_)
            mm_ = M2.MD2(N=3)
            for h_, l_, c_ in zip(Hh, Ll, Cc):
                mm_.step(h_, l_, c_)
                b_ = len(mm_.C) - 1
                vi_pham += sum(1 for s_ in mm_.hSH if s_[2] == b_ and c_ > s_[0]) + sum(1 for s_ in mm_.hSL if s_[2] == b_ and c_ < s_[0])
    tc.append(("TC-MS13 (thuộc tính: kịch bản không thể xảy ra theo D.1; 0 vi phạm / 30.000 nến)", vi_pham == 0))
    # TC-MS09: UP, nến vừa < PROT_L vừa < REF_L → chỉ CHoCH↓
    mm = M2.MD2(N=2); mm.st = M2.UP; mm.protL, mm.protLB = 9.0, 0; mm.vSL = [(9.5, 1, 3)]
    for h, l, c in [(10, 9.6, 9.8), (10, 9.6, 9.8), (10, 9.6, 9.8), (10, 9.6, 9.8)]:
        mm.step(h, l, c)
    e = mm.step(9.9, 8.0, 8.5)
    tc.append(("TC-MS09", e == M2.CHOCH_DN and mm.st == M2.DOWN and mm.protH is not None))
    # TC-PROT01: SL có C(p) = b − 1, p > p₀ → PROT_L = mức SL đó
    seq1 = [(10, 9, 9.5), (10.2, 9.1, 9.6), (10.4, 9.0, 9.2), (11, 9.3, 10.8), (12, 10, 11.5), (11.6, 9.0, 9.5), (11.0, 8.2, 9.0),
            (11.2, 8.6, 9.4), (11.3, 8.7, 9.6), (11.5, 9.0, 10.0), (12.8, 9.5, 12.6)]
    H, Lw, C = thanh(seq1)
    m, ev = M2.chay(H, Lw, C, N=2)
    b = [e for e in m.ev_log if e[1] == M2.BOS_UP]
    tc.append(("TC-PROT01", bool(b) and b[-1][5] == "swing" and b[-1][4] == 8.2))
    # TC-PROT03: SL xác nhận sau b không đổi PROT đã khóa
    p_truoc = m.protL
    for h, l, c in [(12.9, 12.0, 12.5), (12.8, 11.9, 12.2), (12.7, 11.8, 12.1)]:
        m.step(h, l, c)
    tc.append(("TC-PROT03", m.protL == p_truoc))
    # TC-PROT04: PROT_H dự phòng có hai nến cùng High → PROT_H_BAR = nến sớm hơn
    mm = M2.MD2(N=2, a07="gom_p0")
    for h, l, c in [(10, 9, 9.5), (10.5, 9.5, 10), (10.2, 9.4, 9.8), (10, 9.2, 9.6), (9.8, 9.0, 9.3), (9.9, 9.1, 9.5)]:
        mm.step(h, l, c)
    mm.st = M2.UP; mm.protL, mm.protLB = 9.2, 3
    mm.step(9.95, 8.5, 9.0)
    # CHoCH↓ tại b = 6, p₀ = PROT_L_BAR = 3; không có SH với p trong (3, 6] → dự phòng max High trên 3…6: High 10 (nến 3), 9.8, 9.9, 9.95 → 10 tại 3
    tc.append(("TC-PROT04", mm.protH == 10 and mm.protHB == 3))
    # TC-SC01: DOWN, PROT_H = 100; c: Close 100,4 → CHoCH↑ (STRUCT_CONFIRM_BUY), c+1: Close 100,6 không có REF_H → không sự kiện
    mm = M2.MD2(N=2); mm.st = M2.DOWN; mm.protH, mm.protHB = 100.0, 0
    for _ in range(3):
        mm.step(99.8, 99.0, 99.5)
    e1 = mm.step(100.5, 99.4, 100.4); e2 = mm.step(100.7, 100.1, 100.6)
    tc.append(("TC-SC01", e1 == M2.CHOCH_UP and e2 == M2.EV_NONE and mm.st == M2.UP))
    bad = [t for t, ok in tc if not ok]
    ghi("MD2-TC", "MD-2 tham chiếu", "Mô hình tham chiếu MD-2 đạt các TC của đặc tả: TC-MS01, MS02, MS06, MS09, MS11, MS13 (thuộc tính), PROT01, PROT03, PROT04, SC01", "10/10",
        dict(tc), "PASS" if not bad else "FAIL", "FACT (mô hình viết từ D.1–D.3.1)", "mô hình", "md2_tham_chieu.py")
    # đối chứng âm: mô hình cố ý sai thứ tự (BOS↓ ghi đè CHoCH↓ khi cùng nến) phải trượt TC-MS09
    mm = M2.MD2(N=2); mm._choch_truoc = False; mm.st = M2.UP; mm.protL, mm.protLB = 9.0, 0; mm.vSL = [(9.5, 1, 3)]
    for h, l, c in [(10, 9.6, 9.8)] * 4:
        mm.step(h, l, c)
    e = mm.step(9.9, 8.0, 8.5)
    ghi("MD2-DB", "MD-2 tham chiếu", "Đối chứng âm: mô hình cố ý sai (BOS↓ được ghi thay CHoCH↓ khi cùng nến) phải trượt TC-MS09", "bị phát hiện", f"sự kiện = {e} (đúng phải là CHoCH↓ = {M2.CHOCH_DN})",
        "PASS" if e != M2.CHOCH_DN else "FAIL", "FACT", "đối chứng âm", "—")


def du_lieu_H4(n, seed, sig, ma):
    """Chuỗi H4 giả lập (KHÔNG phải dữ liệu Exness): bước ngẫu nhiên có cụm biến động (GARCH đơn giản) + xu hướng theo đoạn."""
    R = random.Random(seed if ma == "XAU" else 1000 + seed); p = 2000.0 if ma == "XAU" else 60000.0
    v = sig; H, Lw, C = [], [], []; tr = 0.0
    k_tr, chu_ky = (0.15, 150) if ma == "XAU" else (0.22, 90)      # BTC: xu hướng mạnh hơn, đổi nhịp nhanh hơn (giả lập, khai báo)
    for i in range(n):
        if i % chu_ky == 0:
            tr = R.gauss(0, sig * k_tr)
        v = max(sig * 0.3, 0.9 * v + 0.1 * sig + 0.25 * sig * abs(R.gauss(0, 1)) - 0.25 * sig * 0.8)
        o = p; c = o + tr + R.gauss(0, v)
        h = max(o, c) + abs(R.gauss(0, v * 0.5)); l = min(o, c) - abs(R.gauss(0, v * 0.5))
        H.append(round(h, 2)); Lw.append(round(l, 2)); C.append(round(c, 2)); p = c
    return H, Lw, C


def t_a07_tac_dong():
    rows = []
    for ma, sig in (("XAU", 8.0), ("BTC", 600.0)):
        for seed in range(1, 6):
            H, Lw, C = du_lieu_H4(3000, seed, sig, ma)
            r = {}
            for v in ("loai_p0", "gom_p0"):
                m, ev = M2.chay(H, Lw, C, N=3, a07=v)
                A = M6.atr_wilder(H, Lw, C)
                reg = M6.chay(m.st_log, ev, C, A)
                r[v] = (m, ev, reg)
            m0, e0, g0 = r["loai_p0"]; m1, e1, g1 = r["gom_p0"]
            du_phong = [x for x in m0.ev_log if x[5] == "du_phong"]
            n = len(C)
            ev_khac = sum(1 for a, b in zip(e0, e1) if a != b)
            st_khac = sum(1 for a, b in zip(m0.st_log, m1.st_log) if a != b)
            ch0 = sum(1 for x in e0 if x in (3, 4)); ch1 = sum(1 for x in e1 if x in (3, 4))
            reg_khac = sum(1 for a, b in zip(g0, g1) if a[0] != b[0])
            lc_khac = sum(1 for a, b in zip(g0, g1) if a[2] != b[2])
            # PROT khác ở bao nhiêu lần tính PROT (cùng nến sự kiện ở hai biến thể)
            d0 = {x[0]: x[4] for x in m0.ev_log}; d1 = {x[0]: x[4] for x in m1.ev_log}
            chung = set(d0) & set(d1); prot_khac = sum(1 for k in chung if d0[k] != d1[k])
            rows.append(dict(ma=ma, seed=seed, nen_H4=n, su_kien_cau_truc=len(m0.ev_log), lan_dung_du_phong=len(du_phong),
                             ty_le_du_phong=round(len(du_phong) / max(1, len(m0.ev_log)), 3), PROT_khac_tren_su_kien_chung=prot_khac,
                             nen_su_kien_khac=ev_khac, nen_ST_khac=st_khac, ty_le_ST_khac=round(st_khac / n, 4), CHoCH_hien_tai=ch0, CHoCH_PA1=ch1,
                             nen_REG_khac=reg_khac, ty_le_REG_khac=round(reg_khac / n, 4), nen_LAST_CHOCH_khac=lc_khac))
    luu("du_lieu_A07_tac_dong.json", dict(ghi_chu="Dữ liệu H4 GIẢ LẬP (không phải Exness). Mô hình tham chiếu MD-2/MD-6 viết từ đặc tả; KHÔNG phải mã Pine.", ket_qua=rows))
    with open(os.path.join(OUT, "du_lieu_A07_tac_dong.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    tb = lambda k: round(sum(r[k] for r in rows) / len(rows), 4)
    ghi("A07-IMP", "A-07", "Định lượng tác động A-07 (PA1 gồm p₀ so với hiện tại loại p₀) trên 10 chuỗi H4 giả lập × 3.000 nến (XAU/BTC, 5 hạt giống): tần suất dùng dự phòng, "
        "PROT khác, CHoCH, ST, REG và LAST_CHOCH_H4 của MD-6", "đo được, có số liệu theo từng chuỗi",
        f"TB tỉ lệ dùng dự phòng {tb('ty_le_du_phong')}; TB PROT khác/chuỗi {tb('PROT_khac_tren_su_kien_chung')}; TB nến ST khác {tb('ty_le_ST_khac') * 100:.2f} %; "
        f"TB nến REG khác {tb('ty_le_REG_khac') * 100:.2f} %; TB nến LAST_CHOCH khác {tb('nen_LAST_CHOCH_khac')}; CHoCH hiện tại/PA1 TB {tb('CHoCH_hien_tai')}/{tb('CHoCH_PA1')}",
        "PASS" if rows and any(r["lan_dung_du_phong"] > 0 for r in rows) else "FAIL", "FACT (mô hình, dữ liệu giả lập) – độ lớn trên dữ liệu thật: chưa biết",
        "mô hình MD-2 → MD-6", "ket_qua/du_lieu_A07_tac_dong.csv")


# =============================================================== mô hình MD-6 (TC-RG của đặc tả)
def t_md6():
    def m_new(**kw):
        return M6.MD6(**kw)
    tc = []
    # TC-RG05: dưới 120 nến
    m = m_new(); r = [m.step(M6.UP, 0, 0.35, 1.0) for _ in range(119)]
    tc.append(("TC-RG05", all(x[0] == M6.THIEU for x in r)))
    # TC-RG06: nến 120 đủ dữ liệu, ST = UP, ER = 0,25 → TRANSITION
    tc.append(("TC-RG06", m.step(M6.UP, 0, 0.25, 1.0)[0] == M6.TRANS and m.T_CNT == 0))
    # TC-RG01: UP, ER = 0,35 → UPTREND
    m = m_new(min_bars=1); tc.append(("TC-RG01", m.step(M6.UP, 0, 0.35, 1.0)[0] == M6.UPT))
    # TC-RG02: hysteresis 0,25 ↔ 0,28 khi UPTREND
    r = [m.step(M6.UP, 0, e, 1.0)[0] for e in (0.25, 0.28, 0.25, 0.28)]
    tc.append(("TC-RG02", all(x == M6.UPT for x in r)))
    # TC-RG03 + TC-RG07: CHoCH → TRANSITION ngay; n…n+5 TRANSITION; n+6 theo quy tắc cơ bản
    m = m_new(min_bars=1); m.step(M6.UP, 0, 0.35, 1.0)
    r = [m.step(M6.DOWN, 4, 0.35, 1.0)] + [m.step(M6.DOWN, 0, 0.35, 1.0) for _ in range(6)]
    tc.append(("TC-RG03", r[0][0] == M6.TRANS and r[0][1] == 1))
    tc.append(("TC-RG07", [x[0] for x in r[:6]] == [M6.TRANS] * 6 and [x[1] for x in r[:6]] == [1, 2, 3, 4, 5, 6] and r[6][0] == M6.DNT and r[6][1] == 0))
    # TC-RG08: CHoCH↓ ở n, CHoCH↑ ở n+3 → T_CNT về 1; TRANSITION tới n+8
    m = m_new(min_bars=1); m.step(M6.UP, 0, 0.35, 1.0)
    seq = [4, 0, 0, 3, 0, 0, 0, 0, 0, 0]
    r = [m.step(M6.UP if i >= 3 else M6.DOWN, e, 0.35, 1.0) for i, e in enumerate(seq)]
    tc.append(("TC-RG08", r[3][1] == 1 and all(x[0] == M6.TRANS for x in r[:9]) and r[9][0] == M6.UPT))
    # TC-RG09: RANGE, ER 0,20 → 0,29, ST = UP → giữ RANGE tới khi ER ≥ 0,30
    m = m_new(min_bars=1); m.step(M6.UP, 0, 0.10, 1.0)
    r = [m.step(M6.UP, 0, e, 1.0)[0] for e in (0.20, 0.24, 0.29)] + [m.step(M6.UP, 0, 0.30, 1.0)[0]]
    tc.append(("TC-RG09", r[:3] == [M6.RANGE] * 3 and r[3] == M6.UPT))
    # TC-RG04: VR = 2,6 → VOL-CỰC; biên lớp
    tc.append(("TC-RG04", M6.lop_vol(2.6) == "VOL-CỰC" and M6.lop_vol(2.5) == "VOL-CỰC" and M6.lop_vol(1.5) == "VOL-CAO" and M6.lop_vol(0.7) == "VOL-THẤP" and M6.lop_vol(0.71) == "VOL-THƯỜNG"))
    # TC-RG11: hiệu lực M5 từ nến M5 mở ≥ thời điểm đóng H4
    tc.append(("TC-RG11", not M6.hieu_luc_M5(12 * 60, 11 * 60 + 55) and M6.hieu_luc_M5(12 * 60, 12 * 60)))
    # C.6: LAST_CHOCH không bị BOS xóa; ghi đè bởi CHoCH sau
    m = m_new(min_bars=1); m.step(M6.UP, 3, 0.35, 1.0); m.step(M6.UP, 1, 0.35, 1.0); a = m.LAST_CHOCH; m.step(M6.DOWN, 4, 0.35, 1.0)
    tc.append(("C.6", a == M6.UP and m.LAST_CHOCH == M6.DOWN))
    # ER: mẫu số 0 → 0; công thức
    C = [100.0] * 25
    tc.append(("C.1-ER", M6.er(C, 24) == 0.0 and abs(M6.er(list(range(30)), 25) - 1.0) < 1e-12 and M6.er(C, 10) is None))
    # BOS đầu tiên từ NONE không mở cửa sổ bắt buộc
    m = m_new(min_bars=1); m.step(M6.NONE, 0, 0.35, 1.0); r = m.step(M6.UP, 1, 0.35, 1.0)
    tc.append(("C.2-BOS", r[0] == M6.UPT and r[1] == 0))
    bad = [t for t, ok in tc if not ok]
    ghi("MD6-TC", "MD-6 tham chiếu", "Mô hình tham chiếu MD-6 đạt TC-RG01…09, TC-RG11 và các hệ quả xác định C.1/C.2/C.6 của đặc tả (chuẩn đối chiếu cho bước viết MD-6)", f"{len(tc)}/{len(tc)}",
        dict(tc), "PASS" if not bad else "FAIL", "FACT (mô hình viết từ C.1–C.6)", "mô hình", "md6_tham_chieu.py; P2 dòng 1198–1202, 1245–1248, 1285")
    ghi("MD6-TC-RG10/12", "MD-6 tham chiếu", "TC-RG10, TC-RG12 (quyền SU-3 theo LAST_CHOCH_H4, lý do 15) thuộc I.3/MD-7, không thuộc MD-6", "—", "ngoài phạm vi MD-6; cần D-P2-01 và MD-7",
        "NOT TESTED", "—", "—", "P2 dòng 1284, 1286")
    # đối chứng âm
    am = {}
    m = M6.MD6(min_bars=1, t_win=5); m.step(M6.UP, 0, 0.35, 1.0)
    r = [m.step(M6.DOWN, 4, 0.35, 1.0)] + [m.step(M6.DOWN, 0, 0.35, 1.0) for _ in range(6)]
    am["cửa sổ 5"] = not ([x[0] for x in r[:6]] == [M6.TRANS] * 6 and r[6][0] == M6.DNT)
    class SaiTre(M6.MD6):
        def _co_ban(self, st, e, reg_truoc):
            return super()._co_ban(st, e, M6.UPT if st == M6.UP else reg_truoc)    # vùng trễ tạo xu hướng mới (sai)
    m = SaiTre(min_bars=1); m.step(M6.UP, 0, 0.10, 1.0)
    am["vùng trễ tạo xu hướng"] = m.step(M6.UP, 0, 0.25, 1.0)[0] != M6.RANGE
    class SaiKhoiTao(M6.MD6):
        def step(self, st, ev, e, v):
            if not self.da_khoi_tao and self.n + 1 >= self.p["min_bars"]:
                self.da_khoi_tao = True; self.n += 1; self.REG = self._co_ban(st, e, M6.UPT); return self.REG, 0, None, None
            return super().step(st, ev, e, v)
    m = SaiKhoiTao(); [m.step(M6.UP, 0, 0.25, 1.0) for _ in range(119)]
    am["khởi tạo không coi REG trước = TRANSITION"] = m.step(M6.UP, 0, 0.25, 1.0)[0] != M6.TRANS
    ghi("MD6-DB", "MD-6 tham chiếu", "Đối chứng âm: 3 mô hình MD-6 cố ý sai (cửa sổ 5 nến; vùng trễ tạo xu hướng; khởi tạo sai REG trước) đều bị TC phát hiện", "3/3",
        am, "PASS" if all(am.values()) else "FAIL", "FACT", "đối chứng âm", "—")
    # dữ liệu thiếu / trễ / khởi động muộn / trùng
    H, Lw, C = du_lieu_H4(400, 3, 8.0, "XAU")
    m, ev = M2.chay(H, Lw, C, N=3); A = M6.atr_wilder(H, Lw, C)
    full = M6.chay(m.st_log, ev, C, A)
    first = next(i for i, x in enumerate(full) if x[0] != M6.THIEU)
    # khởi động muộn: chỉ có 100 nến H4 → toàn bộ THIẾU
    short = M6.chay(m.st_log[:100], ev[:100], C[:100], A[:100])
    # khoảng dữ liệu: bỏ 30 nến H4 ở giữa (không có trên dữ liệu) → MD-6 tính trên chuỗi nến có thật
    keep = [i for i in range(400) if not 200 <= i < 230]
    H2, L2, C2 = [H[i] for i in keep], [Lw[i] for i in keep], [C[i] for i in keep]
    m2, ev2 = M2.chay(H2, L2, C2, N=3); g2 = M6.chay(m2.st_log, ev2, C2, M6.atr_wilder(H2, L2, C2))
    # trùng: MD-0 chống tiếp nhận trùng (tClose đổi) – kiểm tĩnh trong mã
    S = "\n".join(code_lines(PINE))
    trung = bool(re.search(r"Chống xử lý trùng", open(PINE, encoding="utf-8").read())) and bool(re.search(r"newH4", S))
    ok = first == 119 and all(x[0] == M6.THIEU for x in short) and len(g2) == 370 and trung
    ghi("MD6-DATA", "MD-6 tham chiếu", "Tình huống dữ liệu cho MD-6: đủ dữ liệu đúng ở nến H4 thứ 120 (ATR14 + TB 100 → sẵn từ nến 113); khởi động muộn (100 nến) → KHÔNG ĐỦ DỮ LIỆU toàn bộ; "
        "khoảng dữ liệu → tính trên chuỗi nến có thật; trùng nến → MD-0 chặn (newH4 theo tClose)", "đúng đặc tả C.2/C.5", f"nến đủ đầu tiên (chỉ số) {first}; ngắn toàn THIẾU {all(x[0] == M6.THIEU for x in short)}; "
        f"khoảng: {len(g2)} nến được tính; chống trùng trong mã {trung}", "PASS" if ok else "FAIL", "FACT (mô hình + tĩnh)", "mô hình", "md6_tham_chieu.py")


# =============================================================== Q2/D16
def t_q2():
    rows = []
    for f in ("Bid", "Mid", "Ask"):
        rows += Q2.thi_nghiem(seed=7, n_lenh=3000, feed=f)
    luu("du_lieu_Q2_D16.json", dict(ghi_chu="Đường giá GIẢ LẬP; quy tắc B theo tóm tắt Rev.19 + diff PA-B (ASSUMPTION: văn bản gốc D16 không có).", ket_qua=rows))
    with open(os.path.join(OUT, "du_lieu_Q2_D16.csv"), "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    by = {(r["feed"], r["S_tren_Rkh"]): r for r in rows}
    s_pos = [x for x in (0.02, 0.05, 0.10, 0.20)]
    bid = all(by[("Bid", s)]["lech_doi_xung_B"] == 0 and by[("Bid", s)]["lech_doi_xung_A"] > 0 for s in s_pos)
    mid = all(by[("Mid", s)]["lech_doi_xung_A"] == 0 and by[("Mid", s)]["lech_doi_xung_B"] > 0 for s in s_pos)
    ask = all(by[("Ask", s)]["lech_doi_xung_A"] > 0 and by[("Ask", s)]["lech_doi_xung_B"] > 0 for s in s_pos)
    zero = all(by[(f, 0.0)]["lech_doi_xung_A"] == 0 and by[(f, 0.0)]["lech_doi_xung_B"] == 0 for f in ("Bid", "Mid", "Ask"))
    ghi("Q2-SYM", "Q2/D16", "Tính đối xứng BUY ↔ SELL gương (3.000 lệnh × 5 mức spread × 3 loại giá): Rev.19 nói 'A: SELL bị dừng sớm hơn BUY một khoản spread; B: hai chiều đối xứng'",
        "kiểm điều kiện đúng của nhận định", f"Bid: B đối xứng, A lệch = {bid}; Mid: A đối xứng, B lệch = {mid}; Ask: cả hai lệch = {ask}; S = 0: cả hai đối xứng = {zero}",
        "PASS" if bid and mid and ask and zero else "FAIL", "FACT (mô hình + đại số: đối xứng ⇔ độ dời mức SELL = δ_ask − δ_bid)", "mô hình", "ket_qua/du_lieu_Q2_D16.csv")
    # trường hợp biên: SL và TP cùng nến → SL (D4) ở cả hai quy tắc; gap
    b1 = [(100, 101.6, 98.9, 100)]
    a = Q2.thoat(1, 99, 101.5, b1, 0.1, "Bid", "A"); b = Q2.thoat(-1, 101, 98.5, Q2.guong(b1, 100), 0.1, "Bid", "B")
    g = Q2.thoat(-1, 101, 98.5, [(101.2, 101.3, 100.5, 100.8)], 0.1, "Bid", "A", vao_nen_dau=True)
    ok = a[0] == 7 and b[0] == 7 and g[0] == 5
    ghi("Q2-BIEN", "Q2/D16", "Trường hợp biên của quy tắc giá: SL và TP cùng nến → SL (D4, mã 7) ở cả A và B; nến vào lệnh gap qua SL → VÀO-RA NGAY (mã 5)", "đúng Rev.4 6.3",
        f"A BUY {a}; B SELL gương {b}; gap SELL {g}", "PASS" if ok else "FAIL", "FACT (mô hình theo Rev.4 6.3)", "mô hình", "q2_mo_hinh.py")


# =============================================================== TradingView-only
TV = [
    ("TV-02", "Số compiled token thực tế", "TOK-01: ước lượng 93.628 (khoảng ±8 %: 86.138–101.118 – vượt 100.256 ở biên trên); FACT: < 100.256", "TradingView chỉ hiển thị số khi vượt giới hạn (CE10117); không có cách đo trực tiếp khác", "Thấp cho MD-6 (ước tính vài phần trăm); cao cho MD-7…MD-9"),
    ("TV-03", "Runtime XAUUSD/BTCUSD", "RT-01, RT-02 (không vượt bộ đệm lịch sử); nghiệm thu 0.3.4a (stress MD-5, map ≤ KEY_CAP)", "Lỗi runtime thật, giới hạn thời gian thực thi", "Có – mọi module"),
    ("TV-04", "Bar Replay", "Không có phương án thay thế bằng mã", "Hành vi trên Replay", "Có – kiểm repaint"),
    ("TV-05", "Reload/realtime và no-repaint thực tế", "RP-01 (tĩnh); mô hình R-7 realtime (nghiệm thu 0.3.4a) – KHÔNG phải bằng chứng no-repaint", "Xuất CSV trước/sau reload và realtime", "Có – MD-6 đọc H4 qua cùng cơ chế"),
    ("TV-06", "TradingView Profiler", "Mô hình chi phí Python (không phải Profiler)", "Thời gian theo khối thật", "Thấp cho MD-6"),
    ("TV-07", "CSV XAUUSD/BTCUSD", "CSV-01: bộ giải mã TOÀN VẸN sẵn sàng; công cụ doi_chieu_runtime.py (hồ sơ cũ)", "CSV xuất từ TradingView kèm manifest", "Có – parity"),
    ("TV-08", "timeframe.change và trễ khung thật (L-1)", "Mô phỏng đồng hồ 21 ngày (0.3.3): 0 báo nhầm", "Quan sát cột TOÀN VẸN/dashboard trên lịch sử + realtime", "Có – H4 cho MD-6 qua MD-0"),
    ("TV-09", "Runtime lịch sử đối tượng so[1]", "Tài liệu chính thức v6 + mô hình 90/90 + kiểm tĩnh không đột biến (nghiệm thu 0.3.4a)", "Quan sát runtime (bao hàm trong TV-03/TV-05)", "Có – MD-6 đọc sH4"),
    ("TV-10", "Số nến H4 khả dụng trong request.security (MD-6 cần ≥ 120)", "Trang Limitations: 'the number of requested bars is the same as the number of chart bars available for the symbol and timeframe' (SUY LUẬN: tương đương biểu đồ H4 → dư 120)", "Quan sát runtime", "Thấp (theo tài liệu)"),
]


def t_tv():
    for tid, ten, bo_sung, can, md6 in TV:
        ghi(tid, "TradingView-only", ten, "bằng chứng TradingView", f"BLOCKED. Đã kiểm bổ trợ: {bo_sung}. Cần: {can}", "BLOCKED", "—", "—", "MA_TRAN_TV_BLOCKED.csv")


# =============================================================== ma trận
def xuat_ma_tran():
    cols = ["id", "ten", "goc", "tai_lieu", "trich_dan_da_kiem", "loai", "trang_thai", "co", "thieu", "tu_kiem", "can", "anh_huong", "md6", "dx"]
    head = ["ID", "Tên vấn đề", "Nội dung yêu cầu gốc", "Tài liệu và phiên bản", "Trích dẫn đã kiểm (mã tài liệu:dòng)", "Phân loại trạng thái", "Trạng thái hiện tại",
            "Bằng chứng đã có", "Bằng chứng còn thiếu", "Tự kiểm bằng mã/Python?", "Nếu không: loại bằng chứng cần", "Ảnh hưởng nếu chưa giải quyết", "Bắt buộc trước MD-6?", "Đề xuất xử lý và lý do"]
    with open(os.path.join(OUT, "MA_TRAN_VAN_DE_CON_TREO.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f); w.writerow(head)
        for v in VD.VD:
            v = dict(v, trich_dan_da_kiem="; ".join(v.get("_trich_kq", [])))
            w.writerow([v[c] for c in cols])
    with open(os.path.join(OUT, "MA_TRAN_TV_BLOCKED.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ID (nghiệm thu 0.3.4a)", "ID tương ứng ở chay_034 / QĐ 0.3.3 mục 9", "Mục", "Phần đã tự kiểm thêm (mã/mô hình)", "Trạng thái", "Bằng chứng TradingView còn cần", "Liên quan MD-6"])
        doi = {"TV-02": "chay_034 TV-01 (số token)", "TV-03": "chay_034 TV-02; QĐ 9.2", "TV-04": "QĐ 9.4 (một phần)", "TV-05": "chay_034 TV-04; QĐ 9.4", "TV-06": "chay_034 TV-03; QĐ 9.3",
               "TV-07": "chay_034 TV-06; QĐ 9.6", "TV-08": "chay_034 TV-05; QĐ 9.5", "TV-09": "— (mới ở 0.3.4a)", "TV-10": "— (mới, vòng này)"}
        for tid, ten, bo_sung, can, md6 in TV:
            w.writerow([tid, doi[tid], ten, bo_sung, "BLOCKED", can, md6])
        w.writerow(["(QĐ 9.7–9.8)", "chay_033 TV-07/TV-08", "SU-1 không phát tín hiệu khi khung bắt buộc chưa hợp lệ; không bị ảnh hưởng bởi lỗi nội bộ MD-5", "Bộ L-1/D-1/D-2 39/0 (mô hình); IMP-01", "BLOCKED", "Data Window trên TradingView", "Gián tiếp"])
    SS = [
        ("MD-0 (nhận khung, L-1, sysStatus)", "Đã triển khai; mô hình PASS", "Bộ L-1/D-1/D-2 39/0; RP-01", "MD-6 nhận sH4/xH4 qua MD-0 (okH4, newH4, pendH4)", "Giả định A-L1-1/2 (TV-08)", "ĐẦU VÀO ĐƯỢC – còn giả định TV"),
        ("MD-1 (ATR)", "ATR có; VR_H4 CHƯA có", "MD6-IN-01", "VR_H4 là đầu vào C.1", "Thiếu VR làm MD-6 không chạy", "CẦN BỔ SUNG trong bước MD-6 (đặc tả đã định nghĩa)"),
        ("MD-2 cơ sở (swing, REF/PROT, BOS/CHoCH, ST)", "Đã triển khai; khớp D.1–D.3.1 trừ A-07", "Đọc mã dòng 539–740; MD2-TC; A07-01; MD2-TC-PROT02", "ST_H4, EV_H4 là đầu vào C.1; CHoCH H4 kích hoạt TRANSITION", "A-07 đổi CHoCH → đổi REG (A07-IMP)", "CẦN QUYẾT ĐỊNH A-07 TRƯỚC (khuyến nghị)"),
        ("MD-3 (vùng S&D)", "Đã triển khai", "Hồi quy 47/0", "Không (MD-6 không đọc)", "—", "KHÔNG LIÊN QUAN MD-6"),
        ("MD-4 (cụm mức)", "Đã triển khai", "Hồi quy 47/0", "Không (MD-7 đọc)", "—", "KHÔNG LIÊN QUAN MD-6"),
        ("MD-5 (thanh khoản)", "Đã triển khai; nghiệm thu 0.3.4a", "Song song 28 lượt; độ phủ 99,8 %", "Không (MD-7 đọc); QĐ 0.3.3: chưa an toàn làm đầu vào module giao dịch tới khi có bằng chứng TV", "TV-03/05/09", "KHÔNG ĐƯỢC THAY ĐỔI; chưa dùng làm đầu vào giao dịch"),
        ("Pipeline P0–P8, S1/S2a", "Đã triển khai (Phase 1.5)", "Hồi quy 47/0", "I-1 (S1 bước 0 quyền MD-7) cần D-P2-01", "Tích hợp regime vào S1 không có căn cứ phê duyệt", "CẦN QUYẾT ĐỊNH (D-P2-01) trước tích hợp"),
        ("SIG/EXE/PORT", "Đã triển khai; quy tắc A", "EXE-A-01", "Không trực tiếp", "Q2/D16 chưa chốt (phụ thuộc U-02)", "KHÔNG LIÊN QUAN MD-6; Q2 thuộc gói Q1–Q4"),
        ("SU-1", "Đã triển khai; lý do 8 WAIT", "Bộ 39/0; IMP-01", "Sau tích hợp MD-7: quyền đầy đủ (R.3 bước 7)", "—", "KHÔNG ĐƯỢC THAY ĐỔI trong bước MD-6"),
        ("Dữ liệu đa khung (8 request.security)", "Đã triển khai", "REQ-01; RP-01; RT-01", "H4 có sẵn; không cần request mới", "TV-10 (số nến H4)", "ĐẦU VÀO ĐƯỢC – còn giả định TV"),
        ("Đồng bộ, dữ liệu thiếu/trễ, suy giảm/phục hồi", "Đã triển khai (MD-5, MD-0)", "Suy giảm 9/9; L-1", "C.5: thiếu dữ liệu → KHÔNG ĐỦ DỮ LIỆU", "TV-08", "ĐẦU VÀO ĐƯỢC – còn giả định TV"),
        ("Dashboard / Data Window", "Đã triển khai; ngân sách plot đủ", "PLOT-01; CSV-01", "I-5 thêm mã regime (D-P2-01)", "Ngân sách 57/64 sau I-5", "CẦN QUYẾT ĐỊNH (D-P2-01) cho I-5"),
        ("Alerts", "CHƯA triển khai", "ALERT-01", "Không (MD-9)", "Q3/D3 chưa duyệt", "KHÔNG LIÊN QUAN MD-6"),
        ("Token biên dịch", "< 100.256; ước lượng ≈ 93.628", "TOK-01", "MD-6 thêm vài phần trăm (ước lượng)", "Khoảng bất định ±8 % chạm giới hạn ở biên trên", "THEO DÕI (TV-02)"),
        ("Mô hình tham chiếu MD-6", "Đã dựng (vòng này)", "MD6-TC 13/13; MD6-DB 3/3; MD6-DATA", "Chuẩn nghiệm thu MD-6", "—", "SẴN SÀNG làm chuẩn đối chiếu"),
    ]
    with open(os.path.join(OUT, "MA_TRAN_SANG_SAN_SANG_MD6.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f); w.writerow(["Thành phần", "Trạng thái hiện tại", "Bằng chứng", "Phụ thuộc MD-6", "Rủi ro nếu mở tiếp", "Kết luận"])
        w.writerows(SS)


def main():
    nhanh = "--nhanh" in sys.argv
    t0 = time.time()
    h0 = TL.sha(PINE); h33 = TL.sha(TL.TL["PINE_033A"])
    t_tai_lieu(); t_xac_minh(nhanh); t_tinh(); t_md2(); t_a07_tac_dong(); t_md6(); t_q2(); t_tv()
    h1 = TL.sha(PINE)
    ghi("BASE-01", "Baseline", "Pine 0.3.4a và 0.3.3a không đổi trước/sau toàn bộ kiểm thử", "SHA 073234cc… / d1fd298e…", f"trước {h0[:12]} sau {h1[:12]}; 0.3.3a {h33[:12]}",
        "PASS" if h0 == h1 == SHA34A and h33 == SHA33A else "FAIL", "FACT", "sha256", "src034a/, src033/")
    if os.environ.get("ATA_TIEM_LOI"):            # kiểm bộ chạy: một FAIL tiêm vào phải làm mã thoát = 1
        ghi("QA-TIEM", "Bộ chạy", "Lỗi tiêm có chủ đích (ATA_TIEM_LOI)", "FAIL", "tiêm", "FAIL", "—", "—", "—")
    xuat_ma_tran()
    dem = {k: sum(1 for r in KQ if r["ket_qua"] == k) for k in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")}
    code = 1 if dem["FAIL"] else (2 if dem["BLOCKED"] + dem["NOT TESTED"] else 0)
    with open(os.path.join(OUT, "KET_QUA_KIEM_THU.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(KQ[0].keys())); w.writeheader(); w.writerows(KQ)
    luu("KET_QUA_KIEM_THU.json", dict(dem=dem, ma_thoat=code, sha256_034a=h1, ket_qua=KQ))
    with open(os.path.join(OUT, "NHAT_KY.txt"), "w", encoding="utf-8") as f:
        f.write("CỔNG TIỀN MD-6 – nhật ký kiểm thử\n" + "\n".join(LOG) + f"\n\nTỔNG: {dem}\nMÃ THOÁT: {code}\nThời gian: {round(time.time() - t0)} s\n")
    print(dem, "mã thoát", code)
    sys.exit(code)


if __name__ == "__main__":
    main()
