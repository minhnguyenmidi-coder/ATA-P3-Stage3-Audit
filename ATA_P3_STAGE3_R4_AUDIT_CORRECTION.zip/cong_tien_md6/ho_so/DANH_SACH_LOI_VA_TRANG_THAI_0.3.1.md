# DANH SÁCH LỖI VÀ TRẠNG THÁI – sau Build 0.3.1 Candidate

**Quy ước trạng thái**
- **ĐÃ SỬA (mô hình):** mã đã sửa; test trên mô hình Python/tĩnh PASS; chưa kiểm trên TradingView.
- **CÒN MỞ:** chưa sửa.
- **CHỜ QUYẾT ĐỊNH:** thuộc quyền chủ dự án.

**Loại thay đổi**
- SAFE: không đổi hành vi nghiệp vụ.
- BEHAVIOR-CHANGING: đổi hành vi.

Số dòng theo file 0.3.1 Candidate (SHA `4839777…5fa935f`).

## Tổng hợp

| Mã | Nội dung | Mức | Loại thay đổi | Trạng thái | Test |
|---|---|---|---|---|---|
| QA-01 | Runner trả mã thoát 0 khi có FAIL | HIGH (quy trình) | — | **ĐÃ SỬA** (kiểm đột biến PASS) | QA-01 |
| QA-02 | Test tĩnh tuyên bố quá mức (ST-07, ST-08) | MEDIUM | — | **ĐÃ SỬA**, giới hạn ghi rõ | ST-04…08 |
| QA-03 | Mô hình Python thiếu truy vết | MEDIUM | — | **ĐÃ SỬA** | QA-03 |
| A-01 | So "≥ 1 tick" sai do số thực | MEDIUM | BEHAVIOR-CHANGING (tín hiệu SU-1) | ĐÃ SỬA (mô hình) | LG-A01-01…04 |
| A-02 | Khử trùng ≤ 1 tick sai do số thực | LOW | BEHAVIOR-CHANGING (hạng MD-4/MD-5) | ĐÃ SỬA (mô hình) | LG-A02-01 |
| A-03 | PDH/PDL/PWH/PWL bị gỡ trước nến M15 cuối kỳ | MEDIUM | BEHAVIOR-CHANGING (EV MD-5) | ĐÃ SỬA (mô hình) | LG-A03-01…03 |
| A-04 | Nguồn swing chỉ từ 10 swing gần giá, sau tiêu thụ | MEDIUM | BEHAVIOR-CHANGING (EV MD-5) | ĐÃ SỬA (mô hình) | LG-A04-01…04 |
| A-05 | Thứ tự khối ngược B.2.2 | MEDIUM (tiềm ẩn) | SAFE (0 giao cắt phụ thuộc) | ĐÃ SỬA (tĩnh) | ST-12, ST-08 |
| A-06 | Ngân sách plot chạm ngưỡng dự phòng 8 | LOW | SAFE | ĐÃ SỬA: 56 → 54 | ST-06 |
| A-07 | PROT dự phòng quét p₀+1…b, đặc tả ghi p₀…b | LOW | BEHAVIOR-CHANGING nếu chọn PA1 | **CHỜ QUYẾT ĐỊNH** (giữ nguyên) | UD-01 |
| A-08 | mDead/sổ nguồn tăng không giới hạn | LOW | — | **CÒN MỞ**: đã đo trên mô hình, chưa đo trên Pine | LG-A08-01, BLK-06 |
| A-09 | Nhiều EV kết thúc cùng nến chỉ ghi một | LOW | SAFE về giao dịch; đổi định dạng Data Window | ĐÃ SỬA (mô hình) | LG-A09-01, 02 |
| A-10 | Cửa sổ EV/MSS đếm nến đã xử lý | LOW | BEHAVIOR-CHANGING (chỉ khi có nhảy cóc) | ĐÃ SỬA (mô hình) | LG-A10-01, 02, LG-A04-04 |
| A-11 | Dashboard không hiện tickerid | LOW | SAFE | ĐÃ SỬA (tĩnh) | ST-11 |
| A-12 | Chưa từng compile 0.2.9/0.3.0/0.3.1 | HIGH (chặn nghiệm thu) | — | **CÒN MỞ – BLOCKED** | BLK-01 |
| A-13 | Thiếu 3 nến trước b không ghi lý do 8 | LOW | SAFE về giao dịch | ĐÃ SỬA (mô hình + tĩnh) | LG-A13-01 |
| Q2/D16 | Quy tắc giá SL/TP SELL | — | BEHAVIOR-CHANGING nếu chọn B | **CHỜ QUYẾT ĐỊNH** (giữ A) | UD-02 |
| Q1–Q4 | Phê duyệt gói quyết định Phase 1.5 | — | — | **CHỜ NGƯỜI DÙNG PHÊ DUYỆT** | UD-03 |

---

## Chi tiết các lỗi đã sửa

### A-01
- **Ở đâu:** dòng 1382–1387 `f_ge1Tick`; `f_listPick` dòng 1388–1409; `f_zonePick` dòng 1411–1419; S1 dòng 2759 (TP1), 2792 (TP2), 2801 (TP3).
- **Nguyên nhân:** `x >= close + tick` so trên số thực; ví dụ `2048.03 + 0.01 = 2048.0400000000004`.
- **Tác động giao dịch:** setup lẽ ra BỎ QUA (lý do 2) có thể thành tín hiệu với TP1 xa hơn. Trên 20.000 ca giả lập:
  - 99 ca đổi TP1 hoặc lý do;
  - 2.590 ca đổi TP2 (chỉ hiển thị);
  - danh sách đầy đủ ở `results/thay_doi_tin_hieu_A01.csv`.
- **Cách sửa:** `d × (x − base) / tick ≥ 1 − 1e-6`.
- **Rủi ro của cách sửa:** mức lệch lưới cách 0,999999 tick sẽ được nhận. Cạnh vùng và swing lấy từ high/low của feed nên luôn nằm trên lưới.
- **Kiểm:** LG-A01-01 (0/56.000 loại nhầm; 0.3.0 trên cùng dữ liệu loại nhầm 5.425/56.000 = 9,7%), LG-A01-02 (dưới/trên 1 tick, lệch lưới), LG-A01-03 (TP1/TP2/TP3), LG-A01-04 (trước/sau). Trên TradingView: BLK-04.

### A-02
- **Ở đâu:** MD-4 dòng 2509; MD-5 G.5 dòng 1942.
- **Nguyên nhân:** cùng loại với A-01.
- **Tác động:** hạng cụm/nhóm cao hơn 1 bậc ở ca biên. Chưa module nào dùng, nên chưa đổi tín hiệu.
- **Cách sửa:** `|a − b| / tick ≤ 1 + 1e-6`.
- **Rủi ro:** không đáng kể.
- **Kiểm:** LG-A02-01 — với 2048,03/2048,04: cùng nến gốc → hạng 2; khác nến gốc → hạng 3 (không gộp nhầm). Riêng cặp 2048,03/2048,04, 0.3.0 cũng cho hạng 2 (cặp này không rơi vào sai số); lỗi biên của 0.3.0 thể hiện ở phép so (LG-TP-11 vòng trước).

### A-03
- **Ở đâu:** MD-5 bước 1, dòng 2093–2106.
- **Nguyên nhân:** gỡ nguồn kỳ theo dữ liệu kỳ của nến M5 đang xử lý; nến M5 đó đã thuộc kỳ mới.
- **Tác động:** sót sweep PDH/PDL/PWH/PWL ở nến M15 cuối kỳ.
- **Cách sửa:** chỉ gỡ khi `sOp ≥ pdC` (tuần: `pwC`).
- **Rủi ro:** PDH cũ và mới cùng tồn tại trong một lần xử lý, dưới hai khóa khác nhau nên không xung đột.
- **Kiểm:** LG-A03-01 (9/9 nến cuối ngày có EV; 0.3.0: 0), LG-A03-02 (tuần), LG-A03-03 (dữ liệu D đến muộn 2 giờ: không trùng khóa, không gỡ sớm). Mô phỏng dùng mốc thời gian phiên thật: đóng 22:00 UTC, mở 23:00 UTC, nghỉ cuối tuần.

### A-04
- **Ở đâu:** StructX dòng 335–341; f_struct dòng 984–992; biến hàng đợi dòng 1797–1806; f_qPush/f_qStream/f_qRemove dòng 1886–1912; nhận luồng H1/H4 dòng 2015–2027; đưa vào sổ dòng 2113–2130.
- **Nguyên nhân:** chỉ đọc danh sách TP (10 phần tử, ảnh chụp sau khi đã tiêu thụ).
- **Cách sửa:** luồng swing mới độc lập; vào sổ đúng s_min theo G.1.
- **Rủi ro:**
  - thêm 5 trường UDT (94 trường / 188 phần tử);
  - sổ nguồn lớn hơn: mô hình đo tối đa 155 phần tử trên 60.000 nến M15;
  - compile chưa xác nhận.
- **Kiểm:**
  - LG-A04-01: 4 SH ngoài danh sách TP vào sổ; 0.3.0: 0.
  - LG-A04-02: swing bị phá ngay ở nến hiệu lực đầu tiên vẫn cho sweep 2 nến, E = max(High s, High s−1).
  - LG-A04-03: SH và SL cùng nến.
  - LG-A04-04: nhảy cóc.

### A-05
- **Ở đâu:** sắp lại khối, dòng 1660–2928 (11a dòng 1660, 11b 1680, 11b' 1752, 11c 2349, 11d 2650).
- **Cách sửa:** di chuyển nguyên văn (MOVED 737 dòng).
- **Rủi ro:** sai thứ tự khai báo. Kiểm cú pháp nhẹ báo 0 cảnh báo; trình biên dịch thật: BLK-01.
- **Kiểm:** ST-12 (0 giao cắt ghi→đọc ở 13 cặp); ST-08 (định nghĩa upstream mà pipeline đọc chỉ khác ở A-01).

### A-09 / A-06
- **Ở đâu:** đếm kết cục dòng 2260–2270; mã gộp dòng 2335–2337; plot dòng 3242–3246.
- **Tác động:** đổi định dạng CSV, META_VER = 301, cần MANIFEST mới; không ghép được với CSV 0.3.0.
- **Kiểm:** LG-A09-01 (49.500 tổ hợp mã hóa ↔ giải mã đúng), LG-A09-02 (3 xác nhận, 2 bị phá cùng nến), TL-CSV-01.
- Hai EV hết hạn cùng nến là không thể xảy ra theo G.3 [FACT].

### A-10
- **Ở đâu:** dòng 2034–2085 (bix, phát hiện nhảy cóc, đồng bộ lại), 2241, 2243, 2292.
- **Tác động:** chỉ khi dữ liệu gián đoạn.
- **Rủi ro [RECOMMENDATION]:** đồng bộ lại kết thúc toàn bộ nguồn đang có. Đây là lựa chọn bảo thủ, cần anh biết; đặc tả không quy định trường hợp này.
- **Kiểm:** LG-A10-01 (MSS (b) không dùng EV trước gián đoạn; 0.3.0 cho MSS = 1 sai), LG-A10-02.

### A-11
- **Ở đâu:** dòng 3128.
- Quy tắc khóa mã H-01 giống hệt 0.3.0; không thêm danh sách sàn.

### A-13
- **Ở đâu:** dòng 2727–2736.
- Setup vẫn CHỜ XÁC NHẬN, khối mới không ghi `z.sState`.
- [FACT] Nhánh này gần như không xảy ra trên dữ liệu thật, vì vùng chỉ xuất hiện sau thời gian khởi động (≥ 60 nến M5).

---

## Còn mở

| Mã | Việc cần | Ai làm |
|---|---|---|
| A-12 | Compile probe, rồi compile 0.3.1 Candidate | Cần TradingView. Hội đồng không có quyền truy cập; không yêu cầu mật khẩu. |
| A-08 | Profiler: đo thời gian và số phần tử mDead trên lịch sử dài | Cần TradingView |
| A-07, Q2/D16, Q1–Q4 | Quyết định | Chủ dự án |
