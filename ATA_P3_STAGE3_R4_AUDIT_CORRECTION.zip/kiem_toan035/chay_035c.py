# -*- coding: utf-8 -*-
"""Kiểm Build 0.3.5c (D-TV4H-01: không nạp khung nhỏ hơn biểu đồ). python3 kiem_toan035/chay_035c.py → ket_qua035/ket_qua_035c.*"""
import csv, hashlib, json, os, re, subprocess, sys, time, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C      # noqa: E402
import khung as K         # noqa: E402
G = K.G
F35B = os.path.join(G, "src035b", "ATA_P3_Build_0.3.5b_Candidate_Indicator.pine")
F35C = os.path.join(G, "src035c", "ATA_P3_Build_0.3.5c_Candidate_Indicator.pine")
S35B, S35C = K.doc(F35B), K.doc(F35C)
GIAY = {"1": 60, "3": 180, "5": 300, "15": 900, "30": 1800, "60": 3600, "120": 7200, "240": 14400, "D": 86400, "W": 604800, "M": 2628000}


class IpTF(K.Ip):
    def call_builtin(self, name, args, kw):
        if name == "timeframe.in_seconds":
            return GIAY[args[0]]
        return super().call_builtin(name, args, kw)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    t0 = time.time()
    hb, hc = sha(F35B), sha(F35C)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_035c.py")], cwd=G, capture_output=True, text=True)
    C.ghi("Q-01", "A", "0.3.5b đầu vào đúng SHA, không bị ghi đè; 0.3.5c tái lập từ script", "TĨNH", "0.3.5b = beffef3a…; dựng lại cùng SHA",
          f"0.3.5b {hb}; 0.3.5c {hc} → {sha(F35C)}; {r.stdout.strip()}", "PASS" if hb.startswith("beffef3a") and sha(F35C) == hc and r.returncode == 0 else "FAIL", "tools033/dung_build_035c.py")
    d = [l for l in difflib.unified_diff(S35B.split("\n"), S35C.split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    ma = [l for l in d if not re.search(r"0\.3\.5[bc]|^\+//", l)]
    ok = len(ma) == 10 and all("request.security" in l or "f_tfReq" in l or "f_avail(tf) ? tf : timeframe.period" in l for l in ma)
    C.ghi("Q-02", "A", "Diff 0.3.5b → 0.3.5c: chỉ tên bản, hàm f_tfReq (2 dòng) và tham số khung của 4 lệnh request.security f_struct", "TĨNH", "10 dòng mã, đúng loại",
          f"{len(d)} dòng diff; dòng mã: {[l[:90] for l in ma]}", "PASS" if ok else "FAIL", "src035c/DIFF_035b_035c.patch")
    rs = [l for l in S35C.split("\n") if "request.security(" in l and not l.strip().startswith("//")]
    ok = len(rs) == 8 and all(l.startswith("[") for l in rs) and all("lookahead = barmerge.lookahead_on" in l and "gaps = barmerge.gaps_off" in l for l in rs) \
        and S35C.count("[so[1], sx[1]]") == S35B.count("[so[1], sx[1]]") == 1
    C.ghi("Q-03", "A", "R2–R4/R9 giữ nguyên: 8 request.security ở cột 0 (vô điều kiện), lookahead_on, gaps_off; f_struct vẫn trả [so[1], sx[1]]", "TĨNH", "đúng",
          f"{len(rs)} lệnh; cột 0 {all(l.startswith('[') for l in rs)}", "PASS" if ok else "FAIL", "—")
    # chạy NGUYÊN VĂN f_avail + f_tfReq cho mọi khung biểu đồ
    sai, bang = [], {}
    for p, sec in GIAY.items():
        ip = IpTF()
        ip.g.update(chartSec=sec, **{"timeframe.period": p})
        for f in ("f_avail", "f_tfReq"):
            L, b = K.khoi(S35C, f)
            ip.load(K.PM.parse_program(L, b))
        ip.g["timeframe"] = None
        out = []
        for tf in ("15", "60", "240", "D"):
            try:
                v = ip.call_user("f_tfReq", [tf])
            except Exception:
                # pine_mini không có thuộc tính timeframe.period → thay bằng tên toàn cục
                raise
            out.append(v)
            if GIAY[v] < sec:
                sai.append((p, tf, v, "nạp khung nhỏ hơn biểu đồ"))
            if v != (tf if GIAY[tf] > sec else p):      # khả dụng → giữ nguyên khung; không khả dụng (≤ biểu đồ) → đúng khung biểu đồ
                sai.append((p, tf, v, "sai khung"))
        bang[p] = out
    ok = bang["5"] == ["15", "60", "240", "D"] and not sai and bang["240"] == ["240", "240", "240", "D"]
    C.ghi("Q-04", "B", "f_tfReq nguyên văn trên 11 khung biểu đồ: M5 giữ đúng 15/60/240/D (hành vi M5 không đổi); mọi khung khác không bao giờ xin khung nhỏ hơn biểu đồ; khung khả dụng giữ nguyên",
          "THÔNG DỊCH", "M5 → 15/60/240/D; 4h → 240/240/240/D; 0 vi phạm", f"{bang}; vi phạm {sai}", "PASS" if ok else "FAIL", "—")
    # trên M5 các lệnh gọi tương đương chữ với 0.3.5b sau khi thay f_tfReq("x") bằng "x"
    tg = re.sub(r'f_tfReq\("(\w+)"\)', r'"\1"', S35C)
    tg = re.sub(r"// 0\.3\.5c D-TV4H-01.*\nf_tfReq\(string tf\) =>\n    f_avail\(tf\) \? tf : timeframe\.period\n", "", tg).replace("0.3.5c", "0.3.5b")
    kh = [l for l in difflib.unified_diff(S35B.split("\n"), tg.split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    C.ghi("Q-05", "B", "Trên M5 (f_tfReq trả nguyên khung – Q-04): mã 0.3.5c rút gọn trùng từng ký tự 0.3.5b ngoài dòng chú thích đầu tệp → mọi kết quả kiểm 0.3.5/0.3.5b áp dụng nguyên cho M5",
          "TĨNH (thay thế ký hiệu)", "chỉ khác dòng chú thích đầu tệp", [l[:100] for l in kh], "PASS" if len(kh) == 2 and all(l[1:].startswith("// AI Trading") for l in kh) else "FAIL", "—")
    # chạy lại bộ B/C trên mã 0.3.5c
    C.S35, C.L35 = S35C, S35C.split("\n")
    C.S1_35 = K.doan(S35C, "int nt = array.size(trigE)", "// ---- S2a", 4)
    for t in ("t_perm", "t_grade", "t_s1_hoi_quy", "t_s1_muc_tieu", "t_data_window", "t_md5_song_song"):
        C.an_toan("Q-" + t[2:].upper(), "B/C trên 0.3.5c", "Chạy lại " + t + " trên mã 0.3.5c", "THÔNG DỊCH", "như 0.3.5b", "chay_035.py::" + t, getattr(C, t))
    for tid, mt in (("TV-C1", "Gắn 0.3.5c lên biểu đồ 4h (XAU, BTC) – không còn RE10139; dashboard ghi 'KHUNG BIỂU ĐỒ KHÔNG PHẢI M5 – TẮT TÍN HIỆU'"),
                    ("TV-C2", "Gắn 0.3.5c lên M5 – không lỗi, dashboard như 0.3.5b (REGIME H4, khung đến trễ 0/0)")):
        C.ghi(tid, "TradingView", mt, "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.5c", sha=hc, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "ket_qua_035c.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_035c.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem)
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") else 0)


if __name__ == "__main__":
    main()
