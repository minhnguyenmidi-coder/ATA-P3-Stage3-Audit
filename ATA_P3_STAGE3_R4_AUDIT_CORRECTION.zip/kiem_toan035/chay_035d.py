# -*- coding: utf-8 -*-
"""Kiểm Build 0.3.5d (D-TV4H-01: hiển thị đa khung – RE10139). python3 kiem_toan035/chay_035d.py → ket_qua035/ket_qua_035d.*"""
import csv, hashlib, json, os, re, subprocess, sys, time, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C      # noqa: E402
import khung as K         # noqa: E402
from chay_035c import IpTF, GIAY   # noqa: E402
G = K.G
F35C = os.path.join(G, "src035c", "ATA_P3_Build_0.3.5c_Candidate_Indicator.pine")
F35D = os.path.join(G, "src035d", "ATA_P3_Build_0.3.5d_Candidate_Indicator.pine")
S35C, S35D = K.doc(F35C), K.doc(F35D)
KHUNG_BD = ["5", "15", "60", "240", "D", "W", "M", "12M"]
GIAY = dict(GIAY, **{"12M": 31536000})
CTX = ["15", "60", "240", "D"]


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def may_tf(src, p):
    ip = IpTF()
    ip.call_builtin_goc = ip.call_builtin
    ip.g.update(chartSec=GIAY[p], **{"timeframe.period": p})
    for f in ("f_avail", "f_tfReq", "f_cbc"):
        if re.search(r"^" + f + r"\(", src, re.M):
            L, b = K.khoi(src, f)
            ip.load(K.PM.parse_program(L, b))
    return ip


def mo_hinh(build, p, N=20000, cap_ltf=200000):
    """Mô hình bộ nhớ theo tài liệu RE10139 (dữ liệu request.* chép/lưu theo nến): đơn vị = số 'đối tượng-nến' của 4 ngữ cảnh f_struct
    = Σ (số nến tính trong ngữ cảnh + số nến biểu đồ nhận bản chép). N = số nến biểu đồ (giả định như nhau cho mọi khung)."""
    cs = GIAY[p]
    tong = 0
    for tf in CTX:
        ts = GIAY["D"] if tf == "D" else GIAY[tf]
        if build in ("033a", "035b"):           # xin đúng khung, kể cả khung nhỏ hơn biểu đồ (nạp intrabar, tối đa 200.000)
            ctx = N * cs / ts if ts >= cs else min(cap_ltf, N * cs / ts)
            phu = N
        elif build == "035c":                   # khung nhỏ hơn biểu đồ → khung biểu đồ, không giới hạn số nến
            ctx = N * cs / max(ts, cs)
            phu = N
        else:                                   # 035d
            if cs <= 900:
                ctx, phu = N * cs / max(ts, cs), N
            elif ts > cs:
                ctx = min(2000, N * cs / ts); phu = min(N, ctx * ts / cs)
            else:
                ctx, phu = 1, 1
        tong += ctx + phu
    return round(tong)


def main():
    t0 = time.time()
    hc, hd = sha(F35C), sha(F35D)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_035d.py")], cwd=G, capture_output=True, text=True)
    C.ghi("D5-01", "A", "0.3.5c đầu vào đúng SHA; 0.3.5d tái lập từ script", "TĨNH", "0.3.5c = 545d8766…; dựng lại cùng SHA",
          f"0.3.5c {hc}; 0.3.5d {hd} → {sha(F35D)}; {r.stdout.strip()}", "PASS" if hc.startswith("545d8766") and sha(F35D) == hd and r.returncode == 0 else "FAIL", "tools033/dung_build_035d.py")
    d = [l for l in difflib.unified_diff(S35C.split("\n"), S35D.split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    ma = [l for l in d if not re.search(r"0\.3\.5[cd]|^\+//", l)]
    ok = len(ma) == 10 and all("request.security" in l or "f_cbc" in l or "chartSec <= 900 ? 100000 : f_avail(tf) ? 2000 : 1" in l for l in ma) and all(l.endswith(', calc_bars_count = f_cbc("' + t + '"))') for t in CTX for l in ma if l.startswith("+[") and f'f_tfReq("{t}")' in l)
    C.ghi("D5-02", "A", "Diff 0.3.5c → 0.3.5d: tên bản, hàm f_cbc (2 dòng), thêm calc_bars_count vào đúng 4 request.security f_struct; không đụng logic giao dịch",
          "TĨNH", "10 dòng mã đúng loại", [l[:110] for l in ma], "PASS" if ok else "FAIL", "src035d/DIFF_035c_035d.patch")
    # nguyên nhân: dashboard/hiển thị KHÔNG bị khóa theo khung → mất hiển thị trên khung lớn là do script DỪNG (RE10139)
    L = S35D.split("\n")
    dash = [l for l in L if re.match(r"^if iShowDash and barstate\.islast", l)]
    td = [l for l in L if "table.new(" in l and l.startswith("var table")]
    gate = re.findall(r"^if (.*)\n(?:    .*\n)*?    f_cell\(0,", S35D, re.M)
    ok = len(dash) >= 1 and "isM5" not in dash[0] and "logicOn" not in dash[0] and len(td) >= 1
    C.ghi("D5-03", "A", "Nguyên nhân gốc (mã): dashboard chỉ phụ thuộc iShowDash và barstate.islast, KHÔNG có điều kiện khung; khung ≠ M5 chỉ tắt tín hiệu (logicOn) và ghi cảnh báo "
          "→ dashboard/chỉ báo biến mất trên khung lớn chỉ có thể do script dừng vì lỗi runtime (RE10139 – ảnh chụp), không phải do điều kiện hiển thị",
          "TĨNH", "không có điều kiện khung trên nhánh dashboard", f"nhánh dashboard: {dash}; bảng: {[x[:60] for x in td]}", "PASS" if ok else "FAIL", "src035d dòng 'if iShowDash and barstate.islast'")
    # f_tfReq + f_cbc nguyên văn trên 8 khung biểu đồ yêu cầu
    sai, bang = [], {}
    for p in KHUNG_BD:
        ip = may_tf(S35D, p)
        row = []
        for tf in CTX:
            q = ip.call_user("f_tfReq", [tf]); n = ip.call_user("f_cbc", [tf])
            row.append((q, n))
            cs, ts = GIAY[p], GIAY[tf]
            kv_q = tf if ts > cs else p
            kv_n = 100000 if cs <= 900 else (2000 if ts > cs else 1)
            if (q, n) != (kv_q, kv_n):
                sai.append((p, tf, q, n, kv_q, kv_n))
        bang[p] = row
    ok = not sai and bang["5"] == [("15", 100000), ("60", 100000), ("240", 100000), ("D", 100000)] and bang["15"][0] == ("15", 100000)
    C.ghi("D5-04", "B", "f_tfReq/f_cbc nguyên văn trên M5, M15, H1, H4, D, W, M, Y: M5/M15 xin đúng khung cũ với 100000 nến (≥ mọi dữ liệu khả dụng → không đổi); "
          "> M15: khung dùng 2000 nến, khung không dùng 1 nến; không bao giờ xin khung nhỏ hơn biểu đồ", "THÔNG DỊCH", "đúng bảng", f"{bang}; sai {sai}", "PASS" if ok else "FAIL", "—")
    # M5/M15: 100000 ≥ số nến ngữ cảnh lớn nhất có thể (M15 trên biểu đồ M5 ≤ số nến biểu đồ / 3; số nến biểu đồ tối đa của gói cao nhất 40000)
    ok = 100000 >= 40000
    C.ghi("D5-05", "B", "M5/M15 không hồi quy: calc_bars_count = 100000 lớn hơn số nến ngữ cảnh tối đa (≤ 40000 nến biểu đồ của gói cao nhất) → ngữ cảnh tính trên toàn bộ dữ liệu như trước; "
          "các dòng mã khác của 0.3.5d trùng 0.3.5c/0.3.5b", "TĨNH (cận trên)", "100000 ≥ 40000", "100000 ≥ 40000 (giới hạn gói theo trang Limitations của TradingView – giả định, xem báo cáo)",
          "PASS" if ok else "FAIL", "—")
    # mô hình bộ nhớ: khớp mọi quan sát TradingView và cho thấy 0.3.5d trên mọi khung ≤ M5 (đã chạy được)
    obs = {("033a", "240"): "LỖI", ("035b", "240"): "LỖI", ("035c", "240"): "LỖI", ("035b", "5"): "ĐẠT"}
    mh = {b: {p: mo_hinh(b, p) for p in KHUNG_BD} for b in ("033a", "035b", "035c", "035d")}
    nguong = mh["035b"]["5"]
    khop = all((mh[b][p] > nguong) == (v == "LỖI") for (b, p), v in obs.items())
    d_ok = all(mh["035d"][p] <= nguong for p in KHUNG_BD if GIAY[p] > 900) and all(mh["035d"][p] == mh["035b"][p] for p in ("5", "15"))
    C.ghi("D5-06", "B", "Mô hình bộ nhớ theo tài liệu RE10139 (đối tượng-nến của 4 ngữ cảnh, N = 20000 nến biểu đồ): khớp cả 4 quan sát TradingView (M5 đạt; 4h lỗi ở 0.3.3a, 0.3.5b, 0.3.5c) "
          "và 0.3.5d: H1…Y ≤ mức M5 đã chạy được; M5/M15 không đổi so với trước", "MÔ HÌNH (không phải bằng chứng TradingView)", "khớp 4/4; H1…Y ≤ M5; M5/M15 bằng trước",
          f"mức M5 = {nguong}; {mh}", "PASS" if khop and d_ok else "FAIL", "—")
    # R2-R4/R9 và chạy lại test B/C trên 0.3.5d
    rs = [l for l in L if "request.security(" in l and not l.strip().startswith("//")]
    ok = len(rs) == 8 and all(l.startswith("[") for l in rs) and all("lookahead = barmerge.lookahead_on" in l and "gaps = barmerge.gaps_off" in l for l in rs) and S35D.count("[so[1], sx[1]]") == 1
    C.ghi("D5-07", "C", "request.security: vẫn 8 lệnh vô điều kiện, lookahead_on/gaps_off, f_struct trả [so[1], sx[1]] (no-repaint giữ nguyên)", "TĨNH", "đúng", f"{len(rs)} lệnh", "PASS" if ok else "FAIL", "—")
    C.S35, C.L35 = S35D, L
    C.S1_35 = K.doan(S35D, "int nt = array.size(trigE)", "// ---- S2a", 4)
    for t in ("t_perm", "t_grade", "t_s1_hoi_quy", "t_s1_muc_tieu", "t_data_window", "t_md5_song_song"):
        C.an_toan("D5-" + t[2:].upper(), "B/C trên 0.3.5d", "Chạy lại " + t + " trên mã 0.3.5d", "THÔNG DỊCH", "như 0.3.5c", "chay_035.py::" + t, getattr(C, t))
    tok = lambda s: len(re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*|:=|==|!=|<=|>=|=>|\S', "\n".join(re.sub(r"\s*//.*$", "", x) for x in s.split("\n"))))  # noqa: E731
    t34, td_ = tok(C.S34), tok(S35D)
    C.ghi("D5-08", "C", "Token: ước lượng theo tỷ lệ từ vựng so với 0.3.4a (≈ 93.628)", "TĨNH (ước lượng)", "≤ 100.256", f"từ vựng {t34} → {td_}; ước lượng {round(93628 * td_ / t34)}",
          "PASS" if 93628 * td_ / t34 <= 100256 else "FAIL", "—")
    for p in ("5", "15", "60", "240", "D", "W", "M", "12M"):
        C.ghi("TV-" + p, "TradingView", f"Gắn 0.3.5d trên khung {p}: compile, không lỗi đỏ, dashboard hiển thị", "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.5d", sha=hd, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "ket_qua_035d.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_035d.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem)
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") else 0)


if __name__ == "__main__":
    main()
