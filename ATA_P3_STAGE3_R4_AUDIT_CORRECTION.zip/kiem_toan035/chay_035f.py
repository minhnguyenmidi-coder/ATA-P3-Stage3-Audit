# -*- coding: utf-8 -*-
"""Kiểm Build 0.3.5f (sửa lỗi mất hiển thị M5/M15 của 0.3.5e). python3 kiem_toan035/chay_035f.py → ket_qua035/ket_qua_035f.*
Tái sử dụng bộ test 0.3.5 và các kiểm K của kiem_toan_035e; không viết lại test trùng."""
import csv, hashlib, json, os, re, subprocess, sys, time, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C            # noqa: E402
import khung as K               # noqa: E402
import kiem_toan_035e as KT     # noqa: E402
from chay_035c import IpTF      # noqa: E402
from chay_035d import GIAY, KHUNG_BD, CTX   # noqa: E402
G = K.G
F = {v: os.path.join(G, f"src{v}", f"ATA_P3_Build_0.3.{v[2:]}_Candidate_Indicator.pine") for v in ("035b", "035e", "035f")}
SHA_E = "94604c08cfd688e29bdb759896f26549957f314a7576d0c993d4949e18ff6f99"
S = {k: K.doc(p) for k, p in F.items()}
S35F = S["035f"]
LICH_SU = {"15": 100000, "60": 100000, "240": 36000, "D": 6500}   # GIẢ ĐỊNH số nến lịch sử khả dụng (XAU ~25 năm, trần 100000)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


NEN_BD = {"5": 20000, "15": 20000, "60": 20000, "240": 20000, "D": 6500, "W": 1300, "M": 300, "12M": 25}   # số nến biểu đồ: trần 20000, khung lớn bị giới hạn bởi ~25 năm lịch sử (GIẢ ĐỊNH)


def mo_hinh(build, p, N=None):
    """Đối tượng-nến của 4 ngữ cảnh f_struct (tài liệu RE10139: dữ liệu request.* lưu theo nến). Mặc định (không calc_bars_count): ngữ cảnh khung cao
    chỉ phủ khoảng lịch sử biểu đồ. calc_bars_count tường minh: lấy K nến CUỐI của khung đó (≤ lịch sử khả dụng)."""
    N = N or NEN_BD[p]
    cs = GIAY[p]; tong = 0
    for tf in CTX:
        ts = GIAY[tf]; dung = ts > cs
        if build == "035b":
            ctx = N * cs / ts if ts >= cs else min(200000, N * cs / ts)
        elif build == "035e":
            k = (100000 if cs <= 900 else (2000 if dung else 1))
            q = tf if dung else p
            ctx = min(k, LICH_SU.get(q, 10 ** 9) if cs <= 900 else k)
        else:  # 035f
            ctx = N * cs / ts if dung else N * cs / GIAY["12M"]
        tong += ctx + N
    return round(tong)


def main():
    t0 = time.time()
    he, hf = sha(F["035e"]), sha(F["035f"])
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_035f.py")], cwd=G, capture_output=True, text=True)
    C.ghi("F-01", "A", "0.3.5e đầu vào đúng SHA, không ghi đè; 0.3.5f tái lập từ script", "TĨNH", "0.3.5e = 94604c08…", f"0.3.5e {he}; 0.3.5f {hf} → {sha(F['035f'])}",
          "PASS" if he == SHA_E and sha(F["035f"]) == hf and r.returncode == 0 else "FAIL", "tools033/dung_build_035f.py")
    # Nguyên nhân: trên M5 0.3.5e ≡ 0.3.5b trừ calc_bars_count (K-06 của kiểm toán 0.3.5e, chạy lại ở đây)
    KT.S35E, KT.L35E = S["035e"], S["035e"].split("\n")
    ok6, tt6 = KT.k_m5_tuong_duong()
    C.ghi("F-02", "A", "NGUYÊN NHÂN (loại trừ): trên M5, 0.3.5e chỉ khác 0.3.5b (đã chạy được trên M5 – ảnh 19/11 00:27) ở tham số calc_bars_count = 100000 "
          "(f_tfReq trả nguyên khung trên M5 – K-02) → thay đổi gây mất hiển thị M5/M15 là calc_bars_count của 0.3.5d/e", "TĨNH (thay thế ký hiệu)",
          "chỉ khác calc_bars_count + chú thích/khai báo", tt6, "PASS" if ok6 else "FAIL", "src035e dòng 1004–1013; src035b dòng 1000–1003")
    # Sau sửa: 0.3.5f so với 0.3.5b CHỈ khác f_tfReq + chú thích/tên bản; trên M5/M15 f_tfReq("x") = "x" cho mọi khung dùng
    d = [l for l in difflib.unified_diff(S["035b"].split("\n"), S35F.split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    con = [l for l in d if not (l[1:].startswith("//") or re.search(r"0\.3\.5[bf] Candidate", l) or l in ("+f_tfReq(string tf) =>", '+    f_avail(tf) ? tf : "12M"')
                                or re.sub(r'f_tfReq\("(\w+)"\)', r'"\1"', l[1:]) in [x[1:] for x in d if x.startswith("-")])]
    C.ghi("F-03", "A", "Diff 0.3.5b → 0.3.5f: chỉ hàm f_tfReq (2 dòng), tham số khung của 4 lệnh, chú thích, tên bản; 0 calc_bars_count; 0 hằng mới",
          "TĨNH", "0 dòng khác ngoài nhóm", f"{len(d)} dòng; ngoài nhóm {con}; calc_bars_count ngoài chú thích còn {sum('calc_bars_count' in l for l in S35F.split(chr(10)) if not l.lstrip().startswith('//'))}",
          "PASS" if not con and "calc_bars_count" not in "\n".join(l for l in S35F.split("\n") if not l.lstrip().startswith("//")) and "simple int C" not in S35F else "FAIL", "src035f/DIFF_035b_035f.patch")
    # ma trận 8 khung: chạy nguyên văn f_avail + f_tfReq
    bang, sai = {}, []
    for p in KHUNG_BD:
        ip = IpTF(); ip.g.update(chartSec=GIAY[p], **{"timeframe.period": p})
        for f in ("f_avail", "f_tfReq"):
            Lf, b = K.khoi(S35F, f); ip.load(K.PM.parse_program(Lf, b))
        row = {}
        for tf in CTX:
            q, av = ip.call_user("f_tfReq", [tf]), ip.call_user("f_avail", [tf])
            row[tf] = (q, "DÙNG" if av else "KHÔNG DÙNG")
            if GIAY[q] < GIAY[p] or (av and q != tf) or (not av and q != "12M"):
                sai.append((p, tf, q))
        bang[p] = row
    ok = not sai and all(v == (k, "DÙNG") for k, v in bang["5"].items())
    C.ghi("F-04", "B", "Ma trận 8 khung (nguyên văn f_avail/f_tfReq): M5 xin đúng 15/60/240/D; khung dùng giữ nguyên; khung không dùng xin 12M; không bao giờ xin khung nhỏ hơn biểu đồ",
          "THÔNG DỊCH", "0 sai", f"{bang}; sai {sai}", "PASS" if ok else "FAIL", "—")
    mh = {b: {p: mo_hinh(b, p) for p in KHUNG_BD} for b in ("035b", "035e", "035f")}
    nguong = mh["035b"]["5"]
    obs = {("035b", "5"): "ĐẠT", ("035b", "240"): "LỖI", ("035e", "5"): "LỖI", ("035e", "15"): "LỖI", ("035e", "240"): "ĐẠT"}
    khop = {k: (mh[k[0]][k[1]] > nguong) == (v == "LỖI") for k, v in obs.items()}
    f_ok = all(mh["035f"][p] <= nguong for p in KHUNG_BD)
    C.ghi("F-05", "B", "Mô hình bộ nhớ (MÔ HÌNH, không phải bằng chứng TradingView): khớp 5 quan sát (0.3.5b M5 đạt/4h lỗi; 0.3.5e M5, M15 lỗi/4h đạt) và 0.3.5f ≤ mức M5 của 0.3.5b ở cả 8 khung",
          "MÔ HÌNH (lịch sử khả dụng là GIẢ ĐỊNH)", "khớp 5/5; 0.3.5f ≤ M5", f"mức M5 {nguong}; khớp {khop}; {mh}", "PASS" if all(khop.values()) and f_ok else "FAIL", "—")
    # K kiểm tái sử dụng trên 0.3.5f
    KT.S35E, KT.L35E = S35F, S35F.split("\n")
    for tid, fn, mt in (("F-06", KT.k_khong_gia_tri_gia, "Khung không dùng không sinh trạng thái hợp lệ giả (K-03)"), ("F-07", KT.k_chan_tin_hieu, "Tín hiệu chỉ có trên M5 – M15…Y không phát tín hiệu (K-04)"),
                        ):     # K-06 không dùng lại cho 0.3.5f: danh sách cho phép của nó gắn với tên 0.3.5e; tương đương M5 với 0.3.5b được kiểm trực tiếp ở F-03
        C.an_toan(tid, "K (tái sử dụng)", mt, "TĨNH/THÔNG DỊCH", "đúng", "kiem_toan_035e.py::" + fn.__name__, fn)
    rs = [l for l in S35F.split("\n") if "request.security(" in l and not l.strip().startswith("//")]
    ok = len(rs) == 8 and all(l.startswith("[") for l in rs) and all("lookahead = barmerge.lookahead_on" in l and "gaps = barmerge.gaps_off" in l for l in rs) and S35F.count("[so[1], sx[1]]") == 1
    C.ghi("F-09", "C", "request.security: 8 lệnh vô điều kiện, lookahead_on, gaps_off, [so[1], sx[1]] (R2–R4/R9, no-repaint)", "TĨNH", "đúng", f"{len(rs)} lệnh", "PASS" if ok else "FAIL", "—")
    KT.dat_ma(S35F)
    T = ["t_reg_vi_sai", "t_reg_bien", "t_vol", "t_perm", "t_lvpick", "t_grade", "t_d8", "t_a07_pine", "t_a07_tc", "t_zq3", "t_s1_hoi_quy", "t_s1_muc_tieu", "t_chuoi_md6_md7_s1",
         "t_xep_hang_s2b", "t_data_window", "t_hien_thi_canh_bao", "t_md5_song_song"]
    for t in T:
        C.an_toan("B35." + t, "B/C (bộ 0.3.5) trên 0.3.5f", "Chạy lại " + t, "THÔNG DỊCH/THAM CHIẾU", "như 0.3.5e", "chay_035.py::" + t, getattr(C, t))
    p = os.path.join(G, "hoi_quy034")
    r = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "035f"], cwd=p, capture_output=True, text=True, timeout=900)
    dj = json.load(open(os.path.join(p, "results", "ket_qua_test_035f.json"), encoding="utf-8"))
    rows = dj if isinstance(dj, list) else next(v for v in dj.values() if isinstance(v, list))
    fail = sorted(x["id"] for x in rows if x["trang_thai"] == "FAIL")
    dem = {}
    for x in rows:
        dem[x["trang_thai"]] = dem.get(x["trang_thai"], 0) + 1
    C.ghi("D-01f", "D · hồi quy cũ", "hoi_quy034 trên 0.3.5f (chỉ thêm đích '035f', không sửa assertion): FAIL đúng 6 test đổi có chủ đích như 0.3.5/0.3.5e", "HỒI QUY",
          "FAIL = {ST-01, ST-06, ST-08, ST-09, ST-12, UD-01}", f"{dem}; mã thoát gốc {r.returncode}; FAIL {fail}", "PASS" if set(fail) == set(C.KY_VONG_HQ) else "FAIL",
          "hoi_quy034/results/ket_qua_test_035f.json")
    import dot_bien_035 as DB
    song = []
    for ten, cu, moi, tests in DB.DB:
        KT.dat_ma(S35F.replace(cu, moi))
        bat = False
        for t in tests:
            try:
                bat = bat or not getattr(C, t)()[0]
            except Exception:       # noqa: BLE001
                bat = True
        song += [] if bat else [ten]
    KT.dat_ma(S35F)
    C.ghi("D-04f", "D · đối chứng âm", "12 đột biến tiêm vào bản sao 0.3.5f đều bị bắt", "ĐỘT BIẾN", "12/12", f"sống sót {song}", "PASS" if not song else "FAIL", "dot_bien_035.py")
    for p_ in ["COMPILE"] + KHUNG_BD:
        C.ghi("TV-" + p_, "TradingView", "Compile 0.3.5f" if p_ == "COMPILE" else f"0.3.5f trên khung {p_}: chỉ báo, dashboard, Data Window, không lỗi runtime/RE10139",
              "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "—")
    C.ghi("TV-EXNESS", "TradingView", "Dữ liệu Exness thật", "TRADINGVIEW", "—", "chưa có", "NOT TESTED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.5f", sha=hf, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "ket_qua_035f.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_035f.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem, round(time.time() - t0), "s")
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0)


if __name__ == "__main__":
    main()
