# -*- coding: utf-8 -*-
"""Khung chung cho bộ kiểm Build 0.3.5: trích nguyên văn hàm/kiểu/khối từ file Pine, chạy trên pine_mini (KHÔNG phải TradingView)."""
import os, re, sys, math
D = os.path.dirname(os.path.abspath(__file__)); G = os.path.dirname(D)
sys.path.insert(0, os.path.join(G, "kiem_toan034a")); sys.path.insert(0, os.path.join(G, "cong_tien_md6"))
import pine_mini as PM                      # noqa: E402
from pine_mini import PObj, PArr, NA, PineErr   # noqa: E402,F401

F34A = os.path.join(G, "src034a", "ATA_P3_Build_0.3.4a_Candidate_Indicator.pine")
F035 = os.path.join(G, "src035", "ATA_P3_Build_0.3.5_Candidate_Indicator.pine")
SHA34A = "073234cc6d9a5a9fbb81380f59b81482acdf1640484264ac0116909267f68605"
H_GMT7 = 7 * 3600 * 1000


def doc(p):
    return open(p, encoding="utf-8").read()


def hang_so(src):
    out = {}
    for l in src.split("\n"):
        m = re.match(r"^const (?:int|float|bool)\s+(\w+)\s*=\s*([-\d.e]+|true|false)\b", l)
        if m:
            v = m.group(2)
            out[m.group(1)] = (v == "true") if v in ("true", "false") else (float(v) if re.search(r"[.e]", v) else int(v))
    return out


def khoi(src, ten):
    """Khối cấp cao bắt đầu bằng 'ten(' (hàm) hoặc 'type ten' – tới dòng cột 0 kế tiếp. Trả (các dòng, số dòng đầu)."""
    L = src.split("\n")
    i = next(k for k, l in enumerate(L) if l.startswith(ten + "(") or l == "type " + ten or l.startswith("type " + ten + " "))
    j = i + 1
    while j < len(L) and (L[j].strip() == "" or L[j][0] in " \t"):
        j += 1
    while L[j - 1].strip() == "":
        j -= 1
    return L[i:j], i + 1


def doan(src, dau, cuoi, bo_thut=0):
    """Đoạn dòng từ dòng chứa `dau` tới trước dòng chứa `cuoi`; bỏ `bo_thut` ký tự thụt đầu."""
    L = src.split("\n")
    i = next(k for k, l in enumerate(L) if dau in l)
    j = next(k for k in range(i + 1, len(L)) if cuoi in L[k])
    return [l[bo_thut:] if l.strip() else "" for l in L[i:j]], i + 1


class Ip(PM.Interp):
    def call_builtin(self, name, args, kw):
        if name == "hour":          # hour(time, "GMT+7")
            assert args[1] == "GMT+7"
            return int(((args[0] + H_GMT7) // 3600000) % 24)
        if name == "math.round":
            return NA if args[0] is NA else int(math.floor(args[0] + 0.5))
        return super().call_builtin(name, args, kw)

    def ev_slow(self, e, sc):
        if e[0] == "hist" and getattr(self, "chuoi", None) is not None:
            base, k = e[1], self.ev(e[2], sc)
            if base[0] == "name" and base[1] in self.chuoi:
                i = self.g["bar_index"] - k
                return self.chuoi[base[1]][i] if 0 <= i < len(self.chuoi[base[1]]) else NA
        return super().ev_slow(e, sc)


def may(src, ham=(), kieu=(), them=None):
    ip = Ip()
    ip.g.update(hang_so(src))
    ip.g.update(tick=0.01, TICK_TOL=ip.g.get("TICK_TOL", 1e-6))
    if them:
        ip.g.update(them)
    for t in kieu:
        L, b = khoi(src, t)
        ip.load(PM.parse_program(L, b))
    for f in ham:
        L, b = khoi(src, f)
        ip.load(PM.parse_program(L, b))
    return ip


def goi(ip, ten, *a):
    return ip.call_user(ten, list(a))


def obj(ip, t, **f):
    return ip.new_obj(t, [], f)


def chay_dong(ip, lines, base):
    prog = PM.parse_program(lines, base)
    rest = ip.load(prog)
    ip.bar(rest)
