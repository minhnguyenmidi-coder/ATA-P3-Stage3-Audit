# -*- coding: utf-8 -*-
"""Kiểm Build 0.3.5b (sửa bộ nhớ mảng pool I-4 – RE10139). python3 kiem_toan035/chay_035b.py
Chạy lại MỌI test nhóm B/C của bộ 0.3.5 trên mã 0.3.5b, cộng các kiểm riêng của bản sửa. Mã thoát 1/2/0 như bộ 0.3.5."""
import csv, hashlib, json, os, subprocess, sys, time, difflib, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C      # noqa: E402
import khung as K         # noqa: E402
G = K.G
F35B = os.path.join(G, "src035b", "ATA_P3_Build_0.3.5b_Candidate_Indicator.pine")
S35B = K.doc(F35B)
KQ = C.KQ


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    t0 = time.time()
    h_in, h_out = sha(K.F035), sha(F35B)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_035b.py")], cwd=G, capture_output=True, text=True)
    C.ghi("R-01", "A", "0.3.5 đầu vào đúng SHA, không bị ghi đè; 0.3.5b tái lập từ script", "TĨNH", "0.3.5 = 9123ebb1…; dựng lại cùng SHA",
          f"0.3.5 {h_in}; 0.3.5b {h_out} → {sha(F35B)}; {r.stdout.strip()}", "PASS" if h_in.startswith("9123ebb1") and sha(F35B) == h_out and r.returncode == 0 else "FAIL", "tools033/dung_build_035b.py")
    d = [l for l in difflib.unified_diff(C.L35, S35B.split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    code = [l for l in d if not re.search(r"0\.3\.5b?|Build 0\.3\.5", l)]
    kv = {"-    plB := array.new<float>()", "-    prB := array.new<int>()", "-    plS := array.new<float>()", "-    prS := array.new<int>()", "-                plB := gLv", "-                prB := gRk",
          "-                plS := gLv", "-                prS := gRk", "+    array.clear(prB)", "+    array.clear(plS)", "+    array.clear(prS)", "+                array.concat(plB, gLv)",
          "+                array.concat(prB, gRk)", "+                array.concat(plS, gLv)", "+                array.concat(prS, gRk)"}
    du = set(code) - kv
    C.ghi("R-02", "A", "Diff 0.3.5 → 0.3.5b chỉ gồm tên bản và 8 dòng gán mảng pool (thay bằng clear/concat); không còn gán mảng mới cho biến pool",
          "TĨNH", "0 dòng mã ngoài danh sách; 0 '(plB|prB|plS|prS) :='", f"{len(d)} dòng diff; dòng mã ngoài danh sách: {sorted(du)}; còn gán: {re.findall(r'(?:plB|prB|plS|prS) :=', S35B)}",
          "PASS" if not du and not re.findall(r"(?:plB|prB|plS|prS) :=", S35B) else "FAIL", "src035b/DIFF_035_035b.patch")
    # mẫu gán mảng mới trong mã (nguồn bộ nhớ lịch sử): phải về như baseline
    n34, n35, n35b = (len(re.findall(r":= array\.new|:= array\.copy|:= map\.new", s)) for s in (C.S34, C.S35, S35B))
    C.ghi("R-03", "A", "Số chỗ gán mảng/map MỚI cho biến có sẵn (mỗi lần tạo một đối tượng giữ trong bộ đệm lịch sử 500 nến): 0.3.5b bằng baseline 0.3.4a",
          "TĨNH", "0.3.5b = 0.3.4a", f"0.3.4a {n34} · 0.3.5 {n35} · 0.3.5b {n35b}", "PASS" if n35b == n34 else "FAIL", "—")

    # chạy lại toàn bộ test B/C trên 0.3.5b
    C.S35, C.L35 = S35B, S35B.split("\n")
    C.S1_35 = K.doan(S35B, "int nt = array.size(trigE)", "// ---- S2a", 4)
    T = ["t_reg_vi_sai", "t_reg_bien", "t_vol", "t_perm", "t_lvpick", "t_grade", "t_d8", "t_a07_pine", "t_a07_tc", "t_zq3", "t_s1_hoi_quy", "t_s1_muc_tieu",
         "t_chuoi_md6_md7_s1", "t_xep_hang_s2b", "t_data_window", "t_hien_thi_canh_bao", "t_md5_song_song"]
    for t in T:
        C.an_toan("R-" + t[2:].upper(), "B/C trên 0.3.5b", "Chạy lại " + t + " của bộ 0.3.5 trên mã 0.3.5b", "THÔNG DỊCH", "như 0.3.5", "chay_035.py::" + t, getattr(C, t))

    # đồng nhất đối tượng: mảng pool là MỘT đối tượng suốt quá trình (0.3.5b) – đối chứng âm 0.3.5 tạo mảng mới
    import md5_song_song as MS

    def dem_id(text):
        ids = set()
        giu = []
        dem = dict(ne=0)
        MOI = {'plB', 'prB', 'plS', 'prS', 'REG_NA', 'REG_UP', 'REG_DN', 'REG_RG', 'REG_TR', 'VOL_X', 'META_VER'}
        goc = MS.trang_thai

        def tt(m):
            g = m.ip.g
            if "plB" in g:
                for k in ("plB", "prB", "plS", "prS"):
                    giu.append(g[k])           # giữ tham chiếu để Python không tái dùng id của đối tượng đã giải phóng
                    ids.add((k, id(g[k])))
                dem["ne"] += len(g["plB"].v) + len(g["plS"].v) > 0
            return {k: v for k, v in goc(m).items() if k not in MOI}
        MS.trang_thai = tt
        try:
            r = MS.chay("tong_hop", 1200, 3, so_sanh=True, kiem_bb=False, text_a=C.S34, text_b=text, ghi_moc=0)
        finally:
            MS.trang_thai = goc
        return len(ids), dem["ne"], r["nen_chay"], r["sai_khac"]
    n_b, n_a = dem_id(S35B), dem_id(K.doc(K.F035))
    C.ghi("R-04", "C", "Mảng pool giữ một đối tượng cố định qua 1.200 nến (0.3.5b: 4 đối tượng); đối chứng âm: 0.3.5 tạo đối tượng mới mỗi lần chạy bước 7",
          "THÔNG DỊCH (danh tính đối tượng)", "0.3.5b = 4; 0.3.5 > 4", f"(số đối tượng, số nến có pool, số nến chạy, sai khác MD-5) 0.3.5b {n_b} · 0.3.5 {n_a}", "PASS" if n_b[0] == 4 and n_a[0] > 4 and n_b[1] > 100 and n_b[2] > 1000 and n_b[3] is None else "FAIL", "—")
    for tid, mt in (("TV-R1", "RE10139 không còn trên XAUUSD/BTCUSD M5 Exness (khung thiết kế) sau khi tải lại và khi chạy realtime"),
                    ("TV-R2", "So sánh với baseline 0.3.4a trên cùng biểu đồ H4/Bar Replay: lỗi bộ nhớ có sẵn từ baseline hay mới ở 0.3.5"),
                    ("TV-03..07", "Điều kiện 2–5 (Data Window MÃ REGIME, khung trễ 0/0, tải lại/realtime, R-7)")):
        C.ghi(tid, "TradingView", mt, "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "HUONG_DAN_KIEM_TRADINGVIEW_0.3.5b.md")
    dem = {}
    for x in KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.5b", sha=h_out, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=KQ), open(os.path.join(out, "ket_qua_035b.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_035b.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(KQ[0].keys())); w.writeheader(); w.writerows(KQ)
    print(dem)
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") else 0)


if __name__ == "__main__":
    main()
