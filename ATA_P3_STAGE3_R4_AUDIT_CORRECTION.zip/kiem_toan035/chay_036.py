# -*- coding: utf-8 -*-
"""BỘ KIỂM BUILD 0.3.6 – MD-6 REGIME ENGINE. python3 kiem_toan035/chay_036.py → ket_qua035/ket_qua_036.{json,csv}
Gồm: đối chiếu đặc tả–mã (C.1–C.6), TC-RG01…TC-RG12, nhất quán đổi khung (mô hình), và hồi quy toàn bộ bộ test hiện có trên mã 0.3.6.
Mã thoát: 1 có FAIL · 2 còn BLOCKED/NOT TESTED · 0 tất cả PASS."""
import csv, hashlib, json, os, random, re, subprocess, sys, time, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C            # noqa: E402
import khung as K               # noqa: E402
import kiem_toan_035e as KT     # noqa: E402
import md2_tham_chieu as M2     # noqa: E402
import md6_tham_chieu as M6     # noqa: E402
from khung import NA            # noqa: E402

G = K.G
F35F = os.path.join(G, "src035f", "ATA_P3_Build_0.3.5f_Candidate_Indicator.pine")
F036 = os.path.join(G, "src036", "ATA_P3_Build_0.3.6_Candidate_Indicator.pine")
SHA_F = "7c95f3edf578a16bd7998645f510f5edad06dd3d04b027ce2bb6877ede59fe4b"
S35F, S36 = K.doc(F35F), K.doc(F036)
L36 = S36.split("\n")
REGN = {0: "KHÔNG ĐỦ DỮ LIỆU", 1: "UPTREND", 2: "DOWNTREND", 3: "RANGE", 4: "TRANSITION"}


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def dong(pat):
    return next((i + 1 for i, l in enumerate(L36) if re.search(pat, l)), None)


def ip():
    return K.may(S36, C.HAM, ("StructOut", "Zone", "Ev"))


def chuoi_reg(m, buoc, reg=0, tc=0):
    """buoc: list (st, ev, er, full) → list (REG tên, T_CNT) qua f_regNext NGUYÊN VĂN."""
    out = []
    for st, ev, e, full in buoc:
        reg, tc = K.goi(m, "f_regNext", reg, tc, st, ev, e, full)
        out.append((REGN[reg], tc))
    return out


def main():
    t0 = time.time()
    hf, h6 = sha(F35F), sha(F036)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_036.py")], cwd=G, capture_output=True, text=True)
    C.ghi("V-01", "E · phiên bản", "0.3.5f đầu vào đúng SHA, không ghi đè; 0.3.6 tái lập từ script", "TĨNH", "0.3.5f = 7c95f3ed…; dựng lại cùng SHA",
          f"0.3.5f {hf}; 0.3.6 {h6} → {sha(F036)}", "PASS" if hf == SHA_F and sha(F036) == h6 and r.returncode == 0 else "FAIL", "tools033/dung_build_036.py")
    d = [l for l in difflib.unified_diff(S35F.split("\n"), L36, lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    nhom = {"tên bản/chú thích": r"0\.3\.(5f|6) Candidate|^[+-]//", "META_VER": r"META_VER", "trường StructOut mới": r"^\+    (float er|int   tcnt)",
            "constructor so": r"StructOut so = StructOut\.new", "dashboard dòng 11": r'f_cell\(11, "Kiểm thử"'}
    ngoai = [l[:90] for l in d if not any(re.search(p, l) for p in nhom.values())]
    ok = not ngoai and len(d) == 14 and "request.security" not in "".join(d) and not re.search(r"\binput\.|plot\(|alert", "".join(d))
    C.ghi("V-02", "E · phiên bản", "Diff 0.3.5f → 0.3.6 chỉ gồm: tên bản, META_VER, 2 trường StructOut (er, tcnt), constructor so, dòng dashboard 11; 0 input/plot/alert/request.security",
          "TĨNH", "14 dòng thuộc 5 nhóm", f"{len(d)} dòng; ngoài nhóm {ngoai}", "PASS" if ok else "FAIL", "src036/DIFF_035f_036.patch")
    # ---------------- B. đối chiếu đặc tả – mã (C.1–C.6)
    spec = [
        ("C.1 ER_H4 = |C − C[20]| ÷ Σ_{i=0..19}|C[i] − C[i+1]|; mẫu 0 → 0", [r"float erD = math\.sum\(math\.abs\(ta\.change\(close\)\), 20\)", r"erD == 0 \? 0\.0 : math\.abs\(close - close\[20\]\) / erD"]),
        ("C.1 VR_H4 = ATR14 ÷ TB cộng ATR14 của 100 nến", [r"float vrv = a / ta\.sma\(a, 100\)", r"float a\s+= ta\.atr\(ATR_LEN\)"]),
        ("C.1 ST_H4/EV_H4 từ MD-2 (st, ev của f_struct H4); MSS tính là CHoCH (isChoch)", [r"\[rg2, tc2\] = f_regNext\(reg, tcnt, st, ev, erv,"]),
        ("C.2 KHÔNG ĐỦ DỮ LIỆU tới khi ≥ 120 nến H4 đã đóng và ER, VR khác NA", [r"bar_index >= 119 and not na\(erv\) and not na\(vrv\)"]),
        ("C.2 nến đủ dữ liệu đầu: quy tắc cơ bản với REG trước = TRANSITION, T_CNT = 0", [r"r := f_regBase\(st, e, REG_TR\)"]),
        ("C.2 thứ tự 1) CHoCH → TRANSITION, T=1; 2) TRANSITION và 1 ≤ T < 6 → T+1; 3) T=0 + cơ bản", [r"ev == EV_CHOCH_UP or ev == EV_CHOCH_DN", r"reg == REG_TR and t >= 1 and t < 6"]),
        ("C.2 quy tắc cơ bản: NONE/ER<0,20 → RANGE; ER≥0,30 theo ST; vùng trễ giữ xu hướng/RANGE, còn lại TRANSITION", [r"st == ST_NONE or e < 0\.20 \? REG_RG : e >= 0\.30"]),
        ("C.3 VOL: CỰC ≥ 2,5; CAO [1,5; 2,5); THƯỜNG (0,7; 1,5); THẤP ≤ 0,7; không trễ", [r"v >= VOL_X \? 4 : v >= 1\.5 \? 3 : v <= 0\.7 \? 1 : 2"]),
        ("C.5 REG = KHÔNG ĐỦ DỮ LIỆU → lý do 8", [r"if not okH4 or pendH4 or sH4\.reg == REG_NA"]),
        ("C.6 LAST_CHOCH_H4 cập nhật chỉ tại CHoCH, không bao giờ xóa, BOS không đổi", [r"if isChoch\n\s+lch := ev == EV_CHOCH_UP \? 1 : -1"]),
        ("Chỉ dùng nến H4 đã đóng (B.4/R6): f_struct trả so[1], lookahead_on", [r"\[so\[1\], sx\[1\]\]", r"f_tfReq\(\"240\"\), f_struct\(iN_H4, false, true\),  lookahead = barmerge\.lookahead_on"]),
        ("Đầu ra: REG, VR, LAST_CHOCH, ER, T_CNT ở StructOut; Data Window MÃ REGIME; dashboard dòng 11", [r", vrv, reg, lch, stT, chT, zDq, zSq, erv, tcnt\)", r"MD-6 MÃ REGIME", r"· T_CNT "]),
    ]
    for i, (yc, pats) in enumerate(spec, 1):
        vt = []
        ok = True
        for p in pats:
            m = re.search(p, S36)
            if not m:
                ok = False
                vt.append(None)
            else:
                vt.append(S36[:m.start()].count("\n") + 1)
        if i == 10:   # lch chỉ được gán ở đúng một chỗ
            ok = ok and len(re.findall(r"\blch :=", S36)) == 1
        C.ghi(f"B-{i:02d}", "B · đặc tả–mã", yc, "TĨNH", "có trong mã", f"dòng {vt}", "PASS" if ok else "FAIL", "src036")
    # ---------------- C. TC-RG
    m = ip()
    UP, DN, NO = 1, -1, 0
    cu, cd = 3, 4
    tc = {}
    tc["TC-RG01"] = (chuoi_reg(m, [(UP, 0, 0.35, True)], reg=3) == [("UPTREND", 0)] and chuoi_reg(m, [(UP, 0, 0.35, True)], reg=0) == [("UPTREND", 0)],
                     "ST UP, ER 0,35 từ RANGE và từ khởi tạo → UPTREND")
    s = chuoi_reg(m, [(UP, 0, e, True) for e in (0.25, 0.28, 0.25, 0.28, 0.29, 0.20)], reg=1)
    tc["TC-RG02"] = (all(x == ("UPTREND", 0) for x in s), f"UPTREND, ER 0,25↔0,28 (và 0,29; 0,20) → {s}")
    s = chuoi_reg(m, [(DN, cd, 0.9, True)], reg=1)
    tc["TC-RG03"] = (s == [("TRANSITION", 1)], f"CHoCH↓ tại nến H4 đó → {s}")
    m.g.update(okH4=True, pendH4=False, sH4=C.so(m, reg=1, vr=2.6), sH1=C.so(m, st=1), sM15=C.so(m, st=1))
    tc["TC-RG04"] = (K.goi(m, "f_vol", 2.6) == 4 and K.goi(m, "f_perm", 1) == 15,
                     "VR 2,6 → VOL-CỰC (f_vol = 4); setup bị chặn: lý do 15 theo I.3 (đặc tả TC-RG04 ghi 'WAIT' – điểm IP-4 chờ chủ dự án)")
    s = chuoi_reg(m, [(UP, 0, 0.5, False)] * 3)
    m.g.update(sH4=C.so(m, reg=0, vr=1.0))
    tc["TC-RG05"] = (s == [("KHÔNG ĐỦ DỮ LIỆU", 0)] * 3 and K.goi(m, "f_perm", 1) == 8, f"< 120 nến → {s[0]}; f_perm → lý do 8")
    s = chuoi_reg(m, [(UP, 0, 0.25, False), (UP, 0, 0.25, True)])
    tc["TC-RG06"] = (s[1] == ("TRANSITION", 0), f"nến thứ 120 đủ dữ liệu, ST UP, ER 0,25 → {s[1]}")
    s = chuoi_reg(m, [(DN, cd, 0.9, True)] + [(DN, 0, 0.9, True)] * 6, reg=1)
    tc["TC-RG07"] = (s[:6] == [("TRANSITION", k) for k in range(1, 7)] and s[6] == ("DOWNTREND", 0), f"CHoCH↓ ở n: {s}")
    s = chuoi_reg(m, [(DN, cd, 0.9, True), (DN, 0, 0.9, True), (DN, 0, 0.9, True), (UP, cu, 0.9, True)] + [(UP, 0, 0.9, True)] * 6, reg=1)
    tc["TC-RG08"] = (s[3] == ("TRANSITION", 1) and all(x[0] == "TRANSITION" for x in s[3:9]) and s[9] == ("UPTREND", 0), f"CHoCH↓ n, CHoCH↑ n+3: {s}")
    s = chuoi_reg(m, [(UP, 0, e, True) for e in (0.20, 0.23, 0.26, 0.29, 0.30)], reg=3)
    tc["TC-RG09"] = (s[:4] == [("RANGE", 0)] * 4 and s[4] == ("UPTREND", 0), f"RANGE, ER 0,20→0,29 rồi 0,30: {s}")
    for k in ("TC-RG01", "TC-RG02", "TC-RG03", "TC-RG04", "TC-RG05", "TC-RG06", "TC-RG07", "TC-RG08", "TC-RG09"):
        ok, tt = tc[k]
        C.ghi(k, "C · TC-RG", tt.split("→")[0].strip()[:90], "THÔNG DỊCH (f_regNext/f_vol/f_perm nguyên văn)", "đúng bảng P2-1.5.1", tt, "PASS" if ok else "FAIL", "P2-1.5.1 dòng 1198–1202, 1245–1248")
    for k, ly in (("TC-RG10", "SU-3 (lớp ĐẢO CHIỀU) và quyền TRANSITION theo LAST_CHOCH_H4 chưa triển khai (MD-7 đầy đủ/MD-8 – R.3 bước 6–7). Dữ liệu LAST_CHOCH_H4 đã có (sH4.lch)."),
                  ("TC-RG12", "Như TC-RG10: cần SU-3 BUY/SELL.")):
        C.ghi(k, "C · TC-RG", "C.6/I.3 – quyền TRANSITION theo LAST_CHOCH_H4 cho SU-3", "—", "—", ly, "NOT TESTED", "—")
    # TC-RG11: thời điểm hiệu lực – mô hình ngữ nghĩa request.security(lookahead_on) + so[1]
    H4 = 4 * 3600

    def gia_tri(t, lch_theo_nen):
        k = t // H4                    # nến H4 chứa t (lookahead_on)
        return lch_theo_nen.get(k - 1)  # so[1] = đối tượng của nến H4 trước (đã đóng)
    t12 = 12 * 3600
    lch = {t12 // H4 - 2: -1, t12 // H4 - 1: 1}          # nến 04–08: ↓; nến 08–12 (đóng 12:00) có CHoCH↑ → ↑
    v1155, v1200 = gia_tri(t12 - 300, lch), gia_tri(t12, lch)
    ok = v1155 == -1 and v1200 == 1 and "[so[1], sx[1]]" in S36 and S36.count("lookahead = barmerge.lookahead_on") == 8
    C.ghi("TC-RG11", "C · TC-RG", "C.6 hiệu lực LAST_CHOCH_H4 trên M5 từ nến đầu kỳ H4 kế tiếp", "MÔ HÌNH ngữ nghĩa (lookahead_on + so[1]) + TĨNH", "11:55 ↓, 12:00 ↑",
          f"11:55 → {v1155}; 12:00 → {v1200}", "PASS" if ok else "FAIL", "R-7 (vòng 0.3.4a) đã kiểm cơ chế so[1]")
    # ER/VR: mô phỏng ngữ nghĩa chuỗi Pine của biểu thức nguyên văn ↔ tham chiếu M6
    R = random.Random(5)
    Cc = [100.0]
    for _ in range(400):
        Cc.append(round(Cc[-1] + R.gauss(0, 1), 2))
    Cc[50:60] = [Cc[49]] * 10
    sai = []
    for i in range(len(Cc)):
        den = sum(abs(Cc[i - k] - Cc[i - k - 1]) for k in range(20)) if i >= 20 else None   # math.sum(abs(ta.change(close)), 20)
        erv = None if den is None else (0.0 if den == 0 else abs(Cc[i] - Cc[i - 20]) / den)
        ref = M6.er(Cc, i)
        if (erv is None) != (ref is None) or (erv is not None and abs(erv - ref) > 1e-12):
            sai.append(i)
    C.ghi("C-ER", "C · công thức", "ER: ngữ nghĩa chuỗi Pine của 'math.sum(math.abs(ta.change(close)), 20)' và 'math.abs(close − close[20]) ÷ erD' trùng tham chiếu C.1 (gồm đoạn giá đi ngang)",
          "MÔ HÌNH (mô phỏng ngữ nghĩa Pine) + THAM CHIẾU", "0 lệch", f"{len(Cc)} nến; lệch {sai[:5]}", "PASS" if not sai else "FAIL", "md6_tham_chieu.er")
    # 6.10: nhất quán khi đổi khung biểu đồ (mô hình): ngữ cảnh H4 bắt đầu ở đầu lịch sử biểu đồ
    def reg_cuoi(H, Lw, Cc_, w0):
        mm, ee = M2.chay(H[w0:], Lw[w0:], Cc_[w0:], N=3, a07="gom_p0")
        rr = M6.chay(mm.st_log, ee, Cc_[w0:], M6.atr_wilder(H[w0:], Lw[w0:], Cc_[w0:]))
        return rr[-1][0], mm.st_log[-1]
    kq = {420: [0, 0], 1000: [0, 0], 5000: [0, 0]}
    for seed in range(40):
        R = random.Random(100 + seed)
        n = 6000
        Cc_ = [2000.0]
        for i in range(n - 1):
            Cc_.append(round(Cc_[-1] + R.gauss(0.2 * (1 if (i // 600) % 2 else -1), 2.0), 2))
        H = [c + abs(R.gauss(0, 1.2)) for c in Cc_]; Lw = [c - abs(R.gauss(0, 1.2)) for c in Cc_]
        full = reg_cuoi(H, Lw, Cc_, 0)
        for w in kq:
            kq[w][0] += reg_cuoi(H, Lw, Cc_, n - w) == full
            kq[w][1] += 1
    tl = {w: f"{a}/{b}" for w, (a, b) in kq.items()}
    C.ghi("C-TF", "C · nhất quán khung", "REG/ST H4 ở nến cuối khi ngữ cảnh H4 chỉ có 420 nến (biểu đồ M5 ≈ 20k nến), 1000, 5000 (biểu đồ H1) so với toàn lịch sử – 40 chuỗi",
          "MÔ HÌNH MD-2 → MD-6", "ghi nhận tỷ lệ trùng (không có ngưỡng đặc tả)", f"trùng REG+ST ở nến cuối: {tl}", "PASS", "Xem báo cáo mục E – phụ thuộc điểm bắt đầu")
    # dashboard
    l11 = L36[dong(r'f_cell\(11, "Kiểm thử"') - 1]
    ok = all(x in l11 for x in ('array.from("KHÔNG ĐỦ DỮ LIỆU", "UPTREND", "DOWNTREND", "RANGE", "TRANSITION"), sH4.reg)', '" · VOL " + array.get(array.from("–", "THẤP", "THƯỜNG", "CAO", "CỰC"), f_vol(sH4.vr))',
                                 'str.tostring(sH4.er, "#.##")', 'str.tostring(sH4.vr, "#.##")', "str.tostring(sH4.tcnt)", 'sH4.lch == 1 ? "↑" : sH4.lch == -1 ? "↓" : "NA"', '"CHƯA KHẢ DỤNG"'))
    C.ghi("C-DB", "C · hiển thị", "Dashboard dòng 11: REG, VOL (đủ 4 lớp), ER, VR, T_CNT, LAST_CHOCH_H4; chặn bởi okH4 (CHƯA KHẢ DỤNG khi H4 không dùng được)", "TĨNH", "đủ 7 thành phần",
          "dòng %s" % dong(r'f_cell\(11'), "PASS" if ok else "FAIL", "—")
    # ---------------- D. hồi quy: toàn bộ bộ test hiện có trên 0.3.6
    KT.dat_ma(S36)
    T = ["t_reg_vi_sai", "t_reg_bien", "t_vol", "t_perm", "t_lvpick", "t_grade", "t_d8", "t_a07_pine", "t_a07_tc", "t_a07_tac_dong", "t_zq3", "t_s1_hoi_quy", "t_s1_muc_tieu",
         "t_chuoi_md6_md7_s1", "t_xep_hang_s2b", "t_data_window", "t_hien_thi_canh_bao", "t_md5_song_song"]
    for t in T:
        C.an_toan("R." + t, "D · hồi quy (bộ 0.3.5)", "Chạy lại " + t + " trên 0.3.6", "THÔNG DỊCH/THAM CHIẾU", "như 0.3.5f", "chay_035.py::" + t, getattr(C, t))
    KT.S35E, KT.L35E = S36, L36
    for tid, fn, mt in (("R.K-03", KT.k_khong_gia_tri_gia, "Khung không dùng không tạo trạng thái giả"), ("R.K-04", KT.k_chan_tin_hieu, "Tín hiệu chỉ trên M5")):
        C.an_toan(tid, "D · hồi quy (K)", mt, "TĨNH/THÔNG DỊCH", "đúng", "kiem_toan_035e.py::" + fn.__name__, fn)
    rs = [l for l in L36 if "request.security(" in l and not l.strip().startswith("//")]
    ok = len(rs) == 8 and all(l.startswith("[") for l in rs) and "calc_bars_count" not in "".join(rs) and S36.count('f_avail(tf) ? tf : "12M"') == 1
    C.ghi("R.MTF", "D · hồi quy MTF", "Kiến trúc MTF 0.3.5f giữ nguyên: 8 request.security vô điều kiện, không calc_bars_count, f_tfReq → 12M cho khung không dùng", "TĨNH", "đúng", f"{len(rs)} lệnh",
          "PASS" if ok else "FAIL", "—")
    # S1: đầu vào mới (er, tcnt) không được S1/MD-7 đọc
    s1 = "\n".join(C.S1_35[0]) + "\n".join(K.khoi(S36, "f_perm")[0]) + "\n".join(K.khoi(S36, "f_grade")[0])
    C.ghi("R.ISO", "D · ranh giới MD-6", "Trường mới er/tcnt chỉ được đọc ở dashboard – S1, f_perm, f_grade, S2b không đọc (không đổi quyền/logic giao dịch)", "TĨNH", "0 lần đọc",
          "S1/f_perm/f_grade đọc .er/.tcnt: %d; toàn tệp đọc sH4.er/tcnt: %d" % (len(re.findall(r"\.(er|tcnt)\b", s1)), len(re.findall(r"sH4\.(er|tcnt)\b", S36))),
          "PASS" if not re.findall(r"\.(er|tcnt)\b", s1) and len(re.findall(r"sH4\.(er|tcnt)\b", S36)) == 2 else "FAIL", "—")
    p = os.path.join(G, "hoi_quy034")
    r = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "036"], cwd=p, capture_output=True, text=True, timeout=900)
    dj = json.load(open(os.path.join(p, "results", "ket_qua_test_036.json"), encoding="utf-8"))
    rows = dj if isinstance(dj, list) else next(v for v in dj.values() if isinstance(v, list))
    fail = sorted(x["id"] for x in rows if x["trang_thai"] == "FAIL")
    dem = {}
    for x in rows:
        dem[x["trang_thai"]] = dem.get(x["trang_thai"], 0) + 1
    C.ghi("R.HQ034", "D · hồi quy cũ", "hoi_quy034 trên 0.3.6 (chỉ thêm đích '036', không sửa assertion): FAIL chỉ ở 6 test đổi có chủ đích đã phân loại", "HỒI QUY",
          "FAIL = {ST-01, ST-06, ST-08, ST-09, ST-12, UD-01}", f"{dem}; mã thoát gốc {r.returncode}; FAIL {fail}", "PASS" if set(fail) == set(C.KY_VONG_HQ) else "FAIL",
          "hoi_quy034/results/ket_qua_test_036.json")
    # A-09 của bộ 0.3.5 (StructOut 84) – chạy nguyên văn để ghi nhận, không sửa
    C.nhom_a()
    for x in C.KQ:
        if x["id"] in ("A-01", "A-02", "A-03", "A-04", "A-05", "A-06", "A-07", "A-08", "A-09", "A-10", "A-11"):
            x["id"] = "R.A35." + x["id"]
    nf = len([l for l in L36[next(i for i, l in enumerate(L36) if l == "type StructOut") + 1:] if l.startswith("    ")][:200])
    m_ = re.search(r"StructOut so = StructOut\.new\((.*)\)\n", S36)
    na_ = len(re.split(r",(?![^()]*\))", m_.group(1)))
    fs = L36[next(i for i, l in enumerate(L36) if l == "type StructOut") + 1:]
    fs = fs[:next(i for i, l in enumerate(fs) if not l.startswith("    "))]
    C.ghi("V-03", "E · phiên bản", "StructOut 86 trường = 86 đối số constructor so; 2 trường cuối er, tcnt có mặc định (thay cho A-09 của bộ 0.3.5 – kỳ vọng 84 cũ)", "TĨNH", "86 = 86",
          f"trường {len(fs)}; đối số {na_}; 2 cuối {[l.split()[1] for l in fs[-2:]]}", "PASS" if len(fs) == 86 and na_ == 86 and [l.split()[1] for l in fs[-2:]] == ["er", "tcnt"] else "FAIL", "—")
    an = C.an_toan
    an("R.VD", "D · hồi quy", "Vòng đời MD-5 2.054 bước", "HỒI QUY", "0 FAIL", "ket_qua034a_nt/vong_doi.json", C.t_vong_doi)
    import dot_bien_035 as DB
    song = []
    for ten, cu_, moi, tests in DB.DB:
        KT.dat_ma(S36.replace(cu_, moi))
        bat = False
        for t in tests:
            try:
                bat = bat or not getattr(C, t)()[0]
            except Exception:       # noqa: BLE001
                bat = True
        song += [] if bat else [ten]
    KT.dat_ma(S36)
    C.ghi("R.DB", "D · đối chứng âm", "12 đột biến trên bản sao 0.3.6 đều bị bắt", "ĐỘT BIẾN", "12/12", f"sống sót {song}", "PASS" if not song else "FAIL", "dot_bien_035.py")
    for tid, mt in (("TV-COMPILE", "Compile 0.3.6"), ("TV-M5", "M5: chỉ báo, dashboard dòng 11 (REG·VOL·ER·VR·T_CNT·CHoCH H4), Data Window MÃ REGIME, tín hiệu như 0.3.5f"),
                    ("TV-M15-Y", "M15, H1, H4, D, W, M, 12M: không lỗi, dashboard hiện"), ("TV-RELOAD", "Tải lại/realtime/Bar Replay: REG trên nến H4 đã đóng không đổi")):
        C.ghi(tid, "TradingView", mt, "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "—")
    C.ghi("TV-EXNESS", "TradingView", "Dữ liệu Exness thật / Profiler / CSV", "TRADINGVIEW", "—", "chưa có", "NOT TESTED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.6", sha=h6, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "ket_qua_036.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_036.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem, round(time.time() - t0), "s")
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0)


if __name__ == "__main__":
    main()
