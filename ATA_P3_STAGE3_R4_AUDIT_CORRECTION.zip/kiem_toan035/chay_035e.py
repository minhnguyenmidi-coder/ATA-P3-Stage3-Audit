# -*- coding: utf-8 -*-
"""Kiểm Build 0.3.5e (sửa CE10123 của 0.3.5d). python3 kiem_toan035/chay_035e.py → ket_qua035/ket_qua_035e.*"""
import csv, hashlib, json, os, re, subprocess, sys, time, difflib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C      # noqa: E402
import khung as K         # noqa: E402
import chay_035c                # noqa: E402
from chay_035c import IpTF  # noqa: E402
chay_035c.GIAY["12M"] = 31536000
from chay_035d import GIAY, KHUNG_BD, CTX, mo_hinh  # noqa: E402
G = K.G
F35D = os.path.join(G, "src035d", "ATA_P3_Build_0.3.5d_Candidate_Indicator.pine")
F35E = os.path.join(G, "src035e", "ATA_P3_Build_0.3.5e_Candidate_Indicator.pine")
S35D, S35E = K.doc(F35D), K.doc(F35E)
TEN = {"15": "CB15", "60": "CB60", "240": "CB4H", "D": "CBD"}


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    t0 = time.time()
    hd, he = sha(F35D), sha(F35E)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_035e.py")], cwd=G, capture_output=True, text=True)
    C.ghi("E5-01", "A", "0.3.5d đầu vào đúng SHA; 0.3.5e tái lập từ script", "TĨNH", "0.3.5d = b050d51a…; dựng lại cùng SHA",
          f"0.3.5d {hd}; 0.3.5e {he} → {sha(F35E)}; {r.stdout.strip()}", "PASS" if hd.startswith("b050d51a") and sha(F35E) == he and r.returncode == 0 else "FAIL", "tools033/dung_build_035e.py")
    L = S35E.split("\n")
    d = [l for l in difflib.unified_diff(S35D.split("\n"), L, lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    ma = [l for l in d if not re.search(r"0\.3\.5[de]|^\+//", l)]
    ok = len(ma) == 15 and all(re.search(r"f_cbc|simple int C|calc_bars_count = CB|chartSec <= 900 \? 100000 : f_avail", l) for l in ma)
    C.ghi("E5-02", "A", "Diff 0.3.5d → 0.3.5e: chỉ bỏ hàm f_cbc, thêm 5 hằng 'simple int', đổi tham số calc_bars_count của 4 lệnh", "TĨNH", "15 dòng mã đúng loại",
          [l[:100] for l in ma], "PASS" if ok else "FAIL", "src035e/DIFF_035d_035e.patch")
    # CE10123: tham số calc_bars_count chỉ là tên khai báo 'simple int'; vế phải chỉ gồm timeframe.in_seconds(hằng/timeframe.period), hằng số, CS_
    decl = {m.group(1): m.group(2) for m in re.finditer(r"^simple int (\w+)\s*=\s*(.*)$", S35E, re.M)}
    args = re.findall(r"calc_bars_count = (\w+)\)", S35E)
    bad = [a for a in args if a not in decl]
    for k, v in decl.items():
        rest = re.sub(r'timeframe\.in_seconds\((?:"\w+"|timeframe\.period)\)|\bCS_\b|\d+|<=|>|\?|:|\s', "", v)
        if rest:
            bad.append((k, rest))
    ok = len(args) == 4 and not bad and "f_cbc" not in S35E
    C.ghi("E5-03", "C", "Sửa CE10123: calc_bars_count nhận 4 hằng khai báo tường minh 'simple int'; vế phải chỉ dùng timeframe.in_seconds(hằng | timeframe.period) và hằng số (đều simple) – không qua hàm người dùng",
          "TĨNH (kiểu qualifier)", "4 đối số đều khai báo simple int; 0 thành phần series", f"đối số {args}; khai báo {decl}; vi phạm {bad}", "PASS" if ok else "FAIL",
          "Lỗi gốc: ảnh Pine Editor 0.3.5d dòng 1006, CE10123")
    # giá trị: chạy nguyên văn 5 dòng khai báo trên 8 khung, so với f_cbc của 0.3.5d (giá trị không đổi)
    blk = "\n".join(l.replace("simple int ", "int ") for l in L if l.startswith("simple int C"))
    sai, bang = [], {}
    from chay_035d import may_tf
    for p in KHUNG_BD:
        ip = IpTF(); ip.g.update(chartSec=GIAY[p], **{"timeframe.period": p})
        K.chay_dong(ip, blk.split("\n"), 1)
        ipd = may_tf(S35D, p)
        row = []
        for tf in CTX:
            v, vd = ip.g[TEN[tf]], ipd.call_user("f_cbc", [tf])
            row.append(v)
            if v != vd:
                sai.append((p, tf, v, vd))
        bang[p] = row
    ok = not sai and bang["5"] == [100000] * 4 and bang["15"] == [100000] * 4 and bang["240"] == [1, 1, 1, 2000]
    C.ghi("E5-04", "B", "Giá trị 4 hằng trên M5, M15, H1, H4, D, W, M, Y trùng f_cbc của 0.3.5d (M5/M15 = 100000; > M15: khung dùng 2000, không dùng 1)", "THÔNG DỊCH (vi sai 0.3.5d)",
          "0 khác", f"{bang}; khác {sai}", "PASS" if ok else "FAIL", "—")
    rs = [l for l in L if "request.security(" in l and not l.strip().startswith("//")]
    ok = len(rs) == 8 and all(l.startswith("[") for l in rs) and all("lookahead = barmerge.lookahead_on" in l and "gaps = barmerge.gaps_off" in l for l in rs) and S35E.count("[so[1], sx[1]]") == 1
    C.ghi("E5-05", "C", "request.security: 8 lệnh vô điều kiện, lookahead_on/gaps_off, [so[1], sx[1]]", "TĨNH", "đúng", f"{len(rs)} lệnh", "PASS" if ok else "FAIL", "—")
    mh = {p: mo_hinh("035d", p) for p in KHUNG_BD}
    C.ghi("E5-06", "B", "Mô hình bộ nhớ (như D5-06; giá trị giới hạn không đổi so với 0.3.5d)", "MÔ HÌNH", "H1…Y ≤ M5", mh,
          "PASS" if all(mh[p] <= mh["5"] for p in KHUNG_BD if GIAY[p] > 900) else "FAIL", "—")
    C.S35, C.L35 = S35E, L
    C.S1_35 = K.doan(S35E, "int nt = array.size(trigE)", "// ---- S2a", 4)
    for t in ("t_perm", "t_s1_hoi_quy", "t_s1_muc_tieu", "t_data_window", "t_md5_song_song"):
        C.an_toan("E5-" + t[2:].upper(), "B/C trên 0.3.5e", "Chạy lại " + t + " trên mã 0.3.5e", "THÔNG DỊCH", "như 0.3.5d", "chay_035.py::" + t, getattr(C, t))
    for p in ["COMPILE"] + KHUNG_BD:
        C.ghi("TV-" + p, "TradingView", "Compile 0.3.5e" if p == "COMPILE" else f"Gắn 0.3.5e trên khung {p}: không lỗi đỏ, dashboard hiển thị", "TRADINGVIEW", "bằng chứng TradingView",
              "chưa có", "BLOCKED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.5e", sha=he, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "ket_qua_035e.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_035e.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem)
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") else 0)


if __name__ == "__main__":
    main()
