# -*- coding: utf-8 -*-
"""
BỘ KIỂM BUILD 0.3.5 CANDIDATE – python3 kiem_toan035/chay_035.py [--nhanh]
Phạm vi: A-07 PA1 và D-P2-01 I-1…I-6 (kèm MD-6 regime/VOL tối thiểu cho I-1). Kết quả: ket_qua035/.
Mã thoát: 1 có FAIL · 2 không FAIL nhưng còn BLOCKED/NOT TESTED · 0 tất cả PASS.
Nhãn phương pháp: TĨNH (đọc mã) · THÔNG DỊCH (chạy NGUYÊN VĂN mã Pine trên pine_mini – không phải TradingView)
· THAM CHIẾU (mô hình Python viết từ đặc tả) · HỒI QUY (bộ test cũ) · TRADINGVIEW (luôn BLOCKED khi chưa có bằng chứng).
--nhanh: bỏ D-03 (bộ cổng tiền MD-6, ≈ 2 phút) → NOT TESTED.
"""
import csv, hashlib, json, os, random, re, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import khung as K                                   # noqa: E402
from khung import NA, PArr, PineErr                 # noqa: E402
import md6_tham_chieu as M6                         # noqa: E402
import md2_tham_chieu as M2                         # noqa: E402
import tai_lieu as TL                               # noqa: E402

G = K.G
OUT = os.path.join(G, "ket_qua035"); os.makedirs(OUT, exist_ok=True)
KQ = []
NHANH = "--nhanh" in sys.argv
S34, S35 = K.doc(K.F34A), K.doc(K.F035)
L34, L35 = S34.split("\n"), S35.split("\n")
SHA35_GIAO = None


def ghi(tid, nhom, muc_tieu, phuong_phap, ky_vong, thuc_te, kq, bang_chung):
    assert kq in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")
    KQ.append(dict(id=tid, nhom=nhom, muc_tieu=muc_tieu, phuong_phap=phuong_phap, ky_vong=ky_vong, thuc_te=str(thuc_te)[:2000], ket_qua=kq, bang_chung=bang_chung))
    print(f"{kq:11} {tid:13} {muc_tieu[:95]}", flush=True)


def an_toan(tid, nhom, muc_tieu, pp, kv, bc, fn):
    """Chạy fn() → (ok, thực tế). Lỗi Python/Pine trong test = FAIL (không nuốt lỗi)."""
    try:
        ok, tt = fn()
    except Exception as e:      # noqa: BLE001
        import traceback
        ok, tt = False, "LỖI: " + repr(e) + " " + traceback.format_exc()[-600:]
    ghi(tid, nhom, muc_tieu, pp, kv, tt, "PASS" if ok else "FAIL", bc)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def bo_cm(l):
    return re.sub(r"\s*//.*$", "", l)


# ============================================================ NHÓM A – đặc tả và mã nguồn (TĨNH)
def nhom_a():
    global SHA35_GIAO
    h34a = sha(K.F34A)
    SHA35_GIAO = sha(K.F035)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_035.py")], cwd=G, capture_output=True, text=True)
    h_lai = sha(K.F035)
    ghi("A-01", "A", "Baseline 0.3.4a đúng SHA, không bị ghi đè; build 0.3.5 tái lập từ script (cùng SHA), script tự kiểm SHA đầu vào",
        "TĨNH (sha256, chạy lại dung_build_035.py)", f"0.3.4a = {K.SHA34A}; SHA 0.3.5 trước = sau khi dựng lại",
        f"0.3.4a {h34a}; 0.3.5 {SHA35_GIAO} → dựng lại {h_lai}; script: {r.stdout.strip()} {r.stderr.strip()[-200:]}",
        "PASS" if h34a == K.SHA34A and h_lai == SHA35_GIAO and r.returncode == 0 else "FAIL", "tools033/dung_build_035.py")

    import difflib
    dif = [l for l in difflib.unified_diff(L34, L35, lineterm="", n=0)]
    cong = [l for l in dif if l.startswith("+") and not l.startswith("+++")]
    tru = [l for l in dif if l.startswith("-") and not l.startswith("---")]
    hunks = [l for l in dif if l.startswith("@@")]
    # vùng baseline bị đụng
    vung_cu = []
    for h in hunks:
        m = re.match(r"@@ -(\d+)(?:,(\d+))? ", h)
        a, n = int(m.group(1)), int(m.group(2) or 1)
        vung_cu.append((a, a + max(n, 1) - 1))
    # Q2/D16: khối khớp lệnh quy tắc A, giá SL/TP; Q4: D14–D19
    i_a = next(i for i, l in enumerate(L34) if "SỔ – KHỚP LỆNH QUY TẮC A" in l) + 1
    i_b = next(i for i, l in enumerate(L34) if l.startswith("// Phá hòa D8")) + 1
    dung_q2 = [v for v in vung_cu if not (v[1] < i_a or v[0] >= i_b)]
    q4 = [l for l in cong + tru if re.search(r"\bD1[4-9]\b|\bQ2\b|\bQ4\b", l)]
    ok = len(cong) == 179 and len(tru) == 33 and not dung_q2 and not q4
    ghi("A-02", "A", "Phạm vi diff 0.3.4a→0.3.5: chỉ các phép thay của script (+179/−33 dòng); không đụng khối khớp lệnh quy tắc A/giá SL-TP (Q2/D16), không có dòng D14–D19 (Q4)",
        "TĨNH (difflib)", "+179/−33; 0 hunk trong khối quy tắc A (dòng %d–%d của 0.3.4a); 0 dòng D14–D19/Q2/Q4" % (i_a, i_b - 1),
        f"+{len(cong)}/−{len(tru)}; {len(hunks)} hunk; hunk trong khối quy tắc A: {dung_q2}; dòng Q2/Q4: {q4[:3]}", "PASS" if ok else "FAIL", "src035/DIFF_034a_035.patch")

    lint = [(i + 1, l.strip()) for i, l in enumerate(L35) if not l.strip().startswith("//") and re.search(r"(\)|\])\.\w+\s*:=", bo_cm(l))]
    ghi("A-03", "A", "Không có mẫu CE10137 (gán trường lên kết quả gọi hàm/chỉ số)", "TĨNH", "0", lint, "PASS" if not lint else "FAIL", "—")

    def dong_dau(pat):
        return next((i + 1 for i, l in enumerate(L35) if re.search(pat, l)), None)

    def dung_dau(name):
        return next((i + 1 for i, l in enumerate(L35) if not l.startswith(name + "(") and re.search(r"\b" + re.escape(name) + r"\(", bo_cm(l))), None)
    sai = []
    for f in ("f_regBase", "f_regNext", "f_vol", "f_lvPick", "f_suOrd", "f_perm", "f_grade"):
        d_, u_ = dong_dau(r"^" + f + r"\("), dung_dau(f)
        if d_ is None or u_ is None or u_ < d_:
            sai.append((f, d_, u_))
    i_grade = dong_dau(r"^f_grade\(")
    for gname, pat in (("cLo", r"^var array<float>\s+cLo\b"), ("cHi", r"^var array<float>\s+cHi\b"), ("cRank", r"^var array<int>\s+cRank\b"), ("md4OK", r"^var bool\s+md4OK\b"),
                       ("zones", r"^var array<Zone> zones\b"), ("okD", r"^bool okD\b"), ("isXAU", r"^bool\s+isXAU\b"), ("md5OK", r"^var bool\s+md5OK\b"), ("plB", r"^var array<float> plB\b")):
        d_ = dong_dau(pat)
        if d_ is None or d_ > i_grade:
            sai.append((gname, d_, i_grade))
    ghi("A-04", "A", "Thứ tự khai báo Pine: hàm mới khai báo trước lần dùng đầu; biến toàn cục mà f_perm/f_grade/S1 đọc khai báo trước f_grade",
        "TĨNH", "0 vi phạm", sai or "0 vi phạm", "PASS" if not sai else "FAIL", "—")

    cnt = lambda s, p: len(re.findall(p, "\n".join(bo_cm(l) for l in s.split("\n"))))  # noqa: E731
    v = {k: (cnt(S34, p), cnt(S35, p)) for k, p in (("input", r"\binput\.\w+\("), ("request.security", r"\brequest\.security\("), ("alert", r"\balert(?:condition)?\("),
                                                     ("plot", r"^plot\(|\bplot\("), ("ta.", r"\bta\.\w+\("), ("label.new", r"\blabel\.new\("))}
    t_moi = [l for l in L35 if l.startswith("plot(") and l not in L34]
    ok = v["input"][0] == v["input"][1] and v["request.security"][0] == v["request.security"][1] and v["alert"] == (0, 0) and v["plot"][1] == v["plot"][0] + 2 \
        and v["plot"][1] <= 64 - 8 and len(t_moi) == 2 and v["label.new"][0] == v["label.new"][1]
    ghi("A-05", "A", "Tối ưu/không mở rộng: 0 input mới, 0 request.security mới, 0 alert mới, đúng 2 plot Data Window mới (I-5), dự phòng plot ≥ 8; ta.* mới chỉ ở MD-6",
        "TĨNH (đếm ngoài chú thích)", "input/security/alert/label không đổi; plot +2 ≤ 56", f"(0.3.4a, 0.3.5): {v}; plot mới: {[l[:70] for l in t_moi]}",
        "PASS" if ok else "FAIL", "—")

    # trích dẫn đặc tả cho mọi hằng số cố định dùng trong mã
    mau = [("P2", r"ER_H4 < \{0,20\} → RANGE"), ("P2", r"0,20 ≤ ER_H4 < 0,30"), ("P2", r"1 ≤ T_CNT < \{6\}"), ("P2", r"VOL-CỰC \| VR_H4 ≥ \{2,5\}"), ("P2", r"\{1,5\} ≤ VR_H4 < 2,5"),
           ("P2", r"X-S: phiên London/New York \{14:00–23:00 UTC\+7\}"), ("P2", r"8 > 15 > 14 > 9 > 1 > 2 > 16 > 11"), ("P2", r"Không có quyền tại t → setup bị BỎ QUA với lý do 15")]
    tim = [(m, TL.trich(a, m)) for a, m in mau]
    thieu = [m for m, t in tim if t is None]
    ma = all(re.search(p, S35) for p in (r"e < 0\.20", r"e >= 0\.30", r"t < 6", r"const float VOL_X  = 2\.5", r"v >= 1\.5", r"v <= 0\.7", r"hr >= 14 and hr < 23", r">= 2\.0 \* a", r"bar_index >= 119"))
    ghi("A-06", "A", "Hằng số cố định của đặc tả (ER 0,20/0,30; cửa sổ 6; VOL 2,5/1,5/0,7; X-S 14–23 UTC+7; Z-Q3 2,0×ATR; 120 nến; thứ tự lý do) có trích dẫn nguyên văn và có trong mã",
        "TĨNH (tai_lieu.trich + regex mã)", "mọi trích dẫn tìm thấy; mọi hằng có trong mã", {"trich": [(m, t[0] if t else None) for m, t in tim], "ma_ok": ma}, "PASS" if not thieu and ma else "FAIL",
        "cong_tien_md6/ho_so/…P2-1_5_1…txt")

    fb = re.findall(r"int kMax = span\b(?! - 1)", S35)
    fb_cu = re.findall(r"int kMax = span - 1", S35)
    sw = re.findall(r"if p > p0 and p <= b", S35)
    ghi("A-07", "A", "A-07 PA1 – phạm vi p₀: nhánh dự phòng (f_lowestSince/f_highestSince) quét p₀…b; nhánh swing giữ p₀ < p ≤ b (D.3.1)",
        "TĨNH", "2 × 'kMax = span'; 0 × 'span − 1'; 2 × 'p > p0 and p <= b'", f"{len(fb)} / {len(fb_cu)} / {len(sw)}", "PASS" if len(fb) == 2 and not fb_cu and len(sw) == 2 else "FAIL", "—")

    blk, b0 = K.doan(S35, "int nt = array.size(trigE)", "// ---- S2a", 4)
    s = "\n".join(blk)
    pos = [s.find(x) for x in ("e.reason := 8", "e.reason := 15", "e.reason := 14", "e.reason := 9", "e.reason := 1\n", "e.reason := 2\n")]
    ok = all(p > 0 for p in pos) and pos == sorted(pos) and "pm == 8" in s and s.count("f_perm(") == 1
    ghi("A-08", "A", "S1 bước 0 (I-1): f_perm gọi đúng 1 lần/setup trước SL; thứ tự nhánh lý do 8 → 15 → 14 → 9 → 1 → 2", "TĨNH", "đúng thứ tự", f"vị trí {pos}", "PASS" if ok else "FAIL",
        f"src035 dòng {b0}…")

    fs = [l for l in L35[next(i for i, l in enumerate(L35) if l == "type StructOut"):] [1:]]
    fs = fs[:next(i for i, l in enumerate(fs) if not l.startswith("    "))]
    nf = len(fs)
    m = re.search(r"StructOut so = StructOut\.new\((.*)\)\n", S35)
    na_ = len([x for x in re.split(r",(?![^()]*\))", m.group(1))]) if m else -1
    moi = [l.split()[1] for l in fs[-7:]]
    ok = nf == 84 and na_ == 84 and moi == ["vr", "reg", "lch", "stT", "chT", "zDq", "zSq"]
    ghi("A-09", "A", "StructOut: 7 trường mới ở CUỐI (vr, reg, lch, stT, chT, zDq, zSq), có mặc định; constructor so đủ 84 đối số đúng vị trí; f_empty 77 đối số vị trí hợp lệ nhờ mặc định",
        "TĨNH", "84 trường = 84 đối số", f"trường {nf}; đối số {na_}; 7 trường cuối {moi}", "PASS" if ok else "FAIL", "—")

    one = dict(f_regNext=S35.count("f_regNext(reg, tcnt"), erD=S35.count("math.sum(math.abs(ta.change(close)), 20)"), vr=S35.count("a / ta.sma(a, 100)"),
               f_vol_def=len(re.findall(r"^f_vol\(", S35, re.M)), vol15=len(re.findall(r"\b1\.5\b", "\n".join(bo_cm(l) for l in L35))) - len(re.findall(r"\b1\.5\b", "\n".join(bo_cm(l) for l in L34))))
    ok = one == dict(f_regNext=1, erD=1, vr=1, f_vol_def=1, vol15=1) and "sH4.reg" in S35 and not re.search(r"sH1\.reg|sM15\.reg|sD\.reg", S35)
    ghi("A-10", "A", "MD-6 tính một nơi (f_struct, ngữ cảnh H4 được dùng), chỉ cung cấp REG/VR; MD-7/S1/Data Window/dashboard chỉ đọc sH4.reg/sH4.vr; ngưỡng VOL định nghĩa một chỗ (không trùng logic)",
        "TĨNH", "mỗi phần một lần; không đọc reg của khung khác", one, "PASS" if ok else "FAIL", "—")

    # ước lượng token
    tok = lambda s: len(re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\S', "\n".join(bo_cm(l) for l in s.split("\n"))))  # noqa: E731
    t34, t35 = tok(S34), tok(S35)
    uoc = round(93628 * t35 / t34)
    ghi("A-11", "A", "Ước lượng compiled token 0.3.5 theo tỷ lệ token từ vựng (mốc 0.3.4a ≈ 93.628 cho %d token từ vựng; sai số ±8 %%) – giới hạn 100.256" % t34,
        "TĨNH (ƯỚC LƯỢNG – không phải số TradingView)", "≤ 100.256 ở cận trên", f"từ vựng {t34} → {t35} (+{t35 - t34}); ước lượng {uoc} (dải {round(uoc * 0.92)}–{round(uoc * 1.08)})",
        "PASS" if uoc <= 100256 else "FAIL", "—")
    return uoc, t34, t35


# ============================================================ NHÓM B – từng thay đổi (THÔNG DỊCH / THAM CHIẾU)
HAM = ("f_regBase", "f_regNext", "f_vol", "f_ge1Tick", "f_better", "f_lvPick", "f_suOrd", "f_d8", "f_frozen", "f_zonePick", "f_listPick", "f_perm", "f_grade")
REGN = {0: M6.THIEU, 1: M6.UPT, 2: M6.DNT, 3: M6.RANGE, 4: M6.TRANS}


def ip35(**them):
    return K.may(S35, HAM, ("StructOut", "Zone", "Ev"), them)


def so(ip, **f):
    return K.obj(ip, "StructOut", **f)


def t_reg_vi_sai():
    """f_regNext NGUYÊN VĂN ↔ MD6 tham chiếu trên chuỗi ngẫu nhiên (ST/EV/ER/VR), mọi nến."""
    ip = ip35()
    lech, n_tong, phu = [], 0, set()
    for seed in range(12):
        R = random.Random(seed)
        n = 700
        C = [100.0]
        for _ in range(n - 1):
            C.append(round(C[-1] + R.gauss(0.05 * R.choice((-1, 1)) if seed % 3 else 0, 1.0), 2))
        H = [c + abs(R.gauss(0, 0.6)) for c in C]; L_ = [c - abs(R.gauss(0, 0.6)) for c in C]
        A = M6.atr_wilder(H, L_, C)
        ref = M6.MD6()
        reg, tc = 0, 0
        st = 0
        for i in range(n):
            ev = R.choices((0, 1, 2, 3, 4), (80, 6, 6, 4, 4))[0]
            if ev in (3, 4):
                st = 1 if ev == 3 else -1
            elif ev in (1, 2) and st == 0:
                st = 1 if ev == 1 else -1
            e = M6.er(C, i); v = M6.vr(A, i)
            if seed in (5, 6) and e is not None:      # dồn ER vào biên ngưỡng
                e = R.choice((0.1999, 0.20, 0.2001, 0.25, 0.2999, 0.30, 0.3001, 0.0))
            full = i >= 119 and e is not None and v is not None
            reg, tc = K.goi(ip, "f_regNext", reg, tc, st, ev, NA if e is None else e, full)
            r_ref, t_ref, _, _ = ref.step(st, ev, e, v)
            n_tong += 1
            phu.add((REGN[reg], tc > 0))
            if REGN[reg] != r_ref or (reg != 0 and tc != t_ref):
                lech.append((seed, i, REGN[reg], tc, r_ref, t_ref, st, ev, e))
    return not lech and n_tong == 8400 and len(phu) >= 6, f"{n_tong} nến × 12 hạt giống; lệch {len(lech)} {lech[:3]}; tổ hợp trạng thái gặp {sorted(phu)}"


def t_reg_bien():
    ip = ip35()
    f = lambda *a: K.goi(ip, "f_regNext", *a)  # noqa: E731
    ca = [  # (reg, tc, st, ev, e, full) → (reg, tc)
        ((0, 0, 1, 0, 0.35, False), (0, 0)), ((0, 0, 1, 0, 0.35, True), (1, 0)), ((0, 0, -1, 0, 0.25, True), (4, 0)), ((0, 0, 1, 3, 0.10, True), (3, 0)),
        ((1, 0, 1, 0, 0.25, True), (1, 0)), ((3, 0, 1, 0, 0.29, True), (3, 0)), ((3, 0, 1, 0, 0.30, True), (1, 0)), ((2, 0, 1, 0, 0.25, True), (4, 0)),
        ((1, 0, 0, 0, 0.9, True), (3, 0)), ((1, 0, 1, 0, 0.1999, True), (3, 0)), ((1, 0, -1, 4, 0.9, True), (4, 1)), ((4, 1, -1, 0, 0.9, True), (4, 2)),
        ((4, 5, -1, 0, 0.9, True), (4, 6)), ((4, 6, -1, 0, 0.9, True), (2, 0)), ((4, 3, 1, 3, 0.9, True), (4, 1)), ((4, 0, 1, 0, 0.25, True), (4, 0)),
        ((1, 0, 1, 0, 0.35, False), (0, 0))]
    sai = [(a, kv, f(*a)) for a, kv in ca if tuple(f(*a)) != kv]
    return not sai, f"{len(ca)} ca biên (C.2: nến đủ dữ liệu đầu, ngưỡng 0,1999/0,20/0,29/0,30, ST NONE, cửa sổ T_CNT 1→6→thoát, CHoCH giữa cửa sổ); sai {sai}"


def t_vol():
    ip = ip35()
    ca = [(NA, 0), (0.5, 1), (0.7, 1), (0.7001, 2), (1.0, 2), (1.4999, 2), (1.5, 3), (2.4999, 3), (2.5, 4), (9.0, 4)]
    sai = [(v, k, K.goi(ip, "f_vol", v)) for v, k in ca if K.goi(ip, "f_vol", v) != k]
    return not sai, f"{len(ca)} ca (C.3: THẤP ≤ 0,7 < THƯỜNG < 1,5 ≤ CAO < 2,5 ≤ CỰC); sai {sai}"


def mo_hinh_quyen(d, okH4, pendH4, reg, vr, st1, st15, lch15, ch15, stT1):
    """I.3 lớp THUẬN viết thẳng từ văn bản (độc lập với mã): 0 có quyền, 8 thiếu dữ liệu, 15 không quyền."""
    if not okH4 or pendH4 or reg == 0:
        return 8
    if reg != (1 if d == 1 else 2) or vr >= 2.5:
        return 15
    if st1 in (d, 0):
        return 0
    return 0 if (st15 == d and lch15 == d and ch15 is not None and stT1 is not None and ch15 >= stT1) else 15


def t_perm():
    ip = ip35()
    sai, n, dem = [], 0, {0: 0, 8: 0, 15: 0}
    for okH4 in (True, False):
        for pend in (False, True):
            for reg in range(5):
                for vr in (1.0, 2.4999, 2.5):
                    for st1 in (-1, 0, 1):
                        for st15 in (-1, 0, 1):
                            for lch in (-1, 0, 1):
                                for ch, stt in ((NA, 100), (200, 100), (100, 100), (50, 100), (200, NA)):
                                    for d in (1, -1):
                                        ip.g.update(okH4=okH4, pendH4=pend, sH4=so(ip, reg=reg, vr=vr), sH1=so(ip, st=st1, stT=stt), sM15=so(ip, st=st15, lch=lch, chT=ch))
                                        r = K.goi(ip, "f_perm", d)
                                        k = mo_hinh_quyen(d, okH4, pend, reg, vr, st1, st15, lch, None if ch is NA else ch, None if stt is NA else stt)
                                        n += 1; dem[r] = dem.get(r, 0) + 1
                                        if r != k:
                                            sai.append((d, okH4, pend, reg, vr, st1, st15, lch, ch, stt, r, k))
    return not sai and all(dem[k] > 0 for k in (0, 8, 15)), f"{n} tổ hợp (chiều × okH4 × chờ H4 × REG × VR biên 2,5 × ST_H1 × ST_M15 × LAST_CHOCH_M15 × thời điểm CHoCH so T_ĐC bằng/trước/sau/na); phân bố {dem}; sai {len(sai)} {sai[:3]}"


def t_lvpick():
    ip = ip35()
    A = lambda *x: PArr(list(x))  # noqa: E731
    ca = [  # (d, base, v, r, mr, ok) → (lv, rk)
        ((1, 100.0, A(101.0, 100.5, 103.0), A(2, 3, 4), 2, True), (100.5, 3)),
        ((1, 100.0, A(101.0, 100.5, 103.0), A(2, 1, 4), 2, True), (101.0, 2)),
        ((-1, 100.0, A(99.0, 99.5, 97.0), A(2, 3, 4), 3, True), (99.5, 3)),
        ((1, 100.0, A(100.01, 100.009), A(2, 2), 2, True), (100.01, 2)),          # đúng 1 tick là ứng viên; dưới 1 tick bị loại
        ((1, 100.0, A(100.009,), A(5,), 2, True), (NA, NA)),
        ((1, 100.0, A(101.0, 101.0), A(2, 4), 2, True), (101.0, 4)),               # bằng mức: giữ hạng cao hơn
        ((1, 100.0, A(101.0, 101.0), A(4, 2), 2, True), (101.0, 4)),
        ((1, 100.0, A(101.0,), A(4,), 2, False), (NA, NA)),                         # nguồn không khả dụng
        ((1, 100.0, A(), A(), 0, True), (NA, NA)),
        ((1, 100.0, A(99.0, 98.0), A(4, 4), 0, True), (NA, NA)),                     # sai phía
        ((-1, 100.0, A(101.0, 99.99), A(1, 0), 0, True), (99.99, 0))]
    sai = [(a[:2], kv, K.goi(ip, "f_lvPick", *a)) for a, kv in ca if tuple(K.goi(ip, "f_lvPick", *a)) != kv]
    return not sai, f"{len(ca)} ca (gần nhất phía có lợi, ≥ 1 tick, lọc hạng, bằng mức chọn hạng cao, nguồn không khả dụng, rỗng, sai phía); sai {sai}"


T_14H = 1_700_000_000_000 - (1_700_000_000_000 % 86400000) + (14 - 7) * 3600000   # 14:00 UTC+7


def zone(ip, **f):
    base = dict(tf=15, dir=1, bot=100.0, top=101.0, touches=1, zq=False, dead=False)
    base.update(f)
    return K.obj(ip, "Zone", **base)


def t_grade():
    ip = ip35()
    sai, n = [], 0
    R = random.Random(3)
    for _ in range(4000):
        d = R.choice((1, -1))
        z = zone(ip, tf=R.choice((15, 60)), dir=d, touches=R.choice((1, 2)), zq=R.random() < 0.5)
        h1 = [zone(ip, tf=60, dir=R.choice((d, -d)), bot=R.choice((99.0, 100.5)), top=R.choice((101.5, 100.8)), dead=R.random() < 0.2) for _ in range(R.randint(0, 2))]
        okH1 = R.random() < 0.85
        cl = [(R.choice((99.5, 100.5, 102.0)), R.randint(1, 4)) for _ in range(R.randint(0, 3))]
        md4 = R.random() < 0.85
        reg = R.choice((0, 1, 2, 3, 4)); st15 = R.choice((-1, 0, 1)); okD = R.random() < 0.8; stD = R.choice((-1, 0, 1))
        isX = R.random() < 0.5; hr = R.choice((13, 14, 22, 23, 3))
        rk1 = R.choice((0, 2, 3, 4))
        ip.g.update(zones=PArr([z] + h1), okM15=True, okH1=okH1, cLo=PArr([c[0] for c in cl]), cHi=PArr([c[0] + 0.4 for c in cl]), cRank=PArr([c[1] for c in cl]), md4OK=md4,
                    sH4=so(ip, reg=reg), sM15=so(ip, st=st15), okD=okD, sD=so(ip, st=stD), isXAU=isX, time=T_14H + (hr - 14) * 3600000)
        r = K.goi(ip, "f_grade", z, d, rk1)
        # mô hình I.5/E.3 viết thẳng từ văn bản
        zt, zb = 101.0, 100.0
        c1 = z.f["tf"] == 60 or any(h.f["dir"] == d and not h.f["dead"] and okH1 and zb >= h.f["bot"] and zt <= h.f["top"] for h in h1)
        q5 = md4 and any(rk >= 2 and zb <= lo + 0.4 and zt >= lo for lo, rk in cl)
        zs = (z.f["tf"] == 60) + (z.f["touches"] == 1) + z.f["zq"] + (reg == (1 if d == 1 else 2)) + q5
        ctx = (okD and stD == d) + (isX and 14 <= hr < 23) + (zs >= 3) + (rk1 >= 3)
        k = c1 and st15 == d and ctx >= 2
        n += 1
        if bool(r) != bool(k):
            sai.append((d, z.f["tf"], c1, st15, ctx, zs, r))
    # biên X-S: 13:59 không, 14:00 có, 22:59 có, 23:00 không; BTC không áp dụng
    xs = []
    z = zone(ip, tf=60, dir=1, touches=2)
    for hm, isX, kv in ((13 * 60 + 59, True, False), (14 * 60, True, True), (22 * 60 + 59, True, True), (23 * 60, True, False), (15 * 60, False, False)):
        ip.g.update(zones=PArr([z]), okH1=True, cLo=PArr(), cHi=PArr(), cRank=PArr(), md4OK=True, sH4=so(ip, reg=3), sM15=so(ip, st=1), okD=True, sD=so(ip, st=1),
                    isXAU=isX, time=T_14H + (hm - 14 * 60) * 60000)
        r = K.goi(ip, "f_grade", z, 1, 0)       # C-1 (H1), C-2, X-D = 1 → A nếu và chỉ nếu X-S đạt
        if bool(r) != kv:
            xs.append((hm, isX, r))
    return not sai and not xs, f"{n} ca ngẫu nhiên đối chiếu mô hình I.5/E.3 (C-1, C-2, X-D, X-S, X-Z với Z-Q1…Q5, X-T); sai {len(sai)} {sai[:3]}; biên X-S 13:59/14:00/22:59/23:00/BTC sai {xs}"


def t_d8():
    ip = ip35()
    ip4 = K.may(S34, ("f_d8",), ("Ev",))
    R = random.Random(9)
    sai, n = [], 0
    for _ in range(3000):
        def ev(m):
            return K.obj(m, "Ev", tf=R.choice((15, 60)), bosMin=R.choice((10, 20)), rkh=R.choice((1.0, 2.0)), baseMin=R.choice((5, 6)))
        a4, b4 = ev(ip4), ev(ip4)
        a5 = K.obj(ip, "Ev", **{k: a4.f[k] for k in ("tf", "bosMin", "rkh", "baseMin")})
        b5 = K.obj(ip, "Ev", **{k: b4.f[k] for k in ("tf", "bosMin", "rkh", "baseMin")})
        n += 1
        if K.goi(ip, "f_d8", a5, b5) != K.goi(ip4, "f_d8", a4, b4):
            sai.append("đồng hạng/đồng lớp khác 0.3.4a")
        g1, g2 = R.random() < 0.5, R.random() < 0.5
        s1, s2 = R.choice((1, 3, 4, 5)), R.choice((1, 3, 4, 5))
        a5.f.update(grade=g1, su=s1); b5.f.update(grade=g2, su=s2)
        od = {1: 4, 5: 3, 4: 2, 3: 1}
        kv = g1 if g1 != g2 else (od[s1] > od[s2] if s1 != s2 else K.goi(ip4, "f_d8", a4, b4))
        if K.goi(ip, "f_d8", a5, b5) != kv:
            sai.append((g1, g2, s1, s2))
    return not sai, f"{n} cặp: (1) cùng hạng/lớp → kết quả trùng f_d8 0.3.4a (hồi quy D8); (2) bậc 0 hạng A trước, rồi SU-1 > SU-5 > SU-4 > SU-3; sai {len(sai)} {sai[:3]}"


def t_a07_pine():
    """f_lowestSince/f_highestSince NGUYÊN VĂN (0.3.5 và 0.3.4a) ↔ _fallback của MD2 tham chiếu (gom_p0 / loai_p0)."""
    sai, n = [], 0
    m35 = K.may(S35, ("f_lowestSince", "f_highestSince"))
    m34 = K.may(S34, ("f_lowestSince", "f_highestSince"))
    R = random.Random(7)
    for _ in range(600):
        nb = R.randint(5, 60)
        Lw = [round(R.uniform(90, 110), 1) for _ in range(nb)]   # lưới thô → có mức bằng nhau
        Hh = [l + round(R.uniform(0.1, 3), 1) for l in Lw]
        T = [1000 + 60 * i for i in range(nb)]
        b = nb - 1
        p0 = R.randint(max(0, b - 40), b - 1)
        if R.random() < 0.3:
            Lw[p0] = min(Lw) - 1.0; Hh[p0] = max(Hh) + 1.0       # p₀ là cực trị (đúng tình huống TC-PROT02)
        for m, bien in ((m35, "gom_p0"), (m34, "loai_p0")):
            m.chuoi = dict(low=Lw, high=Hh, time=T)
            m.g["bar_index"] = b
            ref = M2.MD2(a07=bien); ref.L, ref.H = Lw, Hh
            for low, fn in ((True, "f_lowestSince"), (False, "f_highestSince")):
                v, bb, tt, cap = K.goi(m, fn, p0)
                rv, rb = ref._fallback(p0, b, low)
                n += 1
                if (v, bb) != (rv, rb) or tt != T[rb] or cap:
                    sai.append((bien, fn, p0, b, (v, bb, tt, cap), (rv, rb)))
    # p0 = na → cap = true; span vượt LB_CAP → cap
    m35.chuoi = dict(low=[1.0] * 600, high=[2.0] * 600, time=list(range(600))); m35.g["bar_index"] = 599
    c1 = K.goi(m35, "f_lowestSince", NA)[3]
    v2 = K.goi(m35, "f_lowestSince", 599 - 500)
    return not sai and c1 is True and v2[3] is True, f"{n} lần gọi (600 chuỗi; 30 % có p₀ là cực trị); sai {len(sai)} {sai[:2]}; p0 na → cap {c1}; span 500 > LB_CAP → cap {v2[3]}"


def thanh(bars):
    return [b[0] for b in bars], [b[1] for b in bars], [b[2] for b in bars]


def t_a07_tc():
    seq = [(10, 9, 9.5), (10.2, 9.1, 9.6), (10.4, 9.0, 9.2), (11, 9.3, 10.8), (11.5, 9.8, 11), (11.8, 10, 11.2), (12, 8.0, 11.5), (11.6, 8.5, 9), (11.4, 8.6, 9.1), (12.6, 9.2, 12.5)]
    H, Lw, C = thanh(seq)
    res = {}
    for v in ("loai_p0", "gom_p0"):
        m, _ = M2.chay(H, Lw, C, N=2, a07=v)
        bos = [e for e in m.ev_log if e[1] == M2.BOS_UP]
        res[v] = bos[-1] if bos else None
    p0 = res["gom_p0"][3]
    kv = min(Lw[p0:10])
    ok = res["gom_p0"][5] == "du_phong" and res["gom_p0"][4] == kv and res["loai_p0"][4] != kv
    # nối với Pine: f_lowestSince 0.3.5 trên đúng chuỗi này, tại b = 9 với p0 trên
    m = K.may(S35, ("f_lowestSince",)); m.chuoi = dict(low=Lw, high=H, time=list(range(10))); m.g["bar_index"] = 9
    pv = K.goi(m, "f_lowestSince", p0)
    return ok and pv[0] == kv, f"TC-PROT02/TC-MS08: p₀ = {p0}, mong đợi PROT_L = {kv}; tham chiếu PA1 {res['gom_p0'][4]} (nhánh {res['gom_p0'][5]}), cách cũ {res['loai_p0'][4]}; Pine 0.3.5 f_lowestSince → {pv[0]}"


def t_a07_tac_dong():
    """Hồi quy PROT/CHoCH/ST/REG trên mô hình: mọi khác biệt PA1 so với cách cũ phải bắt nguồn từ nến p₀ ở nhánh dự phòng."""
    tong = dict(nen=0, su_kien=0, prot_khac=0, prot_khac_sai_nguon=0, choch_cu=0, choch_moi=0, st_khac=0, reg_khac=0)
    for seed in (1, 2, 3, 1001, 1002, 1003):
        R = random.Random(seed)
        n = 2500
        sig = 1.0 if seed < 1000 else 2.6
        C = [2000.0]
        for _ in range(n - 1):
            C.append(round(C[-1] + R.gauss(0, sig), 2))
        H = [round(c + abs(R.gauss(0, sig * 0.7)), 2) for c in C]; Lw = [round(c - abs(R.gauss(0, sig * 0.7)), 2) for c in C]
        out = {}
        for v in ("loai_p0", "gom_p0"):
            m, evs = M2.chay(H, Lw, C, N=3, a07=v)
            A = M6.atr_wilder(H, Lw, C)
            r6 = M6.chay(m.st_log, evs, C, A)
            out[v] = (m, evs, [x[0] for x in r6])
        mo, eo, ro = out["loai_p0"]; mn, en, rn = out["gom_p0"]
        tong["nen"] += n
        tong["choch_cu"] += sum(e in (3, 4) for e in eo); tong["choch_moi"] += sum(e in (3, 4) for e in en)
        tong["st_khac"] += sum(a != b for a, b in zip(mo.st_log, mn.st_log)); tong["reg_khac"] += sum(a != b for a, b in zip(ro, rn))
        # so sánh từng sự kiện tới điểm phân kỳ đầu tiên
        for a, b in zip(mo.ev_log, mn.ev_log):
            if a[:2] != b[:2]:
                break
            tong["su_kien"] += 1
            if a[4] != b[4]:
                tong["prot_khac"] += 1
                c, ev, _, p0, prot, nh = b
                is_low = ev in (M2.BOS_UP, 3)
                if not (nh == "du_phong" and prot == (Lw[p0] if is_low else H[p0])):
                    tong["prot_khac_sai_nguon"] += 1
    ok = tong["prot_khac"] > 0 and tong["prot_khac_sai_nguon"] == 0
    return ok, tong


def t_zq3():
    """Mặt nạ Z-Q3: biểu thức mã hóa trong f_struct và 3 biểu thức giải mã ở f_addZone (NGUYÊN VĂN) khớp cờ từng khe."""
    enc = re.search(r"zDq \+= (.*)\n", S35).group(1)
    dec = [re.search(r"s\.z" + "D" + r"j" + str(k) + r", (.*?)\)\n", S35).group(1).replace("s.zDq", "q") for k in range(3)]
    ip = K.Ip()
    import pine_mini as PM
    e_enc = PM.parse_expr(PM.tokens(enc)); e_dec = [PM.parse_expr(PM.tokens(x)) for x in dec]
    sai, n = [], 0
    import itertools
    for m in range(0, 6):
        for flags in itertools.product((False, True), repeat=m):
            q = 0
            for i, qk in enumerate(flags):
                q += ip.ev(e_enc, [{"qk": qk, "nZD": i}])
            for k in range(3):
                got = bool(ip.ev(e_dec[k], [{"q": q}]))
                kv = k < m and flags[k]
                n += 1
                if got != kv:
                    sai.append((flags, k, got))
    # thân impulsive đúng ngưỡng 2,0 × ATR, xác định ở nến tạo ứng viên và đi cùng mọi thao tác mảng pd*
    ok_s = S35.count("array.push(pdK, math.abs(close - open) >= 2.0 * a)") == 1 and S35.count("array.remove(pdK, q)") == 1 and S35.count("array.get(pdK, q)") == 1 \
        and S35.count("array.remove(pdI, q)") == 1
    return not sai and ok_s, f"{n} kiểm (0–5 vùng/nến × mọi tổ hợp cờ; khe > 2 không ghi); sai {sai[:3]}; đồng bộ pdK với pdI: {ok_s}; mã hóa: {enc}; giải mã: {dec}"


# ---------------------------------------------------------------- S1 chạy nguyên văn
S1_34 = K.doan(S34, "int nt = array.size(trigE)", "// ---- S2a", 4)
S1_35 = K.doan(S35, "int nt = array.size(trigE)", "// ---- S2a", 4)


def lap_s1(src, sc):
    """Dựng trình thông dịch với hàm thật, nạp kịch bản, chạy khối S1 NGUYÊN VĂN. Trả danh sách Ev sau S1."""
    hams = tuple(h for h in HAM if re.search(r"^" + h + r"\(", src, re.M))
    ip = K.may(src, hams, ("StructOut", "Zone", "Ev"))
    g = ip.g

    def sto(lst_h, lst_l, **f):
        d = dict(atr=f.pop("atr", 1.0), shN=len(lst_h), slN=len(lst_l), shInc=False, slInc=False)
        for i in range(10):
            d[f"sh{i}"] = lst_h[i] if i < len(lst_h) else NA
            d[f"sl{i}"] = lst_l[i] if i < len(lst_l) else NA
        d.update(f)
        return K.obj(ip, "StructOut", **d)
    zs, evs = [], []
    for zz in sc["trig"]:
        z = zone(ip, **zz)
        zs.append(z)
        evs.append(K.obj(ip, "Ev", tf=z.f["tf"], dir=z.f["dir"]))
    others = [zone(ip, **o) for o in sc.get("zones", [])]
    g.update(trigZ=PArr(zs), trigE=PArr(evs), zones=PArr(zs + others), close=sc["close"], open=sc["close"] - 0.3 * sc["trig"][0]["dir"] if sc["trig"] else sc["close"],
             atrM5=sc.get("atrM5", 0.5), okM15=sc.get("okM15", True), okH1=sc.get("okH1", True), okH4=sc.get("okH4", True), pendH4=sc.get("pendH4", False),
             okD=sc.get("okD", False), sD=sto([], [], st=sc.get("stD", 0)), isXAU=sc.get("isXAU", True), time=T_14H - 5 * 3600000,
             sM15=sto(sc.get("m15h", []), sc.get("m15l", []), atr=sc.get("atr15", 1.0), st=sc.get("st15", 0), lch=sc.get("lch15", 0), chT=sc.get("ch15", NA)),
             sH1=sto(sc.get("h1h", []), sc.get("h1l", []), st=sc.get("st1", 0), stT=sc.get("stT1", NA)),
             sH4=sto(sc.get("h4h", []), sc.get("h4l", []), reg=sc.get("reg", 1), vr=sc.get("vr", 1.0)),
             iSlBufK=0.1, iInject=False, iSlMaxK=sc.get("slMax", 3.0), iRRMin=sc.get("rrMin", 1.0), bar14=0,
             cLo=PArr([c[0] for c in sc.get("cl", [])]), cHi=PArr([c[1] for c in sc.get("cl", [])]), cRank=PArr([c[2] for c in sc.get("cl", [])]), md4OK=sc.get("md4", True),
             plB=PArr([p[0] for p in sc.get("pb", [])]), prB=PArr([p[1] for p in sc.get("pb", [])]), plS=PArr([p[0] for p in sc.get("ps", [])]), prS=PArr([p[1] for p in sc.get("ps", [])]),
             md5OK=sc.get("md5", True))
    lines, base = (S1_35 if src is S35 else S1_34)
    K.chay_dong(ip, lines, base)
    return evs


TRUONG = ("reason", "state", "sl", "tp1", "tp2", "tp3", "rkh", "rr", "flags", "pass", "grp")


def kb_ngau_nhien(R, d):
    c = 2000.0
    trig = []
    for _ in range(R.randint(1, 3)):
        lo = c - d * R.uniform(0.5, 3) - 0.5
        trig.append(dict(tf=R.choice((15, 60)), dir=d, bot=round(lo, 2), top=round(lo + 0.5, 2), sExt=round(lo - d * R.uniform(0, 1), 2) if d == 1 else round(lo + 0.5 + R.uniform(0, 1), 2),
                         touches=R.choice((1, 2))))
    lv = lambda k: sorted(round(c + d * R.uniform(-1, 25), 2) for _ in range(k))  # noqa: E731
    zones = [dict(tf=R.choice((15, 60)), dir=-d, bot=round(c + d * R.uniform(0.5, 20), 2), top=0, dead=R.random() < 0.2) for _ in range(R.randint(0, 3))]
    for z in zones:
        z["top"] = z["bot"] + 0.6
    sc = dict(close=c, trig=trig, zones=zones, m15h=lv(R.randint(0, 6)), m15l=lv(R.randint(0, 6)), h1h=lv(R.randint(0, 6)), h1l=lv(R.randint(0, 6)), h4h=lv(R.randint(0, 6)),
              h4l=lv(R.randint(0, 6)), okH1=R.random() < 0.9, okM15=R.random() < 0.95, atr15=R.choice((0.3, 1.0, 3.0)), slMax=R.choice((1.0, 3.0)), rrMin=R.choice((0.5, 1.0, 2.0)),
              reg=1 if d == 1 else 2, vr=R.choice((0.5, 1.0, 2.0)), st1=R.choice((d, 0)), st15=R.choice((-1, 0, 1)))
    return sc


def t_s1_hoi_quy():
    """Khi có quyền MD-7 và không có cụm hạng ≥ 2/pool: S1 0.3.5 trùng S1 0.3.4a trên mọi trường của Ev (I-1…I-6 không làm đổi hành vi cũ)."""
    R = random.Random(11)
    sai, n, ly_do = [], 0, {}
    for k in range(400):
        d = R.choice((1, -1))
        sc = kb_ngau_nhien(R, d)
        if k % 2:
            sc["cl"] = [(round(2000 + d * R.uniform(1, 9), 2), round(2000 + d * R.uniform(1, 9), 2) + 0.4, 1)]   # cụm hạng 1: bị lọc ở TP1/TP2, hạng < 3 ở TP3
        e4, e5 = lap_s1(S34, sc), lap_s1(S35, sc)
        for a, b in zip(e4, e5):
            n += 1
            ly_do[a.f["reason"]] = ly_do.get(a.f["reason"], 0) + 1
            kh = [f for f in TRUONG if a.f.get(f) != b.f.get(f)]
            if kh:
                sai.append((k, kh, [(a.f.get(f), b.f.get(f)) for f in kh]))
    return not sai and len(ly_do) >= 4, f"{n} setup / 400 kịch bản; phân bố lý do 0.3.4a {ly_do}; khác biệt {len(sai)} {sai[:3]}"


def kb_co_ban(**k):
    sc = dict(close=2000.0, trig=[dict(tf=15, dir=1, bot=1998.0, top=1998.5, sExt=1997.8, touches=1)], m15h=[2003.0, 2010.0], h1h=[2012.0], h4h=[2030.0], reg=1, vr=1.0, st1=1, st15=1, rrMin=0.5, slMax=5.0)
    sc.update(k)
    return sc


def t_s1_muc_tieu():
    ca = [
        ("H4 chưa về (pendH4) → htfWait ở P-lớp; nếu tới S1: lý do 8", kb_co_ban(pendH4=True), dict(reason=8, state=4)),
        ("REG = KHÔNG ĐỦ DỮ LIỆU → 8", kb_co_ban(reg=0), dict(reason=8)),
        ("okH4 sai → 8", kb_co_ban(okH4=False), dict(reason=8)),
        ("REG = RANGE → 15, không có SL/TP", kb_co_ban(reg=3), dict(reason=15, state=4, sl=NA, tp1=NA, **{"pass": False})),
        ("REG = DOWNTREND với BUY → 15", kb_co_ban(reg=2), dict(reason=15)),
        ("REG = TRANSITION → 15", kb_co_ban(reg=4), dict(reason=15)),
        ("VOL CỰC (VR = 2,5) → 15", kb_co_ban(vr=2.5), dict(reason=15)),
        ("VR = 2,4999 → có quyền", kb_co_ban(vr=2.4999), dict(reason=0, **{"pass": True})),
        ("ST_H1 ngược, không có CHoCH M15 → 15", kb_co_ban(st1=-1, stT1=1000, st15=1, lch15=0), dict(reason=15)),
        ("ST_H1 ngược, CHoCH↑ M15 trước T_ĐC → 15", kb_co_ban(st1=-1, stT1=1000, st15=1, lch15=1, ch15=900), dict(reason=15)),
        ("ST_H1 ngược, CHoCH↑ M15 sau T_ĐC, ST_M15 = UP → có quyền", kb_co_ban(st1=-1, stT1=1000, st15=1, lch15=1, ch15=1100), dict(reason=0, **{"pass": True})),
        ("ST_H1 ngược, CHoCH sau T_ĐC nhưng ST_M15 ≠ UP → 15", kb_co_ban(st1=-1, stT1=1000, st15=-1, lch15=1, ch15=1100), dict(reason=15)),
        ("ST_H1 = NONE → có quyền", kb_co_ban(st1=0), dict(reason=0)),
        ("Thứ tự: thiếu M15 (8) thắng không quyền (15)", kb_co_ban(okM15=False, reg=3), dict(reason=8)),
        ("Thứ tự: không quyền (15) thắng SL sai phía (14)", kb_co_ban(reg=3, trig=[dict(tf=15, dir=1, bot=1998.0, top=1998.5, sExt=2001.0, touches=1)]), dict(reason=15)),
        ("Có quyền, SL sai phía → 14", kb_co_ban(trig=[dict(tf=15, dir=1, bot=1998.0, top=1998.5, sExt=2001.0, touches=1)]), dict(reason=14)),
        ("MD-4 không khả dụng → 8 (không chứng minh được TP1 gần nhất)", kb_co_ban(md4=False), dict(reason=8)),
        ("MD-5 không khả dụng → 8", kb_co_ban(md5=False), dict(reason=8)),
        ("I-4: cụm MD-4 hạng 2 gần hơn swing → TP1 = cạnh dưới cụm", kb_co_ban(cl=[(2002.0, 2002.4, 2)]), dict(tp1=2002.0, reason=0)),
        ("I-4: cụm hạng 1 bị loại khỏi TP1", kb_co_ban(cl=[(2002.0, 2002.4, 1)]), dict(tp1=2003.0)),
        ("I-4: pool BSL MD-5 gần nhất → TP1 = pool", kb_co_ban(pb=[(2002.5, 1)], ps=[(2001.0, 3)]), dict(tp1=2002.5)),
        ("I-4: pool SSL (cùng phía BUY sai) không dùng cho BUY", kb_co_ban(ps=[(2001.0, 3)]), dict(tp1=2003.0)),
        ("L.1/I-4: TP2 = ứng viên kế tiếp trong tập I-4 (cụm sau TP1)", kb_co_ban(cl=[(2002.0, 2002.4, 2), (2005.0, 2005.4, 3)]), dict(tp1=2002.0, tp2=2003.0)),
        ("I-6: TP3 = cụm hạng ≥ 3 gần hơn SH H4", kb_co_ban(cl=[(2020.0, 2020.4, 3)]), dict(tp1=2003.0, tp2=2010.0, tp3=2020.0)),
        ("I-6: cụm hạng 2 không vào TP3", kb_co_ban(cl=[(2020.0, 2020.4, 2)]), dict(tp3=2030.0)),
        ("SELL đối xứng: cụm hạng 2 dưới giá → TP1 = cạnh trên cụm", dict(kb_co_ban(), trig=[dict(tf=15, dir=-1, bot=2001.5, top=2002.0, sExt=2002.2, touches=1)], m15l=[1997.0, 1990.0], h1l=[1988.0],
                                                                         h4l=[1970.0], m15h=[], h1h=[], h4h=[], reg=2, st1=-1, st15=-1, cl=[(1997.6, 1998.0, 2)]), dict(tp1=1998.0, reason=0)),
        ("I-3: hạng A khi C-1 (vùng H1), C-2, X-D và X-T (TP1 là cụm hạng 3)", kb_co_ban(trig=[dict(tf=60, dir=1, bot=1998.0, top=1998.5, sExt=1997.8, touches=2)], okD=True, stD=1,
                                                                                          cl=[(2002.0, 2002.4, 3)], isXAU=False), dict(grade=True, tp1=2002.0)),
        ("I-3: hạng B khi < 2 điều kiện bối cảnh", kb_co_ban(trig=[dict(tf=60, dir=1, bot=1998.0, top=1998.5, sExt=1997.8, touches=2)], cl=[(2002.0, 2002.4, 2)], isXAU=False),
         dict(grade=False, **{"pass": True})),
        ("I-2: loại setup SU-1 (su = 1) cho mọi Ev SU-1", kb_co_ban(), dict(su=1)),
    ]
    sai = []
    for ten, sc, kv in ca:
        e = lap_s1(S35, sc)[0]
        tt = {k: e.f.get(k) for k in kv}
        if any((tt[k] is NA) != (kv[k] is NA) or (tt[k] is not NA and tt[k] != kv[k]) for k in kv):
            sai.append((ten, kv, tt))
    return not sai, f"{len(ca)} kịch bản S1 có chủ đích (I-1 lý do 8/15 và thứ tự, I.3 (a)/(b), VOL biên, I-4 cụm/pool/hạng, TP2 L.1, I-6 TP3, SELL đối xứng, I-3 hạng, I-2 loại); sai {sai}"


# ============================================================ NHÓM C – tích hợp
def t_chuoi_md6_md7_s1():
    """Chuỗi H4 giả lập → f_regNext (nguyên văn) mỗi nến → sH4 → S1 nguyên văn cho BUY và SELL; lý do khớp mô hình I.3 độc lập."""
    ip = ip35()
    R = random.Random(21)
    n = 400
    C = [2000.0]
    for _ in range(n - 1):
        C.append(round(C[-1] + R.gauss(0.4 if (_ // 120) % 2 == 0 else -0.4, 2.0), 2))
    H = [c + 1 for c in C]; Lw = [c - 1 for c in C]
    m, evs = M2.chay(H, Lw, C, N=3, a07="gom_p0")
    A = M6.atr_wilder(H, Lw, C)
    reg, tc = 0, 0
    sai, dem = [], {}
    for i in range(n):
        e, v = M6.er(C, i), M6.vr(A, i)
        reg, tc = K.goi(ip, "f_regNext", reg, tc, m.st_log[i], evs[i], NA if e is None else e, i >= 119 and e is not None and v is not None)
        if i % 7:
            continue
        vv = NA if v is None else v
        for d in (1, -1):
            sc = kb_co_ban(reg=reg, vr=vv if vv is not NA else 1.0, st1=0)
            if d == -1:
                sc.update(trig=[dict(tf=15, dir=-1, bot=2001.5, top=2002.0, sExt=2002.2, touches=1)], m15l=[1997.0], h1l=[1990.0], h4l=[1970.0], m15h=[], h1h=[], h4h=[])
            r = lap_s1(S35, sc)[0].f["reason"]
            kv = mo_hinh_quyen(d, True, False, reg, v if v is not None else 1.0, 0, 0, 0, None, None)
            kv = 0 if kv == 0 else kv
            dem[(REGN[reg], d, r)] = dem.get((REGN[reg], d, r), 0) + 1
            if (kv == 0 and r in (8, 15)) or (kv != 0 and r != kv):
                sai.append((i, REGN[reg], d, r, kv))
    gap = {k[0] for k in dem}
    return not sai and {M6.THIEU, M6.UPT, M6.DNT} <= gap, f"{n} nến H4, S1 mỗi 7 nến × 2 chiều; tổ hợp (REG, chiều, lý do) {dem}; sai {sai[:3]}"


def t_xep_hang_s2b():
    ip = ip35()
    mk = lambda **f: K.obj(ip, "Ev", **dict(dict(tf=15, bosMin=10, rkh=1.0, baseMin=5, su=1, grade=False), **f))  # noqa: E731
    evs = [mk(tf=60, bosMin=30, name=1), mk(grade=True, name=2), mk(tf=60, grade=True, name=3), mk(su=5, tf=60, name=4), mk(su=3, grade=True, tf=60, name=5)]
    for i, e in enumerate(evs):
        e.f["id"] = i
    # chọn phần tử đứng đầu bằng f_d8 như f_ledger (so cặp)
    order = sorted(range(len(evs)), key=lambda i: sum(K.goi(ip, "f_d8", evs[j], evs[i]) for j in range(len(evs)) if j != i))
    kv = [2, 4, 1, 0, 3]   # A-SU1-H1, A-SU3, A-SU1-M15? xem chi tiết dưới
    # mong đợi: hạng A trước (id 1, 2, 4); trong A: SU-1 trước SU-3 → id 2 (H1) trước id 1 (M15) theo D8, rồi id 4 (SU-3); hạng B: SU-1 (id 0) trước SU-5 (id 3)
    kv = [2, 1, 4, 0, 3]
    dung_ledger = "f_d8(" in "\n".join(K.khoi(S35, "f_ledger")[0])
    return order == kv and dung_ledger, f"thứ tự theo f_d8: {order}; mong đợi {kv}; f_ledger dùng f_d8: {dung_ledger}"


def t_data_window():
    ip = ip35()
    ma = {}
    for reg in range(5):
        for v in (NA, 0.5, 1.0, 2.0, 3.0):
            code = reg + 10 * K.goi(ip, "f_vol", v)
            ma.setdefault(code, []).append((reg, v))
    trung = {k: x for k, x in ma.items() if len(x) > 1 and len({K.goi(ip, "f_vol", vv) for _, vv in x}) > 1}
    pl = [l for l in L35 if l.startswith("plot(") and ("MÃ REGIME" in l or "MÃ LOẠI SETUP" in l)]
    ok_pl = len(pl) == 2 and all("display = display.data_window" in l for l in pl) and "sH4.reg + 10 * f_vol(sH4.vr)" in pl[0] and "mainEv.su" in pl[1] and all("runBar" in l for l in pl)
    db = next(l for l in L35 if "Quyền MD-7: THEO I.3" in l)
    ok_db = 'array.from("KHÔNG ĐỦ DỮ LIỆU", "UPTREND", "DOWNTREND", "RANGE", "TRANSITION"), sH4.reg' in db and "f_vol(sH4.vr) == 4" in db and "okH4 ?" in db
    return not trung and ok_pl and ok_db and len(ma) == 25, f"25 mã duy nhất (REG 0–4 × VOL 0–4); trùng {trung}; 2 plot chỉ Data Window, chặn runBar: {ok_pl}; dashboard cùng nguồn sH4.reg/f_vol, chỉ số 0–4 hợp lệ: {ok_db}"


def t_hien_thi_canh_bao():
    tt = dict(alert34=len(re.findall(r"\balert(?:condition)?\(", S34)), alert35=len(re.findall(r"\balert(?:condition)?\(", S35)),
              nhan_kiemthu="COI LÀ ĐẠT" not in S35, tooltip="quyền MD-7 theo I.3" in S35, ten=S35.count("0.3.4a") == 0 or all("0.3.4a" not in l for l in L35 if not l.strip().startswith("//")))
    ok = tt["alert34"] == 0 and tt["alert35"] == 0 and tt["nhan_kiemthu"] and tt["tooltip"]
    return ok, f"{tt} – cảnh báo Q3 thuộc MD-9 (R.3 bước 8), ngoài I-1…I-6 → không thêm, không có cảnh báo trùng"


def t_md5_song_song():
    import md5_song_song as MS
    goc = MS.trang_thai
    MOI = {"plB", "prB", "plS", "prS", "REG_NA", "REG_UP", "REG_DN", "REG_RG", "REG_TR", "VOL_X", "META_VER"}   # 4 mảng mới + hằng số mới/đổi (A-06, ST-09)
    loi_nhat = []

    def tt(m):
        s = goc(m)
        g = m.ip.g
        if "plB" in g:
            # tính nhất quán: mức công bố gần nhất phía BSL/SSL phải nằm trong tập pool giữ cho I-4
            c = g.get("cM15")
            if g.get("pubLv") is not NA and g["pubLv"] not in g["plB"].v:
                loi_nhat.append(("pubLv∉plB", g["pubLv"]))
            if g.get("pslLv") is not NA and g["pslLv"] not in g["plS"].v:
                loi_nhat.append(("pslLv∉plS", g["pslLv"]))
            if c is not NA and any(x is NA for x in g["plB"].v):
                loi_nhat.append("na trong plB")
        return {k: v for k, v in s.items() if k not in MOI}
    MS.trang_thai = tt
    kq = []
    try:
        for ten, n, seed in (("lien_tuc", 1500, 1), ("cum_dong_thoi", 1500, 2), ("tong_hop", 2600, 3), ("bat_kip_hai_phia", 1500, 4)):
            r = MS.chay(ten, n, seed, so_sanh=True, kiem_bb=True, text_a=S34, text_b=S35, ghi_moc=0)
            kq.append((ten, r["nen_chay"], r["sai_khac"], r["loi_chay"], len(r["loi_bat_bien"])))
    finally:
        MS.trang_thai = goc
    ok = all(x[2] is None and x[3] is None and x[4] == 0 and x[1] > 1000 for x in kq) and not loi_nhat
    return ok, f"MD-5 nguyên văn 0.3.4a ↔ 0.3.5 (bỏ 4 mảng mới): {kq}; nhất quán pool ↔ mức công bố: {loi_nhat[:3] or 'đạt'}"


# ============================================================ NHÓM D – hồi quy
KY_VONG_HQ = {  # test cũ đổi kết quả do thay đổi CÓ CHỦ ĐÍCH (không sửa test cũ) → phải có kiểm độc lập trong bộ này
    "ST-01": "StructOut 77 → 84 trường (MD-6/Z-Q3) – kiểm độc lập A-09",
    "ST-06": "Test cũ cộng 2 plot I-5 lên số hiện tại; 0.3.5 đã gồm 2 plot đó → 56 + 2 > 56. Dự phòng thực 64 − 56 = 8 – kiểm độc lập A-05",
    "ST-08": "Định nghĩa upstream mới mà pipeline đọc (REG_*, VOL_X, f_perm, f_grade, f_lvPick, f_p0/Z-Q3, plB…) – phạm vi diff A-02",
    "ST-09": "META_VER 303 → 305 (đổi logic và định dạng Data Window) – A-01/C-04",
    "ST-12": "Pipeline nay đọc đầu ra MD-5 (pool) và MD-4 (cụm) theo I-4/I-6 – C-01, B-S1-02; lưu ý quyết định 0.3.3 về MD-5",
    "UD-01": "A-07 đã chuyển sang PA1 theo quyết định – A-07, B-A07-*",
}


def t_hoi_quy_cu():
    p = os.path.join(G, "hoi_quy034")
    r = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "035"], cwd=p, capture_output=True, text=True, timeout=900)
    d = json.load(open(os.path.join(p, "results", "ket_qua_test_035.json"), encoding="utf-8"))
    rows = d if isinstance(d, list) else next(v for v in d.values() if isinstance(v, list))
    fail = sorted(x["id"] for x in rows if x["trang_thai"] == "FAIL")
    dem = {}
    for x in rows:
        dem[x["trang_thai"]] = dem.get(x["trang_thai"], 0) + 1
    r4 = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "034a"], cwd=p, capture_output=True, text=True, timeout=900)
    d4 = json.load(open(os.path.join(p, "results", "ket_qua_test_034a.json"), encoding="utf-8"))
    rows4 = d4 if isinstance(d4, list) else next(v for v in d4.values() if isinstance(v, list))
    dem4 = {}
    for x in rows4:
        dem4[x["trang_thai"]] = dem4.get(x["trang_thai"], 0) + 1
    return (fail, dem, r.returncode, dem4, r4.returncode)


def t_vong_doi():
    r = subprocess.run([sys.executable, os.path.join(G, "kiem_toan034a", "vong_doi.py")], cwd=G, capture_output=True, text=True, timeout=1200)
    p = os.path.join(G, "ket_qua034a_nt", "vong_doi.json")
    vd = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None
    return r.returncode == 0 and vd and vd["dem"]["FAIL"] == 0 and vd["dem"]["PASS"] >= 2000, (vd["dem"] if vd else r.stdout[-400:] + r.stderr[-400:])


def main():
    t0 = time.time()
    uoc, t34, t35 = nhom_a()
    B = [("B-REG-01", "I-1/MD-6 C.2", "f_regNext ↔ mô hình MD-6 tham chiếu trên 8.400 nến ngẫu nhiên (gồm ER dồn vào biên ngưỡng)", "THÔNG DỊCH + THAM CHIẾU", t_reg_vi_sai),
         ("B-REG-02", "I-1/MD-6 C.2", "Ca biên quy tắc regime: nến đủ dữ liệu đầu tiên, ngưỡng ER, ST NONE, cửa sổ TRANSITION 6 nến, CHoCH trong cửa sổ", "THÔNG DỊCH", t_reg_bien),
         ("B-VOL-01", "I-1/MD-6 C.3", "Lớp VOL tại các biên 0,7 / 1,5 / 2,5 và na", "THÔNG DỊCH", t_vol),
         ("B-PERM-01", "I-1 (I.3)", "Quyền MD-7 lớp THUẬN ↔ mô hình I.3 viết từ văn bản, toàn bộ tổ hợp", "THÔNG DỊCH + THAM CHIẾU", t_perm),
         ("B-LV-01", "I-4/I-6", "Chọn mức từ cụm MD-4/pool MD-5 (f_lvPick)", "THÔNG DỊCH", t_lvpick),
         ("B-GRADE-01", "I-3 (I.5, E.3)", "Hạng A/B ↔ mô hình I.5/E.3; biên X-S và BTC", "THÔNG DỊCH + THAM CHIẾU", t_grade),
         ("B-D8-01", "I-3 (S2b)", "Phá hòa S2b bậc 0 (hạng, lớp setup) và hồi quy D8 với 0.3.4a", "THÔNG DỊCH (vi sai 0.3.4a)", t_d8),
         ("B-A07-01", "A-07 PA1", "Nhánh dự phòng Pine nguyên văn ↔ MD-2 tham chiếu (0.3.5 = gồm p₀; 0.3.4a = loại p₀), mức bằng nhau, p₀ cực trị, p0 na, vượt LB_CAP", "THÔNG DỊCH + THAM CHIẾU", t_a07_pine),
         ("B-A07-02", "A-07 PA1", "TC-PROT02/TC-MS08 của đặc tả đạt với PA1 (mô hình và Pine)", "THAM CHIẾU + THÔNG DỊCH", t_a07_tc),
         ("B-A07-03", "A-07 PA1", "Hồi quy PROT/CHoCH/ST/REG: mọi PROT khác cách cũ đều do nến p₀ ở nhánh dự phòng; định lượng thay đổi CHoCH/ST/REG", "THAM CHIẾU (MD-2 → MD-6)", t_a07_tac_dong),
         ("B-ZQ3-01", "I-3 (Z-Q3)", "Mặt nạ Z-Q3 mã hóa/giải mã nguyên văn, đồng bộ mảng ứng viên", "THÔNG DỊCH + TĨNH", t_zq3),
         ("B-S1-01", "I-1…I-6", "Hồi quy S1: có quyền và không có cụm/pool hợp lệ → trùng 0.3.4a mọi trường", "THÔNG DỊCH (vi sai 0.3.4a)", t_s1_hoi_quy),
         ("B-S1-02", "I-1…I-6", "Kịch bản S1 có chủ đích: lý do 8/15 và thứ tự, I.3 (a)/(b), VOL biên, cụm/pool/hạng, TP2, TP3, SELL, hạng, loại", "THÔNG DỊCH", t_s1_muc_tieu)]
    for tid, nh, mt, pp, fn in B:
        an_toan(tid, "B · " + nh, mt, pp, "đúng mong đợi / 0 sai khác", "kiem_toan035/chay_035.py::" + fn.__name__, fn)
    C = [("C-01", "MD-6 → MD-7 → S1: chuỗi H4 → regime nguyên văn → quyền → lý do S1 khớp mô hình", "THÔNG DỊCH + THAM CHIẾU", t_chuoi_md6_md7_s1),
         ("C-02", "S2b xếp hạng nhiều ứng viên: hạng A trước, lớp setup, rồi D8; f_ledger dùng f_d8", "THÔNG DỊCH", t_xep_hang_s2b),
         ("C-03", "Data Window/dashboard: mã regime duy nhất, cùng nguồn sH4; 2 plot chỉ Data Window", "THÔNG DỊCH + TĨNH", t_data_window),
         ("C-04", "Cảnh báo/hiển thị: không thêm cảnh báo (Q3 thuộc MD-9), không còn nhãn 'coi là đạt'", "TĨNH", t_hien_thi_canh_bao),
         ("C-05", "MD-5 nguyên văn 0.3.4a ↔ 0.3.5 trên 4 kịch bản (gồm H1 dừng/bắt kịp/khóa sát ngưỡng); bất biến; pool giữ cho I-4 nhất quán với mức công bố", "THÔNG DỊCH (vi sai)", t_md5_song_song)]
    for tid, mt, pp, fn in C:
        an_toan(tid, "C · tích hợp", mt, pp, "đúng / 0 sai khác", "kiem_toan035/chay_035.py::" + fn.__name__, fn)
    # D
    try:
        fail, dem, rc, dem4, rc4 = t_hoi_quy_cu()
        ok = set(fail) == set(KY_VONG_HQ) and dem.get("PASS", 0) == 42 and (dem4.get("PASS"), dem4.get("FAIL", 0), dem4.get("BLOCKED"), dem4.get("NOT TESTED")) == (48, 0, 9, 1)
        ghi("D-01", "D · hồi quy", "Bộ hồi quy cũ hoi_quy034 trên 0.3.5 (KHÔNG sửa test cũ; chỉ thêm đích '035'): FAIL chỉ ở đúng 6 test có thay đổi chủ đích, mỗi test có kiểm độc lập",
            "HỒI QUY", "FAIL ⊆ {ST-01, ST-06, ST-08, ST-09, ST-12, UD-01}; 0.3.4a vẫn 48/0/9/1",
            f"0.3.5: {dem} (mã thoát gốc {rc}); FAIL = {fail}; giải thích {KY_VONG_HQ}; 0.3.4a: {dem4} (mã thoát {rc4})", "PASS" if ok else "FAIL",
            "hoi_quy034/results/ket_qua_test_035.json, ket_qua_test_034a.json")
    except Exception as e:      # noqa: BLE001
        ghi("D-01", "D · hồi quy", "Bộ hồi quy cũ hoi_quy034 trên 0.3.5", "HỒI QUY", "—", repr(e), "FAIL", "—")
    an_toan("D-02", "D · hồi quy", "Vòng đời MD-5 (2.054 bước, hàm Pine nguyên văn) vẫn 0 FAIL sau khi mở rộng pine_mini (for…in, math.floor)", "HỒI QUY (thông dịch)",
            "0 FAIL", "ket_qua034a_nt/vong_doi.json", t_vong_doi)
    if NHANH:
        ghi("D-03", "D · hồi quy", "Bộ cổng tiền MD-6 (baseline 0.3.4a, mô hình MD-2/MD-6) không đổi", "HỒI QUY", "31/0/9/1 trừ RV-02", "bỏ qua (--nhanh)", "NOT TESTED", "—")
    else:
        r = subprocess.run([sys.executable, "cong_tien_md6/chay_cong_tien.py", "--nhanh"], cwd=G, capture_output=True, text=True, timeout=1200)
        p = os.path.join(G, "cong_tien_md6", "ket_qua", "KET_QUA_KIEM_THU.json")
        d = json.load(open(p, encoding="utf-8"))
        rows = d if isinstance(d, list) else next(v for v in d.values() if isinstance(v, list))
        dem = {}
        for x in rows:
            dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
        ok = dem.get("FAIL", 0) == 0 and r.returncode == 2
        ghi("D-03", "D · hồi quy", "Bộ cổng tiền MD-6 (baseline 0.3.4a, mô hình MD-2/MD-6) vẫn 0 FAIL", "HỒI QUY", "0 FAIL; mã thoát 2", f"{dem}; mã thoát {r.returncode}",
            "PASS" if ok else "FAIL", "cong_tien_md6/ket_qua/KET_QUA_KIEM_THU.json")
    r = subprocess.run([sys.executable, os.path.join(G, "kiem_toan035", "dot_bien_035.py")], cwd=G, capture_output=True, text=True, timeout=1500)
    p = os.path.join(OUT, "dot_bien_035.json")
    db = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None
    ghi("D-04", "D · đối chứng âm", "12 đột biến tiêm vào bản sao 0.3.5 (A-07, VOL, T_ĐC, ngưỡng ER, cửa sổ 6, lọc hạng, bậc hạng S2b, X-S BTC, thứ tự 8/15, TP3, pool sai phía, Z-Q3) đều bị test bắt",
        "ĐỘT BIẾN (thông dịch)", "12/12 bị bắt; mã gốc vẫn đạt", (db["song_sot"], db["ma_goc_van_dat"]) if db else r.stdout[-400:],
        "PASS" if r.returncode == 0 and db and not db["song_sot"] and db["ma_goc_van_dat"] else "FAIL", "ket_qua035/dot_bien_035.json")
    # TradingView – không có bằng chứng → BLOCKED (không bao giờ PASS từ mô hình)
    TV = [("TV-01", "Compile 0.3.5 trên TradingView (và số token thực nếu hiện)", "Ước lượng A-11 chỉ là ước lượng; CE10117/CE10137 chỉ chứng minh được bằng compile thật"),
          ("TV-02", "Điều kiện 1: runtime không lỗi XAUUSD và BTCUSD M5 (Exness)", "Vòng for mới trong f_grade/f_lvPick chỉ chạy ở nến trigger; giới hạn thời gian/vòng lặp chỉ đo được trên TradingView"),
          ("TV-03", "Điều kiện 2: tải lại/realtime – lịch sử đã xác nhận không bị viết lại; giá trị intrabar phân biệt với trạng thái xác nhận", "Thiết kế dùng so[1]/lookahead_on; cần bằng chứng runtime"),
          ("TV-04", "Bar Replay", "Bắt buộc theo chỉ thị; chưa thực hiện → BLOCKED. Tác động: chưa chứng minh không repaint ở chế độ phát lại"),
          ("TV-05", "Điều kiện 3: bộ đếm khung trễ dashboard 0/0", "Chỉ đọc được trên biểu đồ thật"),
          ("TV-06", "Điều kiện 4: ≥ 120 nến H4 đã đóng, ER/VR hợp lệ (MÃ REGIME ≠ 0 trong Data Window)", "request.security H4 trên biểu đồ M5 chỉ có số nến H4 tương ứng lịch sử M5 đã nạp; cần kiểm trên tài khoản của chủ dự án"),
          ("TV-07", "Điều kiện 5: R-7 so[1] khi runtime/tải lại", "Mô hình đã kiểm ở vòng 0.3.4a; runtime chưa"),
          ("TV-08", "Profiler / CSV thật Exness", "Chưa có dữ liệu thật")]
    for tid, mt, ly in TV:
        ghi(tid, "TradingView", mt, "TRADINGVIEW", "bằng chứng từ TradingView", ly, "BLOCKED", "HUONG_DAN_KIEM_TRADINGVIEW_0.3.5.md")
    dem = {}
    for r_ in KQ:
        dem[r_["ket_qua"]] = dem.get(r_["ket_qua"], 0) + 1
    tom = dict(build="0.3.5 Candidate", sha_035=SHA35_GIAO, sha_034a=K.SHA34A, dem=dem, token_uoc=uoc, token_tu_vung=(t34, t35), thoi_gian_s=round(time.time() - t0, 1))
    json.dump(dict(tom_tat=tom, ket_qua=KQ), open(os.path.join(OUT, "ket_qua_035.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(OUT, "ket_qua_035.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(KQ[0].keys())); w.writeheader(); w.writerows(KQ)
    print(dem, f"{tom['thoi_gian_s']} s")
    sys.exit(1 if dem.get("FAIL") else (2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0))


if __name__ == "__main__":
    main()
