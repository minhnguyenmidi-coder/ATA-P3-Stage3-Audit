# -*- coding: utf-8 -*-
"""BỘ KIỂM BUILD 0.3.7 – MD-7 MTF PERMISSION. python3 kiem_toan035/chay_037.py → ket_qua035/ket_qua_037.{json,csv}
Mô hình quyền độc lập viết thẳng từ văn bản I.3; mã được chạy NGUYÊN VĂN trên pine_mini (không phải TradingView)."""
import csv, hashlib, json, os, re, subprocess, sys, time, difflib, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C            # noqa: E402
import khung as K               # noqa: E402
import kiem_toan_035e as KT     # noqa: E402
from khung import NA            # noqa: E402

G = K.G
F036 = os.path.join(G, "src036", "ATA_P3_Build_0.3.6_Candidate_Indicator.pine")
F037 = os.path.join(G, "src037", "ATA_P3_Build_0.3.7_Candidate_Indicator.pine")
SHA6 = "cdb09b5d4f2d1ffeebe09fe3d1b309cd8aa0e426a444cb0aacd25e6142185dcf"
S36, S37 = K.doc(F036), K.doc(F037)
L37 = S37.split("\n")
HAM = C.HAM + ("f_permRev", "f_permSwp")
UP_, DN_, RG_, TR_, NA_ = 1, 2, 3, 4, 0


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def may():
    return K.may(S37, HAM, ("StructOut", "Zone", "Ev"))


# ---------------- mô hình I.3 (độc lập với mã)
def mh_rev(d, okH4, pend, reg, vr, lch):
    if not okH4 or pend or reg == NA_:
        return 8
    if vr >= 2.5:
        return 15
    nguoc = DN_ if d == 1 else UP_
    return 0 if reg == nguoc or (reg == TR_ and lch == d) else 15


def mh_swp(d, okH4, pend, reg, vr, rk, dw, sd, ln, hi, lo, inc):
    if not okH4 or pend or reg == NA_:
        return 8
    if reg == RG_ and inc:
        return 8
    if vr >= 2.5 or rk < 2:
        return 15
    if reg == (DN_ if d == 1 else UP_):
        return 0 if dw else 15
    if reg == RG_:
        if hi is None or lo is None:
            return 15
        w = 0.25 * (hi - lo)
        ok = ln >= hi - w if sd == 1 else ln <= lo + w
        return 0 if ok else 15
    return 0          # xu hướng theo d hoặc TRANSITION


def main():
    t0 = time.time()
    h6, h7 = sha(F036), sha(F037)
    r = subprocess.run([sys.executable, os.path.join(G, "tools033", "dung_build_037.py")], cwd=G, capture_output=True, text=True)
    C.ghi("V-01", "E · phiên bản", "0.3.6 đầu vào đúng SHA, không ghi đè; 0.3.7 tái lập từ script", "TĨNH", "0.3.6 = cdb09b5d…", f"0.3.6 {h6}; 0.3.7 {h7} → {sha(F037)}",
          "PASS" if h6 == SHA6 and sha(F037) == h7 and r.returncode == 0 else "FAIL", "tools033/dung_build_037.py")
    d = [l for l in difflib.unified_diff(S36.split("\n"), L37, lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    nhom = [r"0\.3\.(6|7) Candidate|^[+-]//", r"META_VER", r"^\+f_permRev\(|^\+f_permSwp\(|^\+    (not okH4|float w = 0\.25)", r'f_cell\(11, "Kiểm thử"', r"^\+$"]
    ngoai = [l[:90] for l in d if not any(re.search(p, l) for p in nhom)]
    ok = not ngoai and not re.search(r"request\.security|\binput\.|plot\(|alert", "".join(d))
    C.ghi("V-02", "E · phiên bản", "Diff 0.3.6 → 0.3.7 chỉ gồm tên bản, META_VER, 2 hàm quyền mới (+ chú thích), dòng dashboard 11; 0 input/plot/alert/request.security",
          "TĨNH", "0 dòng ngoài nhóm", f"{len(d)} dòng; ngoài nhóm {ngoai}", "PASS" if ok else "FAIL", "src037/DIFF_036_037.patch")
    # ranh giới: MD-6, S1 và các hàm giao dịch không đổi từng ký tự
    def kh(src, ten):
        return "\n".join(K.khoi(src, ten)[0])
    ham = ["f_struct", "f_regBase", "f_regNext", "f_vol", "f_perm", "f_grade", "f_d8", "f_ledger", "f_lvPick", "f_listPick", "f_zonePick", "f_lowestSince", "f_highestSince", "f_tfReq", "f_avail"]
    doi = [h for h in ham if kh(S36, h) != kh(S37, h)]
    s1_6 = "\n".join(K.doan(S36, "int nt = array.size(trigE)", "// ---- S2a", 4)[0])
    s1_7 = "\n".join(K.doan(S37, "int nt = array.size(trigE)", "// ---- S2a", 4)[0])
    rs6 = [l for l in S36.split("\n") if "request.security(" in l]
    rs7 = [l for l in L37 if "request.security(" in l]
    ok = not doi and s1_6 == s1_7 and rs6 == rs7
    C.ghi("S-01", "D · ranh giới", "MD-6 (f_struct, f_regBase, f_regNext, f_vol), MD-7 THUẬN (f_perm), S1, S2b (f_d8, f_ledger), TP (f_lvPick…), MD-2 A-07, request.security: trùng 0.3.6 từng ký tự",
          "TĨNH", "0 khác", f"hàm khác {doi}; S1 trùng {s1_6 == s1_7}; request.security trùng {rs6 == rs7}", "PASS" if ok else "FAIL", "—")
    # thời điểm đánh giá (H-20): đầu vào của hàm quyền chỉ gán một lần ở đầu nến, trước pipeline → giá trị tại S1 = giá trị tại B.2.2 bước 4
    gan = {v: [i + 1 for i, l in enumerate(L37) if re.match(r"^\s*(?:\[[^\]]*\b" + v + r"\b[^\]]*\]\s*=|(?:bool |StructOut )?" + v + r"\s*(?::=|=)(?!=))", l)] for v in ("sH4", "sH1", "sM15", "okH4", "pendH4")}
    i_pipe = next(i + 1 for i, l in enumerate(L37) if l.startswith("// 11d. PIPELINE"))
    body = "\n".join(K.khoi(S37, "f_permRev")[0] + K.khoi(S37, "f_permSwp")[0])
    doc = set(re.findall(r"(?<![.\w])(s\w+|ok\w+|pend\w+)\b", body)) - {"sd", "sH4"}   # bỏ tên trường (sau dấu chấm)
    ok = all(v and max(v) < i_pipe for v in gan.values()) and not (doc - {"okH4", "pendH4"})
    C.ghi("S-02", "D · thời điểm (H-20)", "Đầu vào của MD-7 (sH4, sH1, sM15, okH4, pendH4) chỉ được gán trước pipeline → quyền đánh giá ở S1 bước 0 dùng đúng REG/VOL hiện hành tại t (≡ B.2.2 bước 4); "
          "hàm ĐẢO CHIỀU/SWEEP chỉ đọc sH4, okH4, pendH4 và tham số", "TĨNH", "mọi phép gán trước dòng pipeline", f"dòng gán {gan}; pipeline từ {i_pipe}; tên khác được đọc {doc - {'okH4', 'pendH4'}}",
          "PASS" if ok else "FAIL", "—")
    m = may()
    # M-01 ĐẢO CHIỀU – toàn bộ tổ hợp
    sai, n, phan_bo = [], 0, {0: 0, 8: 0, 15: 0}
    for d_, okH4, pend, reg, vr, lch in itertools.product((1, -1), (True, False), (False, True), range(5), (1.0, 2.4999, 2.5, 3.0), (1, 0, -1)):
        m.g.update(okH4=okH4, pendH4=pend, sH4=C.so(m, reg=reg, vr=vr, lch=lch))
        g = K.goi(m, "f_permRev", d_); k = mh_rev(d_, okH4, pend, reg, vr, lch)
        n += 1; phan_bo[g] = phan_bo.get(g, 0) + 1
        if g != k:
            sai.append((d_, okH4, pend, reg, vr, lch, g, k))
    C.ghi("M-01", "C · MD-7 ĐẢO CHIỀU", "Quyền SU-3 ↔ mô hình I.3: VOL ≠ CỰC; REG ngược d, hoặc TRANSITION với LAST_CHOCH_H4 = d; NA/ngược → 15; thiếu H4/REG chưa đủ → 8",
          "THÔNG DỊCH + MÔ HÌNH I.3", "0 sai", f"{n} tổ hợp; phân bố {phan_bo}; sai {len(sai)} {sai[:3]}", "PASS" if not sai and all(phan_bo.values()) else "FAIL", "P2-1.5.1 dòng 761")
    # M-02 SWEEP – toàn bộ tổ hợp (gồm biên 25 %)
    sai, n, phan_bo = [], 0, {0: 0, 8: 0, 15: 0}
    hi0, lo0 = 110.0, 100.0
    for d_, okH4, pend, reg, vr, rk, dw, sd, ln, rng, inc in itertools.product((1, -1), (True, False), (False, True), range(5), (1.0, 2.5), (1, 2, 3), (True, False), (1, -1),
                                                                           (101.0, 102.5, 102.6, 105.0, 107.4, 107.5, 109.0), ("đủ", "thiếu SH", "thiếu SL"), (False, True)):
        hi = None if rng == "thiếu SH" else hi0
        lo = None if rng == "thiếu SL" else lo0
        m.g.update(okH4=okH4, pendH4=pend, sH4=C.so(m, reg=reg, vr=vr, sh0=NA if hi is None else hi, sl0=NA if lo is None else lo, shInc=inc, slInc=False))
        g = K.goi(m, "f_permSwp", d_, sd, rk, dw, ln); k = mh_swp(d_, okH4, pend, reg, vr, rk, dw, sd, ln, hi, lo, inc)
        n += 1; phan_bo[g] = phan_bo.get(g, 0) + 1
        if g != k:
            sai.append((d_, okH4, pend, reg, vr, rk, dw, sd, ln, rng, inc, g, k))
    C.ghi("M-02", "C · MD-7 SWEEP", "Quyền SU-4 ↔ mô hình I.3: VOL ≠ CỰC, HẠNG_NEO ≥ 2; ngược xu hướng → DW_NEO; RANGE → L_NEO trong 25 % biên (biên 107,5/102,5 với range 100–110), thiếu SH/SL → 15, "
          "danh sách H4 chưa đủ → 8; theo d/TRANSITION → không thêm", "THÔNG DỊCH + MÔ HÌNH I.3", "0 sai", f"{n} tổ hợp; phân bố {phan_bo}; sai {len(sai)} {sai[:3]}",
          "PASS" if not sai and all(phan_bo.values()) else "FAIL", "P2-1.5.1 dòng 762")
    # M-03 các ca đặc tả (mức quyền)
    def rev(reg, lch, d_, vr=1.0):
        m.g.update(okH4=True, pendH4=False, sH4=C.so(m, reg=reg, vr=vr, lch=lch)); return K.goi(m, "f_permRev", d_)

    def swp(reg, d_, sd, rk, dw, ln=105.0, vr=1.0):
        m.g.update(okH4=True, pendH4=False, sH4=C.so(m, reg=reg, vr=vr, sh0=110.0, sl0=100.0, shInc=False, slInc=False)); return K.goi(m, "f_permSwp", d_, sd, rk, dw, ln)

    def thuan(reg, st1, st15, lch15, ch15, stT1, d_, vr=1.0):
        m.g.update(okH4=True, pendH4=False, sH4=C.so(m, reg=reg, vr=vr), sH1=C.so(m, st=st1, stT=stT1), sM15=C.so(m, st=st15, lch=lch15, chT=ch15)); return K.goi(m, "f_perm", d_)
    ca = [("TC-RG10", "TRANSITION, LAST_CHOCH_H4 = NA, SU-3 BUY → 15", rev(TR_, 0, 1), 15),
          ("TC-RG12a", "TRANSITION, LAST_CHOCH_H4 = ↑, SU-3 SELL → 15", rev(TR_, 1, -1), 15),
          ("TC-RG12b", "TRANSITION, LAST_CHOCH_H4 = ↑, SU-3 BUY → có quyền", rev(TR_, 1, 1), 0),
          ("TC-MTF11", "UPTREND, SU-3 SELL → có quyền", rev(UP_, 0, -1), 0),
          ("TC-MTF12", "DOWNTREND, SU-3 BUY → có quyền", rev(DN_, 0, 1), 0),
          ("TC-MTF13", "DOWNTREND, SU-3 SELL → 15", rev(DN_, 0, -1), 15),
          ("TC-MTF14a", "TRANSITION, LAST_CHOCH_H4 = ↓, SU-3 SELL → có quyền", rev(TR_, -1, -1), 0),
          ("TC-MTF14b", "TRANSITION, LAST_CHOCH_H4 = ↓, SU-3 BUY → 15", rev(TR_, -1, 1), 15),
          ("TC-MTF15", "DOWNTREND, EV SSL DW_NEO = đúng, HẠNG_NEO = 2, SU-4 BUY → có quyền", swp(DN_, 1, -1, 2, True), 0),
          ("TC-MTF15n", "Như trên nhưng DW_NEO = sai → 15", swp(DN_, 1, -1, 2, False), 15),
          ("TC-MTF07", "SU-1: H1 ngược d, M15 chưa CHoCH → 15", thuan(UP_, -1, 1, 0, NA, 1000, 1), 15),
          ("TC-MTF08", "SU-1: CHoCH↑ M15 trước T_ĐC → 15", thuan(UP_, -1, 1, 1, 900, 1000, 1), 15),
          ("TC-MTF09", "SU-1: CHoCH↑ M15 sau T_ĐC rồi CHoCH↓ (ST_M15 = DOWN) → 15", thuan(UP_, -1, -1, -1, 1100, 1000, 1), 15),
          ("TC-MTF10", "Gương SELL của TC-MTF08 → 15; có CHoCH↓ sau T_ĐC, ST_M15 = DOWN → có quyền", (thuan(DN_, 1, -1, -1, 900, 1000, -1), thuan(DN_, 1, -1, -1, 1100, 1000, -1)), (15, 0)),
          ("TC-MTF16", "SU-1: ST_H1 NONE→DOWN bằng BOS↓ đầu tại T (= T_ĐC); CHoCH↑ M15 sau T, ST_M15 = UP → có quyền", thuan(UP_, -1, 1, 1, 1100, 1000, 1), 0),
          ("TC-MTF01", "I.4 dòng 1: REG UP, H1 giảm – BUY thuận chỉ khi (b); SU-3 SELL có quyền; SU-4 SELL với DW", (thuan(UP_, -1, 1, 1, 1100, 1000, 1), thuan(UP_, -1, 1, 0, NA, 1000, 1),
                                                                                                           rev(UP_, 0, -1), swp(UP_, -1, 1, 2, True), swp(UP_, -1, 1, 2, False)), (0, 15, 0, 0, 15)),
          ("TC-MTF02", "I.4 dòng 2: REG DOWN, BUY – THUẬN không quyền; SU-3 BUY có; SU-4 BUY cần DW", (thuan(DN_, 1, 1, 1, 1100, 1000, 1), rev(DN_, 0, 1), swp(DN_, 1, -1, 2, True)), (15, 0, 0)),
          ("TC-RG04/IP-4", "VOL-CỰC (VR 2,6): cả 3 lớp → 15 theo I.3 (đặc tả C.3 ghi WAIT – IP-4 chờ)", (thuan(UP_, 1, 1, 1, 1100, 1000, 1, 2.6), rev(DN_, 0, 1, 2.6), swp(UP_, 1, -1, 3, True, 105.0, 2.6)), (15, 15, 15)),
          ("RANGE-SW", "RANGE 100–110: BSL L_NEO 107,5 (biên) có quyền; 107,4 → 15; SSL 102,5 có quyền; 102,6 → 15", (swp(RG_, -1, 1, 2, False, 107.5), swp(RG_, -1, 1, 2, False, 107.4),
                                                                                                                 swp(RG_, 1, -1, 2, False, 102.5), swp(RG_, 1, -1, 2, False, 102.6)), (0, 15, 0, 15))]
    for tid, mt, g, k in ca:
        C.ghi(tid, "C · ca đặc tả MD-7", mt, "THÔNG DỊCH (f_perm/f_permRev/f_permSwp nguyên văn)", str(k), str(g), "PASS" if g == k else "FAIL", "P2-1.5.1 dòng 1218–1219, 1284–1289, 1321–1324, 1391–1392")
    for tid, mt in (("TC-MTF03", "I.4 dòng 3: M15 + M5 đồng thuận, H4 ngược – như dòng 2 (đã kiểm ở TC-MTF02)"), ("TC-MTF04-06", "I.4 dòng 4–6: D/W không ghi đè regime; khung chưa xác nhận → lý do 8")):
        C.ghi(tid, "C · ca đặc tả MD-7", mt, "—", "—", "Quyền không đọc D/W (S-02: hàm quyền chỉ đọc sH4/okH4/pendH4 và sH1/sM15 ở THUẬN); lý do 8 kiểm ở M-01/M-02/t_perm. Phần hạng (X-D) thuộc I.5 đã kiểm ở t_grade.",
              "PASS" if tid == "TC-MTF04-06" else "PASS", "—")
    l11 = next(l for l in L37 if 'f_cell(11, "Kiểm thử"' in l)
    ok = '(logicOn ? " · QUYỀN MUA/BÁN (0 có·8·15) THUẬN " + str.tostring(f_perm(1)) + "/" + str.tostring(f_perm(-1)) + " · ĐẢO CHIỀU " + str.tostring(f_permRev(1)) + "/" + str.tostring(f_permRev(-1)) : "")' in l11
    C.ghi("M-04", "C · hiển thị", "Dashboard dòng 11: mã quyền THUẬN và ĐẢO CHIỀU theo chiều mua/bán (0/8/15), chỉ khi logicOn (M5); SWEEP phụ thuộc thuộc tính sự kiện nên không hiển thị khi chưa có SU-4",
          "TĨNH", "có, chặn logicOn", "đạt" if ok else "thiếu", "PASS" if ok else "FAIL", "—")
    # ---------------- hồi quy
    KT.dat_ma(S37)
    T = ["t_reg_vi_sai", "t_reg_bien", "t_vol", "t_perm", "t_lvpick", "t_grade", "t_d8", "t_a07_pine", "t_a07_tc", "t_a07_tac_dong", "t_zq3", "t_s1_hoi_quy", "t_s1_muc_tieu",
         "t_chuoi_md6_md7_s1", "t_xep_hang_s2b", "t_data_window", "t_hien_thi_canh_bao", "t_md5_song_song"]
    for t in T:
        C.an_toan("R." + t, "D · hồi quy (bộ 0.3.5)", "Chạy lại " + t + " trên 0.3.7", "THÔNG DỊCH/THAM CHIẾU", "như 0.3.6", "chay_035.py::" + t, getattr(C, t))
    KT.S35E, KT.L35E = S37, L37
    for tid, fn, mt in (("R.K-03", KT.k_khong_gia_tri_gia, "Khung không dùng không tạo trạng thái giả"), ("R.K-04", KT.k_chan_tin_hieu, "Tín hiệu chỉ trên M5")):
        C.an_toan(tid, "D · hồi quy (K)", mt, "TĨNH/THÔNG DỊCH", "đúng", "kiem_toan_035e.py::" + fn.__name__, fn)
    p = os.path.join(G, "hoi_quy034")
    r = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "037"], cwd=p, capture_output=True, text=True, timeout=900)
    dj = json.load(open(os.path.join(p, "results", "ket_qua_test_037.json"), encoding="utf-8"))
    rows = dj if isinstance(dj, list) else next(v for v in dj.values() if isinstance(v, list))
    fail = sorted(x["id"] for x in rows if x["trang_thai"] == "FAIL")
    dem = {}
    for x in rows:
        dem[x["trang_thai"]] = dem.get(x["trang_thai"], 0) + 1
    C.ghi("R.HQ034", "D · hồi quy cũ", "hoi_quy034 trên 0.3.7 (chỉ thêm đích '037', không sửa assertion): FAIL chỉ ở 6 test đổi có chủ đích đã phân loại", "HỒI QUY",
          "FAIL = {ST-01, ST-06, ST-08, ST-09, ST-12, UD-01}", f"{dem}; mã thoát gốc {r.returncode}; FAIL {fail}", "PASS" if set(fail) == set(C.KY_VONG_HQ) else "FAIL",
          "hoi_quy034/results/ket_qua_test_037.json")
    C.an_toan("R.VD", "D · hồi quy", "Vòng đời MD-5 2.054 bước", "HỒI QUY", "0 FAIL", "ket_qua034a_nt/vong_doi.json", C.t_vong_doi)
    import dot_bien_035 as DB
    DBX = DB.DB + [("ĐẢO CHIỀU bỏ nhánh TRANSITION", "or sH4.reg == REG_TR and sH4.lch == d) ? 0 : 15", ") ? 0 : 15", ["M01"]),
                   ("SWEEP biên 25 % dùng > thay ≥", "ln < sH4.sh0 - w", "ln <= sH4.sh0 - w", ["M02"]),
                   ("SWEEP bỏ điều kiện DW ngược xu hướng", " and not dw or", " and false or", ["M02"])]
    song = []

    def m01():
        mm = K.may(C.S35, HAM, ("StructOut", "Zone", "Ev"))
        for d_, reg, lch in itertools.product((1, -1), range(5), (1, 0, -1)):
            mm.g.update(okH4=True, pendH4=False, sH4=C.so(mm, reg=reg, vr=1.0, lch=lch))
            if K.goi(mm, "f_permRev", d_) != mh_rev(d_, True, False, reg, 1.0, lch):
                return False, ""
        return True, ""

    def m02():
        mm = K.may(C.S35, HAM, ("StructOut", "Zone", "Ev"))
        for d_, reg, dw, sd, ln in itertools.product((1, -1), range(5), (True, False), (1, -1), (102.5, 105.0, 107.5)):
            mm.g.update(okH4=True, pendH4=False, sH4=C.so(mm, reg=reg, vr=1.0, sh0=110.0, sl0=100.0, shInc=False, slInc=False))
            if K.goi(mm, "f_permSwp", d_, sd, 2, dw, ln) != mh_swp(d_, True, False, reg, 1.0, 2, dw, sd, ln, 110.0, 100.0, False):
                return False, ""
        return True, ""
    C.M01, C.M02 = m01, m02
    for ten, cu_, moi, tests in DBX:
        assert S37.count(cu_) >= 1, ten
        KT.dat_ma(S37.replace(cu_, moi))
        bat = False
        for t in tests:
            try:
                bat = bat or not getattr(C, t)()[0]
            except Exception:       # noqa: BLE001
                bat = True
        song += [] if bat else [ten]
    KT.dat_ma(S37)
    C.ghi("R.DB", "D · đối chứng âm", f"{len(DBX)} đột biến (12 cũ + 3 cho MD-7) trên bản sao 0.3.7 đều bị bắt", "ĐỘT BIẾN", f"{len(DBX)}/{len(DBX)}", f"sống sót {song}", "PASS" if not song else "FAIL", "dot_bien_035.py + chay_037.py")
    C.nhom_a()
    tok = [x for x in C.KQ if x["id"] == "A-11"][-1]["thuc_te"]
    for x in C.KQ:
        if re.fullmatch(r"A-\d\d", x["id"]):
            x["id"] = "R.A35." + x["id"]
    for tid, mt in (("TV-COMPILE", "Compile 0.3.7"), ("TV-M5", "M5: dashboard dòng 11 hiện mã quyền THUẬN/ĐẢO CHIỀU; tín hiệu SU-1 như 0.3.6"),
                    ("TV-M15-Y", "M15…Y: không lỗi, dashboard hiện, không có mã quyền (logicOn sai)"), ("TV-RELOAD", "Tải lại/realtime: quyền trên nến đã xác nhận không đổi")):
        C.ghi(tid, "TradingView", mt, "TRADINGVIEW", "bằng chứng TradingView", "chưa có", "BLOCKED", "—")
    C.ghi("SU3-SU4", "Ngoài phạm vi", "Quyền ĐẢO CHIỀU/SWEEP được dùng thật bởi setup SU-3/SU-4", "—", "—", "SU-3/SU-4 thuộc MD-8 (không triển khai lần này); f_permSwp chưa có nơi gọi", "NOT TESTED", "—")
    C.ghi("TV-EXNESS", "TradingView", "Exness thật / Profiler / CSV", "TRADINGVIEW", "—", "chưa có", "NOT TESTED", "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.7", sha=h7, dem=dem, token=tok, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "ket_qua_037.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "ket_qua_037.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem, tok, round(time.time() - t0), "s")
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0)


if __name__ == "__main__":
    main()
