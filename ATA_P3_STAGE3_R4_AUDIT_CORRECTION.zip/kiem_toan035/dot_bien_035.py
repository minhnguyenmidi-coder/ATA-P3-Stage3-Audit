# -*- coding: utf-8 -*-
"""Đối chứng âm: tiêm từng lỗi vào bản sao mã 0.3.5 (trong bộ nhớ, không ghi file), chạy test liên quan – mỗi đột biến PHẢI bị bắt.
python3 kiem_toan035/dot_bien_035.py → ket_qua035/dot_bien_035.json; mã thoát 1 nếu có đột biến sống sót."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C   # noqa: E402
import khung as K      # noqa: E402

GOC = C.S35
DB = [
    ("A07 lùi về loại p₀", "            int kMax = span                    // 0.3.5 A-07 PA1: nến p0 có chỉ số lịch sử span", "            int kMax = span - 1", ["t_a07_pine", "t_a07_tc"]),
    ("VOL CỰC dùng > thay ≥", "sH4.vr >= VOL_X", "sH4.vr > VOL_X", ["t_perm"]),
    ("Quyền (b) bỏ điều kiện thời điểm T_ĐC", "sM15.chT >= sH1.stT", "true", ["t_perm"]),
    ("Regime: ngưỡng ER 0,30 thành >", "e >= 0.30 ?", "e > 0.30 ?", ["t_reg_vi_sai", "t_reg_bien"]),
    ("Regime: cửa sổ TRANSITION 5 nến", "t >= 1 and t < 6", "t >= 1 and t < 5", ["t_reg_vi_sai", "t_reg_bien"]),
    ("Lọc hạng cụm > thay ≥", "if q >= mr and f_ge1Tick", "if q > mr and f_ge1Tick", ["t_lvpick", "t_s1_muc_tieu"]),
    ("S2b bỏ bậc hạng", "    if a.grade != b.grade\n        r := a.grade\n    else if a.su != b.su", "    if a.su != b.su", ["t_d8", "t_xep_hang_s2b"]),
    ("X-S tính cả BTC", "(isXAU and hr >= 14 and hr < 23 ? 1 : 0)", "(hr >= 14 and hr < 23 ? 1 : 0)", ["t_grade"]),
    ("Thứ tự lý do 15 trước 8", "            if not dataOK or incL or pm == 8 or not md4OK or not md5OK", "            if pm == 15\n                e.reason := 15\n                e.state := SS_SKIP\n            else if not dataOK or incL or pm == 8 or not md4OK or not md5OK", ["t_s1_muc_tieu"]),
    ("TP3 lấy cụm hạng 2", "cRank, 3, md4OK)", "cRank, 2, md4OK)", ["t_s1_muc_tieu"]),
    ("Pool sai phía (BUY dùng SSL)", "[tpP, rkP] = f_lvPick(d, fl, d == 1 ? plB : plS, d == 1 ? prB : prS, 0, md5OK)", "[tpP, rkP] = f_lvPick(d, fl, d == 1 ? plS : plB, d == 1 ? prS : prB, 0, md5OK)", ["t_s1_muc_tieu"]),
    ("Z-Q3 giải mã khe 1 sai", "math.floor(s.zDq / 2) % 2 == 1", "s.zDq % 2 == 1", ["t_zq3"]),
]


def dat(src):
    C.S35, C.L35 = src, src.split("\n")
    C.S1_35 = K.doan(src, "int nt = array.size(trigE)", "// ---- S2a", 4)


def main():
    out, song = [], []
    for ten, cu, moi, tests in DB:
        assert GOC.count(cu) >= 1, ten
        dat(GOC.replace(cu, moi))
        kq = {}
        for t in tests:
            try:
                ok, _ = getattr(C, t)()
            except Exception as e:      # noqa: BLE001
                ok = False
                _ = repr(e)
            kq[t] = "BẮT" if not ok else "SỐNG"
        bat = any(v == "BẮT" for v in kq.values())
        out.append(dict(dot_bien=ten, test=kq, ket_qua="BỊ BẮT" if bat else "SỐNG SÓT"))
        print(("BỊ BẮT  " if bat else "SỐNG    ") + ten, kq, flush=True)
        if not bat:
            song.append(ten)
    dat(GOC)
    ok_goc = all(getattr(C, t)()[0] for t in ("t_perm", "t_d8", "t_s1_muc_tieu"))
    json.dump(dict(dot_bien=out, song_sot=song, ma_goc_van_dat=ok_goc), open(os.path.join(C.OUT, "dot_bien_035.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{len(DB) - len(song)}/{len(DB)} đột biến bị bắt; mã gốc vẫn đạt: {ok_goc}")
    sys.exit(1 if song or not ok_goc else 0)


if __name__ == "__main__":
    main()
