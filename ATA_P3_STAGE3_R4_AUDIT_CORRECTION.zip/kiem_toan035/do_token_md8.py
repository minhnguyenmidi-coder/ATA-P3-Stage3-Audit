# -*- coding: utf-8 -*-
"""Cổng token trước MD-8 (không sửa mã). python3 kiem_toan035/do_token_md8.py → ket_qua038/cong_token_md8.json
1) Hiệu chỉnh tỷ lệ token biên dịch/từ vựng bằng điểm đo THẬT duy nhất (0.3.3: TradingView báo 101.360, CE10117).
2) Khoảng dư địa từ hai kết quả thật: 0.3.3 FAIL (vượt) và 0.3.7 PASS (chủ dự án xác nhận compile).
3) Chi phí đo được của các khối tương tự đang có (để ước lượng SU-3/4/5/6). 4) Mã thừa đo bằng do_ma_thua.py."""
import json, os, re, subprocess, sys
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(G, "ket_qua038"); os.makedirs(OUT, exist_ok=True)


def tok(s):
    return len(re.findall(r'"(?:[^"\\]|\\.)*"|[A-Za-z_][\w.]*|\d+\.?\d*(?:e-?\d+)?|:=|==|!=|<=|>=|=>|\S', "\n".join(re.sub(r"\s*//.*$", "", l) for l in s.split("\n"))))


def doc(p):
    return open(os.path.join(G, p), encoding="utf-8").read()


S33, S37 = doc("src033/ATA_P3_Build_0.3.3_Candidate_Indicator.pine"), doc("src037/ATA_P3_Build_0.3.7_Candidate_Indicator.pine")
L = S37.split("\n")
t33, t37 = tok(S33), tok(S37)
ty_le = 101360 / t33
gioi_han = 100256
uoc_37 = round(t37 * ty_le)
nguong_tu_vung = round(gioi_han / ty_le)


def doan(a, b):
    return tok("\n".join(L[a - 1:b]))


def dong(p):
    return next(i + 1 for i, l in enumerate(L) if re.search(p, l))


khoi = {
    "SU-1: P1…P5 (chạm vùng, ARMED, L*/H*, vô hiệu, trigger)": (dong(r"// ---- P1…P5"), dong(r"// ---- S1 cho từng setup") - 1),
    "SU-1: S1 (TP/SL/RR/quyền/hạng)": (dong(r"// ---- S1 cho từng setup"), dong(r"// ---- S2a") - 1),
    "SU-1: P7, P8": (dong(r"// ---- P7, P8"), dong(r"// ---- Phần riêng từng sổ") - 1),
    "SU-1: MD-3 phía biểu đồ (danh sách vùng, P0)": (dong(r"^// 8\. MD-3 PHÍA BIỂU ĐỒ"), dong(r"^// 9\. S1") - 2),
    "MD-7 + hạng (f_perm, f_permRev, f_permSwp, f_grade)": (dong(r"^f_perm\("), dong(r"^// 11d\. PIPELINE") - 2),
    "Bảng chẩn đoán MD-4/MD-5 (input iDiag45, mặc định TẮT)": (dong(r"^// ---- Bảng chẩn đoán MD-4 / MD-5"), dong(r"^if iShowDash and barstate\.islast") - 1),
    "Bảng chẩn đoán MTF (input iDiag, mặc định TẮT)": (dong(r"^// Bảng chẩn đoán MTF"), dong(r"^// 13\. DATA WINDOW") - 2),
    "Nhãn sự kiện cấu trúc (input iLblTF, mặc định Tắt)": (dong(r'^if iLblTF == "M15"') - 20, dong(r'^if iLblTF == "D"') + 1),
}
chi_phi = {k: dict(dong=f"{a}–{b}", tu_vung=doan(a, b)) for k, (a, b) in khoi.items()}
r = subprocess.run([sys.executable, os.path.join(G, "kiem_toan034a", "do_ma_thua.py"), os.path.join(G, "src037/ATA_P3_Build_0.3.7_Candidate_Indicator.pine"), os.path.join(OUT, "ma_thua_037.json")],
                   capture_output=True, text=True)
mt = json.load(open(os.path.join(OUT, "ma_thua_037.json"), encoding="utf-8"))
kq = dict(hieu_chinh=dict(t_0_3_3=t33, compiled_that_0_3_3=101360, ty_le=round(ty_le, 4)),
          baseline_0_3_7=dict(tu_vung=t37, uoc_compiled=uoc_37, compile_that="PASS (chủ dự án)"),
          du_dia=dict(nguong_tu_vung_uoc=nguong_tu_vung, du_dia_uoc_tu_vung=nguong_tu_vung - t37, du_dia_uoc_compiled=gioi_han - uoc_37,
                      can_tren_cung_tu_vung=t33 - t37, ghi_chu="Cận trên cứng: 0.3.3 (29.909 từ vựng) đã vượt; 0.3.7 (29.368) qua → dư địa ≤ 541 từ vựng nếu tỷ lệ đơn điệu"),
          chi_phi_khoi_dang_co=chi_phi,
          ma_thua=dict(ham_khong_goi=mt.get("khong_goi"), truong_khong_doc=mt.get("truong_khong_doc"), ghi_chu="Danh sách 'khong_doc' của công cụ có báo nhầm trường mặc định UDT; mã thừa thật ≈ 102 từ vựng (đo ở vòng 0.3.4a)"))
json.dump(kq, open(os.path.join(OUT, "cong_token_md8.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(kq, ensure_ascii=False, indent=1)[:3000])
