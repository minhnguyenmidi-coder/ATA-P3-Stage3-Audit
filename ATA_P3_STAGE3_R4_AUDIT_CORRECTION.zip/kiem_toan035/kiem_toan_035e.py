# -*- coding: utf-8 -*-
"""KIỂM TOÁN BUILD 0.3.5e (không sửa mã). python3 kiem_toan035/kiem_toan_035e.py → ket_qua035/kiem_toan_035e.{json,csv}
Tái sử dụng NGUYÊN bộ test 0.3.5 (nhóm A tĩnh, B, C, D) trên mã 0.3.5e + vài kiểm riêng cho thay đổi 0.3.5b–e (K-*).
Không thêm test trùng chức năng; test cũ FAIL do thay đổi đã duyệt được phân loại và liên kết test độc lập."""
import csv, hashlib, json, os, random, re, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chay_035 as C          # noqa: E402
import khung as K             # noqa: E402
import md2_tham_chieu as M2   # noqa: E402
import md6_tham_chieu as M6   # noqa: E402
import chay_035c               # noqa: E402
chay_035c.GIAY["12M"] = 31536000
from chay_035c import IpTF     # noqa: E402
from chay_035d import GIAY, KHUNG_BD, CTX   # noqa: E402

G = K.G
F35E = os.path.join(G, "src035e", "ATA_P3_Build_0.3.5e_Candidate_Indicator.pine")
SHA35E = "94604c08cfd688e29bdb759896f26549957f314a7576d0c993d4949e18ff6f99"
CHUOI = [("src034a/ATA_P3_Build_0.3.4a_Candidate_Indicator.pine", "073234cc6d9a5a9fbb81380f59b81482acdf1640484264ac0116909267f68605"),
         ("src035/ATA_P3_Build_0.3.5_Candidate_Indicator.pine", "9123ebb169eee08b41fb53db434891bb5ba5742fbc1b6e5c480a651726ef0e3e"),
         ("src035b/ATA_P3_Build_0.3.5b_Candidate_Indicator.pine", "beffef3a367b770551db1502c165366c31f14411fbea766403c4177e9a591a78"),
         ("src035c/ATA_P3_Build_0.3.5c_Candidate_Indicator.pine", "545d8766c60aeaa7fb6eb4d62377110f18fea95336166c7d8f71034281fa5c8b"),
         ("src035d/ATA_P3_Build_0.3.5d_Candidate_Indicator.pine", "b050d51adc56234edd2d853a5ec2f7f9dac78c38ae2f75f7bd4a24b56f2aba79"),
         ("src035e/ATA_P3_Build_0.3.5e_Candidate_Indicator.pine", SHA35E)]
S35E = K.doc(F35E)
L35E = S35E.split("\n")


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def dat_ma(src):
    C.S35, C.L35 = src, src.split("\n")
    C.S1_35 = K.doan(src, "int nt = array.size(trigE)", "// ---- S2a", 4)


def khoi_if_bao(i):
    """Dòng 'if …' cấp cao nhất (cột 0) bao dòng i (0-based); None nếu dòng ở cấp cao nhất."""
    if not L35E[i].startswith(" "):
        return None
    for k in range(i, -1, -1):
        l = L35E[k]
        if l and not l[0].isspace() and not l.startswith("//"):
            return l if l.startswith("if ") else None
    return None


# ---------------------------------------------------------------- K: kiểm riêng thay đổi 0.3.5b–e
def k_chuoi_sha():
    kq = [(p, sha(os.path.join(G, p)) == h) for p, h in CHUOI]
    lai = []
    for scr, dst, h in (("dung_build_035b.py", CHUOI[2][0], CHUOI[2][1]), ("dung_build_035c.py", CHUOI[3][0], CHUOI[3][1]),
                        ("dung_build_035d.py", CHUOI[4][0], CHUOI[4][1]), ("dung_build_035e.py", CHUOI[5][0], CHUOI[5][1])):
        r = subprocess.run([sys.executable, os.path.join(G, "tools033", scr)], cwd=G, capture_output=True, text=True)
        lai.append((scr, r.returncode == 0 and sha(os.path.join(G, dst)) == h))
    return all(x[1] for x in kq) and all(x[1] for x in lai), f"SHA {kq}; dựng lại từ script {lai}"


def k_ma_tran_khung():
    """Chạy nguyên văn f_avail, f_tfReq và 5 hằng simple int trên 8 khung; suy ra avX (khung dùng) – không có khung nào xin dữ liệu nhỏ hơn biểu đồ."""
    blk = [l.replace("simple int ", "int ") for l in L35E if l.startswith("simple int C")]
    bang, sai = {}, []
    for p in KHUNG_BD:
        ip = IpTF()
        ip.g.update(chartSec=GIAY[p], **{"timeframe.period": p})
        for f in ("f_avail", "f_tfReq"):
            Lf, b = K.khoi(S35E, f)
            ip.load(K.PM.parse_program(Lf, b))
        K.chay_dong(ip, blk, 1)
        row = {}
        for tf, cb in zip(CTX, ("CB15", "CB60", "CB4H", "CBD")):
            q, n, av = ip.call_user("f_tfReq", [tf]), ip.g[cb], ip.call_user("f_avail", [tf])
            row[tf] = (q, n, "DÙNG" if av else "KHÔNG DÙNG")
            if GIAY[q] < GIAY[p]:
                sai.append((p, tf, "xin khung nhỏ hơn biểu đồ"))
            if av and q != tf:
                sai.append((p, tf, "khung dùng bị đổi"))
            if GIAY[p] <= 900 and n != 100000:
                sai.append((p, tf, "M5/M15 bị giới hạn"))
        bang[p] = row
    ok = not sai and all(v[2] == "DÙNG" for v in bang["5"].values()) and all(v[2] == "KHÔNG DÙNG" for p in ("D", "W", "M", "12M") for v in bang[p].values())
    return ok, (bang, sai)


def k_khong_gia_tri_gia():
    """Khung không dùng (D/W/M/Y; M15/H1 trên H1/H4): f_stTxt nguyên văn trả 'KHÔNG KHẢ DỤNG' dù đối tượng có warm/ready = true (không thể tạo trạng thái hợp lệ giả)."""
    ip = K.may(S35E, ("f_stTxt",), ("StructOut",))
    sai = []
    for warm in (True, False):
        for ready in (True, False):
            s = K.obj(ip, "StructOut", warm=warm, ready=ready, st=1, integ=0)
            av = False      # f_avail(tf) = false ⇒ avX = false bất kể s.warm (dòng 1042–1045)
            r = K.goi(ip, "f_stTxt", av, av and ready, s)
            if r != "KHÔNG KHẢ DỤNG":
                sai.append((warm, ready, r))
    # chuỗi suy ra: avX = f_avail(..) and sX.warm; okX = avX and sX.ready; runBar cần logicOn = isM5 → mọi nhánh giao dịch tắt
    dong = {k: next((i + 1 for i, l in enumerate(L35E) if l.startswith(k)), None) for k in ("bool avM15 = f_avail(\"15\")  and sM15.warm", "bool okM15 = avM15 and sM15.ready",
                                                                                         "bool logicOn = isM5 and chartOK", "bool runBar = logicOn and symOK and barstate.isconfirmed")}
    reg = "(okH4 ? array.get(array.from(" in S35E and 'plot(runBar and okH4 ?' in S35E
    return not sai and all(dong.values()) and reg, f"f_stTxt sai {sai}; dòng điều kiện {dong}; regime dashboard/Data Window chặn bởi okH4/runBar: {reg}"


def k_chan_tin_hieu():
    """Mọi chỗ tạo tín hiệu/ghi sổ/nhãn SU-1 nằm trong khối 'if runBar…' (runBar cần isM5) → M15…Y không thể có tín hiệu."""
    muc = []
    for pat in (r"f_newEv\(", r"array\.push\(trigE", r'"SU-1 " \+ \(w\.dir', r"f_ledger\(", r"LE\.lastX"):
        for i, l in enumerate(L35E):
            if re.search(pat, l) and not l.lstrip().startswith("//") and not re.match(r"^f_\w+\(", l):
                bao = khoi_if_bao(i)
                in_fn = bao is None and l.startswith(" ") and any(L35E[k].startswith("f_") for k in range(i, max(i - 400, 0), -1) if L35E[k] and not L35E[k][0].isspace())
                muc.append((pat, i + 1, (bao or "")[:40], in_fn))
    ngoai = [m for m in muc if not m[2].startswith("if runBar") and not m[3]]
    return bool(muc) and not ngoai, f"{len(muc)} vị trí; ngoài khối runBar (và không trong thân hàm): {ngoai}"


def k_hoi_tu_2000():
    """Giới hạn 2000 nến trên H1/H4 (MÔ HÌNH MD-2 → MD-6): so cấu trúc tính trên 2000 nến cuối với tính trên toàn lịch sử – sau một đoạn khởi động, ST/PROT/REG phải trùng.
    Đo đoạn khởi động và tỷ lệ trùng ở 1000 nến cuối (phần hiển thị)."""
    out = []
    for seed in (1, 2, 3, 4, 5, 6):
        R = random.Random(seed)
        n = 6000
        C_ = [2000.0]
        for i in range(n - 1):
            C_.append(round(C_[-1] + R.gauss(0.15 * (1 if (i // 700) % 2 else -1), 2.0), 2))
        H = [c + abs(R.gauss(0, 1.2)) for c in C_]; Lw = [c - abs(R.gauss(0, 1.2)) for c in C_]
        mF, eF = M2.chay(H, Lw, C_, N=3, a07="gom_p0")
        w0 = n - 2000
        Hw, Lww, Cw = H[w0:], Lw[w0:], C_[w0:]
        mW, eW = M2.chay(Hw, Lww, Cw, N=3, a07="gom_p0")
        rF = [x[0] for x in M6.chay(mF.st_log, eF, C_, M6.atr_wilder(H, Lw, C_))][w0:]
        rW = [x[0] for x in M6.chay(mW.st_log, eW, Cw, M6.atr_wilder(Hw, Lww, Cw))]
        stF = mF.st_log[w0:]
        lech = [i for i in range(2000) if stF[i] != mW.st_log[i] or rF[i] != rW[i]]
        khoi = (max(lech) + 1) if lech else 0
        cuoi = sum(1 for i in range(1000, 2000) if stF[i] == mW.st_log[i] and rF[i] == rW[i]) / 1000
        out.append((seed, khoi, cuoi))
    ok = all(c == 1.0 for _, _, c in out)
    return ok, f"(hạt giống, nến khởi động cuối cùng còn lệch, tỷ lệ trùng ST+REG ở 1000 nến cuối): {out}"


def k_m5_tuong_duong():
    """M5: thay CBx bằng 100000 và f_tfReq("x") bằng "x" (giá trị trên M5 – K-02) → mã 0.3.5e so với 0.3.5b chỉ khác chú thích, khai báo hằng/hàm phụ và tham số calc_bars_count."""
    b = K.doc(os.path.join(G, CHUOI[2][0]))
    e = re.sub(r'f_tfReq\("(\w+)"\)', r'"\1"', S35E)
    e = re.sub(r", calc_bars_count = CB\w+\)", ")", e)
    import difflib
    d = [l for l in difflib.unified_diff(b.split("\n"), e.split("\n"), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
    con = [l for l in d if not (l[1:].startswith("//") or l.startswith("+simple int C") or l.startswith("+f_tfReq(") or "f_avail(tf) ? tf : timeframe.period" in l
                                or re.search(r"0\.3\.5[be] Candidate", l))]
    return not con, f"{len(d)} dòng khác; dòng khác ngoài nhóm cho phép: {con}"


def main():
    t0 = time.time()
    assert sha(F35E) == SHA35E
    dat_ma(S35E)
    # Nhóm A cũ (tĩnh) chạy lại trên 0.3.5e: A-01 kiểm tái lập 0.3.5 (vẫn hợp lệ), A-02 kỳ vọng diff của 0.3.5 → sẽ khác (đổi có chủ đích)
    C.nhom_a()
    for r in C.KQ:
        r["id"] = "A35." + r["id"]
    an = C.an_toan
    T = [("t_reg_vi_sai", "MD-6 C.2"), ("t_reg_bien", "MD-6 C.2"), ("t_vol", "MD-6 C.3"), ("t_perm", "I-1 I.3"), ("t_lvpick", "I-4/I-6"), ("t_grade", "I-3"), ("t_d8", "I-3 S2b"),
         ("t_a07_pine", "A-07"), ("t_a07_tc", "A-07"), ("t_a07_tac_dong", "A-07 PROT/CHoCH/ST/REG"), ("t_zq3", "I-3 Z-Q3"), ("t_s1_hoi_quy", "S1 vi sai 0.3.4a"),
         ("t_s1_muc_tieu", "S1 kịch bản"), ("t_chuoi_md6_md7_s1", "MD-6→MD-7→S1"), ("t_xep_hang_s2b", "S2b"), ("t_data_window", "I-5"), ("t_hien_thi_canh_bao", "hiển thị"),
         ("t_md5_song_song", "MD-5 vi sai 0.3.4a")]
    for t, nh in T:
        an("B35." + t, "B/C (bộ 0.3.5) · " + nh, "Chạy lại " + t + " trên mã 0.3.5e", "THÔNG DỊCH/THAM CHIẾU", "như 0.3.5", "chay_035.py::" + t, getattr(C, t))
    K_ = [("K-01", "Chuỗi SHA 0.3.4a → 0.3.5 → b → c → d → e nguyên vẹn; mỗi bước dựng lại từ script ra đúng SHA", "TĨNH", k_chuoi_sha),
          ("K-02", "Ma trận 8 khung (chạy nguyên văn f_avail/f_tfReq/CB*): khung xin, số nến, khung dùng/không dùng; không xin khung nhỏ hơn biểu đồ; M5/M15 không bị giới hạn", "THÔNG DỊCH", k_ma_tran_khung),
          ("K-03", "Khung không dùng không tạo trạng thái hợp lệ giả (f_stTxt nguyên văn, chuỗi avX/okX/logicOn/runBar)", "THÔNG DỊCH + TĨNH", k_khong_gia_tri_gia),
          ("K-04", "Mọi chỗ tạo tín hiệu/sổ/nhãn SU-1 nằm trong khối runBar (cần M5) → M15…Y không có tín hiệu", "TĨNH", k_chan_tin_hieu),
          ("K-05", "Giới hạn 2000 nến (H1/H4): cấu trúc ST và REG trên 2000 nến cuối trùng tính toàn lịch sử ở phần hiển thị (MÔ HÌNH MD-2/MD-6)", "MÔ HÌNH", k_hoi_tu_2000),
          ("K-06", "M5: 0.3.5e tương đương ký hiệu với 0.3.5b (bản đã có xác nhận M5 trên TradingView) ngoài tham số calc_bars_count", "TĨNH (thay thế ký hiệu)", k_m5_tuong_duong)]
    for tid, mt, pp, fn in K_:
        an(tid, "K · thay đổi 0.3.5b–e", mt, pp, "đúng", "kiem_toan_035e.py::" + fn.__name__, fn)
    # D: hồi quy cũ, vòng đời, cổng tiền, đột biến
    p = os.path.join(G, "hoi_quy034")
    r = subprocess.run([sys.executable, "tests/chay_test.py", "--target", "035e"], cwd=p, capture_output=True, text=True, timeout=900)
    d = json.load(open(os.path.join(p, "results", "ket_qua_test_035e.json"), encoding="utf-8"))
    rows = d if isinstance(d, list) else next(v for v in d.values() if isinstance(v, list))
    fail = sorted(x["id"] for x in rows if x["trang_thai"] == "FAIL")
    dem = {}
    for x in rows:
        dem[x["trang_thai"]] = dem.get(x["trang_thai"], 0) + 1
    ok = set(fail) == set(C.KY_VONG_HQ)
    C.ghi("D-01e", "D · hồi quy cũ", "hoi_quy034 trên 0.3.5e (KHÔNG sửa assertion; chỉ thêm đích '035e'): FAIL đúng bằng 6 test đổi có chủ đích như ở 0.3.5", "HỒI QUY",
          "FAIL = {ST-01, ST-06, ST-08, ST-09, ST-12, UD-01}", f"{dem}; mã thoát gốc {r.returncode}; FAIL {fail}; liên kết {C.KY_VONG_HQ}", "PASS" if ok else "FAIL",
          "hoi_quy034/results/ket_qua_test_035e.json")
    an("D-02e", "D · hồi quy", "Vòng đời MD-5 (2.054 bước) vẫn 0 FAIL", "HỒI QUY", "0 FAIL", "ket_qua034a_nt/vong_doi.json", C.t_vong_doi)
    r = subprocess.run([sys.executable, "cong_tien_md6/chay_cong_tien.py", "--nhanh"], cwd=G, capture_output=True, text=True, timeout=1200)
    d = json.load(open(os.path.join(G, "cong_tien_md6", "ket_qua", "KET_QUA_KIEM_THU.json"), encoding="utf-8"))
    rows = d if isinstance(d, list) else next(v for v in d.values() if isinstance(v, list))
    dem = {}
    for x in rows:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    C.ghi("D-03e", "D · hồi quy", "Bộ cổng tiền MD-6 (mô hình MD-2/MD-6, baseline 0.3.4a) vẫn 0 FAIL", "HỒI QUY", "0 FAIL", f"{dem}; mã thoát {r.returncode}", "PASS" if not dem.get("FAIL") else "FAIL",
          "cong_tien_md6/ket_qua/KET_QUA_KIEM_THU.json")
    import dot_bien_035 as DB
    DB.GOC = S35E
    song = []
    for ten, cu, moi, tests in DB.DB:
        dat_ma(S35E.replace(cu, moi))
        bat = False
        for t in tests:
            try:
                bat = bat or not getattr(C, t)()[0]
            except Exception:       # noqa: BLE001
                bat = True
        if not bat:
            song.append(ten)
    dat_ma(S35E)
    C.ghi("D-04e", "D · đối chứng âm", "12 đột biến tiêm vào bản sao 0.3.5e đều bị bắt", "ĐỘT BIẾN", "12/12", f"sống sót: {song}", "PASS" if not song else "FAIL", "dot_bien_035.py (danh sách)")
    # TradingView: bằng chứng do chủ dự án xác nhận (không có phiên quan sát trực tiếp)
    TV = [("TV-COMPILE", "Compile 0.3.5e", "PASS", "Chủ dự án xác nhận bằng lời (19/11): compile thành công. Claude không quan sát trực tiếp."),
          ("TV-H4", "H4: chỉ báo + dashboard hiển thị, không RE10139", "PASS", "Chủ dự án xác nhận bằng lời (19/11). Không có ảnh của 0.3.5e."),
          ("TV-KHUNG-LON", "Khung lớn (chung): chỉ báo xuất hiện", "PASS", "Chủ dự án xác nhận chung 'khi chuyển sang khung lớn chỉ báo xuất hiện' – không tách từng khung H1/D/W/M/Y"),
          ("TV-M5", "M5 sau 0.3.5e: runtime, dashboard, Data Window, tín hiệu", "BLOCKED", "Chưa có xác nhận trên 0.3.5e. Bằng chứng M5 có trên 0.3.5b; K-06 chứng minh tương đương ký hiệu nhưng hành vi calc_bars_count = 100000 trên TradingView là GIẢ ĐỊNH"),
          ("TV-M15", "M15: hiển thị, tín hiệu tắt", "BLOCKED", "Chưa có xác nhận riêng"),
          ("TV-H1", "H1", "BLOCKED", "Chưa có xác nhận riêng"), ("TV-D", "D", "BLOCKED", "Chưa có xác nhận riêng"), ("TV-W", "W", "BLOCKED", "Chưa có xác nhận riêng"),
          ("TV-M", "M", "BLOCKED", "Chưa có xác nhận riêng"), ("TV-Y", "12M", "BLOCKED", "Chưa có xác nhận riêng"),
          ("TV-REPLAY-M5", "Tải lại/realtime/Bar Replay trên M5 với 0.3.5e", "BLOCKED", "Đã xác nhận trên 0.3.5b (lời chủ dự án); chưa trên 0.3.5e"),
          ("TV-EXNESS", "Dữ liệu Exness thật (XAU/BTC M5)", "NOT TESTED", "Mọi ảnh dùng OANDA/Bitstamp"),
          ("TV-PROFILER-CSV", "Profiler / CSV thật", "BLOCKED", "Chưa có dữ liệu")]
    for tid, mt, kq, ly in TV:
        C.ghi(tid, "TradingView", mt, "TRADINGVIEW (xác nhận của chủ dự án)" if kq == "PASS" else "TRADINGVIEW", "bằng chứng TradingView", ly, kq, "—")
    dem = {}
    for x in C.KQ:
        dem[x["ket_qua"]] = dem.get(x["ket_qua"], 0) + 1
    out = os.path.join(G, "ket_qua035")
    json.dump(dict(tom_tat=dict(build="0.3.5e", sha=SHA35E, dem=dem, giay=round(time.time() - t0, 1)), ket_qua=C.KQ), open(os.path.join(out, "kiem_toan_035e.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)
    with open(os.path.join(out, "kiem_toan_035e.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(C.KQ[0].keys())); w.writeheader(); w.writerows(C.KQ)
    print(dem, round(time.time() - t0), "s")
    sys.exit(1 if dem.get("FAIL") else 2 if dem.get("BLOCKED") or dem.get("NOT TESTED") else 0)


if __name__ == "__main__":
    main()
