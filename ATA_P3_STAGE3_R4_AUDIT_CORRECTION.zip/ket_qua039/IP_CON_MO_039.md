# Danh sách điểm mở sau Build 0.3.9

Tất cả đều ở trạng thái **OPEN – chờ chủ dự án quyết**. Build 0.3.9 không đóng IP nào.

## A. Giữ nguyên từ trước (không đụng)

| Mã | Nội dung tóm tắt | Phạm vi ảnh hưởng |
|---|---|---|
| IP-4 | VOL-CỰC: WAIT hay lý do 15 | SU-3/SU-5 dùng lại `f_permRev`/`f_perm` hiện có, nên khi VOL-CỰC sẽ ra lý do 15, như SU-1/SU-4 |
| IP-11…IP-14 | Quyền SU-4 khi H4 RANGE | Không liên quan SU-3/SU-5 |
| IP-15 | EV ở đường bắt kịp không tạo SU-4 | Không đổi |
| IP-16 | SU-6 chọn mức nào và dùng trạng thái cụm nào | Không đổi |
| IP-17 | "Ưu tiên pool BSL" | Không đổi |
| IP-18 | SU-4 dùng chung `iSlBufK`/`iVoidK` | Không đổi; xem thêm IP-27 |
| OP-1 / OP-2 / OP-3 | Vô hiệu M5 tại nến a của SU-4 / hệ quả IP-15 / tiêu đề input `iSlBufK` | Không đổi |
| IP-1…IP-10, Q2/D16, Q4/D14–D19 | — | Không đổi |

## B. Mới phát sinh khi triển khai 0.3.9

| Mã | Mục đặc tả | Vấn đề | Cách 0.3.9 xử lý | Trạng thái |
|---|---|---|---|---|
| **IP-19** | J.2 bước 1; F.3; F.4 | "Cụm MD-4 hạng ≥ 3 có ít nhất một mức HỖ TRỢ" và điều kiện vô hiệu "cụm bị vô hiệu/FLIPPED xuống". Cụm được gom lại ở mỗi nến H1 và trạng thái F.4 lưu theo từng MỨC, nhưng đặc tả không định nghĩa danh tính một cụm qua các lần gom | **Không triển khai nhánh cụm.** Nhánh vùng H1 hoạt động bình thường | **BLOCKED** |
| IP-20 | J.2 bước 3 | Tại t2 không có vùng M15 nào thỏa t1 < j ≤ t2 | Thể hiện kết thúc, không ghi sự kiện (không có mã lý do phù hợp) | Diễn giải |
| IP-21 | J.2 bước 1 | Mỗi nến M15 giao cắt vùng H1 tạo một thể hiện. Đặc tả không có quy tắc khử trùng | Theo đúng chữ đặc tả: nhiều thể hiện song song, có thể ARMED trùng một vùng | Diễn giải; có rủi ro hiệu năng |
| IP-22 | K.5 | Ô nhập chế độ ACTIONABLE / SHADOW / TẮT cho từng setup | Chưa có: chỉ thị cấm thêm input và cố định bảng trạng thái; ngoài ra còn ràng buộc token. SU-3/SU-5 cố định SHADOW | Chờ quyết |
| IP-23 | I.5; J.4 | I.5 yêu cầu C-1, C-2 cho SU-5 nhưng J.4 không định nghĩa hai điều kiện này | Không tính hạng ở chế độ SHADOW (K.5 chỉ cần P_ref/SL/TP1) | **BLOCKED** (hạng SU-5) |
| IP-24 | J.4.1/J.4.2 | "BOS↑/BOS↓ M15" và "BOS↓ phá Lv" | Chỉ sự kiện BOS (không gồm CHoCH). Vô hiệu khi có BOS ngược chiều với Close vượt qua Lv | Diễn giải |
| IP-25 | J.4.3 | "Mức Lv không tạo SU-5 mới" | Ghi nhớ giá chính xác của Lv (có dấu theo chiều) suốt lịch sử | Diễn giải |
| IP-26 | J.2 bước 4; E.2 | "Lần chạm đầu tiên" | Theo E.2: lần chạm làm số lần chạm của vùng đi từ 0 lên 1. Nếu lần chạm đó xảy ra trước t2 hoặc là gap, SU-3 không ARMED và sẽ hết hạn | Diễn giải |
| IP-27 | J.0; J.2; J.4 | Hệ số đệm SL {0,2} và {0,5}A | Dùng `iSlBufK` cho cả ATR_M5 và ATR_M15; hệ số 0,5 của SU-5 cố định trong mã | Diễn giải (liên quan IP-18) |
| IP-28 | K.5 | Vị trí sự kiện SHADOW trong ô Data Window | Chỉ điền ô còn trống sau các sự kiện actionable; "tràn" chỉ đếm actionable | Diễn giải |
| IP-29 | J.4 bước 1 | Khi MD-4 chưa khả dụng thì không xác định được ứng viên cụm | Không tạo SU-5 | Diễn giải |
| IP-30 | J.2; K.5 (3) | Thời điểm phát hiện vùng H1 bị gỡ; cách tính LIVE | Phát hiện ở lần nhận M15/H1 kế tiếp; LIVE dùng H*/L* của nến đã đóng gần nhất | Diễn giải |
| **TK-1** | Ngân sách token | Ước lượng 0.3.9 vượt ngưỡng compile | PA-1…PA-5 trong báo cáo, mục 11 | **Chặn nghiệm thu** |
