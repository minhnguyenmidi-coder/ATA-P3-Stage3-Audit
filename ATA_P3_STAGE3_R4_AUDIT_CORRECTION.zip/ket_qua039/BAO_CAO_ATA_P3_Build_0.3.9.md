# ATA P3 · Build 0.3.9 · SU-3 / SU-5 chế độ SHADOW – Báo cáo tổng hợp

## 1. Tóm tắt kết quả

**Kết luận nghiệm thu: BLOCKED.** Chi tiết căn cứ ở mục 18.

**Đã làm:**
- Đã tạo Build 0.3.9 thật, có code chạy được, từ baseline 0.3.8 (SHA khớp).
- SU-3 (J.2) và SU-5 (J.4) được triển khai ở chế độ SHADOW (K.5).
- 0.3.9 chỉ THÊM mã. Bỏ các khối thêm và trả 5 dòng thông tin phiên bản về như cũ thì thu lại đúng 0.3.8 từng ký tự.

**Kết quả kiểm thử:**
- **Bộ kiểm 0.3.9:** 47 PASS · 1 FAIL · 7 BLOCKED · 1 NOT TESTED.
- **FAIL duy nhất** là ngân sách token (T-01, ước lượng). Đây là FAIL thật về nguy cơ không compile được, không phải lỗi logic.
- **Bộ hồi quy 0.3.8 chạy lại trên 0.3.9:** 67 PASS · 9 FAIL · 5 BLOCKED · 1 NOT TESTED. So với chính bộ đó trên 0.3.8, chỉ 4 ID đổi kết quả, và cả 4 đều đã giải thích.
- **Cô lập SHADOW:** chứng minh bằng 3 lớp bằng chứng độc lập:
  - lớp tĩnh;
  - chụp toàn bộ trạng thái khi chạy;
  - vi sai 0.3.8 ↔ 0.3.9 trên 400 kịch bản × 36 nến.
  
  Kết quả: 0 khác biệt ở mọi đầu ra actionable.
- **Đột biến:** 42 đột biến. 41 bị bắt; 1 sống sót là đột biến tương đương, có chứng minh.

**Lỗi tự phát hiện và đã sửa trong lúc làm:** test bắt được 2 lỗi thật trong mã SHADOW mới viết, cả hai đã sửa và chạy lại toàn bộ. Không lỗi nào lọt vào actionable.
1. Nhánh ARMED của SU-3 bị gắn nhầm vào `else` của khối tra vùng, nên SU-3 không bao giờ ARMED.
2. Bộ đếm 24 nến M5 sau ARMED dùng chung biến với bộ đếm bước trước, nên SU-3 hết hạn sớm 1 nến. Đã tách thành biến riêng `k5`.

**Rủi ro chặn nghiệm thu: token.**
- 0.3.9 có 30.226 token từ vựng, ước lượng ≈ 102.434 token biên dịch, vượt giới hạn 100.256.
- Con số này còn lớn hơn 0.3.3 (29.909 token từ vựng), bản đã bị TradingView báo CE10117 (vượt giới hạn token).
- Tôi **không tự cắt logic và không tự sửa phần baseline** để giảm token, đúng mục 6 của chỉ thị. Các phương án có số đo nằm ở mục 11.

## 2. Baseline hash

| | |
|---|---|
| File | `src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine` |
| SHA-256 | `79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13` |
| Kết quả kiểm | Khớp (V-01). Không đổi sau toàn bộ kiểm thử (V-04). |

## 3. Build 0.3.9 hash

| | |
|---|---|
| File | `ATA_P3_Build_0.3.9_Candidate_Indicator.pine` |
| SHA-256 | `2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0` |
| Tái lập | `python3 tools033/dung_build_039.py` (khóa SHA đầu vào 0.3.8) cho cùng SHA (V-02) |

## 4. Phạm vi code thay đổi

Diff `DIFF_038_039.patch`: thêm 198 dòng, sửa 5 dòng, không xóa dòng nào.

**6 khối chèn:**

| # | Khối | Vị trí trong 0.3.9 | Token từ vựng |
|---|---|---|---|
| 1 | Kiểu SH, biến `sh`/`s5L`/`shTxt`/`evS`; hàm `f_zS`, `f_evS`, `f_shT`, `f_shEnd` | 1868–1907 | 240 |
| 2 | Khối tiền-kích hoạt M15/H1 (B.2.2 bước 2, đặt trước MD-4) | 2808–2866 | 506 |
| 3 | `f_shS1` – S1 riêng của SHADOW | 3157–3172 | 244 |
| 4 | Khối M5 SHADOW: chạm/rời/retest, ARMED, P4, L*/H*, trigger, S1, hết hạn. Đặt **sau** sổ (f_ledger) | 3526–3601 | 795 |
| 5 | Ô Data Window còn trống nhận sự kiện SHADOW | 3624–3626 | 17 |
| 6 | Dòng dashboard "SHADOW (không giao dịch)", gồm trạng thái LIVE | 3769–3774 | 55 |

**5 dòng sửa:** tiêu đề, `indicator(...)`, META_VER 308 → 309, chữ phiên bản ở dòng 0 dashboard, và số hàng bảng dashboard 15 → 16.

**Bằng chứng không sửa gì khác (I-01, I-02, C-04):**
- Mọi hàm của 0.3.8 trùng từng ký tự trong 0.3.9.
- Các khối sau cũng trùng từng ký tự: SU-1 (P1…P5, S1), SU-4, S2a, P7/P8 và sổ X-0…X-4, `f_ledger`, ARMED SU-4 + SU-6, MD-5, MD-4, mainEv/nhãn, 56 plot Data Window, 8 lệnh `request.security`.
- Không thêm input, plot, alert, label, box, line, `ta.*` hay `request.*` nào.

## 5. Kiến trúc SU-3 (J.2)

| Bước | Thực hiện | Vị trí |
|---|---|---|
| 1 – CHẠM MỨC | Nến M15 đã đóng giao cắt (E.2) vùng Demand/Supply H1 hợp lệ. Khi đó khóa MỐC = Low/High[t1]; RUNNING = MỐC; k = 1 nếu cùng lúc có nến H1 đóng. **Nhánh cụm MD-4 hạng ≥ 3: BLOCKED (IP-19), không triển khai** (C-05, C-06) | Khối tiền-kích hoạt |
| 2 – MSS H1 | RUNNING = min Low M15 trong (t1, t2], gồm cả nến cuối kỳ H1 chứa t2. Bước 2 đạt khi có MSS H1 theo D.3 (a) (CHoCH cùng chiều + cờ `mssA`) tại t2 > t1, trong nến H1 thứ 1…24. Tại t2 khóa FINAL và ATR_M15(t2) | Khối tiền-kích hoạt |
| 3 – VÙNG MỚI | Vùng M15 cùng chiều có t1 < j ≤ t2, lấy j muộn nhất; bằng nhau thì lấy vùng có base muộn hơn. j = thời điểm **đóng** nến BOS = bosMin + 15. Bước này chạy ở khối M5 (sau P0), nên vùng hình thành đúng tại t2 vẫn được tính | Khối M5 |
| 4 – CHẠM VÙNG | Lần chạm đầu tiên của vùng (P1 của SU-1 ghi `touches` 0 → 1 trên nến này), không gap, nến mở ≥ t2 → ARMED. SHADOW **chỉ đọc** vùng, không ghi | Khối M5 |
| 5 – TRIGGER | L*/H* theo Phase 1.5 (b là nến sớm nhất); H* = High lớn nhất của b−1…b−3. Trigger khi Close > H* và nến tăng; không trigger khi khung lớn đang chờ dữ liệu. SL = min(L* − 0,2×ATR_M5, ĐÁY_1_FINAL − 0,2×ATR_M15(t2)). Quyền I.3 lớp ĐẢO CHIỀU (`f_permRev`) | Khối M5 + `f_shS1` |

**Vô hiệu và hết hạn:**

| Giai đoạn | Vô hiệu | Hết hạn |
|---|---|---|
| Trước bước 2 | Close H1 qua MỐC; vùng H1 bị gỡ | 24 nến H1 |
| Trước bước 4 | Vùng bước 3 bị gỡ | 48 nến M15 kể từ t3 |
| Sau ARMED | P4 vô hiệu (5); vùng bị gỡ (6) | 24 nến M5 |

SELL đối xứng (S3-15). Mỗi thể hiện chỉ ARMED một lần và bị gỡ khi kết thúc.

## 6. Kiến trúc SU-5 (J.4)

| Bước | Thực hiện |
|---|---|
| 1 – BREAKOUT | Có BOS M15 tại j (sự kiện BOS, không phải CHoCH). Lv = REF, hoặc cạnh cụm MD-4 hạng ≥ 2 thỏa Close[j−1] ≤ U < Close[j]. Ưu tiên cụm; giữa các cụm ưu tiên hạng cao, bằng hạng thì cạnh xa hơn. A = ATR_M15(j). Cụm lấy như cuối nến trước, vì khối này chạy trước MD-4 theo B.2.2 |
| 2 – RỜI MỨC | Nến M5 mở ≥ T_j có Close ≥ Lv + 0,5A |
| 3 – RETEST | Nến M5 **đầu tiên** sau bước 2 giao cắt dải Lv ± 0,25A. Open không gap → ARMED. Gap → kết thúc, lý do 4 (J.4.3) |
| 4 – TRIGGER | L* = Low nhỏ nhất từ a, chỉ cập nhật khi nhỏ hơn nghiêm ngặt. H* = High lớn nhất của các nến b−1…b−3 **có thời điểm mở ≥ T_j**; không có nến nào thì H* = High[b]. SL = min(L* − 0,2×ATR_M5, Lv − 0,5A). Quyền lớp THUẬN (`f_perm`, như SU-1) |

**Vô hiệu neo:**
- Close M15 < Lv − 0,25A trong các nến j+1…j+24;
- hoặc có BOS ngược chiều đóng qua Lv.

**Vô hiệu setup:** Close M5 < (Lv − 0,25A) − 0,1×ATR_M5.

**Hết hạn:** chưa retest tới nến M15 j+24; hoặc 24 nến M5 sau ARMED (bộ đếm `k5` riêng).

**J.4.3:** Lv của mọi SU-5 đã kết thúc được ghi nhớ và không tạo SU-5 mới.

**S1 SHADOW** (`f_shS1`, dùng chung cho SU-3 và SU-5): tính P_ref, SL, TP1 (ứng viên theo I-4) và R:R. Thứ tự lý do 8 > 15 > 14 > 9 > 1 > 2 > 16. Khi đạt thì trạng thái 17, lý do 16 "SHADOW – KHÔNG GIAO DỊCH". Không đếm vào lỗi 14, không vào S2a.

## 7. Shadow isolation

| Test | Phương pháp | Nội dung | Kết quả |
|---|---|---|---|
| I-01 | Tĩnh | Dựng lại 0.3.8 từ 0.3.9: trùng từng ký tự; 5 dòng sửa đều là thông tin phiên bản | PASS |
| I-02 | Tĩnh | Mọi hàm và khối actionable trùng từng ký tự | PASS |
| I-03 | Tĩnh | Tập ghi của toàn bộ mã chèn: chỉ biến cục bộ, `shTxt`, trường `x.*`/`e.*` của chính SHADOW, các mảng `sh`/`s5L`/`evS` và đúng 1 lệnh thêm vào ô Data Window còn trống. Không alert, label, plot, sổ, `request` hay `input` | PASS |
| I-04 | Chạy nguyên văn | 300 kịch bản × 36 nến, có trạng thái actionable giả lập đầy đủ. Chụp **sâu** toàn bộ biến toàn cục (mọi mảng, mọi đối tượng, mọi trường) trước và sau từng nến: chỉ biến SHADOW thay đổi, kể cả mọi trường của vùng MD-3 mà SU-1 dùng. Có 1.525 sự kiện SHADOW phát sinh | PASS |
| I-06 | Vi sai | 400 kịch bản × 36 nến = 14.400 nến, cùng dữ liệu và trạng thái ban đầu. Chạy nguyên văn ARMED SU-4 + SU-6 → SU-1 P1…P5 + S1 → SU-4 → S2a → (SHADOW, chỉ 0.3.9) → ô Data Window/mainEv/portSlot/cnt14. Đầu ra actionable của 0.3.8 và 0.3.9 trùng ở **mọi nến**. Có 2.494 sự kiện SHADOW, 29 lần ĐẠT, 13 nến SHADOW trigger cùng lúc với SU-1/SU-4, 1.971 ô trống được điền đúng sau sự kiện actionable, tối đa 25 thể hiện cùng tồn tại | PASS |
| I-07 | Suy ra | Sổ, SL/TP quản lý lệnh: mã trùng 0.3.8 và chạy trước SHADOW; đầu vào sổ trùng ở từng nến; SHADOW không ghi biến sổ | PASS |

Các đầu ra được so ở I-06:
- sự kiện SU-1/SU-4;
- trigger và S1 (SL, TP1/2/3, R:R, hạng, lý do);
- ứng viên cuối S2a; trạng thái vùng; thể hiện SU-4;
- bar14, cnt14, passBuy, passSell, slotOverflow, mainEv, portSlot, SU-6;
- các ô Data Window actionable.

**Giới hạn của I-07:** driver không chạy chính `f_x0`/`f_exec` trên dữ liệu ngẫu nhiên. Mã này trùng 0.3.8 và chạy trước SHADOW trong cùng nến, nên chỉ bị ảnh hưởng nếu SHADOW ghi biến sổ, mà I-03 và I-04 đã loại trừ.

**Các tình huống yêu cầu ở mục D của chỉ thị đều có trong I-04/I-06:**
- chỉ SU-3, chỉ SU-5, cả hai, nhiều thể hiện cùng lúc;
- VOID, EXPIRED, trigger, retest gap;
- thiếu dữ liệu, khung chờ;
- SHADOW trigger cùng nến với SU-1/SU-4;
- thể hiện SHADOW kết thúc khi SU-4 còn tồn tại, và ngược lại.

## 8. Regression

**R-01:** chạy lại toàn bộ bộ 0.3.8 trên 0.3.9.
- Script `kiem_toan039/hoi_quy_bo_038_tren_039.py` được sinh tự động; chỉ đổi đích và thư mục kết quả, **không sửa assertion**. hoi_quy034 chạy với đích `039`; tôi chỉ thêm dòng ánh xạ, bản cũ lưu ở `BAN_GIAO_039/cong_cu_truoc_039/`.
- Kết quả 67/9/5/1. So với chính bộ đó trên 0.3.8, chỉ 4 ID đổi:

| ID | 0.3.8 → 0.3.9 | Nguyên nhân |
|---|---|---|
| T-01, R.A35.A-11 | PASS → FAIL | Ước lượng token vượt ngưỡng (cùng nguyên nhân với T-01 của bộ 0.3.9) |
| R.t_md5_song_song | PASS → FAIL | Assertion cũ so **toàn bộ** biến của vùng DX032 với 0.3.4a. Bốn biến khác đúng là bốn biến SHADOW mới khai báo trong vùng (`sh`, `s5L`, `evS`, `shTxt`). Kết quả cũ giữ nguyên |
| R.PHAN_LOAI | PASS → FAIL | Hệ quả của hai dòng trên |

**R-02 (thay thế cho R.t_md5_song_song):**
1. Biến khác trong kết quả cũ đúng bằng 4 biến SHADOW.
2. Chạy lại cùng 4 kịch bản (7.100 nến) MD-5 nguyên văn 0.3.4a ↔ 0.3.9, loại 4 biến đó (và `s4`, như bộ 0.3.8 đã làm ở dòng 441–442): 0 khác, 0 lỗi chạy, 0 lỗi bất biến.

Kết quả: PASS.

Các FAIL lịch sử của bộ 0.3.8 (R.t_data_window, R.A35.A-02/05/09/10) **giữ nguyên, không đóng**. 18 đột biến cũ của bộ 0.3.8 vẫn bị bắt trên 0.3.9.

## 9. Mutation

42 đột biến chọn theo logic thực của đặc tả và mã nguồn, áp lên **bản sao** trong bộ nhớ. Mỗi đột biến được chạy qua các nhóm test S3, S5, I-tĩnh, I-04 và I-06. Chi tiết từng đột biến và test đã bắt nó nằm trong `dot_bien_039.txt`.

| | Số lượng |
|---|---|
| Tổng | 42 |
| Bị bắt | 41 |
| Sống sót – tương đương | 1 |
| Sống sót – không tương đương | 0 |
| Không áp được | 0 |

**Nhóm đột biến:**
- **SU-3 (16):** bỏ MSS (a), đảo chiều MSS, bỏ hoặc đổi biên vô hiệu MỐC, bỏ RUNNING, bỏ vô hiệu vùng H1, hết hạn 24 → 25, nhận j = t1, chọn j sớm nhất, bỏ điều kiện lần chạm đầu, bỏ điều kiện không gap, bỏ điều kiện mở ≥ t2, hết hạn 48 → 47, bỏ vô hiệu vùng bước 3, sai lớp quyền, đảo min/max của SL.
- **SU-5 (14):** ưu tiên REF, sai phá hòa hạng, nhận cụm hạng 1, nhận CHoCH, ngưỡng rời mức, retest cùng nến rời mức, gap vẫn ARMED, biên vô hiệu neo, bỏ BOS ngược, hết hạn 24 → 25, bỏ lọc T_j, L* không nghiêm ngặt, bỏ ghi nhớ Lv.
- **Chung (5):** hết hạn sau ARMED 23 → 24, bỏ chặn khung chờ, S1 bỏ lý do 15, S1 bỏ lý do 8 khi thiếu pool, ĐẠT ghi FINAL thay vì 17.
- **Cách ly (8):** SHADOW đẩy vào trigE, chiếm ô Data Window trước actionable, ghi vùng MD-3, đếm passBuy, tăng bar14, phát cảnh báo, xóa s4, đẩy vào evs.

**Đột biến tương đương:** "bỏ điều kiện nến mở ≥ t2".
- Trạng thái chờ chạm (st = 1) chỉ được gán khi dữ liệu H1 của t2 vừa về.
- Mọi nến M5 xử lý sau đó có thời điểm mở ≥ t2 (D.4/R1–R10).
- Vì vậy điều kiện này luôn đúng. Tôi giữ nó để bám đúng chữ J.2.

**Chưa kiểm khi chạy:**
- Đột biến "tăng bar14" chỉ bị bắt bằng kiểm tĩnh I-03, vì trong dữ liệu ngẫu nhiên SHADOW không gặp lý do 14.
- Đột biến "bỏ vô hiệu vùng bước 3" bị bắt do test dừng với lỗi truy cập vùng `na`. Trên Pine, trường hợp này cũng sẽ là lỗi runtime.

## 10. Data Window / dashboard

- **DW-01:** 56 plot trùng từng ký tự với 0.3.8; không thêm plot. Sự kiện SHADOW (trạng thái 17 khi ĐẠT, lý do 16) chỉ hiện ở ô sự kiện **còn trống** sau các sự kiện actionable. `slotOverflow` chỉ đếm actionable, nên các ô actionable không đổi (I-06).
- **DW-02:** dashboard có thêm 1 hàng là hàng 15, "SHADOW (không giao dịch)", theo K.5 (3). Nội dung: "SHADOW: SU-x BUY/SELL – THEO DÕI / LIVE / ĐẠT (không giao dịch)". Các hàng baseline 1…14 trùng 0.3.8. Không có nhãn tín hiệu, EARLY hay cảnh báo cho SHADOW.
- **DW-03:** "LIVE" chỉ tính trên nến chưa đóng, trong khối hiển thị, và chỉ gán biến hiển thị. LIVE có repaint theo thiết kế của K.5, và dùng H*/L* của nến đã đóng gần nhất.
- **Vì sao cần hàng dashboard:** K.5 (3) yêu cầu đúng một dòng riêng cho SHADOW. Chi phí 55 token từ vựng.

## 11. Token

**Phương pháp (tái lập bằng T-01 trong `ket_qua_039.json`):**
- Đếm token từ vựng bằng một biểu thức cố định (bỏ chú thích).
- Quy ra token biên dịch bằng tỷ lệ 3,3889, lấy từ **điểm đo thật duy nhất**: 0.3.3 có 29.909 token từ vựng thì TradingView báo 101.360 token biên dịch (CE10117).
- Số đo thật về compile: 0.3.3 FAIL; 0.3.7 (29.368 từ vựng) và 0.3.8 (28.369 từ vựng) compile được (chủ dự án xác nhận).

| Bản | Token từ vựng | Ước lượng biên dịch | Loại số liệu |
|---|---|---|---|
| 0.3.8 | 28.369 | ≈ 96.141 | Ước lượng; compile thật PASS |
| **0.3.9** | **30.226 (+1.857)** | **≈ 102.434** | **Ước lượng; chưa compile** |
| Ngưỡng 100.256 quy ra từ vựng | ≈ 29.583 | — | Ước lượng |
| 0.3.9 vượt | +643 từ vựng so với ngưỡng ước lượng; +317 so với 0.3.3 (đã FAIL) | — | — |

**Chi phí theo phần (ước lượng, từ vựng):**

| Phần | Token từ vựng |
|---|---|
| Riêng SU-3 | ≈ 490 |
| Riêng SU-5 | ≈ 424 |
| Phần chung (kiểu, S1 SHADOW, khung vòng đời, Data Window, dashboard) | ≈ 943 |
| Bản chỉ có SU-5 | ≈ 29.736 → vẫn vượt ngưỡng ước lượng 153 |
| Bản chỉ có SU-3 | ≈ 29.802 → vẫn vượt |

**Số đo thật của 0.3.9:** chưa có (T-02 BLOCKED).

**Phương án** (chưa thực hiện cái nào vì đều cần chủ dự án quyết):

| PA | Nội dung | Tác động / đánh giá |
|---|---|---|
| **PA-1 (đề nghị làm trước)** | Anh compile 0.3.9 một lần trên TradingView. Nếu qua: hết rủi ro token. Nếu báo CE10117: thông báo lỗi có **số token thật**, cho điểm hiệu chỉnh thứ hai để tính chính xác phần cần giảm | Không sửa mã. Đây là phép đo duy nhất đáng tin vì tỷ lệ hiện chỉ dựa trên 1 điểm |
| PA-2 | Gỡ mã chết đã đo trong baseline: 7 biến `lastEv*`/`lastMss*` không được đọc (`lastMssM15` được đọc, giữ lại) ≈ 75; hàm `f_srcList` không được gọi ≈ 196; `lotMax` không đọc ≈ 12. Tổng ≈ 280 token từ vựng | Không đổi logic (có thể chứng minh), nhưng chạm mã đã nghiệm thu. Chưa đủ một mình. Chưa rõ trình biên dịch có tính hàm không được gọi hay không |
| PA-3 | Gộp mã chọn TP1/TP2/TP3 đang lặp ở S1 SU-1, S1 SU-4 và S1 SHADOW thành một hàm | Ước lượng tiết kiệm 200–300. Chạm SU-1/SU-4 đã nghiệm thu; cần chứng minh tương đương bằng vi sai (đã có công cụ) |
| PA-4 | Rút gọn thêm phần mã SHADOW mới | Ước lượng 100–200 |
| PA-5 | Tách 0.3.9 thành SU-5 trước, SU-3 sau | Vẫn vượt ước lượng nếu không kèm PA-2/3/4 |

## 12. Compile

**Chưa compile trên TradingView.** TV-COMPILE, TV-M5, TV-RELOAD và TV-KHUNG đều BLOCKED. Kết quả PASS trên pine_mini không phải bằng chứng compile.

## 13. Các test FAIL

- **T-01 (bộ 0.3.9):** ước lượng token vượt ngưỡng. Đây là FAIL thật về ngân sách token.
- **Bộ 0.3.8 chạy trên 0.3.9:**
  - T-01, R.A35.A-11: cùng nguyên nhân token.
  - R.t_md5_song_song: assertion lịch sử; giữ FAIL, có thay thế R-02 PASS.
  - R.PHAN_LOAI: hệ quả.
  - 5 FAIL lịch sử có từ 0.3.8: giữ nguyên.

## 14. Các test BLOCKED

| Test | Lý do |
|---|---|
| C-06 | Nhánh cụm MD-4 của SU-3, chờ IP-19 |
| C-07 | Hạng SHADOW, chờ IP-23 |
| T-02 | Token biên dịch thật |
| TV-COMPILE, TV-M5, TV-RELOAD, TV-KHUNG | Cần quyền TradingView |

## 15. Các test NOT TESTED

- **TV-EXNESS:** dữ liệu Exness thật, Profiler, CSV.
- Hành vi trên TradingView khi dữ liệu khung lớn đến trễ thật sự (pendH1) đối với SHADOW. Driver chỉ mô phỏng cờ chờ.

## 16. IP chưa giải quyết

Danh sách đầy đủ trong `IP_CON_MO_039.md`.

- **Giữ nguyên, không đụng:** IP-4, IP-15, IP-16, IP-17, IP-18, IP-11…IP-14, OP-1, OP-2, OP-3, Q2/D16, Q4/D14–D19, IP-1…IP-10.
- **Mới ở 0.3.9:**

| IP | Nội dung | Trạng thái |
|---|---|---|
| IP-19 | SU-3 nhánh cụm MD-4 hạng ≥ 3: đặc tả không định nghĩa danh tính cụm qua các lần gom lại, nên không xác định được "cụm bị vô hiệu/FLIPPED xuống" | **BLOCKED, không triển khai** |
| IP-20 | SU-3 không có vùng mới ở bước 3 | Kết thúc, không ghi sự kiện |
| IP-21 | SU-3 trùng thể hiện: mỗi nến M15 giao cắt vùng H1 tạo một thể hiện | Theo đúng chữ J.2; chưa có quy tắc khử trùng |
| IP-22 | Ô nhập chế độ K.5 chưa triển khai | Cố định SHADOW |
| IP-23 | SU-5: I.5 yêu cầu C-1/C-2 nhưng J.4 không định nghĩa | Không tính hạng |
| IP-24 | "BOS" hiểu là sự kiện BOS (không gồm CHoCH); "BOS↓ phá Lv" hiểu là BOS↓ có Close < Lv | Diễn giải |
| IP-25 | J.4.3 ghi nhớ Lv theo giá chính xác, suốt phiên | Diễn giải |
| IP-26 | "Lần chạm đầu tiên" của SU-3 theo E.2. Nếu lần chạm đầu xảy ra trước t2 hoặc là gap thì SU-3 hết hạn | Diễn giải |
| IP-27 | Đệm SL của SU-3/SU-5 dùng `iSlBufK` (0,2) cho cả ATR_M5 và ATR_M15; hệ số 0,5A của SU-5 cố định trong mã | Liên quan IP-18 |
| IP-28 | Vị trí sự kiện SHADOW trong ô Data Window | Chỉ điền ô trống sau actionable |
| IP-29 | SU-5 cần MD-4 khả dụng mới tạo thể hiện | Diễn giải |
| IP-30 | Vô hiệu vùng H1 ở bước 1 có thể trễ đến lần nhận M15/H1 kế tiếp; LIVE dùng H*/L* của nến đã đóng | Diễn giải |

## 17. Các rủi ro

1. **Token (cao):** khả năng cao 0.3.9 không compile được (CE10117). Xem PA-1…PA-5 ở mục 11.
2. **Hiệu năng (trung bình):** số thể hiện SU-3 có thể tăng khi giá nằm lâu trong vùng H1 (IP-21; tối đa 25 trong kiểm thử). Mỗi nến có vòng lặp qua các vùng. Chưa đo được giới hạn thời gian chạy trên TradingView.
3. **Bộ nhớ (thấp):** mảng `s5L` tăng theo số SU-5 đã kết thúc trong cả lịch sử.
4. **Diễn giải (trung bình):** IP-19…IP-30 cần chủ dự án quyết. Nếu đổi diễn giải, mã SHADOW phải sửa và kiểm lại; actionable không bị ảnh hưởng.
5. **Phương pháp kiểm:** pine_mini không phải TradingView. Toán tử lịch sử `[]` được bổ sung riêng cho bộ 0.3.9.

## 18. Kết luận nghiệm thu

**BLOCKED.**

**Căn cứ:**
- **CODE:** đúng baseline; chỉ thêm khối SHADOW và 5 dòng phiên bản/dashboard (I-01, I-02, C-04); không đóng IP nào; không đổi logic actionable.
- **SU-3/SU-5:** triển khai theo J.2/J.4/K.5 trừ phần chặn bởi IP-19 và IP-23. Có 29 test vòng đời, biên, đồng bộ, thiếu dữ liệu và trùng (SU-3: 17, SU-5: 12), chạy nguyên văn, đều PASS. Có mô hình độc lập cho SU-5 (300 chuỗi, 0 khác).
- **REGRESSION:** đã chạy; mọi khác biệt đã giải thích; FAIL lịch sử giữ nguyên.
- **SHADOW ISOLATION:** có bằng chứng tĩnh, bằng chứng chụp trạng thái khi chạy và vi sai 0.3.8 ↔ 0.3.9 cho cùng dữ liệu; có đột biến cách ly; có kiểm pipeline, Data Window, cảnh báo; sổ được kiểm gián tiếp.
- **TOKEN:** ước lượng vượt ngưỡng và vượt cả 0.3.3 (đã FAIL). Chưa có số đo thật.
- **TRADINGVIEW:** chưa compile.

Không thể ACCEPT hay ACCEPT WITH OPEN ITEMS, vì nhiều khả năng bản này không compile được trên nền tảng. Cũng không REJECT, vì không có lỗi logic hay cách ly nào. Trạng thái BLOCKED được gỡ bằng PA-1: một lần compile trên TradingView.
