# Báo cáo kiểm đột biến – vòng 3

## A. Đột biến MÃ NGUỒN (KD-MUT-SRC: PASS)

Baseline (bản sao KHÔNG đột biến, chế độ gate): `{"rc": 0, "tom_tat": {"PASS": 100}, "so_test": 100, "so_assertion": 112502}`

Phân loại: `{"KILLED_EXPECTED": 42}` trên 42 đột biến khai báo.

| # | File | Đột biến | Kết quả | Test kỳ vọng (khai báo trước) | Test bắt bằng assertion (thực tế) | Test lỗi ngoại lệ | SHA bản đột biến |
|---|---|---|---|---|---|---|---|
| 1 | mo_phong_lenh.py | biên rủi ro 0 | KILLED_EXPECTED | KD-GOLD-EXTRA | KD-MIRROR-PROP, KD-ORACLE-PROP, KD-R1-NOLOOK, KD-ENTRY-RETRO, KD-GOLD-EXTRA, KD-SM-TRADE, KD-FIRST |  | 97516809be9e29d7 |
| 2 | mo_phong_lenh.py | R2 Open = SL | KILLED_EXPECTED | KD-GOLD-R2-C-EQ | KD-GOLD-R2-C-EQ, KD-MIRROR-GOLD |  | 47336fde27607691 |
| 3 | mo_phong_lenh.py | R2 Open = TP1 | KILLED_EXPECTED | KD-GOLD-R2-D-EQ | KD-GOLD-R2-D-EQ |  | e3f68abc720444fc |
| 4 | mo_phong_lenh.py | gap SL biên | KILLED_EXPECTED | KD-GOLD-EXTRA | KD-ORACLE-PROP, KD-GOLD-EXTRA |  | 60dd8f748a55d543 |
| 5 | mo_phong_lenh.py | chạm SL biên | KILLED_EXPECTED | KD-GOLD-EXTRA | KD-ORACLE-PROP, KD-GOLD-EXTRA |  | 7556f309eb9e463f |
| 6 | mo_phong_lenh.py | chạm TP biên | KILLED_EXPECTED | KD-GOLD-EXTRA | KD-ORACLE-PROP, KD-GOLD-EXTRA |  | bc6dcaf72994953c |
| 7 | mo_phong_lenh.py | đảo quy tắc cùng nến | KILLED_EXPECTED | KD-GOLD-R1-SB-SL, KD-GOLD-R1-SB-TP | KD-GOLD-R1-SB-SL, KD-GOLD-R1-SB-TP, KD-GOLD-S-SB-TP, KD-GOLD-S-SB-SL, KD-ORACLE-PROP |  | 9becf3b87f20de00 |
| 8 | mo_phong_lenh.py | MAE nến thoát TP1 | KILLED_EXPECTED | KD-GOLD-EXTRA | KD-ORACLE-PROP, KD-GOLD-EXTRA |  | e749e60286a7481d |
| 9 | mo_phong_lenh.py | MFE nến thoát SL | KILLED_EXPECTED | KD-GOLD-R1-SL-FAV | KD-GOLD-R1-SL-FAV, KD-GOLD-R2-I, KD-ORACLE-PROP |  | 5bd9f4bc6efd1ea1 |
| 10 | mo_phong_lenh.py | F3 tái phát | KILLED_EXPECTED | KD-GOLD-R1-SB-TP, KD-GOLD-S-SB-TP | KD-GOLD-R1-SB-TP, KD-GOLD-S-SB-TP, KD-ORACLE-PROP |  | aae8b79d457c9608 |
| 11 | mo_phong_lenh.py | max_bars lệch 1 | KILLED_EXPECTED | KD-GOLD-R1-HITAFTER | KD-GOLD-R1-HITAFTER, KD-ORACLE-PROP, KD-R1-NOLOOK |  | d32ce981900c1b14 |
| 12 | mo_phong_lenh.py | biên OPEN/TIMEOUT | KILLED_EXPECTED | KD-GOLD-R1-TIMEOUT-EXACT | KD-GOLD-R1-NOLOOK, KD-GOLD-R1-TIMEOUT-EXACT, KD-GOLD-S-TIMEOUT, KD-ORACLE-PROP |  | c3370fd230af0f55 |
| 13 | mo_phong_lenh.py | R1 bỏ kiểm gap nến đầu | KILLED_EXPECTED | KD-GOLD-R1-GAPSL, KD-GOLD-R1-GAPTP | KD-GOLD-R1-GAPSL, KD-GOLD-R1-GAPTP, KD-GOLD-R1-GAPXA, KD-GOLD-S-R1-GAPSL, KD-ORACLE-PROP, KD-GOLD-EXTRA, KD-FIRST |  | 82ca0d47a81b5bcb |
| 14 | mo_phong_lenh.py | chi phí trượt giá 1 lần | KILLED_EXPECTED | KD-GOLD-EXTRA | KD-GOLD-EXTRA |  | a126d08e327650b0 |
| 15 | mo_phong_lenh.py | R1 dùng nến trigger (nhìn trước) | KILLED_EXPECTED | KD-GOLD-R1-NOLOOK | KD-GOLD-R1-TP, KD-GOLD-R1-SL, KD-GOLD-R1-SL-FAV, KD-GOLD-R1-TPNULL, KD-GOLD-R1-TIMEOUT, KD-GOLD-R1-OPEN, KD-GOLD-R1-GAPSL, KD-GOLD-R1-GAPTP, KD-GOLD-R1-GAPXA, K |  | 52cbcc8aeacd75d5 |
| 16 | mo_phong_lenh.py | F1 tái phát | KILLED_EXPECTED | KD-OCC-GOLD | KD-OCC-GOLD, KD-OCC-PROP, KD-F32 |  | 50267e5864fe4b33 |
| 17 | mo_phong_lenh.py | biên vào = thoát | KILLED_EXPECTED | KD-OCC-GOLD | KD-OCC-GOLD, KD-OCC-PROP, KD-F32 |  | 0ee1c571fbc7a0c5 |
| 18 | mo_phong_lenh.py | F2 tái phát | KILLED_EXPECTED | KD-DUP-GOLD | KD-DUP-GOLD, KD-DUP-PROP, KD-F26 |  | ced47df210ee6597 |
| 19 | mo_phong_lenh.py | bỏ khóa phụ signal_id (F32) | KILLED_EXPECTED | KD-OCC-GOLD | KD-OCC-GOLD, KD-OCC-PROP, KD-F32 |  | 265d3a2eb5fadd33 |
| 20 | mo_phong_lenh.py | bỏ kiểm signal_id trùng (F32) | KILLED_EXPECTED | KD-F32 | KD-F32 |  | 41cf6746dea0f931 |
| 21 | mo_phong_lenh.py | đảo ưu tiên thời gian | KILLED_EXPECTED | KD-F32 | KD-OCC-PROP, KD-F32 |  | 30179f4e084cefd7 |
| 22 | mo_phong_lenh.py | F29 tái phát | KILLED_EXPECTED | KD-F29, KD-REPL-OT05 | KD-GOLD-R1-BADBAR, KD-ORACLE-PROP, KD-REPL-OT05, KD-F29 |  | 0874ee25fbd9f292 |
| 23 | chi_so.py | hòa vốn tính là thua | KILLED_EXPECTED | KD-MET-1BE | KD-MET-1BE, KD-MET-BEONLY, KD-MET-WINBE, KD-MET-PROP |  | 18d73bc2ff7f6bc9 |
| 24 | chi_so.py | F10 tái phát | KILLED_EXPECTED | KD-MET-1WIN | KD-MET-ZERO, KD-MET-1WIN, KD-MET-1BE, KD-MET-WINONLY, KD-MET-BEONLY, KD-MET-WINBE, KD-MET-PROP | KD-JSON, KD-MET-OPEN | 188c251710dd268d |
| 25 | chi_so.py | mẫu số win rate | KILLED_EXPECTED | KD-MET-WINBE | KD-MET-1BE, KD-MET-BEONLY, KD-MET-WINBE, KD-MET-PROP |  | d62582ca995f45dc |
| 26 | chi_so.py | OPEN vào R | KILLED_EXPECTED | KD-MET-OPEN | KD-MET-ZERO, KD-MET-OPEN, KD-MET-PROP, KD-MET-R3 |  | 41eac3b4b69d5857 |
| 27 | chi_so.py | phân vị sai | KILLED_EXPECTED | KD-PCT | KD-PCT |  | acf3460a0b7f2e63 |
| 28 | chi_so.py | F11 tái phát | KILLED_EXPECTED | KD-FUNNEL | KD-DUP-SEED, KD-FUNNEL |  | 5485b20f449ab15e |
| 29 | chi_so.py | F35 tái phát | KILLED_EXPECTED | KD-F29, KD-FUNNEL-R3 | KD-F29, KD-FUNNEL-R3 |  | e0327a264cfa8688 |
| 30 | chi_so.py | gross_r dùng r_net | KILLED_EXPECTED | KD-MET-R3 | KD-MET-R3 |  | 57b3f2a162d27bf4 |
| 31 | hop_dong.py | F12 tái phát (NaN) | KILLED_EXPECTED | KD-HD-MUT | KD-HD-MUT |  | f2683e965b2cb818 |
| 32 | hop_dong.py | bỏ ts ↔ ts_ms | KILLED_EXPECTED | KD-HD-MUT | KD-HD-MUT |  | 2a3e031e6ea45e8e |
| 33 | hop_dong.py | bool giả int | KILLED_EXPECTED | KD-HD-MUT | KD-HD-MUT |  | b34d813fada5d2bd |
| 34 | hop_dong.py | bỏ kiểm risk cấp bảng | KILLED_EXPECTED | KD-HD-MUT | KD-HD-MUT |  | b9a3cc3414075016 |
| 35 | hop_dong.py | bỏ máy trạng thái sự kiện | KILLED_EXPECTED | KD-HD-MUT, KD-REPL-HD01S3 | KD-HD-MUT, KD-REPL-HD01S3 |  | eac49af725b92e38 |
| 36 | hop_dong.py | F36 tái phát (crash ts ngoài miền) | KILLED_EXPECTED | KD-HD-FUZZ, KD-HD-MUT | KD-HD-MUT, KD-HD-FUZZ |  | 2a31647ef3d65c21 |
| 37 | hop_dong.py | bỏ kiểm bản ghi không phải object | KILLED_EXPECTED | KD-HD-FUZZ | KD-HD-FUZZ |  | 3a83bb8c4407d39f |
| 38 | may_trang_thai.py | nới CREATED → ARMED | KILLED_EXPECTED | KD-SM-TABLE | KD-SM-TABLE, KD-HD-MUT, KD-REPL-HD01S3 |  | a6b1230403e9e083 |
| 39 | may_trang_thai.py | bỏ kiểm R2 vào sau trigger | KILLED_EXPECTED | KD-SM-TRADE-NEG | KD-SM-TRADE-NEG |  | 5355c758cdf27528 |
| 40 | pipeline.py | F26 tái phát | KILLED_EXPECTED | KD-F26, KD-DUP-GOLD | KD-DUP-GOLD, KD-F26 |  | 5df14267b3a032c2 |
| 41 | chuan_hoa.py | F28 tái phát (STEP trước sự kiện engine) | KILLED_EXPECTED | KD-F28-ADAPTER | KD-SM-ENGINE, KD-F28-ADAPTER, KD-F28-SEEDS |  | a94873213968d9c2 |
| 42 | chuan_hoa.py | F28 tái phát (CREATED lấy st cuối nến) | KILLED_EXPECTED | KD-F28-ADAPTER | KD-SM-ENGINE, KD-F28-ADAPTER, KD-F28-SEEDS |  | 1fcae9fce34c1d1c |

Quy tắc: chỉ KILLED_EXPECTED (ít nhất một test kỳ vọng FAIL bằng assertion) được tính; ngoại lệ không tính; ≥ 80 % test lỗi ngoại lệ = ENV_ERROR.

Log: `kiem_toan_r3/ket_qua/log_dot_bien_nguon.txt`.

## B. Đột biến HỢP ĐỒNG DỮ LIỆU (KD-HD-MUT: PASS)

Phân loại: `{"PHAT_HIEN_DUNG": 116}` – 116 lần thực thi (29 loại × 4 fixture), 0 bỏ qua.

| Đột biến | Fixture | Kết quả | Lý do kỳ vọng | Thông báo bộ kiểm (rút gọn) |
|---|---|---|---|---|
| xóa trường bắt buộc (EVENTS.reason) | BUY-TP1 | PHAT_HIEN_DUNG | thiếu reason | EVENTS[0] thiếu reason |
| xóa trường bắt buộc (TRADES.outcome) | BUY-TP1 | PHAT_HIEN_DUNG | thiếu outcome | TRADES[0] thiếu outcome |
| thêm trường lạ | BUY-TP1 | PHAT_HIEN_DUNG | trường lạ la | SIGNALS[0] trường lạ la |
| sai kiểu (p_ref chuỗi) | BUY-TP1 | PHAT_HIEN_DUNG | p_ref: kiểu | SIGNALS[0] p_ref: kiểu str ≠ float |
| bool giả int (dir = True) | BUY-TP1 | PHAT_HIEN_DUNG | dir: bool | EVENTS[1] dir: bool thay int |
| bool giả int (bars_held = True) | BUY-TP1 | PHAT_HIEN_DUNG | bars_held: bool | TRADES[0] bars_held: bool thay int |
| sai timestamp (ts ≠ ts_ms) | BUY-TP1 | PHAT_HIEN_DUNG | ts ≠ ts_ms | EVENTS[2] ts ≠ ts_ms (2026-01-02T03:15:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (trigger_ts lệch) | BUY-TP1 | PHAT_HIEN_DUNG | trigger_ts ≠ trigger_ts_ms | SIGNALS[0] trigger_ts ≠ trigger_ts_ms (2026-01-01T00:00:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (ngoài miền năm 9999) | BUY-TP1 | PHAT_HIEN_DUNG | quá năm 9999, ts ≠ ts_ms | EVENTS[0] ts ≠ ts_ms (2026-01-02T03:05:00Z vs <ngoài miền: 100000000000000000000>) |
| sai ID (signal_id không tái lập) | BUY-TP1 | PHAT_HIEN_DUNG | không tái lập | SIGNAL ffffffffffffffff: signal_id không tái lập được từ (setup_id, trigger_ts_ms) |
| trùng sự kiện | BUY-TP1 | PHAT_HIEN_DUNG | trùng event_id | EVENTS: trùng event_id |
| trùng lệnh | BUY-TP1 | PHAT_HIEN_DUNG | trùng (signal_id, sim_rule, cost_model) | TRADES: trùng (signal_id, sim_rule, cost_model) |
| sai thứ tự (emit_seq ngược thời gian) | BUY-TP1 | PHAT_HIEN_DUNG | có ts_ms nhỏ hơn | EVENTS: emit_seq 2 có ts_ms nhỏ hơn emit_seq 1 |
| sai R (r_gross ≠ giá thoát) | BUY-TP1 | PHAT_HIEN_DUNG | /r_gross/×risk | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (lệch giá) | BUY-TP1 | PHAT_HIEN_DUNG | /r_gross/×risk, risk ≠ | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (nhất quán nội bộ bản ghi) | BUY-TP1 | PHAT_HIEN_DUNG | risk ≠ (entry − SL)×dir | TRADE 6048cc1b50ab6472: risk ≠ (entry − SL)×dir |
| sai outcome (đảo TP1 ↔ SL) | BUY-TP1 | PHAT_HIEN_DUNG | SL không gap, TP1 phải r_gross > 0, TP1 khi tín hiệu không có TP1 | TRADES[0] SL không gap phải r_gross = −1 |
| sai hình học (SL sai phía) | BUY-TP1 | PHAT_HIEN_DUNG | SL không nằm phía rủi ro | SIGNALS[0] hình học: SL không nằm phía rủi ro của P_ref |
| sai vòng đời (CREATED → ARMED) | BUY-TP1 | PHAT_HIEN_DUNG | CREATED → ARMED | MÁY TRẠNG THÁI: aaaa000000000001: chuyển tiếp không hợp lệ CREATED → ARMED |
| sai vòng đời (sự kiện sau TRIGGER) | BUY-TP1 | PHAT_HIEN_DUNG | sau sự kiện kết thúc | EVENTS aaaa000000000001: có sự kiện sau sự kiện kết thúc hoặc nhiều sự kiện kết thúc |
| NaN | BUY-TP1 | PHAT_HIEN_DUNG | mfe_r: không hữu hạn | TRADES[0] mfe_r: không hữu hạn (nan) |
| Infinity | BUY-TP1 | PHAT_HIEN_DUNG | sl: không hữu hạn | SIGNALS[0] sl: không hữu hạn (inf) |
| −Infinity | BUY-TP1 | PHAT_HIEN_DUNG | anchor_price: không hữu hạn | EVENTS[0] anchor_price: không hữu hạn (-inf) |
| NO_FILL có R | BUY-TP1 | PHAT_HIEN_DUNG | NO_FILL: risk phải null | TRADES[0] NO_FILL: risk phải null |
| OPEN có thoát | BUY-TP1 | PHAT_HIEN_DUNG | OPEN: exit phải null | TRADES[0] OPEN: exit phải null |
| chi phí không khớp cost_model | BUY-TP1 | PHAT_HIEN_DUNG | chi phí (theo cost_model) | TRADES[0] r_gross − r_net ≠ chi phí (theo cost_model) / risk |
| rr_entry sai | BUY-TP1 | PHAT_HIEN_DUNG | rr_entry | TRADE 6048cc1b50ab6472: rr_entry ≠ (TP1 − entry)×dir / risk |
| lệnh cho tín hiệu bị bỏ (reason 15) | BUY-TP1 | PHAT_HIEN_DUNG | không đạt S1 | TRADE 6048cc1b50ab6472: tín hiệu không đạt S1 (reason 15) nhưng có TRADE |
| ID chéo seed (gộp hai bộ giống hệt) | BUY-TP1 | PHAT_HIEN_DUNG | trùng event_id, trùng emit_seq | EVENTS: trùng event_id |
| xóa trường bắt buộc (EVENTS.reason) | SELL-TP1 | PHAT_HIEN_DUNG | thiếu reason | EVENTS[0] thiếu reason |
| xóa trường bắt buộc (TRADES.outcome) | SELL-TP1 | PHAT_HIEN_DUNG | thiếu outcome | TRADES[0] thiếu outcome |
| thêm trường lạ | SELL-TP1 | PHAT_HIEN_DUNG | trường lạ la | SIGNALS[0] trường lạ la |
| sai kiểu (p_ref chuỗi) | SELL-TP1 | PHAT_HIEN_DUNG | p_ref: kiểu | SIGNALS[0] p_ref: kiểu str ≠ float |
| bool giả int (dir = True) | SELL-TP1 | PHAT_HIEN_DUNG | dir: bool | EVENTS[1] dir: bool thay int |
| bool giả int (bars_held = True) | SELL-TP1 | PHAT_HIEN_DUNG | bars_held: bool | TRADES[0] bars_held: bool thay int |
| sai timestamp (ts ≠ ts_ms) | SELL-TP1 | PHAT_HIEN_DUNG | ts ≠ ts_ms | EVENTS[2] ts ≠ ts_ms (2026-01-02T03:15:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (trigger_ts lệch) | SELL-TP1 | PHAT_HIEN_DUNG | trigger_ts ≠ trigger_ts_ms | SIGNALS[0] trigger_ts ≠ trigger_ts_ms (2026-01-01T00:00:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (ngoài miền năm 9999) | SELL-TP1 | PHAT_HIEN_DUNG | quá năm 9999, ts ≠ ts_ms | EVENTS[0] ts ≠ ts_ms (2026-01-02T03:05:00Z vs <ngoài miền: 100000000000000000000>) |
| sai ID (signal_id không tái lập) | SELL-TP1 | PHAT_HIEN_DUNG | không tái lập | SIGNAL ffffffffffffffff: signal_id không tái lập được từ (setup_id, trigger_ts_ms) |
| trùng sự kiện | SELL-TP1 | PHAT_HIEN_DUNG | trùng event_id | EVENTS: trùng event_id |
| trùng lệnh | SELL-TP1 | PHAT_HIEN_DUNG | trùng (signal_id, sim_rule, cost_model) | TRADES: trùng (signal_id, sim_rule, cost_model) |
| sai thứ tự (emit_seq ngược thời gian) | SELL-TP1 | PHAT_HIEN_DUNG | có ts_ms nhỏ hơn | EVENTS: emit_seq 2 có ts_ms nhỏ hơn emit_seq 1 |
| sai R (r_gross ≠ giá thoát) | SELL-TP1 | PHAT_HIEN_DUNG | /r_gross/×risk | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (lệch giá) | SELL-TP1 | PHAT_HIEN_DUNG | /r_gross/×risk, risk ≠ | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (nhất quán nội bộ bản ghi) | SELL-TP1 | PHAT_HIEN_DUNG | risk ≠ (entry − SL)×dir | TRADE 6048cc1b50ab6472: risk ≠ (entry − SL)×dir |
| sai outcome (đảo TP1 ↔ SL) | SELL-TP1 | PHAT_HIEN_DUNG | SL không gap, TP1 phải r_gross > 0, TP1 khi tín hiệu không có TP1 | TRADES[0] SL không gap phải r_gross = −1 |
| sai hình học (SL sai phía) | SELL-TP1 | PHAT_HIEN_DUNG | SL không nằm phía rủi ro | SIGNALS[0] hình học: SL không nằm phía rủi ro của P_ref |
| sai vòng đời (CREATED → ARMED) | SELL-TP1 | PHAT_HIEN_DUNG | CREATED → ARMED | MÁY TRẠNG THÁI: aaaa000000000001: chuyển tiếp không hợp lệ CREATED → ARMED |
| sai vòng đời (sự kiện sau TRIGGER) | SELL-TP1 | PHAT_HIEN_DUNG | sau sự kiện kết thúc | EVENTS aaaa000000000001: có sự kiện sau sự kiện kết thúc hoặc nhiều sự kiện kết thúc |
| NaN | SELL-TP1 | PHAT_HIEN_DUNG | mfe_r: không hữu hạn | TRADES[0] mfe_r: không hữu hạn (nan) |
| Infinity | SELL-TP1 | PHAT_HIEN_DUNG | sl: không hữu hạn | SIGNALS[0] sl: không hữu hạn (inf) |
| −Infinity | SELL-TP1 | PHAT_HIEN_DUNG | anchor_price: không hữu hạn | EVENTS[0] anchor_price: không hữu hạn (-inf) |
| NO_FILL có R | SELL-TP1 | PHAT_HIEN_DUNG | NO_FILL: risk phải null | TRADES[0] NO_FILL: risk phải null |
| OPEN có thoát | SELL-TP1 | PHAT_HIEN_DUNG | OPEN: exit phải null | TRADES[0] OPEN: exit phải null |
| chi phí không khớp cost_model | SELL-TP1 | PHAT_HIEN_DUNG | chi phí (theo cost_model) | TRADES[0] r_gross − r_net ≠ chi phí (theo cost_model) / risk |
| rr_entry sai | SELL-TP1 | PHAT_HIEN_DUNG | rr_entry | TRADE 6048cc1b50ab6472: rr_entry ≠ (TP1 − entry)×dir / risk |
| lệnh cho tín hiệu bị bỏ (reason 15) | SELL-TP1 | PHAT_HIEN_DUNG | không đạt S1 | TRADE 6048cc1b50ab6472: tín hiệu không đạt S1 (reason 15) nhưng có TRADE |
| ID chéo seed (gộp hai bộ giống hệt) | SELL-TP1 | PHAT_HIEN_DUNG | trùng event_id, trùng emit_seq | EVENTS: trùng event_id |
| xóa trường bắt buộc (EVENTS.reason) | BUY-TPnull | PHAT_HIEN_DUNG | thiếu reason | EVENTS[0] thiếu reason |
| xóa trường bắt buộc (TRADES.outcome) | BUY-TPnull | PHAT_HIEN_DUNG | thiếu outcome | TRADES[0] thiếu outcome |
| thêm trường lạ | BUY-TPnull | PHAT_HIEN_DUNG | trường lạ la | SIGNALS[0] trường lạ la |
| sai kiểu (p_ref chuỗi) | BUY-TPnull | PHAT_HIEN_DUNG | p_ref: kiểu | SIGNALS[0] p_ref: kiểu str ≠ float |
| bool giả int (dir = True) | BUY-TPnull | PHAT_HIEN_DUNG | dir: bool | EVENTS[1] dir: bool thay int |
| bool giả int (bars_held = True) | BUY-TPnull | PHAT_HIEN_DUNG | bars_held: bool | TRADES[0] bars_held: bool thay int |
| sai timestamp (ts ≠ ts_ms) | BUY-TPnull | PHAT_HIEN_DUNG | ts ≠ ts_ms | EVENTS[2] ts ≠ ts_ms (2026-01-02T03:15:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (trigger_ts lệch) | BUY-TPnull | PHAT_HIEN_DUNG | trigger_ts ≠ trigger_ts_ms | SIGNALS[0] trigger_ts ≠ trigger_ts_ms (2026-01-01T00:00:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (ngoài miền năm 9999) | BUY-TPnull | PHAT_HIEN_DUNG | quá năm 9999, ts ≠ ts_ms | EVENTS[0] ts ≠ ts_ms (2026-01-02T03:05:00Z vs <ngoài miền: 100000000000000000000>) |
| sai ID (signal_id không tái lập) | BUY-TPnull | PHAT_HIEN_DUNG | không tái lập | SIGNAL ffffffffffffffff: signal_id không tái lập được từ (setup_id, trigger_ts_ms) |
| trùng sự kiện | BUY-TPnull | PHAT_HIEN_DUNG | trùng event_id | EVENTS: trùng event_id |
| trùng lệnh | BUY-TPnull | PHAT_HIEN_DUNG | trùng (signal_id, sim_rule, cost_model) | TRADES: trùng (signal_id, sim_rule, cost_model) |
| sai thứ tự (emit_seq ngược thời gian) | BUY-TPnull | PHAT_HIEN_DUNG | có ts_ms nhỏ hơn | EVENTS: emit_seq 2 có ts_ms nhỏ hơn emit_seq 1 |
| sai R (r_gross ≠ giá thoát) | BUY-TPnull | PHAT_HIEN_DUNG | /r_gross/×risk | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (lệch giá) | BUY-TPnull | PHAT_HIEN_DUNG | /r_gross/×risk, risk ≠ | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (nhất quán nội bộ bản ghi) | BUY-TPnull | PHAT_HIEN_DUNG | risk ≠ (entry − SL)×dir | TRADE 6048cc1b50ab6472: risk ≠ (entry − SL)×dir |
| sai outcome (đảo TP1 ↔ SL) | BUY-TPnull | PHAT_HIEN_DUNG | SL không gap, TP1 phải r_gross > 0, TP1 khi tín hiệu không có TP1 | TRADES[0] TP1 phải r_gross > 0 |
| sai hình học (SL sai phía) | BUY-TPnull | PHAT_HIEN_DUNG | SL không nằm phía rủi ro | SIGNALS[0] hình học: SL không nằm phía rủi ro của P_ref |
| sai vòng đời (CREATED → ARMED) | BUY-TPnull | PHAT_HIEN_DUNG | CREATED → ARMED | MÁY TRẠNG THÁI: aaaa000000000001: chuyển tiếp không hợp lệ CREATED → ARMED |
| sai vòng đời (sự kiện sau TRIGGER) | BUY-TPnull | PHAT_HIEN_DUNG | sau sự kiện kết thúc | EVENTS aaaa000000000001: có sự kiện sau sự kiện kết thúc hoặc nhiều sự kiện kết thúc |
| NaN | BUY-TPnull | PHAT_HIEN_DUNG | mfe_r: không hữu hạn | TRADES[0] mfe_r: không hữu hạn (nan) |
| Infinity | BUY-TPnull | PHAT_HIEN_DUNG | sl: không hữu hạn | SIGNALS[0] sl: không hữu hạn (inf) |
| −Infinity | BUY-TPnull | PHAT_HIEN_DUNG | anchor_price: không hữu hạn | EVENTS[0] anchor_price: không hữu hạn (-inf) |
| NO_FILL có R | BUY-TPnull | PHAT_HIEN_DUNG | NO_FILL: risk phải null | TRADES[0] NO_FILL: risk phải null |
| OPEN có thoát | BUY-TPnull | PHAT_HIEN_DUNG | OPEN: exit phải null | TRADES[0] OPEN: exit phải null |
| chi phí không khớp cost_model | BUY-TPnull | PHAT_HIEN_DUNG | chi phí (theo cost_model) | TRADES[0] r_gross − r_net ≠ chi phí (theo cost_model) / risk |
| rr_entry sai | BUY-TPnull | PHAT_HIEN_DUNG | rr_entry | TRADE 6048cc1b50ab6472: rr_entry có giá trị khi tín hiệu không có TP1 |
| lệnh cho tín hiệu bị bỏ (reason 15) | BUY-TPnull | PHAT_HIEN_DUNG | không đạt S1 | TRADE 6048cc1b50ab6472: tín hiệu không đạt S1 (reason 15) nhưng có TRADE |
| ID chéo seed (gộp hai bộ giống hệt) | BUY-TPnull | PHAT_HIEN_DUNG | trùng event_id, trùng emit_seq | EVENTS: trùng event_id |
| xóa trường bắt buộc (EVENTS.reason) | SELL-TPnull | PHAT_HIEN_DUNG | thiếu reason | EVENTS[0] thiếu reason |
| xóa trường bắt buộc (TRADES.outcome) | SELL-TPnull | PHAT_HIEN_DUNG | thiếu outcome | TRADES[0] thiếu outcome |
| thêm trường lạ | SELL-TPnull | PHAT_HIEN_DUNG | trường lạ la | SIGNALS[0] trường lạ la |
| sai kiểu (p_ref chuỗi) | SELL-TPnull | PHAT_HIEN_DUNG | p_ref: kiểu | SIGNALS[0] p_ref: kiểu str ≠ float |
| bool giả int (dir = True) | SELL-TPnull | PHAT_HIEN_DUNG | dir: bool | EVENTS[1] dir: bool thay int |
| bool giả int (bars_held = True) | SELL-TPnull | PHAT_HIEN_DUNG | bars_held: bool | TRADES[0] bars_held: bool thay int |
| sai timestamp (ts ≠ ts_ms) | SELL-TPnull | PHAT_HIEN_DUNG | ts ≠ ts_ms | EVENTS[2] ts ≠ ts_ms (2026-01-02T03:15:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (trigger_ts lệch) | SELL-TPnull | PHAT_HIEN_DUNG | trigger_ts ≠ trigger_ts_ms | SIGNALS[0] trigger_ts ≠ trigger_ts_ms (2026-01-01T00:00:00Z vs 2026-01-02T03:20:00Z) |
| sai timestamp (ngoài miền năm 9999) | SELL-TPnull | PHAT_HIEN_DUNG | quá năm 9999, ts ≠ ts_ms | EVENTS[0] ts ≠ ts_ms (2026-01-02T03:05:00Z vs <ngoài miền: 100000000000000000000>) |
| sai ID (signal_id không tái lập) | SELL-TPnull | PHAT_HIEN_DUNG | không tái lập | SIGNAL ffffffffffffffff: signal_id không tái lập được từ (setup_id, trigger_ts_ms) |
| trùng sự kiện | SELL-TPnull | PHAT_HIEN_DUNG | trùng event_id | EVENTS: trùng event_id |
| trùng lệnh | SELL-TPnull | PHAT_HIEN_DUNG | trùng (signal_id, sim_rule, cost_model) | TRADES: trùng (signal_id, sim_rule, cost_model) |
| sai thứ tự (emit_seq ngược thời gian) | SELL-TPnull | PHAT_HIEN_DUNG | có ts_ms nhỏ hơn | EVENTS: emit_seq 2 có ts_ms nhỏ hơn emit_seq 1 |
| sai R (r_gross ≠ giá thoát) | SELL-TPnull | PHAT_HIEN_DUNG | /r_gross/×risk | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (lệch giá) | SELL-TPnull | PHAT_HIEN_DUNG | /r_gross/×risk, risk ≠ | TRADES[0] /r_gross/×risk ≠ /exit − entry/ |
| sai risk (nhất quán nội bộ bản ghi) | SELL-TPnull | PHAT_HIEN_DUNG | risk ≠ (entry − SL)×dir | TRADE 6048cc1b50ab6472: risk ≠ (entry − SL)×dir |
| sai outcome (đảo TP1 ↔ SL) | SELL-TPnull | PHAT_HIEN_DUNG | SL không gap, TP1 phải r_gross > 0, TP1 khi tín hiệu không có TP1 | TRADES[0] TP1 phải r_gross > 0 |
| sai hình học (SL sai phía) | SELL-TPnull | PHAT_HIEN_DUNG | SL không nằm phía rủi ro | SIGNALS[0] hình học: SL không nằm phía rủi ro của P_ref |
| sai vòng đời (CREATED → ARMED) | SELL-TPnull | PHAT_HIEN_DUNG | CREATED → ARMED | MÁY TRẠNG THÁI: aaaa000000000001: chuyển tiếp không hợp lệ CREATED → ARMED |
| sai vòng đời (sự kiện sau TRIGGER) | SELL-TPnull | PHAT_HIEN_DUNG | sau sự kiện kết thúc | EVENTS aaaa000000000001: có sự kiện sau sự kiện kết thúc hoặc nhiều sự kiện kết thúc |
| NaN | SELL-TPnull | PHAT_HIEN_DUNG | mfe_r: không hữu hạn | TRADES[0] mfe_r: không hữu hạn (nan) |
| Infinity | SELL-TPnull | PHAT_HIEN_DUNG | sl: không hữu hạn | SIGNALS[0] sl: không hữu hạn (inf) |
| −Infinity | SELL-TPnull | PHAT_HIEN_DUNG | anchor_price: không hữu hạn | EVENTS[0] anchor_price: không hữu hạn (-inf) |
| NO_FILL có R | SELL-TPnull | PHAT_HIEN_DUNG | NO_FILL: risk phải null | TRADES[0] NO_FILL: risk phải null |
| OPEN có thoát | SELL-TPnull | PHAT_HIEN_DUNG | OPEN: exit phải null | TRADES[0] OPEN: exit phải null |
| chi phí không khớp cost_model | SELL-TPnull | PHAT_HIEN_DUNG | chi phí (theo cost_model) | TRADES[0] r_gross − r_net ≠ chi phí (theo cost_model) / risk |
| rr_entry sai | SELL-TPnull | PHAT_HIEN_DUNG | rr_entry | TRADE 6048cc1b50ab6472: rr_entry có giá trị khi tín hiệu không có TP1 |
| lệnh cho tín hiệu bị bỏ (reason 15) | SELL-TPnull | PHAT_HIEN_DUNG | không đạt S1 | TRADE 6048cc1b50ab6472: tín hiệu không đạt S1 (reason 15) nhưng có TRADE |
| ID chéo seed (gộp hai bộ giống hệt) | SELL-TPnull | PHAT_HIEN_DUNG | trùng event_id, trùng emit_seq | EVENTS: trùng event_id |

## C. Độ bền bộ kiểm (KD-HD-FUZZ: PASS)

`{"so_ca": 20000, "bi_bac": 19265, "ngoai_le": 0}`
