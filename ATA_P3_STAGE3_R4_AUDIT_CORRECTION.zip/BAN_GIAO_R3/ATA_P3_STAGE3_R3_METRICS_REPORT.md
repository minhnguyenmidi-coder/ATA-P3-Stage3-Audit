# Báo cáo chỉ số – vòng 3

Kỳ vọng tính tay (vector_vang.M, KD-MET-R3) và oracle (oracle.chi_so) – không dùng code được kiểm để tính kỳ vọng.

| Test | Trạng thái | Assertion | Nội dung | Thực tế |
|---|---|---|---|---|
| KD-MET-ZERO | PASS | 22 | 0 lệnh đóng (chỉ OPEN, NO_FILL, NO_DATA, INVALID) | {"dong": 0, "net_r": 0.0, "expectancy": null, "win_rate": null, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THANG_THUA", "ty_le_tp1": null, "mo": 1,  |
| KD-MET-1WIN | PASS | 14 | 1 lệnh thắng TP1 +2 | {"dong": 1, "net_r": 2.0, "expectancy": 2.0, "win_rate": 1.0, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THUA", "ty_le_tp1": 1.0} |
| KD-MET-1LOSS | PASS | 12 | 1 lệnh thua SL −1 | {"dong": 1, "expectancy": -1.0, "win_rate": 0.0, "profit_factor": 0.0, "pf_trang_thai": "OK", "thua": 1} |
| KD-MET-1BE | PASS | 14 | 1 lệnh hòa vốn TIMEOUT 0 | {"dong": 1, "hoa_von": 1, "win_rate": 0.0, "win_rate_khong_hoa": null, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THANG_THUA", "expectancy": 0.0} |
| KD-MET-WINONLY | PASS | 12 | Chỉ thắng: TP1 +2, TIMEOUT +1,5 | {"net_r": 3.5, "expectancy": 1.75, "win_rate": 1.0, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THUA", "ty_le_tp1": 0.5} |
| KD-MET-LOSSONLY | PASS | 10 | Chỉ thua: −1, −1, TIMEOUT −0,5 | {"net_r": -2.5, "expectancy": -0.8333333333333334, "win_rate": 0.0, "profit_factor": 0.0, "pf_trang_thai": "OK"} |
| KD-MET-BEONLY | PASS | 8 | Chỉ hòa vốn ×2 | {"hoa_von": 2, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THANG_THUA", "win_rate": 0.0} |
| KD-MET-WINLOSS | PASS | 10 | +2, −1, −1 → net 0, PF 1,0, win 1/3 | {"net_r": 0.0, "expectancy": 0.0, "profit_factor": 1.0, "win_rate": 0.3333333333333333, "win_rate_khong_hoa": 0.3333333333333333} |
| KD-MET-WINBE | PASS | 8 | +2, 0 → win 0,5; win không hòa 1,0; PF null | {"win_rate": 0.5, "win_rate_khong_hoa": 1.0, "profit_factor": null, "pf_trang_thai": "KHONG_CO_LENH_THUA"} |
| KD-MET-LOSSBE | PASS | 6 | −1, 0 → win 0; win không hòa 0; PF 0 | {"win_rate": 0.0, "win_rate_khong_hoa": 0.0, "profit_factor": 0.0} |
| KD-MET-OPEN | PASS | 8 | OPEN không vào R: TP1 +2, OPEN +5 | {"dong": 1, "mo": 1, "net_r": 2.0, "expectancy": 2.0} |
| KD-MET-TIMEOUTWIN | PASS | 8 | TIMEOUT +0,5 là thắng nhưng không phải TP1; SL −1 | {"win_rate": 0.5, "ty_le_tp1": 0.0, "profit_factor": 0.5, "net_r": -0.5} |
| KD-MET-TP1NEG | PASS | 8 | TP1 sau chi phí −0,05 → thua, nhưng tỷ lệ TP1 = 1 | {"win_rate": 0.0, "thua": 1, "ty_le_tp1": 1.0, "profit_factor": 0.0} |
| KD-MET-TP1NULLMIX | PASS | 4 | Tín hiệu TP1 null kết thúc SL vẫn ở mẫu số tỷ lệ TP1: SL −1, TP1 +2 | {"ty_le_tp1": 0.5, "profit_factor": 2.0} |
| KD-MET-POSNET | PASS | 6 | Net dương: +3, −1 | {"net_r": 2.0, "expectancy": 1.0, "profit_factor": 3.0} |
| KD-MET-NEGNET | PASS | 4 | Net âm: +1, −1, −1 | {"net_r": -1.0, "profit_factor": 0.5} |
| KD-MET-PROP | PASS | 51780 | Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ kết cục, R = 0 đúng, chi phí âm sau TP1) – code = oracle trên mọi trường chung | "1.000 tập" |
| KD-MET-R3 | PASS | 14 | Golden bổ sung (tính tay): gross_r vs net_r có chi phí; MFE/MAE/giữ trung bình; đếm xung đột cùng nến và thoát gap; mẫu  | {"net_r": -1.3000000000000003, "gross_r": -1.0, "mfe_tb": 0.7999999999999999, "mae_tb": -1.0666666666666667, "xung_dot_cung_nen": 1, "thoat_gap": 1} |

Định nghĩa khóa: xem ATA_P3_STAGE3_CORRECTION_REPORT.md vòng 2, mục 3, và docstring chi_so.py (thêm gross_r ở vòng 3).
