# ATA P3 · STAGE 3 · ĐÁNH GIÁ ĐỘ ĐỘC LẬP CỦA ORACLE (Remediation vòng 3)

"Oracle" ở đây là bản tính lại kết quả dùng làm chuẩn so sánh với code đang kiểm.

**Kết luận ngắn:** `kiem_doc_lap/oracle.py` là một **bản hiện thực độc lập** (không chung code, cấu trúc thuật toán khác). Nhưng nó **không có đặc tả độc lập**: oracle, golden vectors và code đều do cùng một tác giả viết từ cùng một bản quy ước.

Vì vậy, sự trùng khớp giữa code và oracle chỉ chứng minh hai điều:
- (a) code hiện thực đúng quy ước đã viết;
- (b) không có lỗi lập trình nào chỉ có ở một bên.

Nó **không** chứng minh bản thân quy ước là đúng với thị trường hay với TradingView. Giới hạn này giữ nguyên trạng thái HYPOTHESIS cho mọi kết luận về thị trường.

## 1. So sánh thuật toán

| Khía cạnh | Code (`shadow_eval/mo_phong_lenh.py`) | Oracle (`kiem_doc_lap/oracle.py`) | Khác biệt cấu trúc? |
|---|---|---|---|
| BUY/SELL | Một vòng lặp, nhân `d` vào mọi phép so sánh | Đổi dấu giá (x → −x), chỉ có logic BUY; đổi High/Low khi d = −1 | CÓ: lỗi dấu riêng của SELL không thể giống nhau ở hai bên |
| MFE/MAE | Cập nhật dần trong vòng lặp; nến thoát xử lý bằng nhánh riêng | Gom "mẫu giá" rồi lấy max/min một lần; nến thoát chỉ thêm mẫu theo quy ước | CÓ (về thuật toán); CHUNG (về quy ước nến thoát) |
| R2 | Nhánh `cfg.entry` kiểm Open với SL/TP trước khi vào | Như code (cùng đặc tả) | KHÔNG: chung thứ tự kiểm |
| Kiểm dữ liệu | `nen_hong()` trả lý do | `_nen_ok()` trả bool | Cú pháp khác, cùng điều kiện |
| Chỉ số | Gom nhóm, tính PF/win/CI | Một nhóm, từ định nghĩa; không có CI | Một phần (CI không có oracle, dùng tính chất) |
| Lọc danh mục | Thuật toán tham lam theo khóa (entry, emit_seq, signal_id) | KHÔNG mô phỏng lại; kiểm 4 tính chất P1–P4 | CÓ: kiểm tính chất thay vì sao chép thuật toán |
| Khử trùng | Sắp theo emit_seq, giữ bản đầu | min emit_seq mỗi khóa (tập) | CÓ |

## 2. Phần dùng chung

| Loại | Dùng chung | Bằng chứng |
|---|---|---|
| Code / helper | **Không**. `oracle.py` và `vector_vang.py` chỉ import `math`; không import gì từ shadow_eval | KD-JSON quét AST; có thể kiểm tay dòng import |
| Cấu trúc dữ liệu | Có: nến dạng dict {t, o, h, l, c}; tín hiệu {dir, p_ref, sl, tp1} | Thiết kế hợp đồng |
| Hằng số | Có: EPS = 1e-9 (thắng/thua); BAR_MS 300 000 | Đều xuất phát từ đặc tả |
| Quy ước (đặc tả) | **Có, toàn bộ**: R1/R2, sl_first, quy tắc nến thoát MFE/MAE, max_bars đếm theo nến, NO_FILL khi Open ≥ TP1, INVALID khi TP1 sai phía | docstring mo_phong_lenh.py |
| Tác giả | Cùng tác giả | — |

## 3. Nguy cơ lỗi chung và biện pháp giảm

| # | Nguy cơ lỗi chung | Mức | Biện pháp đã có | Còn lại |
|---|---|---|---|---|
| 1 | Quy ước nến thoát MFE/MAE sai so với mong muốn của chủ dự án | TRUNG BÌNH | Ghi rõ bằng văn bản; golden tính tay; KD-FIRST kiểm cận theo nguyên lý đầu, KHÔNG dựa quy ước nến thoát (MFE ≥ mức có lợi của các nến trọn vẹn, MAE ≤ mức bất lợi của chúng) | Chủ dự án xác nhận quy ước |
| 2 | Thứ tự kiểm R2 (SL trước TP) giống nhau ở hai bên | THẤP | Hai điều kiện loại trừ nhau khi SL < giá vào < TP | — |
| 3 | sl_first là giả định | Đã công khai | Cờ same_bar_conflict, biến thể tp_first | Không có dữ liệu tick để xác minh |
| 4 | Golden do cùng tác giả tính, có thể chung hiểu lầm | TRUNG BÌNH | Phép tính ghi trong mô tả vector; tính chất (gương, không nhìn trước, nguyên lý đầu) không phụ thuộc người tính | Nên có người thứ hai kiểm 59 vector (RECOMMENDATION) |
| 5 | Oracle bỏ qua time_gaps (không tính khoảng trống thời gian) | THẤP | time_gaps kiểm riêng bằng OT-04 (hồi quy) | Oracle không phủ trường này |
| 6 | CI bootstrap không có oracle | TRUNG BÌNH | Kiểm tính chất: đối xứng phân vị (tính tay), tất định, không phụ thuộc thứ tự, khối rộng hơn khi tự tương quan, hữu hạn, tái lập giữa hai tiến trình, độ phủ CS-06 | Không có oracle số học cho CI |
| 7 | Máy trạng thái do cùng tác giả suy từ Pine | TRUNG BÌNH | Dẫn dòng 0.3.9 trong docstring; đầu ra engine thật (60 seed) đều thuộc bảng | Không có đặc tả chính thức ngoài Phase 1.5 |

## 4. Bằng chứng kiểm thử của oracle (lần chạy này)

| Kiểm | Kết quả |
|---|---|
| Oracle khớp 45 golden giả lập (KD-ORACLE-GOLD) | Xem ket_qua_doc_lap.json |
| Code = oracle trên 8.000 ca ngẫu nhiên, đủ 7 kết cục (KD-ORACLE-PROP) | 0 ca lệch |
| Gương BUY/SELL trên code và oracle (KD-MIRROR-GOLD) | 0 lệch |
| Nguyên lý đầu trên code, không dùng quy ước nến thoát (KD-FIRST) | 4.000 ca |
| Không nhìn trước, giá vào không hồi tố (KD-R1-NOLOOK, KD-ENTRY-RETRO) | PASS |
| Chỉ số: code = oracle trên 1.000 tập + 17 golden tính tay | PASS |
| Lọc danh mục: tính chất P1–P4 (KD-OCC-PROP, KD-F32) | PASS |
| Khử trùng: oracle tập (KD-DUP-PROP) | PASS |
| Kiểm đột biến mã nguồn: mỗi đột biến có test kỳ vọng khai báo trước | Xem bao_cao_dot_bien_nguon.json |

## 5. Phân loại

- Tuyên bố "oracle độc lập về **hiện thực**": FACT. Có thể kiểm bằng import và cấu trúc.
- Tuyên bố "oracle độc lập về **đặc tả**": **SAI**. Không được tuyên bố.
- Tính đúng của quy ước so với thị trường hoặc TradingView: HYPOTHESIS, BLOCKED (cần REPLAY-EQ và dữ liệu thật).
