# Danh sách NOT TESTED

| Test | Nội dung | Lý do |
|---|---|---|
| KD-REPLAY-FULL | Replay toàn script từ OHLCV (f_struct, MD-3/4/5, request.security, ta.*) | Chưa hiện thực – ngoài phạm vi (không xây full Pine interpreter) |
| REG:REPLAY-FULL | Replay toàn script từ OHLCV (f_struct, MD-3, MD-4, MD-5, request.security) | Chưa hiện thực – ngoài phạm vi nhiệm vụ (không tự xây full Pine interpreter) |
| REG:DL-REAL-FILE | Nhập file xuất thật từ TradingView / MT5 Exness | Chưa có file thật; định dạng được kiểm bằng file tổng hợp (DL-01, DL-02, DL-09) |
| REG:FUNNEL-REAL | Phễu SU-3/SU-5 trên dữ liệu thật | Phụ thuộc REPLAY-FULL và dữ liệu thật |
