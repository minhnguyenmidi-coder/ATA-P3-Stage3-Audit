# Tái hiện F28 – adapter bỏ STEP (kịch bản cô lập)

Test: **KD-F28-ADAPTER** – trạng thái **PASS**, 44 assertion, 2.2 ms, hash `32edbfab25bb3aa0`.

Mục tiêu: F28 (adapter CÔ LẬP, driver giả lập): 7 kịch bản nhiều chuyển tiếp cùng nến (CREATED/STEP/ARMED/TRIGGER/VOID/EXPIRED/END_NO_EVENT, trùng khóa) – (trước) adapter cũ cho chuỗi thiếu STEP; (sau) chuỗi ĐÚNG Y kỳ vọng, emit_seq tăng liên tục, cùng nến cùng ts, không trùng event_id, không mất sự kiện engine, máy trạng thái 0 lỗi

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_f28_adapter (dòng 1028)`

Kết quả thực tế (nguyên văn JSON):

```json
{
 "truoc_sai": [
  "A tạo + bước 2 cùng nến",
  "B tạo + bước 2 + ARMED cùng nến",
  "C tạo + STEP + ARMED + TRIGGER cùng nến",
  "D bước 2 rồi kết thúc không sự kiện cùng nến (IP-20)",
  "E bước 2 rồi VOID cùng nến",
  "G hai thể hiện trùng khóa: VOID thuộc bản bị gỡ"
 ],
 "truoc": {
  "A tạo + bước 2 cùng nến": {
   "x": [
    "CREATED"
   ]
  },
  "B tạo + bước 2 + ARMED cùng nến": {
   "x": [
    "CREATED",
    "ARMED"
   ]
  },
  "C tạo + STEP + ARMED + TRIGGER cùng nến": {
   "x": [
    "CREATED",
    "ARMED",
    "TRIGGER"
   ]
  },
  "D bước 2 rồi kết thúc không sự kiện cùng nến (IP-20)": {
   "x": [
    "CREATED",
    "END_NO_EVENT"
   ]
  },
  "E bước 2 rồi VOID cùng nến": {
   "x": [
    "CREATED",
    "VOID"
   ]
  },
  "F EXPIRED ở khối tiền-kích hoạt (st 0)": {
   "x": [
    "CREATED",
    "EXPIRED"
   ]
  },
  "G hai thể hiện trùng khóa: VOID thuộc bản bị gỡ": {
   "x1": [
    "CREATED",
    "END_NO_EVENT"
   ],
   "x2": [
    "CREATED",
    "VOID"
   ]
  }
 },
 "sau": {
  "A tạo + bước 2 cùng nến": {
   "x": [
    "CREATED",
    "STEP"
   ]
  },
  "B tạo + bước 2 + ARMED cùng nến": {
   "x": [
    "CREATED",
    "STEP",
    "ARMED"
   ]
  },
  "C tạo + STEP + ARMED + TRIGGER cùng nến": {
   "x": [
    "CREATED",
    "STEP",
    "ARMED",
    "TRIGGER"
   ]
  },
  "D bước 2 rồi kết thúc không sự kiện cùng nến (IP-20)": {
   "x": [
    "CREATED",
    "STEP",
    "END_NO_EVENT"
   ]
  },
  "E bước 2 rồi VOID cùng nến": {
   "x": [
    "CREATED",
    "STEP",
    "VOID"
   ]
  },
  "F EXPIRED ở khối tiền-kích hoạt (st 0)": {
   "x": [
    "CREATED",
    "EXPIRED"
   ]
  },
  "G hai thể hiện trùng khóa: VOID thuộc bản bị gỡ": {
   "x1": [
    "CREATED",
    "STEP",
    "END_NO_EVENT"
   ],
   "x2": [
    "CREATED",
    "STEP",
    "VOID"
   ]
  }
 }
}
```


# Tái hiện F28 / F28b – 60 seed engine thật

Test: **KD-F28-SEEDS** – trạng thái **PASS**, 124 assertion, 19320.2 ms, hash `fea4893b502511da`.

Mục tiêu: F28 trên 60 seed engine thật: (trước) adapter cũ vi phạm máy trạng thái; (sau) 0 vi phạm; bỏ mọi STEP khỏi chuỗi trước và sau → giống hệt, TRỪ các thể hiện mà chuỗi cũ tự vi phạm máy trạng thái (F28b: nhiều ARMED gán cho một thể hiện trùng khóa) – mọi khác biệt đó được lưu; mỗi thể hiện ≤ 1 STEP; lưu event trace trước/sau

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_f28_seeds (dòng 1050)`

Kết quả thực tế (nguyên văn JSON):

```json
{
 "seed": 60,
 "vi_pham_truoc": 373,
 "vi_pham_sau": 0,
 "the_hien_khac_ngoai_STEP": 3,
 "ghi_chu": "mọi khác biệt ngoài STEP đều là chuỗi cũ vi phạm (F28b)"
}
```

Event trace trước/sau (seed 0–4): `kiem_toan_r3/ket_qua/f28_event_trace_seed0_4.json`; các ca gán lại ARMED (F28b): `kiem_toan_r3/ket_qua/f28b_gan_ARMED_trung_khoa.json`.
