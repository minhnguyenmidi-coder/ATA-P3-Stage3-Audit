# Lỗi còn tồn tại / rủi ro còn lại

- Không còn lỗi code nào đã xác nhận mà chưa sửa (theo kết quả chạy thực: bộ độc lập {"PASS": 102, "BLOCKED": 6, "NOT TESTED": 1}).
- Rủi ro còn lại (không phải lỗi đã xác nhận): oracle không độc lập về đặc tả (O-1); thứ tự STEP trong nến và ghép thể hiện IP-21 là quy ước (B-4, F28b); CI bootstrap không có oracle số học; quy ước nến thoát MFE/MAE và sl_first chưa được xác nhận bằng dữ liệu tick; bộ GATE không gồm hồi quy.
- B-1…B-4 (quan sát Pine baseline) giữ nguyên – không sửa Pine.
