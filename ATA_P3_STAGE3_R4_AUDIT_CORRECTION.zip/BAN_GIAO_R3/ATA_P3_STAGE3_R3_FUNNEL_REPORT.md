# Báo cáo phễu – vòng 3

Mẫu số khóa trong `chi_so.MAU_SO` (dùng chung dashboard/báo cáo). Vòng 3: lệnh đã vào rồi mất dữ liệu được tính là ĐÃ VÀO (F35) và đếm riêng `vao_roi_mat_du_lieu`.

| Test | Trạng thái | Assertion | Thực tế |
|---|---|---|---|
| KD-FUNNEL | PASS | 26 | {"tao": 4, "armed": 2, "trigger": 4, "s1_dat": 2, "bo_quyen": 1, "bo_khac": 1, "trung": 1, "lenh_gia_lap": 5, "khong_khop": 1, "khong_du_lieu": 1, "khong_hop_le": 1, "da_vao": 2, "ty_le_armed": 0.5, "ty_le_void": 0.25, "ty_le_het_han": 0.25, "ty_le_ket_thuc_khong_su_kien": 0.25, "ty_le_trigger_tren_ |
| KD-FUNNEL-R3 | PASS | 9 | {"lenh_gia_lap": 5, "da_vao": 3, "vao_roi_mat_du_lieu": 1} |
| KD-F29 | PASS | 42 | {"bang_trang_thai": [{"fill_note": "NO_NEXT_BAR", "quy_tac": "next_open", "da_vao": false, "entry_price": null, "risk": null, "r": null, "bars_held": 0}, {"fill_note": "INVALID_BAR", "quy_tac": "next_open", "da_vao": false, "entry_price": null, "risk": null, "r": null, "bars_held": 0}, {"fill_note": |
