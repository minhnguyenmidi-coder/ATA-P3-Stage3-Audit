# ATA P3 · STAGE 3 · INDEPENDENT AUDIT REMEDIATION (vòng 3)

Sinh tự động từ kết quả chạy thực của vòng này (`kiem_toan_r3/ket_qua/`). Không dùng output cũ.

Baseline Pine (SHA-256 tính trực tiếp): 0.3.8 `79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13` · 0.3.9 `2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0` – không đổi.

## Kết quả chạy

- Bộ độc lập ĐẦY ĐỦ: {"PASS": 102, "BLOCKED": 6, "NOT TESTED": 1} · 109 test · 112562 assertion · 1096.6 s
- Bộ độc lập NHANH: {"PASS": 85} · 21924 assertion
- Hồi quy Stage 3 (88) trong cây sạch: {"PASS": 76, "FAIL": 3, "BLOCKED": 6, "NOT TESTED": 3}
- Đột biến mã nguồn: {"KILLED_EXPECTED": 42} / 42 · baseline {"rc": 0, "tom_tat": {"PASS": 100}, "so_test": 100, "so_assertion": 112502}
- Đột biến hợp đồng: {"PHAT_HIEN_DUNG": 116} / 116
- JSON strict: {"so_site": 30, "site_khong_strict": 0, "so_file_json": 150, "phan_loai_file": {"STRICT_OK": 148, "MIEN_LICH_SU": 2}, "mien": ["ket_qua_shadow_eval/ket_qua.json", "ket_qua_shadow_eval/ket_qua_truoc_sua.json"]}

## Kết luận từng nghi vấn của kiểm toán

| Nghi vấn | Kết luận sau tái hiện | Hành động |
|---|---|---|
| KD-HD-MUT tính ngoại lệ là phát hiện | NV1-a: **BÁC BỎ** – mã vòng 2 tính ngoại lệ là LỌT (test FAIL). NV1-b: **XÁC NHẬN** điểm yếu khác – không kiểm lý do bị bác (thông báo vô nghĩa vẫn PASS). Fuzz phát hiện lỗi thật F36 (bộ kiểm crash) | 7 lớp kết quả, chỉ PHÁT HIỆN ĐÚNG LÝ DO được tính; 4 fixture; fuzz 20.000 ca; sửa F36 |
| KD-JSON regex 3 dòng | NV2: **XÁC NHẬN** – báo nhầm lời gọi strict kéo dài > 3 dòng, bỏ sót bí danh; thêm: bỏ sót hoàn toàn json.dumps (8 lời gọi không strict, F37) | Quét AST; sửa 8 lời gọi; miễn lịch sử theo file+SHA+vị trí |
| KD-REG-S3 có thể đọc output cũ | NV3: **XÁC NHẬN** – subprocess hỏng (exit 3, không ghi gì) vẫn để runner vòng 2 đọc file cũ | Cây sạch + run_id + mtime + exit code + FAIL = đúng tập lỗi thời + REG-01/02 phải PASS; chạy lại bộ 0.3.9 mới. Chính cổng mới bắt được lỗi môi trường F38 |
| KD-MUT-SRC giết theo mã thoát | NV4: **XÁC NHẬN** – lỗi import được tính là 'killed' | Baseline sạch + ánh xạ test khai báo trước + phân loại; lỗi import → ENV_ERROR |
| MUT-01…05 (bộ Stage 3 vòng 1) | NV5: **XÁC NHẬN** – ngoại lệ tính là bắt được | Không sửa test cũ; thay bằng KD-MUT-SRC |
| F26 / F28 / F29 / F32 | Tái hiện được trên bản trước sửa; bản hiện tại đúng. Phát hiện thêm F28b (gán nhiều ARMED cho một thể hiện IP-21) và F35 (phễu) | Test tái hiện trước/sau |
| Oracle độc lập | Độc lập về hiện thực, KHÔNG độc lập về đặc tả | Báo cáo riêng; thêm KD-FIRST |

## Tiêu chí kết thúc (mục XVII)

| Tiêu chí | Trạng thái | Bằng chứng |
|---|---|---|
| Baseline sạch | ĐẠT | KD-BASELINE=PASS |
| Test mới chạy đầy đủ | ĐẠT | bộ độc lập đầy đủ: {"PASS": 102, "BLOCKED": 6, "NOT TESTED": 1}, 112562 assertion |
| Test cũ được xử lý có bằng chứng | ĐẠT | KD-REG-S3=PASS, KD-REPL-OT05=PASS, KD-REPL-OT06=PASS, KD-REPL-HD01S3=PASS, KD-REPL-CU-HD01=PASS, KD-REPL-CU-DUP01=PASS |
| KD-HD-MUT không tính ngoại lệ là killed | ĐẠT | KD-HD-MUT=PASS, KD-HD-FUZZ=PASS |
| KD-JSON strict được xác minh | ĐẠT | KD-JSON=PASS |
| KD-REG-S3 không dùng output cũ | ĐẠT | KD-REG-S3=PASS |
| KD-MUT-SRC có ánh xạ test | ĐẠT | KD-MUT-SRC=PASS |
| F26 tái hiện + xác minh | ĐẠT | KD-F26=PASS |
| F28 tái hiện + xác minh | ĐẠT | KD-F28-ADAPTER=PASS, KD-F28-SEEDS=PASS |
| F29 tái hiện + xác minh | ĐẠT | KD-F29=PASS |
| F32 tái hiện + xác minh | ĐẠT | KD-F32=PASS |
| Oracle độc lập được đánh giá | ĐẠT | KD-FIRST=PASS, KD-ORACLE-GOLD=PASS, KD-ORACLE-PROP=PASS |
| Chỉ số và phễu được xác minh | ĐẠT | KD-MET-ZERO=PASS, KD-MET-1WIN=PASS, KD-MET-1LOSS=PASS, KD-MET-1BE=PASS, KD-MET-WINONLY=PASS, KD-MET-LOSSONLY=PASS, KD-MET-BEONLY=PASS, KD-MET-WINLOSS=PASS, KD-MET-WINBE=PASS, KD-MET-LOSSBE=PASS, KD-MET-OPEN=PASS, KD-MET-TIMEOUTWIN=PASS, KD-MET-TP1NEG=PASS, KD-MET-TP1NULLMIX=PASS, KD-MET-POSNET=PASS, KD-MET-NEGNET=PASS, KD-MET-PROP=PASS, KD-MET-R3=PASS, KD-FUNNEL=PASS, KD-FUNNEL-R3=PASS |
| Manifest được tính lại | xem ATA_P3_STAGE3_R3_MANIFEST_VALIDATION.txt (sinh lúc đóng gói) | — |
| Package chạy lại được | xem log chạy lại từ gói giải nén | — |
| Điều chưa chứng minh được ghi rõ | ĐẠT | BLOCKED.md, NOT_TESTED.md, LOI_CON_TON_TAI.md, ORACLE_INDEPENDENCE.md |

## Phạm vi KHÔNG mở rộng (mục XIII)

Full Pine replay, đánh giá thị trường thật, REPLAY-EQ, token thật, compile TradingView: **chưa thực hiện – BLOCKED/NOT TESTED** (xem danh sách). Không thay bằng SYNTH.

## Tài liệu trong gói

FINDINGS_MATRIX.csv, TEST_MATRIX.csv, REPRO_F26/F28/F29/F32.md, ORACLE_INDEPENDENCE.md, REGRESSION_REPORT.md, MUTATION_REPORT.md, STRICT_JSON_REPORT.md, METRICS/FUNNEL/BOOTSTRAP_REPORT.md, BASELINE_HASHES.txt, SOURCE_HASHES.txt, MANIFEST_SHA256.txt + MANIFEST_VALIDATION.txt, DIFF.patch, FILE_KHONG_SUA.txt, TEST_KHONG_CHAY.md, BLOCKED.md, NOT_TESTED.md, LOI_CON_TON_TAI.md, OWNER_DECISIONS.md; log: kiem_toan_r3/log/ (đầy đủ, nhanh, baseline trước sửa, hồi quy 0.3.9), kiem_toan_r3/ket_qua/log_dot_bien_nguon.txt, kiem_toan_r3/ket_qua/hoi_quy/.
