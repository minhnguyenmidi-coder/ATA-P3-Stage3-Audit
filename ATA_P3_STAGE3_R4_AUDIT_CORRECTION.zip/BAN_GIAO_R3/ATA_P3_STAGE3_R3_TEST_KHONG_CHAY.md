# Test không chạy

Trong bộ độc lập đầy đủ, mọi test có thể chạy bằng code đều đã chạy. Không chạy: KD-REAL-XAU-SU3, KD-REAL-XAU-SU5, KD-REAL-BTC-SU3, KD-REAL-BTC-SU5, KD-REPLAY-EQ, KD-TV-TOKEN, KD-REPLAY-FULL (BLOCKED/NOT TESTED – xem hai danh sách tương ứng).

Chế độ GATE (dùng cho mỗi đột biến) cố ý không gồm KD-REG-S3 và KD-MUT-SRC; chế độ NHANH chỉ gồm test đánh dấu nhanh – đều có log riêng.
