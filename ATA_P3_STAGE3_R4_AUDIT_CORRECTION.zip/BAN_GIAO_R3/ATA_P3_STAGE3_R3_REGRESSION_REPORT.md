# Báo cáo hồi quy – vòng 3 (KD-REG-S3: PASS)

Run: `{"run_id": "7718adbc-b133-408d-b78f-fa39e9745d90", "exit": 1, "dem": {"PASS": 76, "FAIL": 3, "BLOCKED": 6, "NOT TESTED": 3, "ERROR": 0}, "fail": ["HD-01", "OT-05", "OT-06"], "lien_ket_loi_thoi_s3": {"OT-05": {"ly_do": "Assertion cũ đòi fill_note = INVALID_BAR cho nến hỏng SAU khi đã vào; vòng 2 tách trạng thái (F29) → INVALID_BAR_AFTER_FILL", "thay_the": "KD-REPL-OT05"}, "OT-06": {"ly_do": "Assertion cũ đòi NON_MONOTONIC_TIME; sau khi vào nay là NON_MONOTONIC_TIME_AFTER_FILL (F29)", "thay_the": "KD-REPL-OT06"}, "HD-01": {"ly_do": "Fixture cũ có CREATED → ARMED (thiếu STEP); máy trạng thái bác `

Bộ Stage 3 (88 test, KHÔNG sửa assertion) chạy trong bản sao cây sạch: {"PASS": 76, "FAIL": 3, "BLOCKED": 6, "NOT TESTED": 3}.

Bộ gốc (22 test) qua REG-01: chạy nguyên trạng dừng tại DUP-01; qua shim harness: {"PASS": 16, "FAIL": 2, "BLOCKED": 4}.

Bộ 0.3.9 chạy MỚI trong vòng này (bản sao /tmp/reg039, bắt đầu epoch 1795182943): {"PASS": 47, "BLOCKED": 7, "FAIL": 1, "NOT TESTED": 1}, 1027 s – so từng test với lần gốc qua REG-02.

## Test lỗi thời – lý do và test thay thế 1-1

### Bộ Stage 3 (88)

| Test cũ | Vì sao assertion lỗi thời | Test thay thế | Trạng thái thay thế |
|---|---|---|---|
| OT-05 | Assertion cũ đòi fill_note = INVALID_BAR cho nến hỏng SAU khi đã vào; vòng 2 tách trạng thái (F29) → INVALID_BAR_AFTER_FILL | KD-REPL-OT05 | PASS |
| OT-06 | Assertion cũ đòi NON_MONOTONIC_TIME; sau khi vào nay là NON_MONOTONIC_TIME_AFTER_FILL (F29) | KD-REPL-OT06 | PASS |
| HD-01 | Fixture cũ có CREATED → ARMED (thiếu STEP); máy trạng thái bác ĐÚNG MỘT lỗi này | KD-REPL-HD01S3 | PASS |

### Bộ gốc (22)

| Test cũ | Vì sao assertion lỗi thời | Test thay thế | Trạng thái thay thế |
|---|---|---|---|
| HD-01 | Bản ghi mẫu thiếu emit_seq (schema ≥ 1.1); bản ghi sai cũ kỳ vọng đúng 4 lỗi nhưng bộ kiểm dừng sớm ở outcome lạ | KD-REPL-CU-HD01 | PASS |
| E2E-01 | Fixture trigger_ts cố định sai (F17) + thiếu emit_seq | E2E-01 (Stage 3) + RP-03 + KD-SM-ENGINE | E2E-01 Stage 3: PASS |
| DUP-01 | Tín hiệu mẫu không có emit_seq; khu_trung từ chối đoán thứ tự (F2) → bộ cũ dừng tại đây khi chạy nguyên trạng | KD-REPL-CU-DUP01 | PASS |

Không có test cũ nào bị bỏ mà không có thay thế. 85/88 test Stage 3 và 20/22 test gốc chạy lại với kết quả không đổi so với lần trước (PASS/BLOCKED/NOT TESTED như cũ).

Log: `kiem_toan_r3/ket_qua/hoi_quy/stdout_kiem_thu_stage3.log`, `kiem_toan_r3/log/reg039_stdout.txt`.
