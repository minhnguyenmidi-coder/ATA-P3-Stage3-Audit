# Tái hiện nghi vấn của kiểm toán viên – trước sửa (runner Round 2) và sau sửa (runner mới)

Script: `kiem_toan_r3/tai_hien_nghi_van.py` (chạy trên cây cô lập có đúng mã gói Round 2 – SHA ở `kiem_toan_r3/log/baseline_truoc_sua_sha_module.txt`). Kết quả nguyên văn: `kiem_toan_r3/ket_qua/tai_hien_nghi_van.json`.

## Trước sửa (runner Round 2)

| Nghi vấn | Kết luận | Kịch bản và quan sát | Bằng chứng |
|---|---|---|---|
| NV1-a KD-HD-MUT: exception của validator có được tính là 'đã phát hiện'? | BÁC BỎ | validator luôn ném ngoại lệ → runner Round 2 cho KD-HD-MUT = FAIL (exception bị tính là KHÔNG phát hiện, không phải 'killed') | {"status": "FAIL", "actual": "NGOẠI LỆ: RuntimeError('validator crash có chủ đích')"} |
| NV1-b KD-HD-MUT: phát hiện SAI LÝ DO có bị tính là đạt? | XÁC NHẬN | validator vẫn bác đúng các bộ đột biến nhưng chỉ trả MỘT thông báo vô nghĩa (không nêu vi phạm nào) → runner Round 2 cho KD-HD-MUT = PASS: không kiểm lý do bị bác, nên một đột biến bị bắt vì lỗi KHÁC cũng được tính là đạt; không phân loại; fixture thiếu SELL-TPnull | {"status": "PASS", "actual": "{'so_dot_bien': 82, 'lot': []}"} |
| NV2 KD-JSON: regex giới hạn 3 dòng có bỏ sót / kết luận sai? | XÁC NHẬN | mẫu nguồn có 2 lời gọi: json.dump kéo dài 5 dòng (CÓ allow_nan=False ở dòng 5) và 'luu(x, f)' (bí danh của json.dump, KHÔNG strict). Logic Round 2 thấy {4: False} → báo nhầm lời gọi strict là không strict, và BỎ SÓT hoàn toàn lời gọi qua bí danh; json.dumps cũng không được quét | {"logic_r2_trong_runner": true, "ket_qua_regex": {"4": false}} |
| NV3 KD-REG-S3: có thể đọc output CŨ khi subprocess hỏng? | XÁC NHẬN | bộ Stage 3 bị thay bằng script thoát ngay (exit 3, không ghi gì) – file ket_qua_kiem_thu.json CŨ vẫn còn và runner Round 2 đọc đúng đường dẫn đó, không kiểm mtime/run_id/exit code → sẽ chấm trên kết quả cũ ({'PASS': 75, 'FAIL': 3, 'BLOCKED': 7, 'NOT TESTED': 3}) | {"doc_duong_dan_co_dinh": true, "co_kiem_mtime_hoac_run_id": false, "exit_subprocess": 3, "file_cu_con": true} |
| NV4 KD-MUT-SRC: lỗi import/môi trường có bị tính là 'killed'? | XÁC NHẬN | bản module có 'import mo_dun_khong_ton_tai_xyz' (lỗi import, KHÔNG phải đột biến logic) → runner nhanh Round 2 thoát mã 1; KD-MUT-SRC Round 2 xếp loại bằng 'p.returncode != 0' → sẽ tính là KILLED. Không có baseline sạch, không ánh xạ test | {"exit": 1, "xep_loai_theo_exit_code": true, "stderr_cuoi": "ModuleNotFoundError: No module named 'mo_dun_khong_ton_tai_xyz'"} |
| NV5 MUT-01…05 (bộ Stage 3 vòng 1): ngoại lệ được tính là 'bắt được'? | XÁC NHẬN | _dot_bien() ghi 'FAIL(ngoại lệ)' khi test ném ngoại lệ và MUT-0x coi mọi giá trị ≠ 'PASS' là bắt được. Không sửa test cũ (nguyên tắc 4–5); được THAY bằng KD-MUT-SRC (phân loại KILLED_EXPECTED / TEST_ERROR / ENV_ERROR) | {"dong": 954} |

## Sau sửa (runner mới, cùng kịch bản xấu)

| Nghi vấn | Kết quả | Phản ứng của runner mới |
|---|---|---|
| NV1 | ĐẠT | {"validator_crash": ["VALIDATOR_CRASH"], "thong_bao_vo_nghia": ["PHAT_HIEN_SAI_LY_DO"]} |
| NV2 | ĐẠT | [[4, "json.dump", true], [9, "json.dump", false]] |
| NV3 | ĐẠT | {"status": "FAIL", "actual": "assertion sai: subprocess không tạo output (exit 3)"} |
| NV4 | ĐẠT | {"rc": 1, "phan_loai": "ENV_ERROR"} |
