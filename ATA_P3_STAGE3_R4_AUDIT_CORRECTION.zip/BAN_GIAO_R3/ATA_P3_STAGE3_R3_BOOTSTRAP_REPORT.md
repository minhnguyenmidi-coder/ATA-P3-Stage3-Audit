# Báo cáo bootstrap – vòng 3

Phương pháp: i.i.d. (mốc) và moving-block vòng theo entry_ts (độ nhạy), L = round(n^(1/3)), B = 2.000 mặc định, độ tin cậy 95 %, phân vị đối xứng k = ⌊0,025·B⌋, seed = seed gốc + băm ổn định của (symbol, setup).

Tổng thể: lệnh ĐÓNG của một (symbol, setup). Giả định i.i.d. KHÔNG được mặc định là phù hợp: lệnh có thể phụ thuộc thời gian, chế độ thị trường, phiên, cụm; moving-block chỉ là độ nhạy cho phụ thuộc thời gian. Không có dữ liệu thật → không có tuyên bố thống kê nào về thị trường; mọi số liệu dưới đây là kiểm CƠ CHẾ trên dữ liệu tổng hợp.

| Test | Trạng thái | Assertion | Thực tế |
|---|---|---|---|
| KD-PCT | PASS | 4 | "4 giá trị B" |
| KD-BOOT | PASS | 7 | {"iid": [0.1, 0.85], "khoi_L10": [-0.5, 1.5], "ghi_chu": "chỉ kiểm cơ chế – không phải bằng chứng thống kê thị trường"} |
| KD-BOOT-R3 | PASS | 601 | {"tai_lap": [[[0.3789, 0.82994], "OK"], [[0.39444, 0.82318], "OK", 4]]} |
