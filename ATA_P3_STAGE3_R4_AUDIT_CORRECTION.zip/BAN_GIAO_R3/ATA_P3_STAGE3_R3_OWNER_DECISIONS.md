# Giả định cần chủ dự án quyết định

1. **F31 – R2 và RR tại giá vào.** Hiện: R2 KHÔNG chạy lại S1, ghi `rr_entry`. Lựa chọn: (a) giữ – R2 là biến thể đo độ nhạy thực thi; (b) R2 bỏ lệnh khi rr_entry < iRRMin (thêm NO_FILL lý do RR) – thay đổi chiến lược. Bằng chứng: G-R2-G (rr_entry 0,875). Không tự đổi.
2. **Vào đúng thời điểm thoát của lệnh trước** (lọc danh mục) → hiện bỏ (bảo thủ).
3. **NO_DATA sau khi vào** không chiếm vị thế trong lọc danh mục (kết quả không xác định) – thay thế: coi như OPEN (chiếm tới hết dữ liệu).
4. **sl_first** là quy ước mặc định khi cùng nến chạm SL và TP1.
5. **Quy ước nến thoát MFE/MAE** (xem docstring mo_phong_lenh.py).
6. **Nguồn sự kiện cho đánh giá thật** (Q-S3-1) và cung cấp dữ liệu (Q-S3-2), lịch nghỉ Exness (Q-S3-3).
7. **Gỡ mã chết / biến không đọc** ở Build sau (Q-S3-5) – hiện chỉ ghi nhận.
