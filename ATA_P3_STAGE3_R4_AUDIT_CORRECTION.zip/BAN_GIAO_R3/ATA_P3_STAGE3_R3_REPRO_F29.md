# Tái hiện F29 / F35 – NO_DATA trước/sau khi vào

Test: **KD-F29** – trạng thái **PASS**, 42 assertion, 2.3 ms, hash `245ece94618def0c`.

Mục tiêu: F29: bảng trạng thái NO_DATA trước/sau khi vào – (trước) bản cũ ghi INVALID_BAR cho cả hai; (sau) NO_NEXT_BAR / INVALID_BAR (chưa vào: entry_price null) và INVALID_BAR_AFTER_FILL / NON_MONOTONIC_TIME_AFTER_FILL (đã vào: entry_ts/entry_price giữ, risk/R/MFE/MAE/exit null, bars_held 0); vòng đời, hợp đồng, chỉ số (không vào R), phễu (đã vào + 'vào rồi mất dữ liệu'), oracle nhất quán

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_f29 (dòng 1083)`

Kết quả thực tế (nguyên văn JSON):

```json
{
 "bang_trang_thai": [
  {
   "fill_note": "NO_NEXT_BAR",
   "quy_tac": "next_open",
   "da_vao": false,
   "entry_price": null,
   "risk": null,
   "r": null,
   "bars_held": 0
  },
  {
   "fill_note": "INVALID_BAR",
   "quy_tac": "next_open",
   "da_vao": false,
   "entry_price": null,
   "risk": null,
   "r": null,
   "bars_held": 0
  },
  {
   "fill_note": "INVALID_BAR",
   "quy_tac": "close",
   "da_vao": false,
   "entry_price": null,
   "risk": null,
   "r": null,
   "bars_held": 0
  },
  {
   "fill_note": "INVALID_BAR_AFTER_FILL",
   "quy_tac": "close",
   "da_vao": true,
   "entry_price": 2000.0,
   "risk": null,
   "r": null,
   "bars_held": 0
  },
  {
   "fill_note": "NON_MONOTONIC_TIME_AFTER_FILL",
   "quy_tac": "close",
   "da_vao": true,
   "entry_price": 2000.0,
   "risk": null,
   "r": null,
   "bars_held": 0
  },
  {
   "fill_note": "INVALID_BAR_AFTER_FILL",
   "quy_tac": "close",
   "da_vao": true,
   "entry_price": 2000.0,
   "risk": null,
   "r": null,
   "bars_held": 0
  }
 ],
 "phieu": {
  "da_vao": 4,
  "vao_roi_mat_du_lieu": 3
 }
}
```


# Tái hiện Thay thế OT-05

Test: **KD-REPL-OT05** – trạng thái **PASS**, 13 assertion, 0.6 ms, hash `06fca6dc116118e2`.

Mục tiêu: Thay OT-05: cùng 3 kiểu nến hỏng (High < Low, NaN, giá ≤ 0) ở nến 1 sau khi R1 đã vào → NO_DATA INVALID_BAR_AFTER_FILL (giữ entry, R null); cùng nến hỏng làm nến vào của R2 → NO_DATA INVALID_BAR (chưa vào); nến hỏng SAU nến thoát → TP1; code = oracle

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_repl_ot05 (dòng 830)`

Kết quả thực tế (nguyên văn JSON):

```json
"3 kiểu × R1/R2 + sau thoát"
```


# Tái hiện Thay thế OT-06

Test: **KD-REPL-OT06** – trạng thái **PASS**, 8 assertion, 0.3 ms, hash `dfc9ec4c4ff74278`.

Mục tiêu: Thay OT-06: nến 3 trùng thời gian nến 2, và nến 3 lùi thời gian → NO_DATA NON_MONOTONIC_TIME_AFTER_FILL (R1 và R2); code = oracle

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_repl_ot06 (dòng 845)`

Kết quả thực tế (nguyên văn JSON):

```json
"trùng + lùi × R1/R2"
```
