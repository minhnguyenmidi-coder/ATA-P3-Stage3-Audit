# Tái hiện F32 – lọc danh mục phụ thuộc thứ tự

Test: **KD-F32** – trạng thái **PASS**, 20004 assertion, 138.4 ms, hash `e6cf9efc884e2130`.

Mục tiêu: F32: (trước) bản cũ giữ lệnh khác nhau khi đảo thứ tự hai lệnh trùng (entry_ts, emit_seq); (sau) khóa (entry_ts, emit_seq, signal_id): 400 tập ngẫu nhiên × 25 lần xáo trộn → cùng kết quả; signal_id trùng → ValueError; thời gian vẫn là ưu tiên số 1 (lệnh vào trước thắng dù emit_seq/signal_id lớn hơn); chéo symbol/setup, BUY/SELL, OPEN/NO_FILL/NO_DATA/INVALID

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_f32 (dòng 1118)`

Kết quả thực tế (nguyên văn JSON):

```json
{
 "truoc": "phụ thuộc thứ tự",
 "tap": 400,
 "xao_tron": 25
}
```


# Tái hiện Tính chất lọc danh mục

Test: **KD-OCC-PROP** – trạng thái **PASS**, 8000 assertion, 184.6 ms, hash `0a63c6b975b7c7bf`.

Mục tiêu: Thuộc tính: 1.000 tập lệnh ngẫu nhiên (đủ 7 kết cục, va chạm biên, chéo khóa) × 4 lần xáo trộn → thỏa P1–P4 của oracle và đầu ra không phụ thuộc thứ tự

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_occ_prop (dòng 389)`

Kết quả thực tế (nguyên văn JSON):

```json
"1.000 × 4"
```
