# Báo cáo JSON strict – vòng 3 (KD-JSON: PASS)

Phương pháp: phân tích AST mọi lời gọi `json.dump`/`json.dumps` (kể cả bí danh, from-import, **kwargs) trong phạm vi; quét TOÀN BỘ cây thư mục làm việc tìm *.json; parse strict với định vị từng giá trị không hữu hạn.

## Lời gọi tuần tự hóa

| File | Dòng | Hàm | Strict | Lý do nếu không |
|---|---|---|---|---|
| shadow_eval/pipeline.py | 23 | json.dump | True |  |
| shadow_eval/pipeline.py | 96 | json.dumps | True |  |
| shadow_eval/pipeline.py | 91 | json.dumps | True |  |
| shadow_eval/kiem_thu_stage3.py | 558 | json.dumps | True |  |
| shadow_eval/kiem_thu_stage3.py | 583 | json.dumps | True |  |
| shadow_eval/kiem_thu_stage3.py | 1101 | json.dump | True |  |
| shadow_eval/kiem_thu_stage3.py | 1041 | json.dump | True |  |
| shadow_eval/kiem_thu_stage3.py | 646 | json.dumps | True |  |
| shadow_eval/kiem_thu_stage3.py | 41 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 509 | json.dump | True |  |
| kiem_doc_lap/chay_doc_lap.py | 684 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 687 | json.dump | True |  |
| kiem_doc_lap/chay_doc_lap.py | 1077 | json.dump | True |  |
| kiem_doc_lap/chay_doc_lap.py | 1078 | json.dump | True |  |
| kiem_doc_lap/chay_doc_lap.py | 1358 | json.dump | True |  |
| kiem_doc_lap/chay_doc_lap.py | 1394 | json.dump | True |  |
| kiem_doc_lap/chay_doc_lap.py | 471 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 680 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 703 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 495 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 480 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 677 | json.dumps | True |  |
| kiem_doc_lap/chay_doc_lap.py | 60 | json.dumps | True |  |
| token_budget/cong_token.py | 224 | json.dump | True |  |
| kiem_toan_stage3/tao_bao_cao_test_v2.py | 40 | json.dumps | True |  |
| kiem_toan_stage3/tao_bao_cao_test_v2.py | 20 | json.dumps | True |  |
| kiem_toan_r3/tao_bao_cao_r3.py | 19 | json.dumps | True |  |
| kiem_toan_r3/tao_bao_cao_r3.py | 19 | json.dumps | True |  |
| kiem_toan_r3/tao_bao_cao_r3.py | 103 | json.dumps | True |  |
| kiem_toan_r3/dong_goi_r3.py | 66 | json.dumps | True |  |

## File .py ngoài phạm vi (kèm lý do)

| File | Lý do |
|---|---|
| shadow_eval/kiem_thu_shadow_eval.py | bộ test gốc – KHÔNG được sửa (quy tắc test cũ); đầu ra lịch sử được miễn từng file bên dưới |
| token_budget/mo_hinh_token.py | công cụ cũ vòng trước, thay bằng cong_token.py (F34) |
| shadow_eval/tao_capsule_stage3.py | công cụ capsule cũ, không ghi JSON |
| kiem_toan_stage3/dong_goi.py | công cụ đóng gói vòng 1, không ghi JSON |
| kiem_toan_stage3/tao_bao_cao_test.py | sinh báo cáo vòng 1, không ghi JSON |
| kiem_toan_stage3/bang_chung_truoc_sua.py | bằng chứng vòng 1 chạy trên bản TRƯỚC SỬA |

## Miễn lịch sử (đúng file + đúng SHA + đúng vị trí)

| File | SHA-256 | Vị trí | Giá trị | Lý do |
|---|---|---|---|---|
| ket_qua_shadow_eval/ket_qua.json | b47c7d0cf6cc9035827ffa2e8f982e6c006e2126a4ae73cdeeb824d9e7858077 | [['ket_qua', 14, 'actual', 'BTCUSD-SU5', 'profit_factor']] | Infinity | bản sao y hệt file trên (bộ test gốc ghi đè rồi được khôi phục) – cùng SHA |
| ket_qua_shadow_eval/ket_qua_truoc_sua.json | b47c7d0cf6cc9035827ffa2e8f982e6c006e2126a4ae73cdeeb824d9e7858077 | [['ket_qua', 14, 'actual', 'BTCUSD-SU5', 'profit_factor']] | Infinity | đầu ra bộ test gốc chạy trên bản TRƯỚC SỬA – bằng chứng F10 (PF = ∞); giữ nguyên |

## Tất cả file JSON đã quét

| File | Kết quả |
|---|---|
| BAN_GIAO_033/ket_qua_test_033.json | STRICT_OK |
| BAN_GIAO_033/kiem_thu_033.json | STRICT_OK |
| BAN_GIAO_033a/ket_qua_test_033a.json | STRICT_OK |
| BAN_GIAO_033a/kiem_thu_033.json | STRICT_OK |
| BAN_GIAO_034/bench_034.json | STRICT_OK |
| BAN_GIAO_034/ket_qua_test_034.json | STRICT_OK |
| BAN_GIAO_034/ket_qua_test_034a.json | STRICT_OK |
| BAN_GIAO_034/kiem_thu_034.json | STRICT_OK |
| BAN_GIAO_034/kiem_thu_034a.json | STRICT_OK |
| BAN_GIAO_034a_NT/nghiem_thu_034a.json | STRICT_OK |
| cong_tien_md6/ket_qua/KET_QUA_KIEM_THU.json | STRICT_OK |
| cong_tien_md6/ket_qua/du_lieu_A07_tac_dong.json | STRICT_OK |
| cong_tien_md6/ket_qua/du_lieu_Q2_D16.json | STRICT_OK |
| cong_tien_md6/ket_qua/so_tai_lieu.json | STRICT_OK |
| goi/fixtures/csv_gia_lap_postcompile/A.csv.manifest.json | STRICT_OK |
| goi/fixtures/csv_gia_lap_postcompile/B.csv.manifest.json | STRICT_OK |
| goi/fixtures/csv_gia_lap_postcompile/C.csv.manifest.json | STRICT_OK |
| goi/fixtures/csv_gia_lap_postcompile/D.csv.manifest.json | STRICT_OK |
| goi/fixtures/csv_gia_lap_postcompile/E.csv.manifest.json | STRICT_OK |
| goi/fixtures/csv_gia_lap_postcompile/V30.csv.manifest.json | STRICT_OK |
| goi/results/ban_do_phu_thuoc.json | STRICT_OK |
| goi/results/bang_nguon_pine.json | STRICT_OK |
| goi/results/cong_a.json | STRICT_OK |
| goi/results/cong_b.json | STRICT_OK |
| goi/results/do_mdead_du_khung.json | STRICT_OK |
| goi/results/ket_qua_test.json | STRICT_OK |
| goi/results/ket_qua_test_030.json | STRICT_OK |
| goi/results/ket_qua_test_032.json | STRICT_OK |
| goi/results/ket_qua_test_sau_compile.json | STRICT_OK |
| goi/results/kiem_dot_bien.json | STRICT_OK |
| goi/results/phan_loai_diff.json | STRICT_OK |
| goi/results/phan_loai_diff_031_032.json | STRICT_OK |
| goi/results/stress_A08.json | STRICT_OK |
| hoi_quy033/fixtures/csv_gia_lap_postcompile/A.csv.manifest.json | STRICT_OK |
| hoi_quy033/fixtures/csv_gia_lap_postcompile/B.csv.manifest.json | STRICT_OK |
| hoi_quy033/fixtures/csv_gia_lap_postcompile/C.csv.manifest.json | STRICT_OK |
| hoi_quy033/fixtures/csv_gia_lap_postcompile/D.csv.manifest.json | STRICT_OK |
| hoi_quy033/fixtures/csv_gia_lap_postcompile/E.csv.manifest.json | STRICT_OK |
| hoi_quy033/fixtures/csv_gia_lap_postcompile/V30.csv.manifest.json | STRICT_OK |
| hoi_quy033/results/ban_do_phu_thuoc.json | STRICT_OK |
| hoi_quy033/results/bang_nguon_pine.json | STRICT_OK |
| hoi_quy033/results/cong_a.json | STRICT_OK |
| hoi_quy033/results/cong_b.json | STRICT_OK |
| hoi_quy033/results/do_mdead_du_khung.json | STRICT_OK |
| hoi_quy033/results/ket_qua_test.json | STRICT_OK |
| hoi_quy033/results/ket_qua_test_030.json | STRICT_OK |
| hoi_quy033/results/ket_qua_test_032.json | STRICT_OK |
| hoi_quy033/results/ket_qua_test_033.json | STRICT_OK |
| hoi_quy033/results/ket_qua_test_033a.json | STRICT_OK |
| hoi_quy033/results/ket_qua_test_sau_compile.json | STRICT_OK |
| hoi_quy033/results/kiem_dot_bien.json | STRICT_OK |
| hoi_quy033/results/phan_loai_diff.json | STRICT_OK |
| hoi_quy033/results/phan_loai_diff_031_032.json | STRICT_OK |
| hoi_quy033/results/stress_A08.json | STRICT_OK |
| hoi_quy034/fixtures/csv_gia_lap_postcompile/A.csv.manifest.json | STRICT_OK |
| hoi_quy034/fixtures/csv_gia_lap_postcompile/B.csv.manifest.json | STRICT_OK |
| hoi_quy034/fixtures/csv_gia_lap_postcompile/C.csv.manifest.json | STRICT_OK |
| hoi_quy034/fixtures/csv_gia_lap_postcompile/D.csv.manifest.json | STRICT_OK |
| hoi_quy034/fixtures/csv_gia_lap_postcompile/E.csv.manifest.json | STRICT_OK |
| hoi_quy034/fixtures/csv_gia_lap_postcompile/V30.csv.manifest.json | STRICT_OK |
| hoi_quy034/results/ban_do_phu_thuoc.json | STRICT_OK |
| hoi_quy034/results/bang_nguon_pine.json | STRICT_OK |
| hoi_quy034/results/cong_a.json | STRICT_OK |
| hoi_quy034/results/cong_b.json | STRICT_OK |
| hoi_quy034/results/do_mdead_du_khung.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_030.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_032.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_033.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_033a.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_034.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_034a.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_035.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_035e.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_035f.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_036.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_037.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_038.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_039.json | STRICT_OK |
| hoi_quy034/results/ket_qua_test_sau_compile.json | STRICT_OK |
| hoi_quy034/results/kiem_dot_bien.json | STRICT_OK |
| hoi_quy034/results/phan_loai_diff.json | STRICT_OK |
| hoi_quy034/results/phan_loai_diff_031_032.json | STRICT_OK |
| hoi_quy034/results/stress_A08.json | STRICT_OK |
| ket_qua033/kiem_thu_033.json | STRICT_OK |
| ket_qua034/bench_034.json | STRICT_OK |
| ket_qua034/kiem_thu_033.json | STRICT_OK |
| ket_qua034/kiem_thu_034.json | STRICT_OK |
| ket_qua034a/kiem_thu_033.json | STRICT_OK |
| ket_qua034a/kiem_thu_034a.json | STRICT_OK |
| ket_qua034a_nt/P5_H1_va_dot_bien_erf.json | STRICT_OK |
| ket_qua034a_nt/bench_dai.json | STRICT_OK |
| ket_qua034a_nt/do_luong_token.json | STRICT_OK |
| ket_qua034a_nt/do_phu_md5.json | STRICT_OK |
| ket_qua034a_nt/dot_bien_erf_H1_dung.json | STRICT_OK |
| ket_qua034a_nt/dot_bien_erf_khoi_dong_muon.json | STRICT_OK |
| ket_qua034a_nt/ma_thua.json | STRICT_OK |
| ket_qua034a_nt/ma_tran_tac_dong.json | STRICT_OK |
| ket_qua034a_nt/nghiem_thu_034a.json | STRICT_OK |
| ket_qua034a_nt/r7_doi_thoi_diem.json | STRICT_OK |
| ket_qua034a_nt/r7_mo_hinh.json | STRICT_OK |
| ket_qua034a_nt/song_song.json | STRICT_OK |
| ket_qua034a_nt/song_song_bo_sung.json | STRICT_OK |
| ket_qua034a_nt/song_song_bo_sung_bat_kip_day.json | STRICT_OK |
| ket_qua034a_nt/song_song_bo_sung_hai_phia.json | STRICT_OK |
| ket_qua034a_nt/trang_thai_suy_giam.json | STRICT_OK |
| ket_qua034a_nt/vong_doi.json | STRICT_OK |
| ket_qua035/dot_bien_035.json | STRICT_OK |
| ket_qua035/ket_qua_035.json | STRICT_OK |
| ket_qua035/ket_qua_035b.json | STRICT_OK |
| ket_qua035/ket_qua_035c.json | STRICT_OK |
| ket_qua035/ket_qua_035d.json | STRICT_OK |
| ket_qua035/ket_qua_035e.json | STRICT_OK |
| ket_qua035/ket_qua_035f.json | STRICT_OK |
| ket_qua035/ket_qua_036.json | STRICT_OK |
| ket_qua035/ket_qua_037.json | STRICT_OK |
| ket_qua035/kiem_toan_035e.json | STRICT_OK |
| ket_qua038/cong_token_md8.json | STRICT_OK |
| ket_qua038/ket_qua_038.json | STRICT_OK |
| ket_qua038/ma_thua_037.json | STRICT_OK |
| ket_qua038b/ATA_P3_Build_0.3.8_Supplemental_Test_Results.json | STRICT_OK |
| ket_qua038b/truoc/ket_qua_038.json | STRICT_OK |
| ket_qua038b/truoc/ket_qua_test_038.json | STRICT_OK |
| ket_qua039/hoi_quy_bo_038_tren_039/ket_qua_038.json | STRICT_OK |
| ket_qua039/ket_qua_039.json | STRICT_OK |
| ket_qua_shadow_eval/ket_qua.json | MIEN_LICH_SU |
| ket_qua_shadow_eval/ket_qua_truoc_sua.json | MIEN_LICH_SU |
| ket_qua_stage3/doc_lap/ket_qua_doc_lap.json | STRICT_OK |
| ket_qua_stage3/hoi_quy_bo_cu_tren_module_moi.json | STRICT_OK |
| ket_qua_stage3/ket_qua_kiem_thu.json | STRICT_OK |
| ket_qua_stage3/o_BTCUSD_SU3/bao_cao_o.json | STRICT_OK |
| ket_qua_stage3/o_BTCUSD_SU3/synth_kiem_duong_ong.json | STRICT_OK |
| ket_qua_stage3/o_BTCUSD_SU5/bao_cao_o.json | STRICT_OK |
| ket_qua_stage3/o_BTCUSD_SU5/synth_kiem_duong_ong.json | STRICT_OK |
| ket_qua_stage3/o_XAUUSD_SU3/bao_cao_o.json | STRICT_OK |
| ket_qua_stage3/o_XAUUSD_SU3/synth_kiem_duong_ong.json | STRICT_OK |
| ket_qua_stage3/o_XAUUSD_SU5/bao_cao_o.json | STRICT_OK |
| ket_qua_stage3/o_XAUUSD_SU5/synth_kiem_duong_ong.json | STRICT_OK |
| ket_qua_stage3/token_gate/token_gate.json | STRICT_OK |
| ket_qua_stage3/tong_hop_4_o.json | STRICT_OK |
| kiem_toan_r3/baseline_truoc_sua/ket_qua_doc_lap.json | STRICT_OK |
| kiem_toan_r3/ket_qua/bang_dot_bien_hop_dong.json | STRICT_OK |
| kiem_toan_r3/ket_qua/tai_hien_nghi_van.json | STRICT_OK |
| kiem_toan_r3/ket_qua_nhanh/bang_dot_bien_hop_dong.json | STRICT_OK |
| kiem_toan_r3/ket_qua_nhanh/ket_qua_doc_lap.json | STRICT_OK |
| kiem_toan_r3/log/dot_bien_xem_truoc_1.json | STRICT_OK |
| kiem_toan_r3/log/reg039_ket_qua_039.json | STRICT_OK |
| kiem_toan_stage3/bang_chung_truoc_sua.json | STRICT_OK |
| token_budget/mo_hinh_token.json | STRICT_OK |
| token_budget/quan_sat_compile.json | STRICT_OK |
