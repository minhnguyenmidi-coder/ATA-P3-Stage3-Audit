# Danh sách BLOCKED

| Test | Nội dung | Lý do / điều kiện mở khóa |
|---|---|---|
| KD-REAL-XAU-SU3 | Đánh giá SU-3 dữ liệu thật XAUUSD | Không có OHLCV lịch sử có nguồn (mạng của công cụ tắt) và chưa có replay bối cảnh từ OHLCV |
| KD-REAL-XAU-SU5 | Đánh giá SU-5 dữ liệu thật XAUUSD | Như trên |
| KD-REAL-BTC-SU3 | Đánh giá SU-3 dữ liệu thật BTCUSD | Như trên |
| KD-REAL-BTC-SU5 | Đánh giá SU-5 dữ liệu thật BTCUSD | Như trên |
| KD-REPLAY-EQ | Tương đương Python ↔ TradingView | Không có dữ liệu đối chứng; Data Window chỉ giữ một phần sự kiện SHADOW (B-1) |
| KD-TV-TOKEN | Token biên dịch thật 0.3.9 | TradingView không in số token khi compile thành công |
| REG:REAL-XAU-SU3 | Đánh giá SU-3 trên dữ liệu thật XAUUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| REG:REAL-XAU-SU5 | Đánh giá SU-5 trên dữ liệu thật XAUUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| REG:REAL-BTC-SU3 | Đánh giá SU-3 trên dữ liệu thật BTCUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| REG:REAL-BTC-SU5 | Đánh giá SU-5 trên dữ liệu thật BTCUSD | Không có OHLCV lịch sử (mạng tắt, chưa được cung cấp) VÀ replay toàn script từ OHLCV chưa hiện thực |
| REG:REPLAY-EQ | Python replay ↔ TradingView | Chưa có dữ liệu đối chứng từ TradingView; Data Window chỉ chứa một phần sự kiện SHADOW (K.5) – không tuyên bố PASS |
| REG:TV-TOKEN | Token biên dịch thật của 0.3.9 | TradingView không in số token khi compile thành công |

Điều kiện mở khóa chung: (1) file OHLCV M5 lịch sử có nguồn (TradingView export hoặc MT5 Exness + độ lệch giờ máy chủ); (2) quyết định nguồn sự kiện (replay toàn script hoặc kênh xuất từ TradingView); (3) dữ liệu đối chứng TradingView cho REPLAY-EQ; (4) token thật chỉ biết khi TradingView báo lỗi kèm số. Proxy mạng chặn nguồn dữ liệu: `ket_qua_stage3/log/thu_mang_du_lieu_that.txt`.
