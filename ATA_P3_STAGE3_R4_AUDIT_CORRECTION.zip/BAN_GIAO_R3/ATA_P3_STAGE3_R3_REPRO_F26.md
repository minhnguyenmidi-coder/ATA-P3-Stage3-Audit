# Tái hiện F26 – khử trùng trước lọc S1

Test: **KD-F26** – trạng thái **PASS**, 58 assertion, 1068.2 ms, hash `87353ab5fdcd96ab`.

Mục tiêu: F26: (trước) mã pipeline cũ khử trùng trên MỌI tín hiệu rồi mới lọc S1 → cặp [lý do 1 phát trước, lý do 16 phát sau] cho 0 lệnh; (sau) chon_tin_hieu_lenh: 9 ca – một bị S1 loại, hai cùng lý do 16, hai khác lý do bị bỏ, khác chiều, khác setup, khác emit_seq, khác signal_id, xáo trộn, chéo seed – đúng giữ/bỏ; lọc danh mục không đổi kết quả khử trùng

Nguồn: `kiem_doc_lap/chay_doc_lap.py::t_f26 (dòng 925)`

Kết quả thực tế (nguyên văn JSON):

```json
{
 "truoc": "0 lệnh (mất tín hiệu đạt S1)",
 "sau_so_ca": 9,
 "xao_tron": 6
}
```
