# Báo cáo Shadow – ô XAUUSD-SU3

**Kết luận thị trường thật:** BLOCKED – chưa đánh giá hiệu quả thị trường thật

| Bước | Trạng thái | Chi tiết |
|---|---|---|
| 1 nhập | BLOCKED | không có file OHLCV lịch sử trong môi trường (mạng tắt; chưa được cung cấp) |
| 2 kiểm OHLCV | BLOCKED | phụ thuộc bước trước |
| 3 chuẩn hóa | BLOCKED | phụ thuộc bước trước |
| 4 replay engine | BLOCKED | Replay toàn script từ OHLCV chưa hiện thực: f_struct (gọi qua 4 lệnh request.security M15/H1/H4/D), 4 lệnh request.security lấy giá kỳ D/W/M/12M, MD-3 dựng vùng, MD-4 cụm, MD-5 pool, ta.* chưa có trong Python – chỉ các khối SHADOW/S1/ARMED chạy nguyên văn với bối cảnh tiêm sẵn |
| 5 EVENTS/SIGNALS | BLOCKED | phụ thuộc bước 4 |
| 6 khử trùng | BLOCKED | phụ thuộc bước 4 |
| 7 giả lập lệnh | BLOCKED | phụ thuộc bước 4 |
| 8 TRADES + kiểm hợp đồng | BLOCKED | phụ thuộc bước 4 |
| 9 chỉ số + phễu | BLOCKED | phụ thuộc bước 4 |

## Kiểm đường ống trên SYNTH (KHÔNG phải hiệu quả chiến lược)

Bối cảnh vùng/cụm/sự kiện cấu trúc được tiêm ngẫu nhiên, giá là bước ngẫu nhiên. Số liệu dưới đây chỉ chứng minh chuỗi chạy đúng hợp đồng.

- Sự kiện: 1478; tín hiệu: 0; lệnh giả lập: 0; loại trùng (IP-21): 0; bỏ do chồng lấn (biến thể danh mục): 0; lỗi hợp đồng: 0
- Phễu: `{"tao": 730, "armed": 3, "void": 337, "het_han": 0, "gap_bo": 0, "ket_thuc_khong_su_kien": 185, "trigger": 0, "s1_dat": 0, "bo_quyen": 0, "bo_khac": 0, "trung": 0, "lenh_gia_lap": 0, "khong_khop": 0, "khong_du_lieu": 0, "khong_hop_le": 0, "da_vao": 0, "ty_le_armed": 0.00410958904109589, "ty_le_void": 0.46164383561643835, "ty_le_het_han": 0.0, "ty_le_ket_thuc_khong_su_kien": 0.2534246575342466, "ty_le_trigger_tren_armed": 0.0, "ty_le_s1_dat": null, "ty_le_bo_quyen": null, "ty_le_bo_khac": null, "ty_le_trung": null, "ty_le_khong_khop": null, "ty_le_khong_du_lieu": null, "ty_le_khong_hop_le": null, "ty_le_da_vao": null, "mau_so": {"ty_le_armed": "armed / tao", "ty_le_void": "void / tao", "ty_le_het_han": "het_han / tao", "ty_le_ket_thuc_khong_su_kien": "ket_thuc_khong_su_kien / tao", "ty_le_trigger_tren_armed": "trigger / armed", "ty_le_s1_dat": "s1_dat / trigger", "ty_le_bo_quyen": "bo_quyen / trigger", "ty_le_bo_khac": "bo_khac / trigger", "ty_le_trung": "trung / trigger", "ty_le_khong_khop": "khong_khop / lenh_gia_lap", "ty_le_khong_du_lieu": "khong_du_lieu / lenh_gia_lap", "ty_le_khong_hop_le": "khong_hop_le / lenh_gia_lap", "ty_le_da_vao": "da_vao / lenh_gia_lap"}}`
- Chỉ số: không có lệnh (SYNTH không sinh trigger cho setup này)
