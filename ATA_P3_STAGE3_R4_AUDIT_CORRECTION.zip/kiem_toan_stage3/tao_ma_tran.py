# -*- coding: utf-8 -*-
"""Sinh ATA_P3_STAGE3_FINDINGS_MATRIX.csv: mọi finding (F1–F34, B-1…B-4) + mọi test của các báo cáo trước (bộ cũ 22, bộ Stage 3 88) với trạng thái CHẠY LẠI.
'Kết quả' lấy từ kết quả chạy thực (ket_qua_doc_lap.json, ket_qua_kiem_thu.json, hoi_quy_bo_cu_tren_module_moi.json); hash tính trực tiếp."""
import csv, hashlib, json, os, sys
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(G, "BAN_GIAO_STAGE3C", "ATA_P3_STAGE3_FINDINGS_MATRIX.csv")
J = lambda *p: os.path.join(G, *p)      # noqa: E731
KD = {x["test_id"]: x["status"] for x in json.load(open(J("ket_qua_stage3", "doc_lap", "ket_qua_doc_lap.json"), encoding="utf-8"))["ket_qua"]}
S3 = {x["test_id"]: x for x in json.load(open(J("ket_qua_stage3", "ket_qua_kiem_thu.json"), encoding="utf-8"))["ket_qua"]}
CU_TRUOC = {x["test_id"]: x for x in json.load(open(J("ket_qua_shadow_eval", "ket_qua_truoc_sua.json"), encoding="utf-8"))["ket_qua"]}
CU_NAY = {x["test_id"]: x for x in json.load(open(J("ket_qua_stage3", "hoi_quy_bo_cu_tren_module_moi.json"), encoding="utf-8"))["chay_b_shim"]}


def sha(p):
    return hashlib.sha256(open(J(p), "rb").read()).hexdigest() if os.path.exists(J(p)) else "KHÔNG CÓ FILE"


def ket(tests):
    st = [KD.get(t) or (S3[t]["status"] if t in S3 else None) for t in tests]
    st = [s for s in st if s]
    if not st:
        return "NOT TESTED"
    for s in ("FAIL", "BLOCKED", "NOT TESTED"):
        if s in st:
            return s
    return "PASS"


MP, HDp, CSp, CH, PL, MT = "shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py", "shadow_eval/chuan_hoa.py", "shadow_eval/pipeline.py", "shadow_eval/may_trang_thai.py"
P39 = "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine"
# (ID, nội dung, evidence, trước sửa, hiện tại, kết luận, hành động, tests, file, phân loại)
F = [
    ("F1", "NO_FILL (exit null) chặn (symbol, setup) vĩnh viễn trong khong_chong", "bang_chung_truoc_sua.json#F1: giữ 1/bỏ 2", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "chỉ lệnh đã vào chiếm vị thế", ["KD-OCC-GOLD", "KD-OCC-PROP", "KD-MUT-SRC"], MP, "FACT"),
    ("F2", "khu_trung giữ bản theo băm signal_id thay vì thứ tự phát", "#F2: giữ bản phát sau", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "khử trùng theo emit_seq, thiếu/trùng → ValueError", ["KD-DUP-GOLD", "KD-DUP-PROP", "KD-MUT-SRC"], MP, "FACT"),
    ("F3", "tp_first: MAE không cập nhật khi nến chạm cả SL và TP1", "#F3: MAE 0", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "quy tắc nến thoát thống nhất", ["KD-GOLD-R1-SB-TP", "KD-GOLD-S-SB-TP", "KD-ORACLE-PROP", "KD-MUT-SRC"], MP, "FACT"),
    ("F4", "R2: Open vượt TP1 vẫn khớp, ra TP1 với R âm", "#F4: TP1, R −0,25", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "NO_FILL GAP_BEYOND_TP", ["KD-GOLD-R2-D", "KD-GOLD-R2-D-EQ", "KD-GOLD-S-R2-D", "KD-MUT-SRC"], MP, "FACT"),
    ("F5", "Rủi ro ≤ 0 → NO_FILL với risk giả", "#F5: risk 1,0", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "INVALID + fill_note, R null", ["KD-GOLD-R1-INVRISK", "KD-GOLD-R2-K", "KD-GOLD-EXTRA"], MP, "FACT"),
    ("F6", "R2 không có nến kế bị gán NO_FILL", "#F6", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "NO_DATA NO_NEXT_BAR", ["KD-GOLD-R2-J"], MP, "FACT"),
    ("F7", "Không báo khoảng trống thời gian giữa nến", "#F7", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "time_gaps, max_gap_ms; max_bars đếm theo nến (ASSUMPTION ghi rõ)", ["OT-04"], MP, "FACT"),
    ("F8", "Không kiểm nến hỏng", "#F8: OPEN R 0,2 trên nến High<Low", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "NO_DATA INVALID_BAR / …_AFTER_FILL", ["KD-GOLD-R1-BADBAR", "KD-GOLD-R2-L", "KD-ORACLE-PROP"], MP, "FACT"),
    ("F9", "Phân vị bootstrap lệch khi 0,025·B không nguyên", "#F9: B=10 → (0, 8)", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "k = ⌊α/2·B⌋ số nguyên, đối xứng", ["KD-PCT", "KD-MUT-SRC"], CSp, "FACT"),
    ("F10", "Profit factor = Infinity → JSON không hợp lệ", "#F10; hiện vật lịch sử ket_qua_truoc_sua.json chứa Infinity", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "PF null + pf_trang_thai", ["KD-MET-1WIN", "KD-MET-WINONLY", "KD-JSON", "KD-MUT-SRC"], CSp, "FACT"),
    ("F10b", "R = 0 bị tính là thua", "#F10b", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "thắng > 0, thua < 0, hòa vốn riêng", ["KD-MET-1BE", "KD-MET-WINBE", "KD-MET-LOSSBE", "KD-MUT-SRC"], CSp, "FACT"),
    ("F11", "Phễu 'trung' không được tính", "#F11", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "đếm theo dup_key; mẫu số khóa", ["KD-FUNNEL", "KD-MUT-SRC"], CSp, "FACT"),
    ("F12", "Hợp đồng không chặn NaN/∞, bars_held âm, exit trước entry", "#F12: 0 lỗi", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "kiểm hữu hạn + quy tắc theo outcome", ["KD-HD-MUT", "KD-MUT-SRC"], HDp, "FACT"),
    ("F13", "Không kiểm ts↔ts_ms, hình học SL/TP", "#F13", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "kiểm ts↔ts_ms, hình học, rr, dup_key", ["KD-HD-MUT"], HDp, "FACT"),
    ("F14", "Ngày không tồn tại được chấp nhận", "#F14", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "strptime lịch thật", ["HD-04", "KD-HD-MUT"], HDp, "FACT"),
    ("F15", "Không có kiểm cấp bảng", "#F15", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "kiem_bang + máy trạng thái", ["KD-HD-MUT", "KD-HD-VALID"], HDp, "FACT"),
    ("F16", "Schema 1.0 buộc risk/R > 0 cả khi không vào", "schema 1.0", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "ngoại lệ theo outcome (1.1/1.2)", ["KD-HD-VALID"], HDp, "FACT"),
    ("F17", "E2E cũ dùng trigger_ts cố định sai", "kiem_thu_shadow_eval.py:175", "LỖI TEST", "phân loại lỗi thời", "LỖI THẬT (test) – THAY THẾ", "không sửa test cũ; E2E mới", ["REG-01", "KD-REG-S3", "E2E-01"], "shadow_eval/kiem_thu_shadow_eval.py", "FACT"),
    ("F18", "Kết quả test thiếu metadata", "rec() cũ", "THIẾU", "đã bổ sung", "LỖI THẬT – ĐÃ SỬA", "metadata đủ trong 2 bộ mới", ["KD-BASELINE"], "kiem_doc_lap/chay_doc_lap.py", "FACT"),
    ("F19", "SHA256SUMS tự tham chiếu", "dòng e3b0c442… trong gói trước", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "manifest không tự liệt kê; kiểm sau đóng gói", ["MANIFEST-CHECK"], "kiem_toan_stage3/dong_goi.py", "FACT"),
    ("F20", "Mô hình 'sec8' giả định 8 bản f_struct (thực tế 4 lệnh gọi)", "dòng 1003–1006 vs 1716–1719", "SAI GIẢ ĐỊNH", "đã thay bằng gate đa mô hình", "LỖI THẬT (kết luận) – ĐÃ SỬA", "khoảng ước lượng + bất định", ["TG-02", "TG-04"], "token_budget/cong_token.py", "FACT"),
    ("F21", "Tài liệu ghi lastMssM15 được đọc (sai)", "grep 0.3.9: 1124/1133/2680 chỉ ghi", "SAI TÀI LIỆU", "đã đính chính", "LỖI THẬT (tài liệu) – ĐÃ SỬA", "gate liệt kê ứng viên", ["TG-01"], "token_budget/cong_token.py", "FACT"),
    ("F22", "pine_mini: % theo ngữ nghĩa Python với số âm", "pine_mini.num_op", "GIỚI HẠN", "giữ nguyên", "KHÔNG ẢNH HƯỞNG khối đã verify", "ghi phạm vi UNSUPPORTED", [], "kiem_toan034a/pine_mini.py", "FACT"),
    ("F23", "PIPE dùng chỉ số sổ giản lược", "kiem_cach_ly.PIPE", "GIỚI HẠN", "giữ nguyên", "PARTIALLY VERIFIED", "ghi phạm vi", ["RP-02"], "kiem_toan039/kiem_cach_ly.py", "FACT"),
    ("F24", "Ip39 không có request.security / ta.* / lịch sử biến người dùng", "khung039", "GIỚI HẠN", "giữ nguyên", "BLOCKED cho replay toàn script", "ghi phạm vi", ["KD-REPLAY-FULL"], "kiem_toan039/khung039.py", "FACT"),
    ("F25", "Gộp seed: dup_key và lọc danh mục chéo seed", "phễu 28 vs 9; bỏ 17 vs 5", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "tiền tố seed; lọc riêng seed", ["KD-DUP-SEED", "E2E-01"], PL, "FACT"),
    ("F26", "Khử trùng trước lọc S1: bản bị bỏ phát trước che bản đạt S1", "bang_chung_vong2.txt: lệnh được chọn = []", "LỖI LOGIC", "đã sửa", "LỖI THẬT – ĐÃ SỬA (0 ca trên SYNTH; ảnh hưởng dữ liệu thật = HYPOTHESIS)", "chon_tin_hieu_lenh: lọc 16 rồi khử trùng", ["KD-DUP-GOLD"], PL, "FACT"),
    ("F27", "Harness REG-01 ghi JSON không strict", "kiem_thu_stage3.py:1041", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "allow_nan=False", ["KD-JSON"], "shadow_eval/kiem_thu_stage3.py", "FACT"),
    ("F28", "Adapter bỏ sót STEP khi st đổi cùng nến tạo/kết thúc/ARMED", "bang_chung_vong2.txt: 221 vi phạm (CREATED→END 185, CREATED→ARMED 35)", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "phát STEP trung gian; CREATED với st 0", ["KD-SM-ENGINE", "RP-03"], CH, "FACT"),
    ("F29", "NO_DATA trước và sau khi vào bị gộp chung ghi chú", "bang_chung_vong2.txt: INVALID_BAR cả hai", "GỘP TRẠNG THÁI", "đã tách", "LỖI THẬT – ĐÃ SỬA", "…_AFTER_FILL", ["KD-GOLD-R1-BADBAR", "KD-SM-TRADE", "KD-ORACLE-PROP"], MP, "FACT"),
    ("F30", "SIM-05 'Expected 0 khác / Actual khác 0 / PASS' là mâu thuẫn", "kiem_thu_shadow_eval.py:62: actual = f'khác {len(sai)}', assert not sai → 'khác 0' = 0 ca lệch", "NHÃN MƠ HỒ", "xác minh lại", "KHÔNG PHẢI LỖI (nhãn mơ hồ); đối xứng xác minh lại 0 lệch", "golden gương + 6.000 ca; nhãn mới 'so_ca_lech'", ["KD-MIRROR-GOLD", "KD-MIRROR-PROP", "SIM-05"], MP, "FACT"),
    ("F31", "R2 không chạy lại S1 khi RR tại giá vào không đạt", "G-R2-G: rr_entry 0,875 < 1,5 vẫn khớp", "CHƯA GHI RÕ", "ghi rõ + rr_entry", "QUY ƯỚC (ASSUMPTION) – chủ dự án quyết", "thêm rr_entry để phân tích", ["KD-GOLD-R2-G"], MP, "ASSUMPTION"),
    ("F32", "Lọc danh mục phụ thuộc thứ tự đầu vào khi trùng hoàn toàn (entry, emit_seq)", "bang_chung_vong2.txt: [a,b]→a, [b,a]→b", "LỖI", "đã sửa", "LỖI THẬT – ĐÃ SỬA", "khóa phụ signal_id", ["KD-OCC-GOLD", "KD-OCC-PROP", "KD-MUT-SRC"], MP, "FACT"),
    ("F33", "Hiện vật lịch sử ket_qua_truoc_sua.json chứa Infinity", "CS-01 cũ profit_factor: Infinity", "LỊCH SỬ", "giữ làm bằng chứng", "BẰNG CHỨNG F10 – không sửa", "danh sách lịch sử trong KD-JSON", ["KD-JSON"], "ket_qua_shadow_eval/ket_qua_truoc_sua.json", "FACT"),
    ("F34", "mo_hinh_token.py (công cụ cũ) ghi JSON không đặt allow_nan=False", "mo_hinh_token.py:49", "QUAN SÁT", "giữ nguyên (đầu ra hiện hữu hạn)", "KHÔNG ẢNH HƯỞNG hiện tại", "khuyến nghị dùng cong_token.py", ["KD-JSON"], "token_budget/mo_hinh_token.py", "RECOMMENDATION"),
    ("B-1", "Data Window chỉ giữ một phần sự kiện SHADOW (ô trống), không mã SU, không giá", "0.3.9 dòng 3624–3626, 3785, 3857", "THIẾT KẾ K.5", "không sửa Pine", "GIỚI HẠN – REPLAY-EQ BLOCKED", "chủ dự án quyết kênh xuất", ["KD-REPLAY-EQ"], P39, "FACT"),
    ("B-2", "f_srcList/f_srcPush không được gọi", "0.3.9 dòng 1795, 1787", "MÃ CHẾT", "không sửa Pine", "ỨNG VIÊN GIẢM TOKEN", "chủ dự án quyết", ["TG-01"], P39, "FACT"),
    ("B-3", "17 biến ghi mà không đọc", "token_gate.json", "ỨNG VIÊN", "không sửa Pine", "CẦN XÁC NHẬN TAY", "không tự xóa", ["TG-01"], P39, "HYPOTHESIS"),
    ("B-4", "Thể hiện SU-3 trùng khóa (IP-21) không phân biệt được qua sự kiện", "adapter mo_ho 249/40 seed", "IP-21 MỞ", "giữ", "GIỚI HẠN – thứ tự sự kiện trùng khóa không phải FACT", "khử trùng cấp tín hiệu", ["KD-DUP-PROP", "RP-03"], P39, "FACT"),
]
HD_ = ["ID", "Loại dòng", "Nội dung", "Evidence", "Tình trạng trước sửa", "Tình trạng hiện tại", "Kết luận", "Hành động", "Test xác minh", "Kết quả", "Phân loại", "File liên quan", "SHA-256 file liên quan"]
rows = []
for fid, nd, ev, tr, ht, kl, hd, tests, f, pl in F:
    if fid == "F19":                                       # kết quả lấy từ log kiểm manifest do dong_goi_v2.py ghi (không gán tay)
        lg = J("ket_qua_stage3", "log", "kiem_tra_manifest.txt")
        kq = ("PASS" if "KẾT LUẬN: ĐẠT" in open(lg, encoding="utf-8").read() else "FAIL") if os.path.exists(lg) else "NOT TESTED"
    else:
        kq = ket(tests)
    if fid in ("F22",):
        kq = "NOT TESTED"
    rows.append([fid, "FINDING", nd, ev, tr, ht, kl, hd, "; ".join(tests) or "—", kq, pl, f, sha(f)])
THAY = {"HD-01": "KD-HD-VALID; KD-HD-MUT", "E2E-01": "KD-SM-ENGINE; E2E-01 (Stage 3)", "DUP-01": "KD-DUP-GOLD; KD-DUP-PROP", "OT-05": "KD-GOLD-R1-BADBAR; KD-ORACLE-PROP",
        "OT-06": "KD-ORACLE-PROP; KD-SM-TRADE"}
for tid, x in CU_TRUOC.items():
    now = CU_NAY.get(tid, {}).get("result", "KHÔNG CHẠY")
    kl = "TÁI XÁC NHẬN" if now == x["result"] else ("LỖI THỜI – có test thay thế" if tid in THAY else "THAY ĐỔI – xem báo cáo")
    if tid == "DUP-01":
        kl = "LỖI THỜI (chạy nguyên trạng dừng tại đây vì thiếu emit_seq) – shim harness: " + now
    rows.append([f"CU:{tid}", "TEST BỘ CŨ (22)", x["mo_ta"][:160], "ket_qua_shadow_eval/ket_qua_truoc_sua.json", x["result"], now, kl, "chạy lại không sửa (REG-01)",
                 THAY.get(tid, tid), now, "FACT", "shadow_eval/kiem_thu_shadow_eval.py", sha("shadow_eval/kiem_thu_shadow_eval.py")])
for tid, x in S3.items():
    kl = "TÁI XÁC NHẬN" if x["status"] in ("PASS", "BLOCKED", "NOT TESTED") else ("LỖI THỜI – có test thay thế" if tid in THAY else "FAIL CHƯA PHÂN LOẠI")
    rows.append([f"S3:{tid}", "TEST STAGE 3 (88)", x["muc_tieu"][:160], "ket_qua_stage3/ket_qua_kiem_thu.json", "PASS (lần trước, trừ BLOCKED/NOT TESTED)", x["status"], kl,
                 "chạy lại không sửa (KD-REG-S3)", THAY.get(tid, tid), x["status"], "FACT", "shadow_eval/kiem_thu_stage3.py", sha("shadow_eval/kiem_thu_stage3.py")])
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(HD_); w.writerows(rows)
dem = {}
for r in rows:
    dem[(r[1], r[9])] = dem.get((r[1], r[9]), 0) + 1
print(OUT, len(rows), "dòng", dem)
