# -*- coding: utf-8 -*-
"""Sinh ATA_P3_STAGE3_TEST_REPORT.md (C) từ ket_qua_stage3/ket_qua_kiem_thu.json – mọi con số lấy từ file kết quả, không gõ tay."""
import json, os, sys
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
r = json.load(open(os.path.join(G, "ket_qua_stage3", "ket_qua_kiem_thu.json"), encoding="utf-8"))
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(G, "BAN_GIAO_STAGE3B", "ATA_P3_STAGE3_TEST_REPORT.md")
tt = r["tom_tat"]
L = ["# ATA P3 · STAGE 3 · BÁO CÁO KIỂM THỬ (C)", "",
     f"Sinh tự động từ `ket_qua_stage3/ket_qua_kiem_thu.json` (lần chạy này, không dùng kết quả cũ). Python {r['python']}, {r['thoi_gian_s']} giây.", "",
     f"**Tổng {r['so_test']} test: PASS {tt.get('PASS', 0)} · FAIL {tt.get('FAIL', 0)} · BLOCKED {tt.get('BLOCKED', 0)} · NOT TESTED {tt.get('NOT TESTED', 0)}** (đếm riêng từng loại; có FAIL → mã thoát 1).", "",
     f"Baseline sau lượt chạy: 0.3.8 `{r['baseline']['v038']}` · 0.3.9 `{r['baseline']['v039']}`", "",
     "Phiên bản module (SHA-256, 12 ký tự đầu): " + ", ".join(f"{k} `{v}`" for k, v in r["phien_ban_module"].items()), "",
     "Lệnh tái lập: `python3 shadow_eval/kiem_thu_stage3.py` (từ thư mục gốc gói). Metadata đầy đủ của từng test (input, expected, actual, evidence, nguồn, version, thời điểm, hash) nằm trong JSON/CSV.", ""]
nhom = []
for x in r["ket_qua"]:
    if x["nhom"] not in nhom:
        nhom.append(x["nhom"])
for n in nhom:
    xs = [x for x in r["ket_qua"] if x["nhom"] == n]
    d = {}
    for x in xs:
        d[x["status"]] = d.get(x["status"], 0) + 1
    L += [f"## {n} – " + ", ".join(f"{k} {v}" for k, v in d.items()), "", "| ID | Trạng thái | Mục tiêu | Thực tế (rút gọn) | ms | hash |", "|---|---|---|---|---|---|"]
    for x in xs:
        a = x["actual"] if isinstance(x["actual"], str) else json.dumps(x["actual"], ensure_ascii=False, default=str)
        a = a.replace("|", "/").replace("\n", " ")
        L.append(f"| {x['test_id']} | {x['status']} | {x['muc_tieu'].replace('|', '/')} | {a[:220]}{'…' if len(a) > 220 else ''} | {x['duration_ms']} | {x['hash']} |")
    L.append("")
L += ["## Ghi chú phân loại", "",
      "- BLOCKED và NOT TESTED được đếm riêng, không tính là PASS.",
      "- Test đột biến (MUT-*) PASS nghĩa là: khi thay hàm mới bằng hàm TRƯỚC SỬA, test tương ứng FAIL – chứng minh bộ test bắt được lỗi cũ.",
      "- REG-01: bộ test cũ không bị sửa; assertion lỗi thời được phân loại trong `kiem_thu_stage3.LOI_THOI` kèm test thay thế; kết quả chi tiết ở `ket_qua_stage3/hoi_quy_bo_cu_tren_module_moi.json`.",
      "- REG-02: bộ 0.3.9 chạy trên BẢN SAO cây thư mục (`/tmp/reg039`) vì script tái lập dựng lại 0.3.9 – không chạy trên thư mục baseline. T-01 là FAIL LỊCH SỬ (ước lượng token tuyến tính) đã bị compile thật của 0.3.9 bác bỏ; giữ nguyên, không sửa test.",
      "- Dữ liệu SYNTH chỉ kiểm cơ chế, không phải hiệu quả SU-3/SU-5."]
open(out, "w", encoding="utf-8").write("\n".join(L) + "\n")
print(out, tt)
