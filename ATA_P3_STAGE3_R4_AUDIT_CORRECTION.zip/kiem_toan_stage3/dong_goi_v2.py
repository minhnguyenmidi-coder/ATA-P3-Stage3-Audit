# -*- coding: utf-8 -*-
"""Đóng gói Stage 3 – Correction vòng 2: kiểm trước khi đóng (tồn tại, không rỗng, tham chiếu, trùng nội dung, baseline) → ma trận → manifest SHA-256
(không tự liệt kê chính nó) → ZIP. Sau đó tool khác (bên gọi) giải nén và kiểm sha256sum -c. python3 kiem_toan_stage3/dong_goi_v2.py <thư_mục_ra>"""
import hashlib, os, re, subprocess, sys, zipfile, datetime as dt
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs"
TEN = "ATA_P3_Stage3_Correction_R2"
THU_MUC = ["BAN_GIAO_STAGE3C", "BAN_GIAO_STAGE3B", "kiem_doc_lap", "shadow_eval", "token_budget", "kiem_toan_stage3", "ket_qua_stage3", "ket_qua_shadow_eval",
           "kiem_toan034a", "kiem_toan035", "kiem_toan039", "cong_tien_md6", "ket_qua039"]
BAT_BUOC = ["BAN_GIAO_STAGE3C/ATA_P3_STAGE3_CORRECTION_REPORT.md", "BAN_GIAO_STAGE3C/ATA_P3_STAGE3_FINDINGS_MATRIX.csv", "BAN_GIAO_STAGE3C/ATA_P3_STAGE3_TEST_REPORT.md",
            "BAN_GIAO_STAGE3C/ATA_P3_STAGE3_REPLAY_SCOPE.md", "kiem_doc_lap/oracle.py", "kiem_doc_lap/vector_vang.py", "kiem_doc_lap/chay_doc_lap.py",
            "ket_qua_stage3/doc_lap/ket_qua_doc_lap.json", "ket_qua_stage3/ket_qua_kiem_thu.json", "ket_qua_stage3/log/chay_doc_lap.log",
            "kiem_toan_stage3/bang_chung_vong2.txt", "shadow_eval/may_trang_thai.py"]
SHA = {"src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine": "79793fcf7d5530d8f507d9fe4cef3155f52a38306348dd2edb6634d3f8f8cf13",
       "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine": "2184d8926f6b7bef5efcdc9b2baf8425f14438383303e916e462504e9d87fdb0"}


def sha(p):
    return hashlib.sha256(open(os.path.join(G, p), "rb").read()).hexdigest()


def ds():
    out = []
    for d in THU_MUC:
        for root, dirs, files in os.walk(os.path.join(G, d)):
            dirs[:] = sorted(x for x in dirs if x != "__pycache__")
            out += [os.path.relpath(os.path.join(root, f), G) for f in sorted(files) if not f.endswith(".pyc") and not f.startswith("_tam_")]
    for d in sorted(x for x in os.listdir(G) if x.startswith("src0") and os.path.isdir(os.path.join(G, x))):
        out += [f"{d}/{f}" for f in sorted(os.listdir(os.path.join(G, d))) if f.endswith(".pine")]
    return sorted(set(out) - {"BAN_GIAO_STAGE3C/ATA_P3_STAGE3_MANIFEST_SHA256.txt"})      # manifest không tự liệt kê (F19)


def kiem_truoc(files):
    L, ok = [f"Kiểm manifest trước đóng gói – {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}"], True
    for f in BAT_BUOC:
        c = os.path.exists(os.path.join(G, f)) and os.path.getsize(os.path.join(G, f)) > 0
        L.append(f"  bắt buộc {'OK ' if c else 'THIẾU/RỖNG'} {f}"); ok &= c
    rong = [f for f in files if os.path.getsize(os.path.join(G, f)) == 0]
    L.append(f"  file rỗng: {rong or 'không'}"); ok &= not [f for f in rong if f.startswith(("BAN_GIAO_STAGE3C", "kiem_doc_lap"))]
    for f, h in SHA.items():
        c = sha(f) == h; L.append(f"  baseline {f}: {'KHỚP' if c else 'SAI'} {sha(f)}"); ok &= c
    thieu = []
    for f in [x for x in files if x.startswith("BAN_GIAO_STAGE3C/") and x.endswith(".md")]:
        for m in re.findall(r"`((?:shadow_eval|kiem_doc_lap|kiem_toan_stage3|ket_qua_stage3|token_budget)/[^`\s]+)`", open(os.path.join(G, f), encoding="utf-8").read()):
            if not os.path.exists(os.path.join(G, m)):
                thieu.append((f, m))
    L.append(f"  tham chiếu đường dẫn trong báo cáo bị thiếu: {thieu or 'không'}"); ok &= not thieu
    nhom = {}
    for f in files:
        nhom.setdefault(sha(f), []).append(f)
    trung = [v for v in nhom.values() if len(v) > 1]
    L.append(f"  nhóm file trùng nội dung (thông tin, không phải lỗi): {len(trung)}")
    L += [f"    {v}" for v in trung[:20]]
    L.append(f"  đường dẫn trùng: {len(files) - len(set(files))}")
    L.append("KẾT LUẬN: ĐẠT" if ok else "KẾT LUẬN: KHÔNG ĐẠT")
    return ok, "\n".join(L) + "\n"


def main():
    os.makedirs(OUT, exist_ok=True)
    files = ds()
    ok, log = kiem_truoc(files)
    open(os.path.join(G, "ket_qua_stage3", "log", "kiem_tra_manifest.txt"), "w", encoding="utf-8").write(log)
    print(log)
    if not ok:
        sys.exit(2)
    subprocess.run([sys.executable, os.path.join(G, "kiem_toan_stage3", "tao_ma_tran.py")], check=True)
    files = ds()
    man = "".join(f"{sha(f)}  ./{f}\n" for f in files)
    p_man = os.path.join(G, "BAN_GIAO_STAGE3C", "ATA_P3_STAGE3_MANIFEST_SHA256.txt")
    open(p_man, "w", encoding="utf-8").write(man)                       # manifest không chứa dòng của chính nó
    p_zip = os.path.join(OUT, TEN + ".zip")
    with zipfile.ZipFile(p_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(os.path.join(G, f), f)
        z.write(p_man, "BAN_GIAO_STAGE3C/ATA_P3_STAGE3_MANIFEST_SHA256.txt")
        z.writestr("ATA_P3_STAGE3_MANIFEST_SHA256.txt", man)
    print(p_zip, hashlib.sha256(open(p_zip, "rb").read()).hexdigest(), len(files), "file trong manifest")


if __name__ == "__main__":
    main()
