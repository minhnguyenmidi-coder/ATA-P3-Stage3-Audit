# -*- coding: utf-8 -*-
"""Bằng chứng lỗi trên bản Stage 3 TRƯỚC KHI SỬA (shadow_eval/_truoc_sua). Mỗi mục in: mã finding, đầu vào, kết quả quan sát, vì sao sai.
Chạy: python3 kiem_toan_stage3/bang_chung_truoc_sua.py → kiem_toan_stage3/bang_chung_truoc_sua.json. Không sửa gì."""
import json, math, os, sys, random
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(G, "shadow_eval", "_truoc_sua"))
import mo_phong_lenh as MP, chi_so as CS, hop_dong as HD  # noqa: E402
O = []
def ghi(fid, mo, inp, obs, sai):
    O.append(dict(finding=fid, mo_ta=mo, input=inp, quan_sat=obs, vi_sao_sai=sai)); print(fid, "|", obs)
def B(rows, t0=0):
    return [dict(t=t0 + 300000 * i, o=o, h=h, l=l, c=c) for i, (o, h, l, c) in enumerate(rows)]
# F1
tr = [dict(symbol="XAUUSD", setup="SU5", entry_ts_ms=1, exit_ts_ms=None, outcome="NO_FILL"), dict(symbol="XAUUSD", setup="SU5", entry_ts_ms=100, exit_ts_ms=200, outcome="TP1"),
      dict(symbol="XAUUSD", setup="SU5", entry_ts_ms=300, exit_ts_ms=400, outcome="SL")]
g, n = MP.khong_chong(tr)
ghi("F1", "NO_FILL (exit None) chặn khóa (symbol, setup) vĩnh viễn trong khong_chong", "NO_FILL lúc 1, TP1 lúc 100, SL lúc 300", dict(giu=len(g), bo=n), "lệnh NO_FILL không chiếm vị thế; 2 lệnh sau phải được giữ")
# F2
s = [dict(signal_id="ffff", trigger_ts_ms=5, dup_key="k", phat_ra=1), dict(signal_id="0000", trigger_ts_ms=5, dup_key="k", phat_ra=2)]
g, n = MP.khu_trung(s)
ghi("F2", "khu_trung giữ bản theo thứ tự băm signal_id, không theo thứ tự phát ra", "2 tín hiệu cùng dup_key; bản phát ra trước có id 'ffff'", g[0]["phat_ra"], "phải giữ bản phát ra trước (phat_ra=1)")
# F3
sig = dict(dir=1, p_ref=2000.0, sl=1995.0, tp1=2010.0)
r = MP.mo_phong(sig, B([(2000, 2001, 1999, 2000), (2000, 2012, 1994, 2001)]), 0, MP.Cfg(same_bar="tp_first"))
ghi("F3", "Biến thể tp_first: nến chạm cả SL và TP1 nhưng MAE không cập nhật", "Low 1994 < SL 1995", dict(outcome=r["outcome"], mae=r["mae_r"]), "giá đã chạm SL trong nến → MAE phải ≤ −1 (nhất quán với nhánh SL)")
# F4
r = MP.mo_phong(sig, B([(2000, 2001, 1999, 2000), (2015, 2016, 2014, 2015), (2015, 2016, 2014, 2015)]), 0, MP.Cfg(entry="next_open"))
ghi("F4", "R2: Open nến kế đã vượt TP1 → vẫn khớp, ra kết cục không hợp lệ", "Open 2015 > TP1 2010", dict(outcome=r["outcome"], r=r["r_gross"], risk=r["risk"]), "TP đã bị vượt trước khi vào – lệnh không còn hợp lệ, phải là NO_FILL có lý do")
# F5
r = MP.mo_phong(dict(dir=1, p_ref=2000.0, sl=2001.0, tp1=2010.0), B([(2000, 2001, 1999, 2000), (2000, 2001, 1999, 2000)]), 0)
ghi("F5", "R1: SL nằm sai phía (rủi ro ≤ 0) → risk 1e-12, R vô nghĩa", "BUY SL 2001 > P_ref 2000", dict(outcome=r["outcome"], risk=r["risk"]), "phải là trạng thái INVALID, risk = null")
# F6
r = MP.mo_phong(sig, B([(2000, 2001, 1999, 2000)]), 0, MP.Cfg(entry="next_open"))
ghi("F6", "R2: không có nến kế tiếp → gán NO_FILL (lẫn với gap qua SL)", "trigger ở nến cuối", r["outcome"], "đây là thiếu dữ liệu, không phải không khớp")
# F7
bb = B([(2000, 2001, 1999, 2000), (2000, 2002, 1999, 2001), (2001, 2003, 2000, 2002)]); bb[2]["t"] += 3600000 * 10
r = MP.mo_phong(sig, bb, 0, MP.Cfg(max_bars=5))
ghi("F7", "Không phát hiện khoảng trống thời gian giữa các nến", "nến 3 cách nến 2 hơn 10 giờ", sorted(r.keys()), "không có trường nào báo khoảng trống dữ liệu")
# F8
r = MP.mo_phong(sig, B([(2000, 2001, 1999, 2000), (2000, 1990, 2010, 2001)]), 0)
ghi("F8", "Không kiểm nến hỏng (High < Low)", "High 1990, Low 2010", dict(outcome=r["outcome"], r=r["r_gross"]), "nến hỏng phải dừng với NO_DATA/INVALID_BAR")
# F9
idx = {B_: (int(0.025 * B_), int(0.975 * B_) - 1, B_ - 1 - int(0.025 * B_)) for B_ in (10, 30, 50, 70, 2000)}
ghi("F9", "Chỉ số phân vị bootstrap không đối xứng khi 0,025·B không nguyên", "B = 10, 30, 50, 70, 2000", {k: dict(duoi=v[0], tren=v[1], tren_doi_xung=v[2]) for k, v in idx.items()}, "trên ≠ B−1−dưới với B=10,30,50,70")
# F10
h = CS.hieu_qua([dict(symbol="XAUUSD", setup="SU5", outcome="TP1", r_net=2.0, mfe_r=2, mae_r=0, bars_held=1, same_bar_conflict=False)] * 3)
try:
    json.dumps(h[("XAUUSD", "SU5")], allow_nan=False); js = "OK"
except ValueError as e:
    js = "LỖI JSON: " + str(e)
ghi("F10", "Profit factor = inf khi không có lệnh thua → JSON không hợp lệ", "3 lệnh thắng", dict(pf=str(h[("XAUUSD", "SU5")]["profit_factor"]), json=js), "JSON chuẩn không có Infinity; phải null + trạng thái")
# F10b ties
h = CS.hieu_qua([dict(symbol="XAUUSD", setup="SU5", outcome="TIMEOUT", r_net=0.0, mfe_r=0, mae_r=0, bars_held=1, same_bar_conflict=False)] * 2 + [dict(symbol="XAUUSD", setup="SU5", outcome="TP1", r_net=1.0, mfe_r=1, mae_r=0, bars_held=1, same_bar_conflict=False)])
ghi("F10b", "Lệnh R = 0 bị tính là thua (r ≤ 0)", "R = 0, 0, +1", dict(win_rate=h[("XAUUSD", "SU5")]["win_rate"], pf=str(h[("XAUUSD", "SU5")]["profit_factor"])), "hòa vốn phải tách riêng")
# F11
f = CS.phieu([], [dict(symbol="XAUUSD", setup="SU3", reason=16, dup_key="a")] * 3)
ghi("F11", "Trường 'trung' của phễu không bao giờ được tính", "3 tín hiệu cùng dup_key", f[("XAUUSD", "SU3")]["trung"], "phải = 2")
# F12-F16
t = dict(schema_version="1.0", signal_id="s", sim_rule="r", cost_model="c", entry_ts_ms=1, entry_price=float("nan"), risk=float("inf"), outcome="TP1", exit_ts_ms=0, exit_price=1.0,
         r_gross=float("nan"), r_net=5.0, mfe_r=0.0, mae_r=0.0, bars_held=-3, same_bar_conflict=False, gap_exit=False)
ghi("F12", "Hợp đồng không chặn NaN/Infinity, bars_held âm, exit trước entry, R ngoài [MAE, MFE]", "TRADE có NaN, inf, exit_ts < entry_ts, bars_held −3", HD.kiem(t, HD.TRADES), "phải báo lỗi")
s_ = dict(schema_version="1.0", engine_version="0.3.9", source="SYNTH", symbol="XAUUSD", setup="SU5", setup_id="a", signal_id="b", dir=1, trigger_ts="2026-01-01T00:00:00Z",
          trigger_ts_ms=1767323100000, p_ref=2000.0, sl=2010.0, tp1=1990.0, rr=None, reason=16, perm_reg=None, perm_vol=None, dup_key="x")
ghi("F13", "Không kiểm trigger_ts ↔ trigger_ts_ms, hình học SL/TP theo chiều", "trigger_ts lệch 1 ngày; BUY có SL trên, TP dưới giá", HD.kiem(s_, HD.SIGNALS), "phải báo lỗi")
s2 = dict(s_, trigger_ts="2026-13-45T99:99:99Z")
ghi("F14", "trigger_ts không được kiểm định dạng / ngày hợp lệ", "trigger_ts = 2026-13-45T99:99:99Z", HD.kiem(s2, HD.SIGNALS), "phải báo lỗi")
ghi("F15", "Không có kiểm cấp bảng: trùng ID, thứ tự thời gian, liên kết SIGNALS↔EVENTS↔TRADES", "—", "hop_dong.py chỉ có kiem(rec, schema) theo từng bản ghi", "thiếu hoàn toàn")
json.dump(O, open(os.path.join(G, "kiem_toan_stage3", "bang_chung_truoc_sua.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
