# -*- coding: utf-8 -*-
"""Đóng gói Stage 3 – Audit Correction: ZIP (I) + AUDIT CAPSULE văn bản thuần một file (H).
SHA256SUMS.txt KHÔNG chứa dòng của chính nó (sửa F19). Chạy từ bất kỳ đâu: python3 kiem_toan_stage3/dong_goi.py <thư_mục_ra>"""
import datetime as dt, hashlib, json, os, sys, zipfile
G = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs"
TEN = "ATA_P3_Stage3_Audit_Correction"
THU_MUC = ["BAN_GIAO_STAGE3B", "shadow_eval", "token_budget", "kiem_toan_stage3", "ket_qua_stage3", "ket_qua_shadow_eval", "kiem_toan034a", "kiem_toan035",
           "kiem_toan039", "cong_tien_md6", "ket_qua039"]
FILE_LE = ["src033/ATA_P3_Build_0.3.3_Candidate_Indicator.pine", "src033/ATA_P3_Build_0.3.3a_Candidate_Indicator.pine", "src037/ATA_P3_Build_0.3.7_Candidate_Indicator.pine",
           "src038/ATA_P3_Build_0.3.8_Candidate_Indicator.pine", "src039/ATA_P3_Build_0.3.9_Candidate_Indicator.pine"]


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def ds_file():
    out = []
    for d in THU_MUC:
        for root, dirs, files in os.walk(os.path.join(G, d)):
            dirs[:] = sorted(x for x in dirs if x != "__pycache__")
            for f in sorted(files):
                if f.endswith((".pyc",)) or f.startswith("_tam_"):
                    continue
                out.append(os.path.relpath(os.path.join(root, f), G))
    # mọi source Pine lịch sử (khung kiểm thử đọc chúng khi import – cần để tái lập replay); chỉ đọc
    for d in sorted(x for x in os.listdir(G) if x.startswith("src0") and os.path.isdir(os.path.join(G, x))):
        for f in sorted(os.listdir(os.path.join(G, d))):
            if f.endswith(".pine"):
                out.append(f"{d}/{f}")
    return sorted(set(out))


def capsule(files, sums):
    kq = json.load(open(os.path.join(G, "ket_qua_stage3", "ket_qua_kiem_thu.json"), encoding="utf-8"))
    tg = json.load(open(os.path.join(G, "ket_qua_stage3", "token_gate", "token_gate.json"), encoding="utf-8"))
    L = ["=" * 100, "ATA P3 · STAGE 3 · AUDIT CORRECTION & VERIFICATION · AUDIT CAPSULE (văn bản thuần, một file)", "=" * 100,
         f"Tạo lúc (UTC): {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}",
         "Mục đích: chuyển toàn bộ bằng chứng cho kiểm toán độc lập khi không gửi được ZIP. Mọi nội dung trích bằng code từ file trong gói.", "",
         "PHẦN H.1 – BASELINE (chỉ đọc, không sửa)",
         f"  0.3.8  {sha(os.path.join(G, FILE_LE[3]))}", f"  0.3.9  {sha(os.path.join(G, FILE_LE[4]))}", "",
         "PHẦN H.2 – TRẠNG THÁI KIỂM THỬ (lần chạy này)",
         f"  {kq['tom_tat']}  · tổng {kq['so_test']} · {kq['thoi_gian_s']} s · Python {kq['python']}"]
    for x in kq["ket_qua"]:
        L.append(f"  [{x['status']:10}] {x['test_id']:14} {x['muc_tieu'][:150]}")
    L += ["", "PHẦN H.3 – TOKEN GATE (ESTIMATE, không phải token thật)",
          f"  mức: {tg['uoc_luong']['muc']} · khoảng 0.3.9: {tg['uoc_luong']['khoang_uoc_luong']} · dư địa: {tg['uoc_luong']['du_dia_khoang']}",
          f"  mô hình nhất quán: {tg['uoc_luong']['mo_hinh_nhat_quan']}", f"  hàm không gọi: {tg['phan_tich_candidate']['ham_khong_goi']}", "",
          "PHẦN H.4 – CÂU HỎI MỞ CHO CHỦ DỰ ÁN (không tự quyết)",
          "  Q-S3-1  Nguồn sự kiện cho đánh giá thị trường thật: (a) xây replay toàn script từ OHLCV, hay (b) xuất sự kiện SHADOW từ TradingView (đụng K.5 + token)?",
          "  Q-S3-2  Cung cấp dữ liệu M5 lịch sử XAUUSD/BTCUSD (TV export hoặc MT5 Exness + độ lệch giờ máy chủ) cho bước 1–3.",
          "  Q-S3-3  Lịch nghỉ thật của Exness cho XAUUSD (để thay lịch giả định khi phân loại khoảng trống).",
          "  Q-S3-4  Quy ước 'vào đúng nến thoát lệnh trước → bỏ' (lọc danh mục) – giữ bảo thủ hay đổi?",
          "  Q-S3-5  Có cho phép gỡ mã chết f_srcList/f_srcPush và biến không đọc ở Build sau để lấy lại token? (hiện chỉ ghi nhận)",
          "  IP mở giữ nguyên: IP-1…30, OP-1…3, TK-1 (không đóng IP nào trong lượt này).", "",
          "PHẦN H.5 – DANH SÁCH FILE VÀ SHA-256 (SHA256SUMS.txt không tự liệt kê chính nó)"]
    L += [f"  {sums[f]}  {f}" for f in files]
    L += ["", "PHẦN H.6 – BÁO CÁO (nguyên văn)"]
    for f in sorted(x for x in files if x.startswith("BAN_GIAO_STAGE3B/") and x.endswith(".md")):
        L += ["", "-" * 100, f"FILE: {f}  SHA-256 {sums[f]}", "-" * 100, open(os.path.join(G, f), encoding="utf-8").read()]
    L += ["", "PHẦN H.7 – MÃ NGUỒN MODULE STAGE 3 (nguyên văn)"]
    for f in ["shadow_eval/mo_phong_lenh.py", "shadow_eval/hop_dong.py", "shadow_eval/chi_so.py", "shadow_eval/chuan_hoa.py", "shadow_eval/du_lieu.py",
              "shadow_eval/pipeline.py", "token_budget/cong_token.py", "token_budget/quan_sat_compile.json", "shadow_eval/kiem_thu_stage3.py", "kiem_toan_stage3/bang_chung_truoc_sua.py"]:
        L += ["", "-" * 100, f"FILE: {f}  SHA-256 {sums[f]}", "-" * 100, open(os.path.join(G, f), encoding="utf-8").read()]
    L += ["", "PHẦN H.8 – BẰNG CHỨNG LỖI TRƯỚC SỬA (bang_chung_truoc_sua.json)", open(os.path.join(G, "kiem_toan_stage3", "bang_chung_truoc_sua.json"), encoding="utf-8").read(),
          "", "=" * 100, "HẾT CAPSULE", "=" * 100]
    return "\n".join(L) + "\n"


def main():
    os.makedirs(OUT, exist_ok=True)
    files = ds_file()
    sums = {f: sha(os.path.join(G, f)) for f in files}
    cap = capsule(files, sums)
    p_cap = os.path.join(OUT, "ATA_P3_STAGE3_AUDIT_CAPSULE.txt")
    open(p_cap, "w", encoding="utf-8").write(cap)
    sums_txt = "".join(f"{sums[f]}  ./{f}\n" for f in files) + f"{sha(p_cap)}  ./ATA_P3_STAGE3_AUDIT_CAPSULE.txt\n"
    p_zip = os.path.join(OUT, TEN + ".zip")
    with zipfile.ZipFile(p_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(os.path.join(G, f), f)
        z.write(p_cap, "ATA_P3_STAGE3_AUDIT_CAPSULE.txt")
        z.writestr("SHA256SUMS.txt", sums_txt)
    print(p_zip, sha(p_zip), len(files) + 2, "file"); print(p_cap, sha(p_cap))


if __name__ == "__main__":
    main()
